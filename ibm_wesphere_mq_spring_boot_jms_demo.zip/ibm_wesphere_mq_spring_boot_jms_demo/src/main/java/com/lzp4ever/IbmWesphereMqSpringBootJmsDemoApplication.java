package com.lzp4ever;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IbmWesphereMqSpringBootJmsDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(IbmWesphereMqSpringBootJmsDemoApplication.class, args);
    }
}
