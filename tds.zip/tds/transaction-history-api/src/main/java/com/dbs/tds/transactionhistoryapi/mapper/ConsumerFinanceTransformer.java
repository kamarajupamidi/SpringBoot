package com.dbs.tds.transactionhistoryapi.mapper;

import java.util.ArrayList;
import java.util.List;

import com.dbs.moneythor.dto.CustomField;
import com.dbs.moneythor.dto.MoneyThorTransactionResponse;
import com.dbs.moneythor.dto.MoneyThorTransactionUpdateRequest;
import com.dbs.schemas.soi.common._4_1.CommonRq;
import com.dbs.schemas.soi.common._4_1.CommonRs;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.AdministerTransaction;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.AdministerTransactionResponse;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.Result;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.ResultCode;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.TransactionUpdate;
import com.dbs.tds.dto.TransactionNotification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Component;

import static com.dbs.tds.transactionhistoryapi.constant.TransactionUpdateConstants.CATEGORY;
import static com.dbs.tds.transactionhistoryapi.constant.TransactionUpdateConstants.FAILURE_MSG;
import static com.dbs.tds.transactionhistoryapi.constant.TransactionUpdateConstants.NOTE;
import static com.dbs.tds.transactionhistoryapi.constant.TransactionUpdateConstants.PHOTO;
import static com.dbs.tds.transactionhistoryapi.constant.TransactionUpdateConstants.SUCCESS_MSG;

/***
 *
 * This class is used for converting the Consumer Finance service request objects to TDS
 * request objects
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Component
public class ConsumerFinanceTransformer {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(ConsumerFinanceTransformer.class);

	/**
	 * This method is used to transform Soap Request instance to Money Thor Request
	 * instance.
	 *
	 * @param administerTransaction : {@link AdministerTransaction}
	 * @param transactionNotification : {@link TransactionNotification}
	 * @return {@link MoneyThorTransactionUpdateRequest}
	 */
	public MoneyThorTransactionUpdateRequest transformFromSoapToMT(AdministerTransaction administerTransaction,
			TransactionNotification transactionNotification) {
		MoneyThorTransactionUpdateRequest moneyThorTransactionUpdateRequest = new MoneyThorTransactionUpdateRequest();
		List<CustomField> customFields = new ArrayList<>();
		TransactionUpdate transactionUpdate = administerTransaction.getTransactionUpdate();

		if (transactionUpdate.getCategoryName() != null) {
			CustomField customField = new CustomField();
			customField.setName(CATEGORY.value());
			customField.setValue(transactionUpdate.getCategoryName());
			customFields.add(customField);
		}

		if (transactionUpdate.getPhoto() != null) {
			CustomField customField = new CustomField();
			customField.setName(PHOTO.value());
			customField.setValue(transactionUpdate.getPhoto());
			customFields.add(customField);
		}

		if (transactionUpdate.getNotes() != null) {
			CustomField customField = new CustomField();
			customField.setName(NOTE.value());
			customField.setValue(transactionUpdate.getNotes());
			customFields.add(customField);
		}

		moneyThorTransactionUpdateRequest.setKey(transactionNotification.getExtTranId());
		moneyThorTransactionUpdateRequest.setCustomFields(customFields);
		LOGGER.info("Transformed SOAP to MoneyThor : moneyThorRequest={}", moneyThorTransactionUpdateRequest);
		return moneyThorTransactionUpdateRequest;
	}

	/**
	 * This method is used transform the Error response coming from TDS DB to the response
	 * instance which will be send further to Kony.
	 *
	 * @param administerTransaction : {@link AdministerTransaction}
	 * @param transactionNotification : {@link TransactionNotification}
	 *
	 * @return {@link AdministerTransactionResponse}
	 */
	public AdministerTransactionResponse transformErrorToSoap(AdministerTransaction administerTransaction,
			TransactionNotification transactionNotification) {
		AdministerTransactionResponse administerTransactionResponse = new AdministerTransactionResponse();

		administerTransactionResponse.setCommonRs(getCommonRs(administerTransaction.getCommonRq()));
		administerTransactionResponse.setResult(getResult(transactionNotification.getErrorMessage(), ResultCode.ERROR));

		LOGGER.info("Response With Error from SOI Service : {}", administerTransactionResponse);

		return administerTransactionResponse;
	}

	/**
	 * This method is used to transform the response coming from Moneythor to the response
	 * instance which will be send further to Kony.
	 *
	 * @param administerTransaction : {@link AdministerTransaction}
	 * @param moneyThorTransactionResponse : {@link MoneyThorTransactionResponse}
	 *
	 * @return {@link AdministerTransactionResponse}
	 */
	public AdministerTransactionResponse transformFromMTToSoap(AdministerTransaction administerTransaction,
			MoneyThorTransactionResponse moneyThorTransactionResponse) {
		AdministerTransactionResponse administerTransactionResponse = new AdministerTransactionResponse();
		CommonRs commonRs = getCommonRs(administerTransaction.getCommonRq());

		String message = "";
		ResultCode code;
		if (moneyThorTransactionResponse.getHeader().getSuccess()) {
			LOGGER.info("Transaction Update Success at Moneythor.");
			message = SUCCESS_MSG.value();
			code = ResultCode.OK;
		}
		else {
			LOGGER.info("Transaction Update Failed at Moneythor.");
			message = FAILURE_MSG.value();
			code = ResultCode.ERROR;
		}
		Result result = getResult(message, code);

		administerTransactionResponse.setCommonRs(commonRs);
		administerTransactionResponse.setResult(result);

		LOGGER.info("Response for SOI Service : {}", administerTransactionResponse);

		return administerTransactionResponse;
	}

	/***
	 * This method is used to build {@link CommonRs} object.\
	 *
	 * @param commonRq {@link CommonRq}
	 * @return {@link CommonRs}
	 */
	private CommonRs getCommonRs(CommonRq commonRq) {
		CommonRs commonRs = new CommonRs();
		commonRs.setOrgCode(commonRq.getOrgCode());
		commonRs.setRqSysRef(commonRq.getRqSysRef());
		return commonRs;
	}

	/***
	 * This method is used to build {@link Result} object.
	 *
	 * @param message {@link String}
	 * @param code {@link String}
	 * @return {@link Result}
	 */
	private Result getResult(String message, ResultCode code) {
		Result result = new Result();
		result.setMessage(message);
		result.setCode(code);
		return result;
	}
}
