/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: TransactionConstantFields.java
 * Author: DBS Asia Hub 2
 * Date: Oct 12, 2017
 */
package com.dbs.tds.transactionhistoryapi.constant;

/**
 * This class is used as enumeration for collection of constant values which will be used
 * for transaction read functionality.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public enum TransactionConstantFields {
	C("C"),
	D("D"),
	CR("CR"),
	DR("DR"),
	ASC("ASC"),
	DESC("DESC"),
	DEFAULT_SORT_ORDER_DESC("DESC"),
	TDSIN("TDSIN");

	/**
	 * This field is used to store value for value which is of type {@link String }.
	 */
	private String value;

	/**
	 * This is used to initialize the enum property.
	 *
	 * @param value : {@link String}
	 */
	private TransactionConstantFields(String value) {
		this.value = value;
	}

	/**
	 * This method is used to get property value of class {@link TransactionConstantFields
	 * }.
	 *
	 * @return value : {@link String }
	 */
	public String value() {
		return this.value;
	}

}
