package com.dbs.tds.transactionhistoryapi.filter;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import com.dbs.tds.constants.AppIdentifiers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import static com.dbs.tds.constants.AppConstants.APP_REGION;
import static com.dbs.tds.constants.Countries.IN;
import static com.dbs.tds.constants.LoggingConstants.CLIENT_IP;
import static com.dbs.tds.constants.LoggingConstants.HOSTNAME;
import static com.dbs.tds.constants.LoggingConstants.ID;
import static com.dbs.tds.constants.LoggingConstants.INTERFACE_MAP;
import static com.dbs.tds.constants.LoggingConstants.MSG_UID;
import static com.dbs.tds.constants.LoggingConstants.ORG_CODE;
import static com.dbs.tds.constants.LoggingConstants.REQUEST_TYPE;
import static com.dbs.tds.constants.LoggingConstants.RESPONSE_TIME;
import static com.dbs.tds.constants.LoggingConstants.SERVICE_ID;
import static com.dbs.tds.constants.LoggingConstants.SERVICE_NAME;

/**
 * This class is used as the filter for the incoming requests, as it will filter the
 * request and sets the required properties used for Logging.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public class LoggingFilter implements Filter {

	/**
	 * This field is used to store value for ELKLOGGER which is of type {@link Logger }.
	 */
	private static final Logger ELKLOGGER = LoggerFactory.getLogger("elklogger");

	/**
	 * This method is overridden for configuring the initialization.
	 *
	 * @param transactionHistoryFilterConfig : {@link FilterConfig}
	 * @throws ServletException
	 */
	@Override
	public void init(FilterConfig transactionHistoryFilterConfig) throws ServletException {
		// No init parameters required to set.
	}

	/**
	 * This method is used to filter every request and set the Logging properties.
	 *
	 * @param transactionHistoryServletRequest : {@link ServletRequest}
	 * @param transactionHistoryServletResponse : {@link ServletResponse}
	 * @param transactionHistoryFilterChain : {@link FilterChain}
	 *
	 * @throws IOException : {@link IOException}
	 * @throws ServletException : {@link ServletException}
	 */
	@Override
	public void doFilter(ServletRequest transactionHistoryServletRequest,
			ServletResponse transactionHistoryServletResponse, FilterChain transactionHistoryFilterChain)
					throws IOException, ServletException {
		long startTime = System.currentTimeMillis();

		MDC.put(SERVICE_NAME.value(), transactionHistoryServletRequest.getServletContext().getContextPath());
		MDC.put(ORG_CODE.value(), ID.value());
		MDC.put(AppIdentifiers.APP_CODE.name(), AppIdentifiers.APP_CODE.value());
		MDC.put(APP_REGION.value(), IN.name());
		MDC.put(HOSTNAME.value(), transactionHistoryServletRequest.getServerName());
		MDC.put(SERVICE_ID.value(), "tdshistoryapi");
		MDC.put(INTERFACE_MAP.value(), "kony_to_tds");
		MDC.put(REQUEST_TYPE.value(), "individual");
		MDC.put(MSG_UID.value(), UUID.randomUUID().toString());
		MDC.put(CLIENT_IP.value(), getClientIpForTransactionHistory(transactionHistoryServletRequest));
		transactionHistoryFilterChain.doFilter(transactionHistoryServletRequest, transactionHistoryServletResponse);
		long elapsed = System.currentTimeMillis() - startTime;
		MDC.put(RESPONSE_TIME.value(), String.valueOf(elapsed));
		ELKLOGGER.info("");

	}

	/**
	 * This method is used to get client ip address from HTTP Request. Note that incase
	 * client is behind a proxy server then we grab the first IP from X-FORWARDED_FOR http
	 * header.filter every request and set the Logging properties.
	 *
	 * @param transactionHistoryServletRequest : {@link ServletRequest}
	 */
	private static String getClientIpForTransactionHistory(ServletRequest transactionHistoryServletRequest) {
		String transactionHistoryRemoteAddress = "";
		HttpServletRequest transactionHistoryHttpRequest = (HttpServletRequest) transactionHistoryServletRequest;
		if (transactionHistoryHttpRequest != null) {
			transactionHistoryRemoteAddress = transactionHistoryHttpRequest.getHeader("X-FORWARDED-FOR");
			if (transactionHistoryRemoteAddress == null || "".equals(transactionHistoryRemoteAddress)) {
				transactionHistoryRemoteAddress = transactionHistoryHttpRequest.getRemoteAddr();
			}
			else {
				String[] transactionHistoryIPs = transactionHistoryRemoteAddress.split(",");
				transactionHistoryRemoteAddress = transactionHistoryIPs[0];
			}
		}

		return transactionHistoryRemoteAddress;
	}

	@Override
	public void destroy() {
		// No destroy definition available
	}
}
