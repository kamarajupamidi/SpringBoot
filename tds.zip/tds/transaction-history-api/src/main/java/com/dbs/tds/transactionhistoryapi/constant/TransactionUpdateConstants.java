/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: TransactionUpdateConstants.java
 * Author: DBS Asia Hub 2
 * Date: Oct 30, 2017
 */
package com.dbs.tds.transactionhistoryapi.constant;

/**
 * This class is used as enumeration for collection of constant values which will be used
 * for Transaction Update functionality.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public enum TransactionUpdateConstants {

	SUCCESS_MSG("Transaction Update Successful"),
	FAILURE_MSG("Transaction Update Failed."),
	CATEGORY("category"),
	PHOTO("photo"),
	NOTE("note");

	/**
	 * This field is used to store value for value which is of type {@link String }.
	 */
	private String value;

	/**
	 * This is used to initialize the enum property.
	 *
	 * @param value : {@link String}
	 */
	private TransactionUpdateConstants(String value) {
		this.value = value;
	}

	/**
	 * This method is used to return the value of the enum type.
	 *
	 * @return {@link String}
	 */
	public String value() {
		return this.value;
	}

}
