package com.dbs.tds.transactionhistoryapi.service;

import java.util.List;

import javax.xml.ws.Holder;

import com.dbs.schemas.soi.common._4_0.ExtendedHeader;
import com.dbs.schemas.soi.common._4_0.InfoWarn;
import com.dbs.schemas.soi.common._4_0.MsgDetl;
import com.dbs.schemas.soi.common._4_0.Trace;
import com.dbs.schemas.soi.wsdl.positionkeeping.v1_1.Fault;
import com.dbs.schemas.soi.wsdl.positionkeeping.v1_1.PortType;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.AdministerSocialPosition;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.AdministerSocialPositionResponse;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.FundSetlAdd;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.FundSetlAddResponse;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.PositionKeepingTranHistInq;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.PositionKeepingTranHistInqResponse;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrieveDepositAcctTran;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrieveDepositAcctTranResponse;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePendingCollectRequests;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePendingCollectRequestsResponse;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePendingTransactionDetailsReq;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePendingTransactionsResponse;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePeriodicBalance;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePeriodicBalanceResponse;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePersonalFinanceTrans;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePersonalFinanceTransResponse;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrieveTransactionDetails;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrieveTransactionDetailsResponse;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrieveUPITransactions;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrieveUPITransactionsResponse;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.TranFDHistInq;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.TranFDHistInqResponse;
import com.dbs.tds.dto.TransactionHistoryRequest;
import com.dbs.tds.dto.TransactionHistoryResponse;
import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistoryapi.mapper.TransactionRequestTransformer;
import com.dbs.tds.transactionhistoryapi.mapper.TransactionResponseTransformer;
import org.slf4j.MDC;

import org.springframework.stereotype.Service;

import static com.dbs.tds.constants.LoggingConstants.FUNCTIONAL_MAP;

@Service
@javax.jws.WebService(serviceName = "PositionKeeping", portName = "HTTP", targetNamespace = "http://schemas.dbs.com/soi/wsdl/PositionKeeping/v1_1", wsdlLocation = "classpath:wsdl/PositionKeeping_v1_1.wsdl", endpointInterface = "com.dbs.schemas.soi.wsdl.positionkeeping.v1_1.PortType")
public class PositionKeepingService implements PortType {

	private TransactionService transactionService;

	private TransactionRequestTransformer transactionRequestTransformer;

	private PositionKeepingResponseHeaderService positionKeepingResponseHeaderService;

	private TransactionResponseTransformer transactionResponseTransformer;

	public PositionKeepingService(TransactionService transactionService,
			TransactionResponseTransformer transactionResponseTransformer,
			TransactionRequestTransformer transactionRequestTransformer,
			PositionKeepingResponseHeaderService positionKeepingResponseHeaderServic) {

		this.transactionService = transactionService;
		this.transactionResponseTransformer = transactionResponseTransformer;
		this.transactionRequestTransformer = transactionRequestTransformer;
		this.positionKeepingResponseHeaderService = positionKeepingResponseHeaderServic;
	}

	@Override
	public AdministerSocialPositionResponse administerSocialPosition(
			AdministerSocialPosition administerSocialPositionRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "PositionKeeping_Administer_Social_Position");
		return null;
	}

	@Override
	public FundSetlAddResponse administerPosition(FundSetlAdd fundSetlAddRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "PositionKeeping_Administer_Position");
		return null;
	}

	@Override
	public RetrieveDepositAcctTranResponse retrieveDepositAccountTransactions(
			RetrieveDepositAcctTran retrieveDepositAcctTranRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "PositionKeeping_Retrieve_Deposit_Account_Transactions");
		return null;
	}

	/***
	 * This method is used to retrieve list of transactions for CASA Accounts
	 * @param retrievePersonalFinanceTransRq {@link RetrievePersonalFinanceTrans}
	 * @param part1 : {@link Holder} &lt; {@link MsgDetl} &gt;
	 * @param part2 : {@link Holder} &lt; {@link Trace} &gt;
	 * @param part3 : {@link Holder} &lt; {@link ExtendedHeader} &gt;
	 * @param part4 : {@link Holder} &lt; {@link InfoWarn} &gt;
	 * @return RetrievePersonalFinanceTransResponse
	 * @throws Fault {@link Fault}
	 */
	@Override
	public RetrievePersonalFinanceTransResponse retrievePersonalFinanceTrans(
			RetrievePersonalFinanceTrans retrievePersonalFinanceTransRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {

		MDC.put(FUNCTIONAL_MAP.value(), "PositionKeeping_Retrieve_Personal_Finance_Transactions");

		part2.value.getServiceProvider().add(this.positionKeepingResponseHeaderService.getServiceProvider());
		TransactionHistoryRequest transactionHistoryRequest = this.transactionRequestTransformer
				.transformToTransactionHistoryRequest(retrievePersonalFinanceTransRq);

		TransactionHistoryResponse transactionResponse = this.transactionService
				.getTransactionHistory(transactionHistoryRequest);

		List<TransactionNotification> transactionDetails = transactionResponse.getTransactions();

		if ((!transactionDetails.isEmpty())
				&& transactionResponse.getTotalCount() > transactionResponse.getLastIndex()) {
			InfoWarn paginationWarn = this.positionKeepingResponseHeaderService.getPaginationInfoHeader();
			part4.value = paginationWarn;
		}
		else if (transactionDetails.isEmpty()) {
			InfoWarn paginationWarn = this.positionKeepingResponseHeaderService.noRecordsFoundHeader();
			part4.value = paginationWarn;
		}

		return this.transactionResponseTransformer.transformTransactionHistory(transactionResponse,
				retrievePersonalFinanceTransRq);
	}

	@Override
	public PositionKeepingTranHistInqResponse retrieveTransactionHistory(
			PositionKeepingTranHistInq positionKeepingTranHistInqRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "PositionKeeping_Retrieve_Transaction_History");
		return null;
	}

	@Override
	public TranFDHistInqResponse retrieveFDTransactionHistory(TranFDHistInq tranFDHistInqRq, Holder<MsgDetl> part1,
			Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "PositionKeeping_Retrieve_FD_Transactions_History");

		part2.value.getServiceProvider().add(this.positionKeepingResponseHeaderService.getServiceProvider());
		TransactionHistoryRequest transactionHistRequest = this.transactionRequestTransformer
				.transformToTransactionHistoryRequest(tranFDHistInqRq);

		TransactionHistoryResponse transactionResponse = this.transactionService
				.getTransactionHistory(transactionHistRequest);
		List<TransactionNotification> transactionDetails = transactionResponse
				.getTransactions();
		if ((!transactionDetails.isEmpty())
				&& transactionResponse.getTotalCount() > transactionResponse.getLastIndex()) {
			InfoWarn paginationWarn = this.positionKeepingResponseHeaderService.getPaginationInfoHeader();
			part4.value = paginationWarn;
		}
		else if (transactionDetails.isEmpty()) {
			InfoWarn paginationWarn = this.positionKeepingResponseHeaderService.noRecordsFoundHeader();
			part4.value = paginationWarn;
		}
		return this.transactionResponseTransformer.transformTransactionHistory(transactionResponse,
				tranFDHistInqRq);
	}

	@Override
	public RetrievePendingTransactionsResponse retrievePendingTransactions(
			RetrievePendingTransactionDetailsReq retrievePendingTransactionsRq, Holder<MsgDetl> part1,
			Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "PositionKeeping_Retrieve_Pending_Transactions");
		return null;
	}

	/***
	 * This method is used to retrieve Transaction Details from TDS DB.
	 *
	 * @param retrieveTransactionDetailsRq : {@link RetrieveTransactionDetails}
	 * @param part1 : {@link Holder} &lt; {@link MsgDetl} &gt;
	 * @param part2 : {@link Holder} &lt; {@link Trace} &gt;
	 * @param part3 : {@link Holder} &lt; {@link ExtendedHeader} &gt;
	 * @param part4 : {@link Holder} &lt; {@link InfoWarn} &gt;
	 *
	 * @return {@link RetrieveTransactionDetailsResponse}
	 * @throws Fault {@link Fault}
	 */
	@Override
	public RetrieveTransactionDetailsResponse retrieveTransactionDetails(
			RetrieveTransactionDetails retrieveTransactionDetailsRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {

		MDC.put(FUNCTIONAL_MAP.value(), "PositionKeeping_Retrieve_Transactions_Details");
		return this.transactionService
				.retrieveTransactionDetails(retrieveTransactionDetailsRq, part1, part2, part3, part4);
	}

	@Override
	public RetrievePeriodicBalanceResponse retrievePeriodicBalance(RetrievePeriodicBalance retrievePeriodicBalanceRq,
			Holder<MsgDetl> part1, Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4)
			throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "PositionKeeping_Retrieve_Periodic_Balance");
		return null;
	}

	@Override
	public RetrievePendingCollectRequestsResponse retrievePendingCollectRequests(
			RetrievePendingCollectRequests retrievePendingCollectRequestsRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		return null;
	}

	@Override
	public RetrieveUPITransactionsResponse retrieveUPITransactions(RetrieveUPITransactions retrieveUPITransactionsRq,
			Holder<MsgDetl> part1, Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4)
			throws Fault {
		return null;
	}

}
