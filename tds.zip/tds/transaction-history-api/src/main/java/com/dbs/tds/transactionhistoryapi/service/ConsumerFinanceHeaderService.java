package com.dbs.tds.transactionhistoryapi.service;

import javax.xml.datatype.DatatypeConfigurationException;

import com.dbs.schemas.soi.common._4_0.ServiceProvider;
import com.dbs.tds.util.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Component;

/***
 *
 * This class contains common methods for header portion of ConsumerFinanceServices
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Component
public class ConsumerFinanceHeaderService {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(ConsumerFinanceHeaderService.class);

	/***
	 *
	 * This method is used to build {@link ServiceProvider}
	 * @return
	 */
	public ServiceProvider getServiceProvider() {
		ServiceProvider service = new ServiceProvider();
		try {
			service.setSPId("TDSIN");
			service.setMustUnderstand(true);
			service.setSPDateTime(DateUtil.getCurrentXMLGregorianCalendarDate());
		}
		catch (DatatypeConfigurationException e) {
			LOGGER.error("Error In creating XMLGregorianCalendar Object");
		}

		return service;
	}
}
