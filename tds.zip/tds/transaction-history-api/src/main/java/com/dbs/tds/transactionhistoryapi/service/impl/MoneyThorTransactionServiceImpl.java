package com.dbs.tds.transactionhistoryapi.service.impl;

import java.util.Objects;

import com.dbs.moneythor.constants.TransactionStatus;
import com.dbs.moneythor.dto.MoneyThorTransactionHistoryRequest;
import com.dbs.moneythor.dto.MoneyThorTransactionResponse;
import com.dbs.moneythor.dto.MoneyThorTransactionUpdateRequest;
import com.dbs.tds.constants.ErrorConstants;
import com.dbs.tds.constants.StatusCodes;
import com.dbs.tds.transactionhistoryapi.config.MoneyThorRestTemplate;
import com.dbs.tds.transactionhistoryapi.service.MoneyThorTransactionService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.web.client.RestTemplate;

import static com.dbs.moneythor.constants.MoneyThorRequestField.AMPERSAND;
import static com.dbs.moneythor.constants.MoneyThorRequestField.COUNT;
import static com.dbs.moneythor.constants.MoneyThorRequestField.EQUAL;
import static com.dbs.moneythor.constants.MoneyThorRequestField.EXPAND_TIP;
import static com.dbs.moneythor.constants.MoneyThorRequestField.FALSE;
import static com.dbs.moneythor.constants.MoneyThorRequestField.NULL;
import static com.dbs.moneythor.constants.MoneyThorRequestField.PAGE;
import static com.dbs.moneythor.constants.MoneyThorRequestField.QUESTION;
import static com.dbs.moneythor.constants.MoneyThorRequestField.STATUS;
import static com.dbs.moneythor.constants.MoneyThorRequestField.TRUE;
import static com.dbs.moneythor.constants.TransactionStatus.AUTHORIZED;
import static com.dbs.moneythor.constants.TransactionStatus.POSTED;
import static com.dbs.tds.constants.AppConstants.STATUS_CODE_DES_KEY;
import static com.dbs.tds.constants.AppConstants.STATUS_CODE_KEY;
import static com.dbs.tds.constants.LoggingConstants.ERROR_TYPE;

/**
 * This class is used to provide implementation of the Money Thor Transaction Service and
 * provide various methods to interact with Money Thor API for different functionalities.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Service
public class MoneyThorTransactionServiceImpl implements MoneyThorTransactionService {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(MoneyThorTransactionServiceImpl.class);

	/**
	 * This field is used to store instance of {@link MoneyThorRestTemplate }.
	 */
	private MoneyThorRestTemplate moneyThorRestTemplate;

	/**
	 * This field is used to store value for moneyThorUrl which is of type {@link String
	 * }.
	 */
	@Value("${moneythor.url}")
	private String moneyThorUrl;

	/**
	 * This field is used to store value for moneyThorReadTransactionApiEndPoint which is
	 * of type {@link String }.
	 */
	@Value("${moneythor.transactions.read.api}")
	private String moneyThorReadTransactionApiEndPoint;

	/**
	 * This field is used to store value for moneyThorTxnUpdateEndPoint which is of type
	 * {@link String }.
	 */
	@Value("${moneythor.transactions.update.api}")
	private String moneyThorTxnUpdateEndPoint;

	/**
	 * This method is used with injected moneyThorRestTemplate to set the instance of
	 * {@link MoneyThorRestTemplate}, so we will be able to extract instance of
	 * {@link RestTemplate} out of it.
	 *
	 * @param moneyThorRestTemplate : {@link MoneyThorRestTemplate}
	 */
	public MoneyThorTransactionServiceImpl(MoneyThorRestTemplate moneyThorRestTemplate) {
		this.moneyThorRestTemplate = moneyThorRestTemplate;
	}

	/**
	 * This method is used to fetch transaction History from the Money Thor, based on the
	 * details present in the request.
	 *
	 * @param request : {@link MoneyThorTransactionHistoryRequest}
	 * @param customerID : {@link String}
	 * @return {@link MoneyThorTransactionResponse}
	 */
	@Override
	public MoneyThorTransactionResponse getTransactionHistoryFromMT(MoneyThorTransactionHistoryRequest request,
			String customerID) {

		Assert.notNull(customerID, "Customer Id cannot be null");

		String transactionsURL = buildTransactionRequestURL(request);

		RestTemplate restTemplate = this.moneyThorRestTemplate.getRestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("customer", customerID);

		MDC.put(STATUS_CODE_KEY.value(), StatusCodes.SUCCESS.value());
		MDC.put(STATUS_CODE_DES_KEY.value(), StatusCodes.SUCCESS.name());
		MDC.put(ERROR_TYPE.value(), "");
		LOGGER.info(
				"Get transaction history from MoneyThor : transactionsURL={} and request headers={}",
				transactionsURL, headers);
		HttpEntity<String> entity = new HttpEntity<>(headers);

		ResponseEntity<MoneyThorTransactionResponse> transactionResponse = restTemplateExchange(transactionsURL,
				restTemplate, entity);
		return transactionResponse.getBody();
	}

	/**
	 * This method is used to connect with MoneyThor and perform the operation for getting
	 * the transaction history or updating the transaction details.
	 *
	 * @param transactionsURL : {@link String}
	 * @param restTemplate : {@link RestTemplate}
	 * @param entity : {@link HttpEntity}
	 * @return {@link ResponseEntity} &lt; {@link MoneyThorTransactionResponse} &gt;
	 */
	protected ResponseEntity<MoneyThorTransactionResponse> restTemplateExchange(String transactionsURL,
			RestTemplate restTemplate, HttpEntity<?> entity) {
		return restTemplate
				.exchange(transactionsURL, HttpMethod.POST, entity, MoneyThorTransactionResponse.class);
	}

	/**
	 * This method is used to call Money Thor Rest API and update the transaction Detail
	 * in Money Thor.
	 *
	 * @param moneyThorTransactionUpdateRequest :
	 * {@link MoneyThorTransactionUpdateRequest}
	 * @param customerID : {@link String}
	 * @return {@link MoneyThorTransactionResponse}
	 */
	@Override
	public MoneyThorTransactionResponse updateTransactionInMT(
			MoneyThorTransactionUpdateRequest moneyThorTransactionUpdateRequest, String customerID) {
		Assert.notNull(customerID, "Customer Id cannot be null");

		String transactionsURL = this.moneyThorUrl + this.moneyThorTxnUpdateEndPoint;

		RestTemplate restTemplate = this.moneyThorRestTemplate.getRestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("customer", customerID);
		LOGGER.info("Update transaction in MoneyThor : transactionsURL={} and request headers={}",
				transactionsURL, headers);
		HttpEntity<MoneyThorTransactionUpdateRequest> entity = new HttpEntity<>(moneyThorTransactionUpdateRequest,
				headers);

		ObjectMapper mapper = new ObjectMapper();
		String requestJson = "";
		try {
			requestJson = mapper.writeValueAsString(entity.getBody());
			MDC.put(STATUS_CODE_KEY.value(), StatusCodes.SUCCESS.value());
			MDC.put(STATUS_CODE_DES_KEY.value(), StatusCodes.SUCCESS.name());
			MDC.put(ERROR_TYPE.value(), "");
		}
		catch (JsonProcessingException e) {
			MDC.put(STATUS_CODE_KEY.value(), StatusCodes.FAILURE.value());
			MDC.put(STATUS_CODE_DES_KEY.value(), StatusCodes.FAILURE.name());
			MDC.put(ERROR_TYPE.value(), ErrorConstants.TECH.name());
			LOGGER.error("Exception while parsing request to JSON String : {}", e);
		}

		LOGGER.info("Request going to MoneyThor : {}", requestJson);

		ResponseEntity<MoneyThorTransactionResponse> transactionResponse = restTemplateExchange(transactionsURL,
				restTemplate, entity);
		return transactionResponse.getBody();
	}

	/**
	 * This method is used to generate transaction URL on which Money Thor API is exposed.
	 *
	 * @param request : {@link MoneyThorTransactionHistoryRequest}
	 * @return {@link String }
	 */
	private String buildTransactionRequestURL(MoneyThorTransactionHistoryRequest request) {
		StringBuilder transactionRequestURL = new StringBuilder(this.moneyThorUrl);

		final TransactionStatus status = request.getStatus();
		final Integer page = request.getPage();
		final Integer count = request.getCount();

		transactionRequestURL.append(this.moneyThorReadTransactionApiEndPoint);
		transactionRequestURL.append(QUESTION.value()).append(STATUS.value()).append(EQUAL.value());

		if (status != null && (AUTHORIZED.value().equalsIgnoreCase(status.value())
				|| POSTED.value().equalsIgnoreCase(status.value()))) {
			transactionRequestURL.append(status);
		}
		else {
			transactionRequestURL.append(NULL.value());
		}

		transactionRequestURL.append(AMPERSAND.value()).append(PAGE.value()).append(EQUAL.value())
		.append(Objects.toString(page, ""));
		transactionRequestURL.append(AMPERSAND.value()).append(EXPAND_TIP.value()).append(EQUAL.value());

		if (request.getExpandTip() != null && request.getExpandTip()) {
			transactionRequestURL.append(TRUE.value());
		}
		else {
			transactionRequestURL.append(FALSE.value());
		}

		if (count != null) {

			transactionRequestURL.append(AMPERSAND.value()).append(COUNT).append(EQUAL)
			.append(count);
		}
		return transactionRequestURL.toString();
	}

}
