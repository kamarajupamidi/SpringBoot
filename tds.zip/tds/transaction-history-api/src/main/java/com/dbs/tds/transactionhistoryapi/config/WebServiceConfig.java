package com.dbs.tds.transactionhistoryapi.config;

import javax.xml.ws.Endpoint;

import com.dbs.tds.transactionhistoryapi.filter.LoggingFilter;
import com.dbs.tds.transactionhistoryapi.service.ConsumerFinanceService;
import com.dbs.tds.transactionhistoryapi.service.PositionKeepingService;
import org.apache.cxf.bus.spring.SpringBus;
import org.apache.cxf.feature.LoggingFeature;
import org.apache.cxf.jaxws.EndpointImpl;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * This class is used as the configuration for the SOAP services which will be exposed for
 * handling KONY request for different kind of operations.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Configuration
public class WebServiceConfig {

	/**
	 * This method is used to publish the exposed service, on the configured URL so that
	 * it can honor the SOAP requests coming from KONY system and process them
	 * accordingly.
	 *
	 * @param springBusForPositionKeeping : {@link SpringBus}
	 * @param positionKeepingService : {@link PositionKeepingService}
	 * @return {@link Endpoint}
	 */
	@Bean
	public Endpoint positionKeepingendpoint(SpringBus springBusForPositionKeeping, PositionKeepingService positionKeepingService) {

		LoggingFeature featureForPositionKeeping = new LoggingFeature();
		featureForPositionKeeping.setPrettyLogging(true);
		featureForPositionKeeping.initialize(springBusForPositionKeeping);

		springBusForPositionKeeping.getFeatures().add(featureForPositionKeeping);
		EndpointImpl positionKeepingEndpoint = new EndpointImpl(springBusForPositionKeeping, positionKeepingService);
		positionKeepingEndpoint.publish("/PositionKeepingService_1.1");
		return positionKeepingEndpoint;
	}

	/**
	 * This method is used to publish the exposed service, on the configured URL so that
	 * it can honor the SOAP requests coming from KONY system and process them
	 * accordingly.
	 *
	 * @param springBusForConsumerFinance : {@link SpringBus}
	 * @param consumerFinanceService : {@link ConsumerFinanceService}
	 * @return {@link Endpoint}
	 */
	@Bean
	public Endpoint consumerFinanceendpoint(SpringBus springBusForConsumerFinance, ConsumerFinanceService consumerFinanceService) {
		LoggingFeature featureForConsumerFinance = new LoggingFeature();
		featureForConsumerFinance.setPrettyLogging(true);
		featureForConsumerFinance.initialize(springBusForConsumerFinance);

		springBusForConsumerFinance.getFeatures().add(featureForConsumerFinance);
		EndpointImpl consumerFinanceEndpoint = new EndpointImpl(springBusForConsumerFinance, consumerFinanceService);
		consumerFinanceEndpoint.publish("/ConsumerFinanceService_1.0");
		return consumerFinanceEndpoint;
	}

	/**
	 * This method is used to set the Logging Filter so that every request which will be
	 * received by the services can be logged.
	 *
	 * @return {@link FilterRegistrationBean}
	 */
	@Bean
	public FilterRegistrationBean logFilterRegistrationBean() {
		FilterRegistrationBean logRegistrationBeanForTransactionHistory = new FilterRegistrationBean();
		logRegistrationBeanForTransactionHistory.setName("logger");
		LoggingFilter loggingFilter = new LoggingFilter();
		logRegistrationBeanForTransactionHistory.setFilter(loggingFilter);
		return logRegistrationBeanForTransactionHistory;
	}

}
