package com.dbs.tds.transactionhistoryapi.service;

import com.dbs.moneythor.dto.MoneyThorTransactionHistoryRequest;
import com.dbs.moneythor.dto.MoneyThorTransactionResponse;
import com.dbs.moneythor.dto.MoneyThorTransactionUpdateRequest;

import org.springframework.stereotype.Service;

/**
 * This interface is used to expose services for Money Thor Transaction to perform
 * different functionalities.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Service
public interface MoneyThorTransactionService {

	/**
	 * This method is used to get Transaction History from money Thor.
	 *
	 * @param request : {@link MoneyThorTransactionHistoryRequest}
	 * @param customerID : {@link String}
	 * @return {@link MoneyThorTransactionResponse}
	 */
	public MoneyThorTransactionResponse getTransactionHistoryFromMT(MoneyThorTransactionHistoryRequest request,
			String customerID);

	/**
	 * This method is used to update transaction Details in Money Thor.
	 *
	 * @param moneyThorTransactionUpdateRequest :
	 * {@link MoneyThorTransactionUpdateRequest}
	 * @param customerID : {@link String}
	 * @return {@link MoneyThorTransactionResponse}
	 */
	public MoneyThorTransactionResponse updateTransactionInMT(
			MoneyThorTransactionUpdateRequest moneyThorTransactionUpdateRequest, String customerID);

}
