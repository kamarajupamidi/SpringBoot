package com.dbs.tds.transactionhistoryapi.service;

import javax.xml.ws.Holder;

import com.dbs.schemas.soi.common._4_0.ExtendedHeader;
import com.dbs.schemas.soi.common._4_0.InfoWarn;
import com.dbs.schemas.soi.common._4_0.MsgDetl;
import com.dbs.schemas.soi.common._4_0.Trace;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.AdministerTransaction;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrieveTransactionDetails;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrieveTransactionDetailsResponse;
import com.dbs.tds.dto.TransactionHistoryRequest;
import com.dbs.tds.dto.TransactionHistoryResponse;
import com.dbs.tds.dto.TransactionNotification;

import org.springframework.stereotype.Service;

/**
 * This interface is used to expose services for Transaction in TDS context to perform
 * different functionalities.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Service
public interface TransactionService {

	/**
	 * This method is used to get Transaction History from TDS DB.
	 *
	 * @param transactionHistoryRequest : {@link TransactionHistoryRequest}
	 * @return {@link TransactionHistoryResponse}
	 */
	public TransactionHistoryResponse getTransactionHistory(TransactionHistoryRequest transactionHistoryRequest);

	/**
	 * This method is used to update Transaction Details in TDS DB.
	 *
	 * @param administerTransaction : {@link AdministerTransaction}
	 * @return {@link TransactionNotification}
	 */
	public TransactionNotification updateTransactionDetails(AdministerTransaction administerTransaction);

	/**
	 * This method is used to retrieve Transaction Details from TDS DB.
	 *
	 * @param retrieveTransactionDetails : {@link RetrieveTransactionDetails}
	 * @param part1 : {@link Holder} &lt; {@link MsgDetl} &gt;
	 * @param part2 : {@link Holder} &lt; {@link Trace} &gt;
	 * @param part3 : {@link Holder} &lt; {@link ExtendedHeader} &gt;
	 * @param part4 : {@link Holder} &lt; {@link InfoWarn} &gt;
	 *
	 * @return {@link RetrieveTransactionDetailsResponse}
	 */
	public RetrieveTransactionDetailsResponse retrieveTransactionDetails(
			RetrieveTransactionDetails retrieveTransactionDetails, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4);

}
