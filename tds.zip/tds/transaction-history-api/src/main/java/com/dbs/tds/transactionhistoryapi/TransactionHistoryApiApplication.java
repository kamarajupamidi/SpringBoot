package com.dbs.tds.transactionhistoryapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * This class is used for initializing the Spring Boot Container for handling and exposing
 * the SOAP Service which will receive request incoming from Kony and process them
 * accordingly.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@SpringBootApplication
public class TransactionHistoryApiApplication {

	/**
	 * This method is used by JVM to start the Spring Boot Container for this application
	 * which will expose the SOAP Service for handling Kony requests for reading the
	 * transaction history or getting transaction details or updating the transaction
	 * details.
	 *
	 * @param args : {@link String}[]
	 */
	public static void main(String[] args) {
		SpringApplication.run(TransactionHistoryApiApplication.class, args);
	}
}
