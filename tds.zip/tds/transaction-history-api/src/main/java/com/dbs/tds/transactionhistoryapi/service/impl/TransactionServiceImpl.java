package com.dbs.tds.transactionhistoryapi.service.impl;

import javax.xml.ws.Holder;

import com.dbs.schemas.soi.common._4_0.ExtendedHeader;
import com.dbs.schemas.soi.common._4_0.InfoWarn;
import com.dbs.schemas.soi.common._4_0.MsgDetl;
import com.dbs.schemas.soi.common._4_0.Trace;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.AdministerTransaction;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrieveTransactionDetails;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrieveTransactionDetailsResponse;
import com.dbs.tds.constants.ErrorConstants;
import com.dbs.tds.constants.StatusCodes;
import com.dbs.tds.dto.TransactionDetailsRequest;
import com.dbs.tds.dto.TransactionDetailsResponse;
import com.dbs.tds.dto.TransactionHistoryRequest;
import com.dbs.tds.dto.TransactionHistoryResponse;
import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistoryapi.dao.TransactionRepository;
import com.dbs.tds.transactionhistoryapi.exception.TransactionHistoryException;
import com.dbs.tds.transactionhistoryapi.mapper.TransactionRequestTransformer;
import com.dbs.tds.transactionhistoryapi.mapper.TransactionResponseTransformer;
import com.dbs.tds.transactionhistoryapi.service.PositionKeepingResponseHeaderService;
import com.dbs.tds.transactionhistoryapi.service.TransactionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import org.springframework.stereotype.Service;

import static com.dbs.tds.constants.AppConstants.STATUS_CODE_DES_KEY;
import static com.dbs.tds.constants.AppConstants.STATUS_CODE_KEY;
import static com.dbs.tds.constants.LoggingConstants.ERROR_TYPE;

/**
 * This class is used to provide implementation of the TDS Transaction Service and provide
 * various methods to interact with TDS DB for different functionalities.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Service
public class TransactionServiceImpl implements TransactionService {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(TransactionServiceImpl.class);

	/**
	 * This field is used to store instance of type {@link TransactionRepository }.
	 */
	private TransactionRepository transactionRepository;

	/**
	 * This field is used to store value for positionKeepingResponseHeaderService which is
	 * of type {@link PositionKeepingResponseHeaderService }.
	 */
	private PositionKeepingResponseHeaderService positionKeepingResponseHeaderService;

	/**
	 * This field is used to store value for transactionTransformer which is of type
	 * {@link TransactionRequestTransformer }.
	 */
	private TransactionRequestTransformer transactionTransformer;

	/**
	 * This field is used to store value for transactionTransformer which is of type
	 * {@link TransactionResponseTransformer }.
	 */
	private TransactionResponseTransformer transactionResponseTransformer;

	/**
	 * This method is used with injected transactionRepository and transactionTransformer
	 * to set the instance of {@link TransactionRepository} and
	 * {@link TransactionResponseTransformer}, so we will be able to perform different
	 * functions with it.
	 *
	 * @param transactionRepository : {@link TransactionRepository}
	 * @param transactionTransformer : {@link TransactionRequestTransformer}
	 * @param transactionResponseTransformer : {@link TransactionResponseTransformer}
	 * @param positionKeepingResponseHeaderService :
	 * {@link PositionKeepingResponseHeaderService}
	 */
	public TransactionServiceImpl(TransactionRepository transactionRepository,
			TransactionRequestTransformer transactionTransformer,
			TransactionResponseTransformer transactionResponseTransformer,
			PositionKeepingResponseHeaderService positionKeepingResponseHeaderService) {
		this.transactionRepository = transactionRepository;
		this.transactionTransformer = transactionTransformer;
		this.transactionResponseTransformer = transactionResponseTransformer;
		this.positionKeepingResponseHeaderService = positionKeepingResponseHeaderService;
	}

	/**
	 * This method is used to get Transaction History for a particular account from TDS
	 * DB.
	 *
	 * @param transactionHistoryRequest : {@link TransactionHistoryRequest}
	 * @return {@link TransactionHistoryResponse}
	 */
	@Override
	public TransactionHistoryResponse getTransactionHistory(TransactionHistoryRequest transactionHistoryRequest) {
		LOGGER.info("getTransactionHistory with accountNumber={},details={}", transactionHistoryRequest.getAcctId(),
				transactionHistoryRequest);
		return this.transactionRepository.getTransactionhistory(transactionHistoryRequest);
	}

	/**
	 * This method is used to update transaction details in TDS DB, and it returns the
	 * transaction details along with the extracted ext Tran ID.
	 *
	 * @param administerTransaction : {@link AdministerTransaction}
	 * @return {@link TransactionNotification}
	 */
	@Override
	public TransactionNotification updateTransactionDetails(AdministerTransaction administerTransaction) {

		TransactionNotification transactionNotification = null;
		transactionNotification = this.transactionTransformer.transformFromSoapToTDS(administerTransaction);
		LOGGER.info("Converted Request for Db operation : transactionNotification={}", transactionNotification);
		transactionNotification = this.transactionRepository.updateTransactionCategory(transactionNotification);
		LOGGER.info("transaction update response after interactionw with TDS DB : {}", transactionNotification);

		return transactionNotification;
	}

	/**
	 * This method is used to retrieve transaction details from TDS DB, based on the
	 * account Number and TranKey.
	 *
	 * @param retrieveTransactionDetails : {@link RetrieveTransactionDetails}
	 * @param part1 : {@link Holder} &lt; {@link MsgDetl} &gt;
	 * @param part2 : {@link Holder} &lt; {@link Trace} &gt;
	 * @param part3 : {@link Holder} &lt; {@link ExtendedHeader} &gt;
	 * @param part4 : {@link Holder} &lt; {@link InfoWarn} &gt;
	 *
	 * @return {@link RetrieveTransactionDetailsResponse}
	 */
	@Override
	public RetrieveTransactionDetailsResponse retrieveTransactionDetails(
			RetrieveTransactionDetails retrieveTransactionDetails, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) {
		LOGGER.info("retrieveTransactionDetails with tranKey={}",
				retrieveTransactionDetails.getTranSeqNum());

		TransactionDetailsRequest transactionDetailsRequest = this.transactionTransformer
				.transformToTransactionDetailsRequest(retrieveTransactionDetails);

		RetrieveTransactionDetailsResponse retrieveTransactionDetailsResponse = new RetrieveTransactionDetailsResponse();
		part2.value.getServiceProvider().add(this.positionKeepingResponseHeaderService.getServiceProvider());
		retrieveTransactionDetailsResponse.setCommonRs(
				this.transactionResponseTransformer.getCommonRs(retrieveTransactionDetails.getCommonRq().getOrgCode(),
						retrieveTransactionDetails.getCommonRq().getRqSysRef()));

		try {
			TransactionDetailsResponse transactionDetailsResponse = this.transactionRepository
					.retrieveTransactionDetails(transactionDetailsRequest);

			retrieveTransactionDetailsResponse.setTranDetail(this.transactionResponseTransformer
					.getTransactionDetails(transactionDetailsResponse.getTransactionDetails()));
			MDC.put(STATUS_CODE_KEY.value(), StatusCodes.SUCCESS.value());
			MDC.put(STATUS_CODE_DES_KEY.value(), StatusCodes.SUCCESS.name());
			MDC.put(ERROR_TYPE.value(), "");
			LOGGER.info("retrieved TransactionDetails", transactionDetailsResponse);
		}
		catch (TransactionHistoryException e) {
			MDC.put(STATUS_CODE_KEY.value(), StatusCodes.FAILURE.value());
			MDC.put(STATUS_CODE_DES_KEY.value(), StatusCodes.FAILURE.name());
			MDC.put(ERROR_TYPE.value(), ErrorConstants.FUNC.name());
			LOGGER.error("Error while retrieving TransactionDetails", retrieveTransactionDetails);
			InfoWarn warning = this.positionKeepingResponseHeaderService.noRecordsFoundHeader();
			part4.value = warning;
		}

		return retrieveTransactionDetailsResponse;
	}

}
