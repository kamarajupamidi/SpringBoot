package com.dbs.tds.transactionhistoryapi.exception;

public enum ErrorLevel {

	INFO,
	WARN,
	ERROR;

}
