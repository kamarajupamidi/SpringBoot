package com.dbs.tds.transactionhistoryapi.service;

import javax.xml.ws.Holder;

import com.dbs.moneythor.dto.MoneyThorTransactionResponse;
import com.dbs.moneythor.dto.MoneyThorTransactionUpdateRequest;
import com.dbs.schemas.soi.common._4_0.ExtendedHeader;
import com.dbs.schemas.soi.common._4_0.InfoWarn;
import com.dbs.schemas.soi.common._4_0.MsgDetl;
import com.dbs.schemas.soi.common._4_0.Trace;
import com.dbs.schemas.soi.wsdl.consumerfinanceservices.v1_0.Fault;
import com.dbs.schemas.soi.wsdl.consumerfinanceservices.v1_0.PortType;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.AdministerBudget;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.AdministerBudgetResponse;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.AdministerTransaction;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.AdministerTransactionResponse;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.CreateBudget;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.CreateBudgetResponse;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.RetrieveBudgetSummary;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.RetrieveBudgetSummaryResponse;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.RetrieveCategories;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.RetrieveCategoriesResponse;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.RetrieveCategorySummary;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.RetrieveCategorySummaryResponse;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.TerminateBudget;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.TerminateBudgetResponse;
import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistoryapi.mapper.ConsumerFinanceTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import org.springframework.stereotype.Service;

import static com.dbs.tds.constants.LoggingConstants.FUNCTIONAL_MAP;

@Service
@javax.jws.WebService(serviceName = "ConsumerFinanceServices", portName = "HTTP", targetNamespace = "http://schemas.dbs.com/soi/wsdl/ConsumerFinanceServices/v1_0", wsdlLocation = "classpath:wsdl/ConsumerFinanceServices_v1_0.wsdl", endpointInterface = "com.dbs.schemas.soi.wsdl.consumerfinanceservices.v1_0.PortType")
public class ConsumerFinanceService implements PortType {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(ConsumerFinanceService.class);

	/**
	 * This field is used to store value for moneyThorTransactionService which is of type
	 * {@link MoneyThorTransactionService }.
	 */
	private MoneyThorTransactionService moneyThorTransactionService;

	/**
	 * This field is used to store value for transactionService which is of type
	 * {@link TransactionService }.
	 */
	private TransactionService transactionService;

	/**
	 * This field is used to store value for consumerFinanceTransformer which is of type
	 * {@link ConsumerFinanceTransformer }.
	 */
	private ConsumerFinanceTransformer consumerFinanceTransformer;

	/**
	 * This field is used to store value for consumerFinanceHeaderService which is of type
	 * {@link ConsumerFinanceHeaderService }.
	 */
	private ConsumerFinanceHeaderService consumerFinanceHeaderService;

	/**
	 * This constructor is used to build the instance with injected dependencies.
	 *
	 * @param transactionService : {@link TransactionService}
	 * @param consumerFinanceTransformer : {@link ConsumerFinanceTransformer}
	 * @param moneyThorTransactionService : {@link MoneyThorTransactionService}
	 */
	public ConsumerFinanceService(TransactionService transactionService,
			ConsumerFinanceTransformer consumerFinanceTransformer,
			MoneyThorTransactionService moneyThorTransactionService,
			ConsumerFinanceHeaderService consumerFinanceHeaderService) {

		this.transactionService = transactionService;
		this.consumerFinanceTransformer = consumerFinanceTransformer;
		this.moneyThorTransactionService = moneyThorTransactionService;
		this.consumerFinanceHeaderService = consumerFinanceHeaderService;
	}

	@Override
	public AdministerBudgetResponse administerBudget(AdministerBudget administerBudgetRq, Holder<MsgDetl> part1,
			Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "ConsumerFinanceService_Administer_Budget");
		return null;
	}

	@Override
	public RetrieveBudgetSummaryResponse retrieveBudgetSummary(RetrieveBudgetSummary retrieveBudgetSummaryRq,
			Holder<MsgDetl> part1, Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4)
					throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "ConsumerFinanceService_Retrieve_Budget_Summary");
		return null;
	}

	@Override
	public RetrieveCategorySummaryResponse retrieveCategorySummary(RetrieveCategorySummary retrieveCategorySummaryRq,
			Holder<MsgDetl> part1, Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4)
					throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "ConsumerFinanceService_Retrieve_Category_Summary");
		return null;
	}

	@Override
	public CreateBudgetResponse createBudget(CreateBudget createBudgetRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "ConsumerFinanceService_Create_Budget");
		return null;
	}

	/**
	 * This method is used to update the transaction details, coming from SOI, to TDS DB
	 * and in MoneyThor as well.
	 *
	 * @param administerTransactionRq : {@link AdministerTransaction}
	 * @param part1 : {@link Holder} &lt; {@link MsgDetl} &gt;
	 * @param part2 : {@link Holder} &lt; {@link Trace} &gt;
	 * @param part3 : {@link Holder} &lt; {@link ExtendedHeader} &gt;
	 * @param part4 : {@link Holder} &lt; {@link InfoWarn} &gt;
	 *
	 * @return {@link AdministerTransactionResponse}
	 * @throws Fault Fault
	 */
	@Override
	public AdministerTransactionResponse administerTransaction(AdministerTransaction administerTransactionRq,
			Holder<MsgDetl> part1, Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4)
					throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "ConsumerFinanceService_Administer_Transaction");

		part2.value.getServiceProvider().add(this.consumerFinanceHeaderService.getServiceProvider());

		TransactionNotification transactionNotification = this.transactionService
				.updateTransactionDetails(administerTransactionRq);
		LOGGER.info("transaction update response after interaction with TDS DB : {}", transactionNotification);

		if (!transactionNotification.isError()) {
			LOGGER.info("No Error while updating in TDS DB.");
			MoneyThorTransactionUpdateRequest moneyThorTransactionUpdateRequest = this.consumerFinanceTransformer
					.transformFromSoapToMT(administerTransactionRq, transactionNotification);

			MoneyThorTransactionResponse mTResponse = this.moneyThorTransactionService
					.updateTransactionInMT(moneyThorTransactionUpdateRequest,
							administerTransactionRq.getCustInternalId());

			LOGGER.info("Administer transaction : moneythor response={}", mTResponse);
			return this.consumerFinanceTransformer.transformFromMTToSoap(administerTransactionRq, mTResponse);
		}
		else {
			LOGGER.info("Error while updating in TDS DB.");
			return this.consumerFinanceTransformer.transformErrorToSoap(administerTransactionRq,
					transactionNotification);
		}
	}

	@Override
	public RetrieveCategoriesResponse retrieveCategories(RetrieveCategories retrieveCategoriesRq, Holder<MsgDetl> part1,
			Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "ConsumerFinanceService_Retrieve_Categories");
		return null;
	}

	@Override
	public TerminateBudgetResponse terminateBudget(TerminateBudget terminateBudgetRq, Holder<MsgDetl> part1,
			Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "ConsumerFinanceService_Terminate_Budget");
		return null;
	}

}
