package com.dbs.tds.transactionhistoryapi.mapper;

import java.math.BigInteger;
import java.util.Objects;

import javax.xml.datatype.XMLGregorianCalendar;

import com.dbs.schemas.soi.common._4_0.DetailInfo;
import com.dbs.schemas.soi.common._4_1.Amount;
import com.dbs.schemas.soi.common._4_1.DepAcct;
import com.dbs.schemas.soi.common._4_1.RecCtrlIn;
import com.dbs.schemas.soi.wsdl.positionkeeping.v1_1.Fault;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.AdministerTransaction;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.TransactionUpdate;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePersonalFinanceTrans;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePersonalFinanceTrans.AmtRange;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrieveTransactionDetails;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.TranFDHistInq;
import com.dbs.tds.dto.TransactionDetailsRequest;
import com.dbs.tds.dto.TransactionHistoryRequest;
import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistoryapi.exception.ErrorLevel;
import com.dbs.tds.transactionhistoryapi.service.PositionKeepingResponseHeaderService;
import com.dbs.tds.util.CommonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Component;

import static com.dbs.tds.transactionhistoryapi.constant.TransactionConstantFields.ASC;
import static com.dbs.tds.transactionhistoryapi.constant.TransactionConstantFields.C;
import static com.dbs.tds.transactionhistoryapi.constant.TransactionConstantFields.CR;
import static com.dbs.tds.transactionhistoryapi.constant.TransactionConstantFields.D;
import static com.dbs.tds.transactionhistoryapi.constant.TransactionConstantFields.DEFAULT_SORT_ORDER_DESC;

@Component
public class TransactionRequestTransformer {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(TransactionRequestTransformer.class);

	/**
	 * This field is used to store value for DEFAULT_NUMBER_OF_RECORDS which is of type
	 * {@link BigInteger }.
	 */
	private static final BigInteger DEFAULT_NUMBER_OF_RECORDS = BigInteger.valueOf(20);

	/**
	 * This field is used to store value for positionKeepingResponseHeaderService which is
	 * of type {@link PositionKeepingResponseHeaderService }.
	 */
	private PositionKeepingResponseHeaderService positionKeepingResponseHeaderService;

	public TransactionRequestTransformer(PositionKeepingResponseHeaderService positionKeepingResponseHeaderService) {
		this.positionKeepingResponseHeaderService = positionKeepingResponseHeaderService;
	}

	/**
	 * This method is used to transform Soap Request for Transaction Update to TDS request
	 * instance for updating the details in database.
	 *
	 * @param transaction : {@link AdministerTransaction}
	 * @return {@link TransactionNotification}
	 */
	public TransactionNotification transformFromSoapToTDS(AdministerTransaction transaction) {

		TransactionNotification transactionNotification = new TransactionNotification();
		TransactionUpdate transactionUpdate = transaction.getTransactionUpdate();
		transactionNotification.setTranKey(transactionUpdate.getTranSeqNum());
		transactionNotification.setTranCategory(transactionUpdate.getCategoryName());
		transactionNotification.setPhoto(CommonUtils.convertStringToBlob(transactionUpdate.getPhoto()));
		transactionNotification.setNotes(transactionUpdate.getNotes());
		LOGGER.info("Transformed SOAP to TDS : transactionNotification={}", transactionNotification);

		return transactionNotification;
	}

	/***
	 *
	 * This method is used to convert incoming RetrievePersonalFinanceTrans request to
	 * TransactionHistoryRequest request
	 * @param retrievePersonalFinanceTransRq {@link RetrievePersonalFinanceTrans}
	 * @return {@link TransactionHistoryRequest}
	 * @throws Fault {@link Fault}
	 */
	public TransactionHistoryRequest transformToTransactionHistoryRequest(
			RetrievePersonalFinanceTrans retrievePersonalFinanceTransRq) throws Fault {
		TransactionHistoryRequest transactionHistoryRequest = new TransactionHistoryRequest();
		Integer lowerLimit = 0;
		BigInteger maxRecords = DEFAULT_NUMBER_OF_RECORDS;
		String acctId;
		String cursor;

		DepAcct depAcctId = retrievePersonalFinanceTransRq.getDepAcctId();
		RecCtrlIn recCtrlIn = retrievePersonalFinanceTransRq.getRecCtrlIn();
		XMLGregorianCalendar startDate = retrievePersonalFinanceTransRq.getStartDate();
		XMLGregorianCalendar endDate = retrievePersonalFinanceTransRq.getEndDate();

		if (depAcctId == null || (acctId = depAcctId.getAcctId()) == null) {
			DetailInfo errorInfo = this.positionKeepingResponseHeaderService.getDetailinfo("S022", ErrorLevel.ERROR);
			throw new Fault(errorInfo.getStatusDesc(), errorInfo);
		}
		transactionHistoryRequest.setAcctId(acctId);

		if (startDate != null) {
			transactionHistoryRequest.setStartDt(startDate.toGregorianCalendar().getTime());
		}

		if (endDate != null) {
			transactionHistoryRequest.setEndDt(endDate.toGregorianCalendar().getTime());
		}

		transactionHistoryRequest.setSortOrder(DEFAULT_SORT_ORDER_DESC.value());

		if (recCtrlIn != null && (cursor = recCtrlIn.getCursor()) != null) {
			maxRecords = recCtrlIn.getMaxRec();
			maxRecords = maxRecords == null ? DEFAULT_NUMBER_OF_RECORDS : maxRecords;
			transactionHistoryRequest.setCursor(cursor);
			lowerLimit = Integer.parseInt(cursor) * maxRecords.intValue();
		}

		transactionHistoryRequest.setLastTranRef(
				Integer.valueOf(Objects.toString(retrievePersonalFinanceTransRq.getLastTranRef(), "0")));
		transactionHistoryRequest.setLowerLimit(lowerLimit);
		transactionHistoryRequest.setMaxRec(maxRecords);

		AmtRange amtRange = retrievePersonalFinanceTransRq.getAmtRange();
		if (amtRange != null) {
			setAmountRanges(transactionHistoryRequest, amtRange);
		}

		if (retrievePersonalFinanceTransRq.getCrDrInd() != null) {
			setCrDrIndicator(retrievePersonalFinanceTransRq, transactionHistoryRequest);
		}

		return transactionHistoryRequest;
	}

	private void setCrDrIndicator(RetrievePersonalFinanceTrans retrievePersonalFinanceTransRq,
			TransactionHistoryRequest transactionHistoryRequest) {
		if (retrievePersonalFinanceTransRq.getCrDrInd().equalsIgnoreCase(CR.value())
				|| retrievePersonalFinanceTransRq.getCrDrInd().equalsIgnoreCase(C.value())) {
			transactionHistoryRequest.setCrDrInd(C.value());
		}
		else {
			transactionHistoryRequest.setCrDrInd(D.value());
		}
	}

	private void setAmountRanges(TransactionHistoryRequest transactionHistoryRequest, AmtRange amtRange) {
		Amount amtFrom = amtRange.getAmtFrom();
		Amount amtTo = amtRange.getAmtTo();

		if (amtFrom != null) {
			transactionHistoryRequest.setAmountFrom(amtFrom.getAmt());
			transactionHistoryRequest.setCurrency(amtFrom.getCur());
		}

		if (amtTo != null) {
			transactionHistoryRequest.setAmountTo(amtTo.getAmt());
			transactionHistoryRequest.setCurrency(amtTo.getCur());
		}
	}

	/***
	 * This method is used to convert incoming TranFDHistInq request to
	 * TransactionHistoryRequest request
	 * @param tranFDHistInqRq {@link TranFDHistInq}
	 * @return {@link TransactionHistoryRequest}
	 * @throws Fault {@link Fault}
	 */
	public TransactionHistoryRequest transformToTransactionHistoryRequest(TranFDHistInq tranFDHistInqRq) throws Fault {

		TransactionHistoryRequest transactionHistoryRequest = new TransactionHistoryRequest();
		DepAcct depAcctId = tranFDHistInqRq.getDepAcctId();
		RecCtrlIn recCtrlIn = tranFDHistInqRq.getRecCtrlIn();
		BigInteger maxRecords = DEFAULT_NUMBER_OF_RECORDS;
		Integer lowerLimit = 0;

		final XMLGregorianCalendar startDate = tranFDHistInqRq.getStartDate();
		final XMLGregorianCalendar endDate = tranFDHistInqRq.getEndDate();
		String acctId;
		String cursor = null;
		if (depAcctId == null || (acctId = depAcctId.getAcctId()) == null) {
			DetailInfo errorInfo = this.positionKeepingResponseHeaderService.getDetailinfo("S022", ErrorLevel.ERROR);
			throw new Fault(errorInfo.getStatusDesc(), errorInfo);
		}
		transactionHistoryRequest.setAcctId(acctId);

		if (startDate != null) {
			transactionHistoryRequest.setStartDt(startDate.toGregorianCalendar().getTime());
		}
		if (endDate != null) {
			transactionHistoryRequest.setEndDt(endDate.toGregorianCalendar().getTime());
		}

		if ("A".equalsIgnoreCase(tranFDHistInqRq.getTranDateTimeSeq())) {
			transactionHistoryRequest.setSortOrder(ASC.value());
		}
		else {
			transactionHistoryRequest.setSortOrder(DEFAULT_SORT_ORDER_DESC.value());
		}

		if (recCtrlIn != null && (cursor = recCtrlIn.getCursor()) != null) {
			maxRecords = recCtrlIn.getMaxRec();
			maxRecords = maxRecords == null ? DEFAULT_NUMBER_OF_RECORDS : maxRecords;
			transactionHistoryRequest.setCursor(cursor);
			lowerLimit = Integer.parseInt(cursor) * maxRecords.intValue();
		}

		transactionHistoryRequest.setLastTranRef(
				Integer.valueOf(Objects.toString(tranFDHistInqRq.getLastTranRef(), "0")));
		transactionHistoryRequest.setLowerLimit(lowerLimit);
		transactionHistoryRequest.setMaxRec(maxRecords);

		return transactionHistoryRequest;
	}

	/***
	 * This method is used to convert incoming {@link RetrieveTransactionDetails} request
	 * instance to {@link TransactionDetailsRequest} request, which will be used to
	 * interact with TDS DB.
	 *
	 * @param retrieveTransactionDetailsRq : {@link RetrieveTransactionDetails}
	 * @return {@link TransactionDetailsRequest}
	 */
	public TransactionDetailsRequest transformToTransactionDetailsRequest(
			RetrieveTransactionDetails retrieveTransactionDetailsRq) {

		TransactionDetailsRequest transactiondetailsRequest = new TransactionDetailsRequest();
		transactiondetailsRequest.setAccountNumber(retrieveTransactionDetailsRq.getCustInternalId());
		transactiondetailsRequest.setTranKey(retrieveTransactionDetailsRq.getTranSeqNum());

		return transactiondetailsRequest;
	}

}
