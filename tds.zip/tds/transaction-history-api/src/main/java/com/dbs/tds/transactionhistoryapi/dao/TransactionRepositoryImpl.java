package com.dbs.tds.transactionhistoryapi.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import com.dbs.tds.constants.ErrorConstants;
import com.dbs.tds.constants.StatusCodes;
import com.dbs.tds.dto.TransactionDetailsRequest;
import com.dbs.tds.dto.TransactionDetailsResponse;
import com.dbs.tds.dto.TransactionHistoryRequest;
import com.dbs.tds.dto.TransactionHistoryResponse;
import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistoryapi.exception.TransactionHistoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import static com.dbs.tds.constants.AppConstants.STATUS_CODE_DES_KEY;
import static com.dbs.tds.constants.AppConstants.STATUS_CODE_KEY;
import static com.dbs.tds.constants.LoggingConstants.ERROR_TYPE;
import static com.dbs.tds.constants.TransactionDimFields.TRAN_CMMNT;
import static com.dbs.tds.constants.TransactionDimFields.TRAN_CTGR;
import static com.dbs.tds.constants.TransactionFields.ACCTID;
import static com.dbs.tds.constants.TransactionFields.ADDNLREF;
import static com.dbs.tds.constants.TransactionFields.AMOUNT;
import static com.dbs.tds.constants.TransactionFields.AVAILABLEBAL;
import static com.dbs.tds.constants.TransactionFields.CURRENCY;
import static com.dbs.tds.constants.TransactionFields.LST_UPDT_DTTM;
import static com.dbs.tds.constants.TransactionFields.POSTINGDATE;
import static com.dbs.tds.constants.TransactionFields.RELATEDRECID;
import static com.dbs.tds.constants.TransactionFields.RELATEDTRANREF;
import static com.dbs.tds.constants.TransactionFields.TRANCODE;
import static com.dbs.tds.constants.TransactionFields.TRANDATE;
import static com.dbs.tds.constants.TransactionFields.TRANDESC;
import static com.dbs.tds.constants.TransactionFields.TRANID;
import static com.dbs.tds.constants.TransactionFields.TRANKEY;
import static com.dbs.tds.constants.TransactionFields.TRANSEQNUM;
import static com.dbs.tds.constants.TransactionFields.TXNTYPE;
import static com.dbs.tds.constants.TransactionFields.VALUEDATE;
import static com.dbs.tds.constants.TransactionImageFields.IMAGE;
import static com.dbs.tds.transactionhistoryapi.constant.TransactionConstantFields.DESC;

/**
 * This class is used to provide implementation for {@link TransactionRepository} and also
 * provide different functions to interact with TDS DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Repository
public class TransactionRepositoryImpl implements TransactionRepository {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(TransactionRepositoryImpl.class);

	/**
	 * This field is used to store value for GET_TRANS_HISTORY which is of type
	 * {@link String }.
	 */
	private static final String GET_TRANS_HISTORY = " SELECT FACT.TRANKEY,FACT.TRANDATE,FACT.VALUEDATE,FACT.POSTINGDATE,FACT.TRANCODE,FACT.TRANDESC, "
			+ " FACT.AMOUNT,FACT.CURRENCY,FACT.TXNTYPE,FACT.RELATEDTRANREF,FACT.RELATEDRECID,FACT.AVAILABLEBAL,DIM.TRAN_CTGR,DIM.TRAN_CMMNT,FACT.TRANID,FACT.TRANSEQNUM"
			+ " from T_DTA_FACT FACT LEFT JOIN T_DTA_DIM DIM on (DIM.TRANKEY=FACT.TRANKEY) ";

	private static final String GET_COUNT_TRANS_HISTORY = "SELECT COUNT(*) FROM T_DTA_FACT ";

	/**
	 * This field is used to store value for extTranIdExtract which is of type
	 * {@link String }.
	 */
	protected String extTranIdExtract;

	/**
	 * This field is used to store value for imageUpdateQuery which is of type
	 * {@link String }.
	 */
	private String imageUpdateQuery;

	/**
	 * This field is used to store value for transactionDetailsQuery which is of type
	 * {@link String }.
	 */
	private String transactionDetailsQuery;

	/**
	 * This field is used to store value for transactionUpdateJdbcTemplate which is of
	 * type {@link NamedParameterJdbcTemplate }.
	 */
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	/**
	 * This constructor is used with injected {@link JdbcTemplate} for setting up its
	 * instance and transactionUpdateJdbcTemplate as the class variable, which will help
	 * in interacting with TDS DB.
	 *
	 * @param jdbcTemplate : {@link JdbcTemplate}
	 */
	public TransactionRepositoryImpl(JdbcTemplate jdbcTemplate) {
		this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate);

		this.extTranIdExtract = "select EXT_TRANID from T_DTA_FACT where TRANKEY= :TRANKEY;";
		this.imageUpdateQuery = "Insert into T_DTA_IMG(TRANKEY, IMAGE, LST_UPDT_SYS_ID, LST_UPDT_DTTM) values (:TRANKEY, :IMAGE, 'CustomerOperation', :LST_UPDT_DTTM) "
				+ "ON DUPLICATE KEY UPDATE IMAGE= :IMAGE, LST_UPDT_SYS_ID= 'CustomerOperation', LST_UPDT_DTTM= :LST_UPDT_DTTM;";

		this.transactionDetailsQuery = "SELECT FACT.TRANSEQNUM,FACT.TRANDATE,FACT.VALUEDATE,FACT.POSTINGDATE,FACT.TRANCODE,FACT.TRANDESC,"
				+ "FACT.AMOUNT,FACT.CURRENCY,FACT.TXNTYPE,FACT.RELATEDTRANREF,FACT.ADDNLREF,FACT.RELATEDRECID,"
				+ "FACT.AVAILABLEBAL,FACT.TRANID,FACT.TRANKEY,DIM.TRAN_CTGR,DIM.TRAN_CMMNT,IMG.IMAGE from T_DTA_FACT FACT"
				+ " LEFT JOIN T_DTA_DIM DIM on (DIM.TRANKEY=FACT.TRANKEY) LEFT JOIN T_DTA_IMG IMG on (IMG.TRANKEY=FACT.TRANKEY)"
				+ " WHERE FACT.TRANKEY=:TRANKEY";
	}

	/**
	 * This method is used to fetch Transaction History from TDS DB based for a specified
	 * account number and limit is provided to limit the no of records to be fetched from
	 * DB.
	 *
	 * @param transactionHistoryRequest : {@link TransactionHistoryRequest}
	 * @return {@link TransactionHistoryResponse}
	 */
	@Override
	public TransactionHistoryResponse getTransactionhistory(TransactionHistoryRequest transactionHistoryRequest) {
		LOGGER.info("Get transaction history details by : accountNumber={}, details={}",
				transactionHistoryRequest.getAcctId(), transactionHistoryRequest);

		int adjustPagination = 0;

		MapSqlParameterSource paramSource = new MapSqlParameterSource();

		TransactionHistoryResponse transactionHistoryResponse = new TransactionHistoryResponse();

		StringBuilder query = new StringBuilder(GET_TRANS_HISTORY);
		StringBuilder countQuery = new StringBuilder(GET_COUNT_TRANS_HISTORY);

		query.append(" WHERE ACCTID = :ACCTID ");
		countQuery.append(" WHERE ACCTID = :ACCTID ");

		paramSource.addValue(ACCTID.name(), transactionHistoryRequest.getAcctId());

		appendStartDateToQuery(transactionHistoryRequest, paramSource, query, countQuery);

		appendEndDateToQuery(transactionHistoryRequest, paramSource, query, countQuery);

		appendAmountFrom(transactionHistoryRequest, paramSource, query, countQuery);

		appendAmountTo(transactionHistoryRequest, paramSource, query, countQuery);

		appendCurrency(transactionHistoryRequest, paramSource, query, countQuery);

		appendCrDrInd(transactionHistoryRequest, paramSource, query, countQuery);

		query.append(getSortOrder(transactionHistoryRequest.getSortOrder()));
		query.append(" LIMIT :lowerlimit, :maxRecords ");

		Integer totalCount = this.namedParameterJdbcTemplate.query(countQuery.toString(),
				paramSource,
				(RowMapper<Integer>) (paramResultSet, paramInt) -> paramResultSet.getInt(1)).get(0);

		Integer existingCount = transactionHistoryRequest.getLastTranRef();
		String cursor = transactionHistoryRequest.getCursor();

		int pageNum = Integer.parseInt(Objects.toString(cursor, "0"));

		if (existingCount != null && existingCount.intValue() != 0
				&& existingCount.intValue() < totalCount.intValue() && pageNum != 0) {
			adjustPagination = totalCount - existingCount.intValue();
			totalCount = existingCount;
		}

		paramSource.addValue("lowerlimit", transactionHistoryRequest.getLowerLimit() + adjustPagination);
		paramSource.addValue("maxRecords", transactionHistoryRequest.getMaxRec().intValue());

		LOGGER.info("Query generated with this {} and the parameter source {}", query.toString(), paramSource);

		List<TransactionNotification> transactions = this.namedParameterJdbcTemplate.query(query.toString(),
				paramSource,
				(RowMapper<TransactionNotification>) (resultSet, rowNum) -> {
					return getTransactionNotification(resultSet);
				});

		transactionHistoryResponse.setTransactions(transactions);
		transactionHistoryResponse.setTotalCount(totalCount);

		int lastRecordindex = transactionHistoryRequest.getLowerLimit()
				+ transactionHistoryRequest.getMaxRec().intValue();
		if (lastRecordindex < totalCount) {
			transactionHistoryResponse.setLastIndex(lastRecordindex);
		}
		else {
			transactionHistoryResponse.setLastIndex(totalCount);
		}

		transactionHistoryResponse.setMaxRec(transactionHistoryRequest.getMaxRec().intValue());
		transactionHistoryResponse
				.setCursor(Integer.parseInt(Objects.toString(transactionHistoryRequest.getCursor(), "0")));
		transactionHistoryResponse.setCurrentPageCount(transactions.size());

		MDC.put(STATUS_CODE_KEY.value(), StatusCodes.SUCCESS.value());
		MDC.put(STATUS_CODE_DES_KEY.value(), StatusCodes.SUCCESS.name());
		MDC.put(ERROR_TYPE.value(), "");

		LOGGER.info("Transaction history response accountNumber={}, details={}, totalFound={}",
				transactionHistoryRequest.getAcctId(), transactionHistoryRequest, transactions.size());

		return transactionHistoryResponse;
	}

	private void appendCrDrInd(TransactionHistoryRequest transactionHistoryRequest, MapSqlParameterSource paramSource,
			StringBuilder query, StringBuilder countQuery) {
		if (transactionHistoryRequest.getCrDrInd() != null) {
			String txnType = " AND UPPER(TXNTYPE) = :TXNTYPE ";
			query.append(txnType);
			countQuery.append(txnType);
			paramSource.addValue(TXNTYPE.name(), transactionHistoryRequest.getCrDrInd().toUpperCase());
		}
	}

	private void appendCurrency(TransactionHistoryRequest transactionHistoryRequest, MapSqlParameterSource paramSource,
			StringBuilder query, StringBuilder countQuery) {
		if (transactionHistoryRequest.getCurrency() != null) {
			String currency = " AND UPPER(CURRENCY) = :CURRENCY ";
			query.append(currency);
			countQuery.append(currency);
			paramSource.addValue(CURRENCY.name(), transactionHistoryRequest.getCurrency().toUpperCase());
		}
	}

	private void appendAmountTo(TransactionHistoryRequest transactionHistoryRequest, MapSqlParameterSource paramSource,
			StringBuilder query, StringBuilder countQuery) {
		if (transactionHistoryRequest.getAmountTo() != null) {
			String toAmount = " AND AMOUNT <= :toAmount ";
			query.append(toAmount);
			countQuery.append(toAmount);
			paramSource.addValue("toAmount", transactionHistoryRequest.getAmountTo());
		}
	}

	private void appendAmountFrom(TransactionHistoryRequest transactionHistoryRequest,
			MapSqlParameterSource paramSource, StringBuilder query, StringBuilder countQuery) {
		if (transactionHistoryRequest.getAmountFrom() != null) {
			String fromAmount = " AND AMOUNT >= :fromAmount ";
			query.append(fromAmount);
			countQuery.append(fromAmount);
			paramSource.addValue("fromAmount", transactionHistoryRequest.getAmountFrom());
		}
	}

	private void appendEndDateToQuery(TransactionHistoryRequest transactionHistoryRequest,
			MapSqlParameterSource paramSource, StringBuilder query, StringBuilder countQuery) {
		if (transactionHistoryRequest.getEndDt() != null) {
			String tranEndDate = " AND TRANDATE <= :endDt ";
			query.append(tranEndDate);
			countQuery.append(tranEndDate);
			paramSource.addValue("endDt", transactionHistoryRequest.getEndDt());
		}
	}

	private void appendStartDateToQuery(TransactionHistoryRequest transactionHistoryRequest,
			MapSqlParameterSource paramSource, StringBuilder query, StringBuilder countQuery) {
		if (transactionHistoryRequest.getStartDt() != null) {
			String tranStartDate = " AND TRANDATE >= :startDt ";
			query.append(tranStartDate);
			countQuery.append(tranStartDate);
			paramSource.addValue("startDt", transactionHistoryRequest.getStartDt());
		}
	}

	private String getSortOrder(String sortOrderRequest) {

		String sortOrder = " ORDER BY POSTINGDATE ASC ";

		if (DESC.value().equalsIgnoreCase(sortOrderRequest)) {
			sortOrder = " ORDER BY POSTINGDATE DESC ";
		}

		return sortOrder;
	}

	private TransactionNotification getTransactionNotification(ResultSet rs) throws SQLException {
		TransactionNotification transaction = new TransactionNotification();

		transaction.setTranKey(rs.getString(TRANKEY.name()));
		/*
		 * Transaction date and value date returned from SOI are pointed to value date and
		 * trans date respectively. So to maintain consistency in Kony UI, TDS has to swap
		 * the mapping as there is no option to fix at SOI end.
		 */

		if (rs.getTimestamp(VALUEDATE.name()) != null) {
			transaction.setTransactionDate(new Date(rs.getTimestamp(VALUEDATE.name()).getTime()));
		}

		if (rs.getTimestamp(TRANDATE.name()) != null) {
			transaction.setValueDate(new Date(rs.getTimestamp(TRANDATE.name()).getTime()));
		}

		if (rs.getTimestamp(POSTINGDATE.name()) != null) {
			transaction.setPostedDate(new Date(rs.getTimestamp(POSTINGDATE.name()).getTime()));
		}

		transaction.setTransactionParticularCode(rs.getString(TRANCODE.name()));
		transaction.setTransactionParticulars(rs.getString(TRANDESC.name()));
		transaction.setTransactionAmount(rs.getDouble(AMOUNT.name()));
		transaction.setTransactionCurrencyCode(rs.getString(CURRENCY.name()));
		transaction.setPartTransactionType(rs.getString(TXNTYPE.name()));
		transaction.setAvailableBalance(rs.getDouble(AVAILABLEBAL.name()));
		transaction.setTranCategory(rs.getString(TRAN_CTGR.name()));
		transaction.setTransactionReferenceNumber(rs.getString(RELATEDTRANREF.name()));
		transaction.setAdditionalReference(rs.getString(TRAN_CMMNT.name()));
		transaction.setRelatedRecordId(rs.getString(RELATEDRECID.name()));
		transaction.setTransactionId(rs.getString(TRANID.name()));
		transaction.setPartTransactionSerialNumber(rs.getLong(TRANSEQNUM.name()));
		return transaction;
	}

	/**
	 * This method is used to update transaction category Details into the TDS DB.
	 *
	 * @param transactionNotification : {@link TransactionNotification}
	 * @return {@link TransactionNotification}
	 */
	@Override
	public TransactionNotification updateTransactionCategory(TransactionNotification transactionNotification) {

		int rowsAffected = 0;
		Date currentDate = new Date();
		MapSqlParameterSource parameterSource = new MapSqlParameterSource();
		parameterSource
				.addValue(TRANKEY.name(), transactionNotification.getTranKey());

		String extTranId = this.namedParameterJdbcTemplate.query(this.extTranIdExtract,
				parameterSource,
				(RowMapper<String>) (paramResultSet, paramInt) -> paramResultSet.getString(1)).get(0);

		if (null != extTranId && !extTranId.isEmpty()) {
			parameterSource
					.addValue(LST_UPDT_DTTM.name(), currentDate)
					.addValue(TRAN_CTGR.name(), transactionNotification.getTranCategory())
					.addValue(IMAGE.name(), transactionNotification.getPhoto())
					.addValue(TRAN_CMMNT.name(), transactionNotification.getNotes());

			rowsAffected = rowsAffected
					+ updateImageInTDS(parameterSource, transactionNotification)
					+ updateCategoryNotesInTDS(parameterSource, transactionNotification);

			LOGGER.info("No of rows affected : {}", rowsAffected);
			transactionNotification.setExtTranId(extTranId);
		}
		else {
			transactionNotification.setError(true);
			transactionNotification.setErrorReason("Ext Tran ID not present.");
			transactionNotification.setErrorMessage("Transaction Update Failed. Please try after some time.");
		}
		return transactionNotification;
	}

	/**
	 * This method is used to update the Image Field in TDS DB.
	 *
	 * @param parameterSource : {@link MapSqlParameterSource}
	 * @param transactionNotification : {@link TransactionNotification}
	 * @return {@link Integer}
	 */
	private int updateImageInTDS(MapSqlParameterSource parameterSource,
			TransactionNotification transactionNotification) {
		int result = 0;
		if (transactionNotification.getPhoto() != null) {
			result = this.namedParameterJdbcTemplate.execute(this.imageUpdateQuery, parameterSource,
					(PreparedStatementCallback<Integer>) paramPreparedStatement -> paramPreparedStatement
							.executeUpdate());
		}
		return result;
	}

	/**
	 * This method is used to update the Category and Notes Field in TDS DB.
	 *
	 * @param parameterSource : {@link MapSqlParameterSource}
	 * @param transactionNotification : {@link TransactionNotification}
	 * @return {@link Integer}
	 */
	private int updateCategoryNotesInTDS(MapSqlParameterSource parameterSource,
			TransactionNotification transactionNotification) {

		int result = 0;
		if (null != transactionNotification.getNotes() || null != transactionNotification.getTranCategory()) {
			StringBuilder categoryNotesUpdateQuery = new StringBuilder(
					"Insert into T_DTA_DIM(TRANKEY, TRAN_CTGR, TRAN_CMMNT, LST_UPDT_SYS_ID) values "
							+ "(:TRANKEY, :TRAN_CTGR, :TRAN_CMMNT, 'CustomerOperation') ON DUPLICATE KEY UPDATE ");

			if (null != transactionNotification.getNotes()) {
				categoryNotesUpdateQuery.append("TRAN_CMMNT= :TRAN_CMMNT, ");
			}

			if (null != transactionNotification.getTranCategory()) {
				categoryNotesUpdateQuery.append("TRAN_CTGR= :TRAN_CTGR, ");
			}

			categoryNotesUpdateQuery.append("LST_UPDT_SYS_ID= 'CustomerOperation';");

			LOGGER.info("Query for Category and Notes Update : {}", categoryNotesUpdateQuery);

			result = this.namedParameterJdbcTemplate.execute(categoryNotesUpdateQuery.toString(), parameterSource,
					(PreparedStatementCallback<Integer>) paramPreparedStatement -> paramPreparedStatement
							.executeUpdate());
		}

		return result;
	}

	/**
	 * This method is used to retrieve transaction details from TDS DB.
	 *
	 * @param transactionDetailsRequest : {@link TransactionDetailsRequest}
	 * @return TransactionDetailsResponse {@link TransactionDetailsResponse}
	 * @throws TransactionHistoryException {@link TransactionHistoryException}
	 */
	@Override
	public TransactionDetailsResponse retrieveTransactionDetails(
			TransactionDetailsRequest transactionDetailsRequest) throws TransactionHistoryException {
		LOGGER.info("retrieving TransactionDetails with tranKey={}",
				transactionDetailsRequest.getTranKey());
		TransactionDetailsResponse transactionDetailsresponse = new TransactionDetailsResponse();

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue(TRANKEY.name(), transactionDetailsRequest.getTranKey());
		TransactionNotification transactionDetails = null;

		try {
			transactionDetails = this.namedParameterJdbcTemplate.queryForObject(
					this.transactionDetailsQuery, paramSource,
					(RowMapper<TransactionNotification>) (rs, rowNum) -> {
						TransactionNotification transaction = new TransactionNotification();

						/*
						 * Transaction date and value date returned from SOI are pointed
						 * to value date and trans date respectively. So to maintain
						 * consistency in Kony UI, TDS has to swap the mapping as there is
						 * no option to fix at SOI end.
						 */

						if (rs.getTimestamp(VALUEDATE.name()) != null) {
							transaction.setTransactionDate(new Date(rs.getTimestamp(VALUEDATE.name()).getTime()));
						}
						if (rs.getTimestamp(TRANDATE.name()) != null) {
							transaction.setValueDate(new Date(rs.getTimestamp(TRANDATE.name()).getTime()));
						}
						if (rs.getTimestamp(POSTINGDATE.name()) != null) {
							transaction.setPostedDate(new Date(rs.getTimestamp(POSTINGDATE.name()).getTime()));
						}
						transaction.setPartTransactionSerialNumber(rs.getLong(TRANSEQNUM.name()));
						transaction.setTransactionParticularCode(rs.getString(TRANCODE.name()));
						transaction.setTransactionParticulars(rs.getString(TRANDESC.name()));
						transaction.setTransactionAmount(rs.getDouble(AMOUNT.name()));
						transaction.setTransactionCurrencyCode(rs.getString(CURRENCY.name()));
						transaction.setPartTransactionType(rs.getString(TXNTYPE.name()));
						transaction.setAvailableBalance(rs.getDouble(AVAILABLEBAL.name()));
						transaction.setTransactionReferenceNumber(rs.getString(RELATEDTRANREF.name()));
						transaction.setAdditionalReference(rs.getString(ADDNLREF.name()));
						transaction.setRelatedRecordId(rs.getString(RELATEDRECID.name()));
						transaction.setTransactionId(rs.getString(TRANID.name()));
						transaction.setNotes(rs.getString(TRAN_CMMNT.name()));
						transaction.setTranCategory(rs.getString(TRAN_CTGR.name()));
						transaction.setTranKey(rs.getString(TRANKEY.name()));
						transaction.setPhoto(rs.getBlob(IMAGE.name()));

						return transaction;
					});
			MDC.put(STATUS_CODE_KEY.value(), StatusCodes.SUCCESS.value());
			MDC.put(STATUS_CODE_DES_KEY.value(), StatusCodes.SUCCESS.name());
			MDC.put(ERROR_TYPE.value(), "");
		}
		catch (DataAccessException e) {
			MDC.put(STATUS_CODE_KEY.value(), StatusCodes.FAILURE.value());
			MDC.put(STATUS_CODE_DES_KEY.value(), StatusCodes.FAILURE.name());
			MDC.put(ERROR_TYPE.value(), ErrorConstants.FUNC.name());
			throw new TransactionHistoryException(
					"No Record Found that matches the TransactionDetails =" + transactionDetailsRequest);
		}
		transactionDetailsresponse.setTransactionDetails(transactionDetails);

		LOGGER.info("retrieved TransactionDetails = ", transactionDetailsresponse);
		return transactionDetailsresponse;
	}

}
