package com.dbs.tds.transactionhistoryapi.service;

import javax.xml.datatype.DatatypeConfigurationException;

import com.dbs.schemas.soi.common._4_0.DetailInfo;
import com.dbs.schemas.soi.common._4_0.InfoWarn;
import com.dbs.schemas.soi.common._4_0.ServiceProvider;
import com.dbs.tds.transactionhistoryapi.exception.ErrorCodes;
import com.dbs.tds.transactionhistoryapi.exception.ErrorLevel;
import com.dbs.tds.util.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Component;

import static com.dbs.tds.transactionhistoryapi.constant.TransactionConstantFields.TDSIN;

@Component
public class PositionKeepingResponseHeaderService {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(PositionKeepingResponseHeaderService.class);

	public InfoWarn getPaginationInfoHeader() {

		String moreRecordFound = "S100";
		ErrorCodes errorCode = ErrorCodes.valueOf(moreRecordFound);

		org.xmlsoap.schemas.soap.envelope.Fault fault = new org.xmlsoap.schemas.soap.envelope.Fault();
		fault.setFaultcode(errorCode.getFaultCode());
		fault.setFaultstring(errorCode.getDescription());
		fault.setFaultactor(TDSIN.value());

		generated.Detail detail = new generated.Detail();

		DetailInfo detailInfo = getDetailinfo(moreRecordFound, ErrorLevel.INFO);
		detailInfo
				.setStatusDesc("More Records are available. Please send a subsequent Request to fetch further details");
		detail.getDetailInfo().add(detailInfo);
		fault.setDetail(detail);

		InfoWarn infoWarn = new InfoWarn();
		infoWarn.setAny(fault);

		return infoWarn;
	}

	public InfoWarn noRecordsFoundHeader() {

		String noRecordFoundCode = "S001";
		ErrorCodes errorCode = ErrorCodes.valueOf(noRecordFoundCode);

		org.xmlsoap.schemas.soap.envelope.Fault fault = new org.xmlsoap.schemas.soap.envelope.Fault();
		fault.setFaultcode(errorCode.getFaultCode());
		fault.setFaultstring(errorCode.getDescription());
		fault.setFaultactor(TDSIN.value());

		generated.Detail detail = new generated.Detail();

		DetailInfo detailInfo = getDetailinfo(noRecordFoundCode, ErrorLevel.INFO);
		detail.getDetailInfo().add(detailInfo);
		fault.setDetail(detail);

		InfoWarn infoWarn = new InfoWarn();
		infoWarn.setAny(fault);

		return infoWarn;
	}

	public DetailInfo getDetailinfo(String errorCodeNum, ErrorLevel errorLevel) {

		ErrorCodes errorCode = ErrorCodes.valueOf(errorCodeNum);

		DetailInfo detailInfo = new DetailInfo();
		detailInfo.setSeverity(errorLevel.name());
		detailInfo.setStatusCode(errorCodeNum);
		detailInfo.setStatusDesc(errorCode.getDescription());

		return detailInfo;
	}

	/***
	 *
	 * This method is used to build {@link ServiceProvider}
	 * @return
	 */
	public ServiceProvider getServiceProvider() {
		ServiceProvider serviceProvider = new ServiceProvider();
		try {
			serviceProvider.setSPId("TDSIN");
			serviceProvider.setSPDateTime(DateUtil.getCurrentXMLGregorianCalendarDate());
			serviceProvider.setMustUnderstand(true);
		}
		catch (DatatypeConfigurationException e) {
			LOGGER.error("Error In creating XMLGregorianCalendar Object");
		}

		return serviceProvider;
	}
}