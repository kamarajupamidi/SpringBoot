package com.dbs.tds.transactionhistoryapi;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;

/**
 * This class is used to initialize the Servlet for this Spring Boot application, so that
 * the WAR file for this application can be deployed on JBoss Server.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public class ServletInitializer extends SpringBootServletInitializer {

	/**
	 * This method is an overridden method from its parent class which is used to
	 * configure the servlet which will be initialized by this class.
	 *
	 * @param application : {@link SpringApplicationBuilder}
	 * @return {@link SpringApplicationBuilder}
	 */
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(TransactionHistoryApiApplication.class);
	}

}
