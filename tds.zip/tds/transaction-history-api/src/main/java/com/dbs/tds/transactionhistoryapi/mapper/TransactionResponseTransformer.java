/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: TransactionTransformer.java
 * Author: DBS Asia Hub 2
 * Date: Aug 31, 2017
 */
package com.dbs.tds.transactionhistoryapi.mapper;

import java.math.BigInteger;
import java.util.List;

import com.dbs.schemas.soi.common._4_1.Amount;
import com.dbs.schemas.soi.common._4_1.CommonRs;
import com.dbs.schemas.soi.common._4_1.RecCtrlOut;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.Category;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePersonalFinanceTrans;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePersonalFinanceTransResponse;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePersonalFinanceTransResponse.TranDetail;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePersonalFinanceTransResponse.TranDetail.Categories;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.TranDetailExt;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.TranFDHistInq;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.TranFDHistInqResponse;
import com.dbs.tds.dto.TransactionHistoryResponse;
import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistoryapi.exception.TransactionHistoryException;
import com.dbs.tds.util.CommonUtils;
import com.dbs.tds.util.DateUtil;
import org.apache.commons.lang3.StringUtils;

import org.springframework.stereotype.Component;

import static com.dbs.tds.transactionhistoryapi.constant.TransactionConstantFields.C;
import static com.dbs.tds.transactionhistoryapi.constant.TransactionConstantFields.CR;
import static com.dbs.tds.transactionhistoryapi.constant.TransactionConstantFields.DR;

/**
 * This class is used to transform the details from Source instance to Destination
 * Instance.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Component
public class TransactionResponseTransformer {

	/**
	 * This method is used to transform List of TransactionHistoryResponse to
	 * corresponding RetrievePersonalFinanceTransResponse response
	 *
	 * @param transactionResponse : {@link TransactionHistoryResponse}
	 * @param retrievePersonalFinanceTransRq : {@link RetrievePersonalFinanceTrans}
	 *
	 * @return {@link RetrievePersonalFinanceTransResponse}
	 */
	public RetrievePersonalFinanceTransResponse transformTransactionHistory(
			TransactionHistoryResponse transactionResponse,
			RetrievePersonalFinanceTrans retrievePersonalFinanceTransRq) {
		RetrievePersonalFinanceTransResponse retrievePersonalFinanceTransResponse = new RetrievePersonalFinanceTransResponse();

		retrievePersonalFinanceTransResponse.setCustInternalId(retrievePersonalFinanceTransRq.getCustInternalId());
		retrievePersonalFinanceTransResponse.setCISInternalId(retrievePersonalFinanceTransRq.getCISInternalId());
		retrievePersonalFinanceTransResponse
				.setAltCustInternalId(retrievePersonalFinanceTransRq.getAltCustInternalId());
		retrievePersonalFinanceTransResponse.setDepAcctId(retrievePersonalFinanceTransRq.getDepAcctId());
		retrievePersonalFinanceTransResponse.setStartDate(retrievePersonalFinanceTransRq.getStartDate());
		retrievePersonalFinanceTransResponse.setEndDate(retrievePersonalFinanceTransRq.getEndDate());
		retrievePersonalFinanceTransResponse.setDeliveryMethod(retrievePersonalFinanceTransRq.getDeliveryMethod());

		CommonRs commonRs = getCommonRs(retrievePersonalFinanceTransRq.getCommonRq().getOrgCode(),
				retrievePersonalFinanceTransRq.getCommonRq().getRqSysRef());

		retrievePersonalFinanceTransResponse.setCommonRs(commonRs);

		RecCtrlOut recCtrlOut = new RecCtrlOut();

		if (transactionResponse.getTotalCount() > transactionResponse.getLastIndex()) {
			recCtrlOut.setCursor(String.valueOf(transactionResponse.getCursor() + 1));
		}

		recCtrlOut.setSentRec(BigInteger.valueOf(transactionResponse.getCurrentPageCount()));
		retrievePersonalFinanceTransResponse.setRecCtrlOut(recCtrlOut);
		retrievePersonalFinanceTransResponse.setLastTranRef(String.valueOf(transactionResponse.getTotalCount()));

		getTransactionDetails(transactionResponse.getTransactions(), retrievePersonalFinanceTransResponse);
		return retrievePersonalFinanceTransResponse;
	}

	/**
	 * This method is used to map Transaction details of the customer and add
	 * corresponding list to the RetrievePersonalFinanceTransResponse object
	 *
	 * @param transNotifications : {@link List}<{@link TransactionNotification}>
	 * @param retrievePersonalFinanceTransResponse :
	 * {@link RetrievePersonalFinanceTransResponse}
	 *
	 */
	private void getTransactionDetails(List<TransactionNotification> transNotifications,
			RetrievePersonalFinanceTransResponse retrievePersonalFinanceTransResponse) {
		for (TransactionNotification transnotification : transNotifications) {

			TranDetail tranDetailForPersonalFinance = new TranDetail();
			tranDetailForPersonalFinance.setTranSeqNum(transnotification.getTranKey());

			tranDetailForPersonalFinance
					.setTranDate(DateUtil.getXMLGregorianCalendarDate(transnotification.getTransactionDate()));
			tranDetailForPersonalFinance
					.setTranTime(DateUtil.getXMLGregorianCalendarTime(transnotification.getTransactionDate()));

			tranDetailForPersonalFinance
					.setValueDate(DateUtil.getXMLGregorianCalendarDate(transnotification.getValueDate()));

			if (transnotification.getPostedDate() != null) {
				tranDetailForPersonalFinance
						.setPostingDate(DateUtil.getXMLGregorianCalendarDate(transnotification.getPostedDate()));
				tranDetailForPersonalFinance
						.setPostingTime(DateUtil.getXMLGregorianCalendarTime(transnotification.getPostedDate()));
			}

			tranDetailForPersonalFinance.setTranCode(transnotification.getTransactionParticularCode());
			tranDetailForPersonalFinance.setTranCodeDesc(transnotification.getTransactionParticulars());

			Amount tranAmount = getAmount(transnotification.getTransactionAmount(),
					transnotification.getTransactionCurrencyCode());
			tranDetailForPersonalFinance.setTranAmt(tranAmount);
			tranDetailForPersonalFinance.setCrDrInd(
					C.value().equalsIgnoreCase(transnotification.getPartTransactionType()) ? CR.value() : DR.value());

			Amount transactionBalance = getAmount(transnotification.getAvailableBalance(),
					transnotification.getTransactionCurrencyCode());
			tranDetailForPersonalFinance.setTranBal(transactionBalance);

			Categories categories = new Categories();
			Category category = new Category();
			category.setCategoryName(transnotification.getTranCategory());
			categories.getCategory().add(category);
			tranDetailForPersonalFinance.setCategories(categories);

			tranDetailForPersonalFinance.setRelatedTranRef(transnotification.getTransactionReferenceNumber());

			if (StringUtils.isNotBlank(transnotification.getAdditionalReference())) {
				tranDetailForPersonalFinance.getAddnlRef().add(transnotification.getAdditionalReference());
			}

			tranDetailForPersonalFinance.setRelatedRecId(transnotification.getRelatedRecordId());

			tranDetailForPersonalFinance.setSPTranRef(transnotification.getTransactionId());
			if (transnotification.getPartTransactionSerialNumber() != null) {
				tranDetailForPersonalFinance
						.setSPTranSerialNo(String.valueOf(transnotification.getPartTransactionSerialNumber()));
			}

			retrievePersonalFinanceTransResponse.getTranDetail().add(tranDetailForPersonalFinance);
		}
	}

	/**
	 * This method is used to map Transaction details of the customer and add
	 * corresponding list to the TranFDHistInqResponse object
	 *
	 * @param transNotifications : {@link List}<{@link TransactionNotification}>
	 * @param tranFDHistInqResponse : {@link TranFDHistInqResponse}
	 */
	private void getTransactionDetails(List<TransactionNotification> transNotifications,
			TranFDHistInqResponse tranFDHistInqResponse) {

		for (TransactionNotification transnotification : transNotifications) {
			TranFDHistInqResponse.TranDetail tranDetailForTranFDHist = new TranFDHistInqResponse.TranDetail();
			tranDetailForTranFDHist.setTranSeqNum(transnotification.getTranKey());

			tranDetailForTranFDHist
					.setTranDate(DateUtil.getXMLGregorianCalendarDate(transnotification.getTransactionDate()));
			tranDetailForTranFDHist
					.setTranTime(DateUtil.getXMLGregorianCalendarTime(transnotification.getTransactionDate()));
			tranDetailForTranFDHist
					.setValueDate(DateUtil.getXMLGregorianCalendarDate(transnotification.getValueDate()));

			if (transnotification.getPostedDate() != null) {
				tranDetailForTranFDHist
						.setPostingDate(DateUtil.getXMLGregorianCalendarDate(transnotification.getPostedDate()));
				tranDetailForTranFDHist
						.setPostingTime(DateUtil.getXMLGregorianCalendarTime(transnotification.getPostedDate()));
			}
			tranDetailForTranFDHist.setTranCode(transnotification.getTransactionParticularCode());
			tranDetailForTranFDHist.setTranCodeDesc(transnotification.getTransactionParticulars());

			Amount tranAmount = getAmount(transnotification.getTransactionAmount(),
					transnotification.getTransactionCurrencyCode());
			tranDetailForTranFDHist.setTranAmt(tranAmount);
			tranDetailForTranFDHist.setCrDrInd(
					C.value().equalsIgnoreCase(transnotification.getPartTransactionType()) ? CR.value() : DR.value());
			tranDetailForTranFDHist.setRelatedTranRef(transnotification.getTransactionReferenceNumber());
			if (StringUtils.isNotBlank(transnotification.getAdditionalReference())) {
				tranDetailForTranFDHist.getAddnlRef().add(transnotification.getAdditionalReference());
			}
			tranDetailForTranFDHist.setRelatedRecId(transnotification.getRelatedRecordId());
			tranFDHistInqResponse.getTranDetail().add(tranDetailForTranFDHist);

		}

	}

	/**
	 * This method is used to transform List of TransactionHistoryResponse to
	 * corresponding TranFDHistInqResponse response
	 *
	 * @param transactionResponse : {@link TransactionHistoryResponse}
	 * @param tranFDHistInqRq : {@link TranFDHistInq}
	 *
	 * @return {@link TranFDHistInqResponse}
	 */
	public TranFDHistInqResponse transformTransactionHistory(TransactionHistoryResponse transactionResponse,
			TranFDHistInq tranFDHistInqRq) {
		TranFDHistInqResponse tranFDHistInqResponse = new TranFDHistInqResponse();

		CommonRs commonRs = getCommonRs(tranFDHistInqRq.getCommonRq().getOrgCode(),
				tranFDHistInqRq.getCommonRq().getRqSysRef());
		tranFDHistInqResponse.setCommonRs(commonRs);

		tranFDHistInqResponse.setDepAcctId(tranFDHistInqRq.getDepAcctId());
		tranFDHistInqResponse.setStartDate(tranFDHistInqRq.getStartDate());
		tranFDHistInqResponse.setEndDate(tranFDHistInqRq.getEndDate());
		tranFDHistInqResponse.setLastNoOfTran(tranFDHistInqRq.getLastNoOfTran());
		tranFDHistInqResponse.setDeliveryMethod(tranFDHistInqRq.getDeliveryMethod());

		RecCtrlOut recCtrlOut = new RecCtrlOut();

		if (transactionResponse.getTotalCount() > transactionResponse.getLastIndex()) {
			recCtrlOut.setCursor(String.valueOf(transactionResponse.getCursor() + 1));
		}

		recCtrlOut.setSentRec(BigInteger.valueOf(transactionResponse.getCurrentPageCount()));
		tranFDHistInqResponse.setRecCtrlOut(recCtrlOut);
		tranFDHistInqResponse.setLastTranRef(String.valueOf(transactionResponse.getTotalCount()));

		getTransactionDetails(transactionResponse.getTransactions(), tranFDHistInqResponse);
		return tranFDHistInqResponse;
	}

	/**
	 * This method is used to map Transaction details to {@link TranDetailExt} object and
	 * return the same
	 * @param transnotification : {@link TransactionNotification}
	 * @return {@link TranDetailExt}
	 * @throws TransactionHistoryException {@link TransactionHistoryException}
	 *
	 */
	public TranDetailExt getTransactionDetails(TransactionNotification transnotification)
			throws TransactionHistoryException {

		TranDetailExt tranDetail = new TranDetailExt();
		tranDetail.setTranSeqNum(transnotification.getTranKey());

		tranDetail.setTranDate(DateUtil.getXMLGregorianCalendarDate(transnotification.getTransactionDate()));
		tranDetail.setTranTime(DateUtil.getXMLGregorianCalendarTime(transnotification.getTransactionDate()));
		tranDetail.setValueDate(DateUtil.getXMLGregorianCalendarDate(transnotification.getValueDate()));

		if (transnotification.getPostedDate() != null) {
			tranDetail.setPostingDate(DateUtil.getXMLGregorianCalendarDate(transnotification.getPostedDate()));
			tranDetail.setPostingTime(DateUtil.getXMLGregorianCalendarTime(transnotification.getPostedDate()));
		}
		tranDetail.setTranCode(transnotification.getTransactionParticularCode());
		tranDetail.setTranCodeDesc(transnotification.getTransactionParticulars());

		Amount tranAmount = getAmount(transnotification.getTransactionAmount(),
				transnotification.getTransactionCurrencyCode());
		tranDetail.setTranAmt(tranAmount);
		tranDetail.setCrDrInd(
				C.value().equalsIgnoreCase(transnotification.getPartTransactionType()) ? CR.value() : DR.value());

		Amount transactionBalance = getAmount(transnotification.getAvailableBalance(),
				transnotification.getTransactionCurrencyCode());
		tranDetail.setTranBal(transactionBalance);
		tranDetail.setSPTranRef(transnotification.getTransactionId());
		tranDetail.setRelatedTranRef(transnotification.getTransactionReferenceNumber());
		if (transnotification.getPartTransactionSerialNumber() != null) {
			tranDetail.setSPTranSerialNo(String.valueOf(transnotification.getPartTransactionSerialNumber()));
		}

		if (StringUtils.isNotBlank(transnotification.getNotes())) {
			tranDetail.getAddnlRef().add(transnotification.getNotes());
		}

		tranDetail.setRelatedRecId(transnotification.getRelatedRecordId());

		tranDetail.setPhoto(CommonUtils.convertBlobToString(transnotification.getPhoto()));

		TranDetailExt.Categories categories = new TranDetailExt.Categories();
		Category category = new Category();
		category.setCategoryName(transnotification.getTranCategory());
		categories.getCategory().add(category);
		tranDetail.setCategories(categories);

		return tranDetail;
	}

	/***
	 * This method is used to build {@link CommonRs} object
	 * @param orgCode {@link String}
	 * @param rqSysRef {@link String}
	 * @return {@link CommonRs}
	 */
	public CommonRs getCommonRs(String orgCode, String rqSysRef) {
		CommonRs commonRs = new CommonRs();
		commonRs.setOrgCode(orgCode);
		commonRs.setRqSysRef(rqSysRef);
		return commonRs;
	}

	/***
	 * This method is used to build {@link Amount} object
	 * @param amountValue {@link Double}
	 * @param currencyCode {@link String}
	 * @return {@link Amount}
	 */
	private Amount getAmount(Double amountValue, String currencyCode) {
		Amount amount = new Amount();
		amount.setAmt(amountValue);
		amount.setCur(currencyCode);
		return amount;
	}

}
