package com.dbs.tds.transactionhistoryapi.dao;

import com.dbs.tds.dto.TransactionDetailsRequest;
import com.dbs.tds.dto.TransactionDetailsResponse;
import com.dbs.tds.dto.TransactionHistoryRequest;
import com.dbs.tds.dto.TransactionHistoryResponse;
import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistoryapi.exception.TransactionHistoryException;

import org.springframework.stereotype.Repository;

/**
 * This interface is used to provide abstract functionalities for interacting with TDS DB
 * for Transaction Read/Update operations.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Repository
public interface TransactionRepository {

	/***
	 *
	 * This method is used to fetch Transaction History from TDS DB based for a specified
	 * transactionHistoryRequest account number
	 * @param transactionHistoryRequest : {@link TransactionHistoryRequest}
	 * @return TransactionHistoryResponse {@link TransactionHistoryResponse}
	 */
	public TransactionHistoryResponse getTransactionhistory(TransactionHistoryRequest transactionHistoryRequest);

	/**
	 * This method is used to update transaction details in TDS DB.
	 *
	 * @param transactionNotification : {@link TransactionNotification}
	 * @return {@link TransactionNotification}
	 */
	public TransactionNotification updateTransactionCategory(TransactionNotification transactionNotification);

	/**
	 * This method is used to retrieve transaction details from TDS DB.
	 *
	 * @param transactionDetailsRequest : {@link TransactionDetailsRequest}
	 * @return TransactionDetailsResponse {@link TransactionDetailsResponse}
	 * @throws TransactionHistoryException {@link TransactionHistoryException}
	 */
	public TransactionDetailsResponse retrieveTransactionDetails(
			TransactionDetailsRequest transactionDetailsRequest) throws TransactionHistoryException;
}
