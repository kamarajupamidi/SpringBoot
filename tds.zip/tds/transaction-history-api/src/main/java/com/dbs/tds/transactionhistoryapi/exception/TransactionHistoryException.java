package com.dbs.tds.transactionhistoryapi.exception;

/**
 * This class is used as the exception which will be thrown whenever there is any
 * exception occurred during the processing.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public class TransactionHistoryException extends Exception {

	/**
	 * This field is used to store value for serialVersionUID which is of type {@link long
	 * }.
	 */
	private static final long serialVersionUID = 3069778477268575602L;

	/**
	 * This field is used to store value for message which is of type {@link String }.
	 */
	private final String message;

	/**
	 * Custom Exception for reading transactions.
	 * @param message : {@link String }
	 */
	public TransactionHistoryException(String message) {
		super(message);
		this.message = message;
	}

	/**
	 * This method is used to get property message of class
	 * {@link TransactionHistoryException }.
	 *
	 * @return message : {@link String }
	 */
	@Override
	public String getMessage() {
		return this.message;
	}

}
