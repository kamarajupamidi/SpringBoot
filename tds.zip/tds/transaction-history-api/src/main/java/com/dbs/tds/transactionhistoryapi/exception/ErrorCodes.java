package com.dbs.tds.transactionhistoryapi.exception;

public enum ErrorCodes {

	S001(Constants.CANONICAL.value(), "No record found", Constants.SERVER.value()),
	S002(Constants.CANONICAL.value(), "Account Not Found", Constants.CLIENT.value()),
	S022(Constants.CANONICAL.value(), "Invalid Customer Id", Constants.CLIENT.value()),
	S100(Constants.CANONICAL.value(), "More Records Available", Constants.CLIENT.value()),
	S999(Constants.CANONICAL.value(), "System Error", Constants.SERVER.value());

	/**
	 * This field is used to store value for errorType which is of type {@link String }.
	 */
	private String errorType;

	/**
	 * This field is used to store value for description which is of type {@link String }.
	 */
	private String description;

	/**
	 * This field is used to store value for faultCode which is of type {@link String }.
	 */
	private String faultCode;

	/**
	 * This is used to initialize the enum properties.
	 *
	 * @param errorType : {@link String}
	 * @param description : {@link String}
	 * @param faultCode : {@link String}
	 */
	private ErrorCodes(String errorType, String description, String faultCode) {
		this.errorType = errorType;
		this.description = description;
		this.faultCode = faultCode;
	}

	/**
	 * This method is used to get property errorType of class {@link ErrorCodes }.
	 *
	 * @return errorType : {@link String }
	 */
	public String getErrorType() {
		return this.errorType;
	}

	/**
	 * This method is used to get property description of class {@link ErrorCodes }.
	 *
	 * @return description : {@link String }
	 */
	public String getDescription() {
		return this.description;
	}

	/**
	 * This method is used to get property faultCode of class {@link ErrorCodes }.
	 *
	 * @return faultCode : {@link String }
	 */
	public String getFaultCode() {
		return this.faultCode;
	}

	/**
	 * This enum is used for defining the error details.
	 *
	 * @author DBS Asia Hub 2
	 * @version 1.0
	 *
	 */
	private enum Constants {

		SERVER("Server"),
		CLIENT("Client"),
		CANONICAL("CANONICAL");

		/**
		 * This field is used to store value for value which is of type {@link String }.
		 */
		private String value;

		/**
		 * @param value
		 */
		Constants(String value) {
			this.value = value;
		}

		/**
		 * This method is used to get property value of class
		 * {@link ErrorCodes.Constants }.
		 *
		 * @return value : {@link String }
		 */
		public String value() {
			return this.value;
		}

	}

}
