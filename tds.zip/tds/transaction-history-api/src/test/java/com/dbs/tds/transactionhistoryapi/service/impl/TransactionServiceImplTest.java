package com.dbs.tds.transactionhistoryapi.service.impl;

import java.util.Date;

import javax.xml.ws.Holder;

import com.dbs.schemas.soi.common._4_0.InfoWarn;
import com.dbs.schemas.soi.common._4_0.ServiceProvider;
import com.dbs.schemas.soi.common._4_0.Trace;
import com.dbs.schemas.soi.common._4_1.CommonRq;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.AdministerTransaction;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrieveTransactionDetails;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrieveTransactionDetailsResponse;
import com.dbs.tds.dto.TransactionDetailsRequest;
import com.dbs.tds.dto.TransactionDetailsResponse;
import com.dbs.tds.dto.TransactionHistoryRequest;
import com.dbs.tds.dto.TransactionHistoryResponse;
import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistoryapi.dao.TransactionRepository;
import com.dbs.tds.transactionhistoryapi.exception.TransactionHistoryException;
import com.dbs.tds.transactionhistoryapi.mapper.TransactionRequestTransformer;
import com.dbs.tds.transactionhistoryapi.mapper.TransactionResponseTransformer;
import com.dbs.tds.transactionhistoryapi.service.PositionKeepingResponseHeaderService;
import com.dbs.tds.util.CommonUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TransactionServiceImplTest {

	@Mock
	private TransactionRepository transactionRepo;

	@Mock
	private TransactionRequestTransformer transactionRequestTransformer;

	@Mock
	private TransactionResponseTransformer transactionResponseTransformer;

	@Mock
	private TransactionHistoryRequest transactionHistReq;

	@Mock
	private TransactionHistoryResponse transactionHistRes;

	@Mock
	private TransactionDetailsRequest transactionDetailsRequest;

	@Mock
	private TransactionDetailsResponse transactionDetailsResponse;

	@Spy
	private RetrieveTransactionDetails retrieveTransactionDetails = getTranReq();

	@Mock
	private RetrieveTransactionDetailsResponse retrieveTransactionDetailsResponse;

	@Mock
	private AdministerTransaction administerTransaction;

	@Spy
	private TransactionNotification transactionNotification = getTranNotification();

	@Mock
	private PositionKeepingResponseHeaderService positionKeepingResponseHeaderService;

	private Holder<InfoWarn> part4 = new Holder<>();

	private Holder<Trace> part2 = new Holder<>();

	@InjectMocks
	private TransactionServiceImpl transactionServiceImpl;

	@Mock
	private ServiceProvider serviceProvider;

	@Before
	public void setUp() {
		Trace trace = new Trace();
		this.part2.value = trace;
	}

	@Test
	public void testGetTransactionHistory() {
		when(this.transactionRepo.getTransactionhistory(this.transactionHistReq)).thenReturn(this.transactionHistRes);

		TransactionHistoryResponse transactionHistResp = this.transactionServiceImpl
				.getTransactionHistory(this.transactionHistReq);
		assertNotNull("Response not received", transactionHistResp);
		verify(this.transactionRepo).getTransactionhistory(this.transactionHistReq);
		verify(this.transactionHistReq).getAcctId();
		verifyNoMoreInteractions(this.transactionRepo, this.transactionHistReq);
	}

	@Test
	public void testUpdateTransactionDetails() {
		TransactionNotification notification = new TransactionNotification();
		notification.setExtTranId("123");
		when(this.transactionRequestTransformer.transformFromSoapToTDS(this.administerTransaction))
				.thenReturn(this.transactionNotification);
		when(this.transactionRepo.updateTransactionCategory(this.transactionNotification))
				.thenReturn(notification);

		TransactionNotification result = this.transactionServiceImpl
				.updateTransactionDetails(this.administerTransaction);

		assertSame("Value of Ext Tran ID should be same", notification.getExtTranId(), result.getExtTranId());
		verify(this.transactionRequestTransformer).transformFromSoapToTDS(this.administerTransaction);
		verify(this.transactionRepo).updateTransactionCategory(this.transactionNotification);
		verifyNoMoreInteractions(this.transactionRequestTransformer, this.transactionNotification,
				this.transactionRepo);
	}

	/***
	 *
	 * This method contains test cases for transaction details retrieval service method
	 * invoke
	 * @throws TransactionHistoryException
	 */
	@Test
	public void testRetrieveTransactionDetails() throws TransactionHistoryException {

		when(this.transactionRequestTransformer.transformToTransactionDetailsRequest(this.retrieveTransactionDetails))
				.thenReturn(this.transactionDetailsRequest);
		when(this.transactionRepo
				.retrieveTransactionDetails(this.transactionDetailsRequest))
						.thenReturn(this.transactionDetailsResponse);
		when(this.positionKeepingResponseHeaderService.getServiceProvider()).thenReturn(this.serviceProvider);

		this.transactionServiceImpl.retrieveTransactionDetails(this.retrieveTransactionDetails, null, this.part2, null,
				null);

	}

	/***
	 *
	 * This method contains test cases for transaction details retrieval service method
	 * invoke when exception is thrown
	 * @throws TransactionHistoryException
	 */
	@Test
	public void testRetrieveTransactionDetailsExceptionCase() throws TransactionHistoryException {

		when(this.transactionRequestTransformer.transformToTransactionDetailsRequest(this.retrieveTransactionDetails))
				.thenReturn(this.transactionDetailsRequest);
		when(this.positionKeepingResponseHeaderService.getServiceProvider()).thenReturn(this.serviceProvider);

		doThrow(TransactionHistoryException.class).when(this.transactionRepo)
				.retrieveTransactionDetails(this.transactionDetailsRequest);

		this.transactionServiceImpl.retrieveTransactionDetails(this.retrieveTransactionDetails, null, this.part2, null,
				this.part4);

	}

	private RetrieveTransactionDetails getTranReq() {

		RetrieveTransactionDetails req = new RetrieveTransactionDetails();
		req.setCommonRq(getCommonRq());
		req.setTranSeqNum("123");
		req.setCustInternalId("1234");
		return req;
	}

	private CommonRq getCommonRq() {
		CommonRq commonReq = new CommonRq();
		commonReq.setOrgCode("2009");
		commonReq.setChannelId("1234");
		commonReq.setRqSysRef("ref");

		return commonReq;
	}

	private TransactionNotification getTranNotification() {
		TransactionNotification notification = new TransactionNotification();
		notification.setExtTranId("1234");
		notification.setTranKey("123456");
		notification.setTransactionDate(new Date());
		notification.setPostedDate(new Date());
		notification.setValueDate(new Date());
		notification.setTranCategory("category");
		notification.setNotes("notes");
		notification.setPhoto(CommonUtils.convertStringToBlob("blob-data"));

		return notification;
	}

}
