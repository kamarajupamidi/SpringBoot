package com.dbs.tds.transactionhistoryapi;

import javax.sql.DataSource;

import org.apache.cxf.bus.spring.SpringBus;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

@Configuration
@ComponentScan({ "com.dbs.tds.transactionhistoryapi.repository.impl" })
@Import(TransactionHistoryApiApplication.class)
public class TransactionHistoryApiRepoConfig {

	@Bean
	public DataSource dataSource() {
		return new EmbeddedDatabaseBuilder()
				.addScripts("table_schema.sql", "data.sql")
				.setType(EmbeddedDatabaseType.H2).build();
	}

	@Bean
	public SpringBus springBus() {
		return new SpringBus();
	}

}
