package com.dbs.tds.transactionhistoryapi.mapper;

import java.math.BigInteger;
import java.sql.SQLException;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.dbs.moneythor.dto.CustomField;
import com.dbs.moneythor.dto.MoneyThorTransactionUpdateRequest;
import com.dbs.schemas.soi.common._4_0.DetailInfo;
import com.dbs.schemas.soi.common._4_1.Amount;
import com.dbs.schemas.soi.common._4_1.CommonRq;
import com.dbs.schemas.soi.common._4_1.DepAcct;
import com.dbs.schemas.soi.common._4_1.RecCtrlIn;
import com.dbs.schemas.soi.wsdl.positionkeeping.v1_1.Fault;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.AdministerTransaction;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.TransactionUpdate;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePersonalFinanceTrans;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePersonalFinanceTrans.AmtRange;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrieveTransactionDetails;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.TranFDHistInq;
import com.dbs.tds.dto.TransactionDetailsRequest;
import com.dbs.tds.dto.TransactionHistoryRequest;
import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistoryapi.exception.ErrorLevel;
import com.dbs.tds.transactionhistoryapi.service.PositionKeepingResponseHeaderService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;

import org.springframework.test.context.junit4.SpringRunner;

import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

/***
 * Unit test cases for {@link TransactionRequestTransformer} methods.
 *
 * @author sivanarayana
 *
 * @version 1.0
 */
@RunWith(SpringRunner.class)
public class TransactionRequestTransformerTest {

	private static final String TRAN_SEQ_NUM = "tran-seq-num";

	private static final String CATEGORY_NAME = "category-name";

	private static final String PHOTO = "photo";

	private static final String NOTES = "notes";

	private static final String CUST_INTERNAL_ID = "cust-internal-id";

	private static final String ACCT_ID = "acct-id";

	private static final String SORT_ORDER = "DESC";

	private static final String CURSOR = "1";

	private static final BigInteger MAX_REC = BigInteger.valueOf(10);

	private static final XMLGregorianCalendar START_DATE_XML = getDataTypeFactory().newXMLGregorianCalendar();

	private static final XMLGregorianCalendar END_DATE_XML = getDataTypeFactory().newXMLGregorianCalendar();

	private TransactionRequestTransformer transformer;

	private ConsumerFinanceTransformer consumerFinanceTransformer;

	private AdministerTransaction administerTransaction;

	private RetrievePersonalFinanceTrans retrievePersonalFinanceTransRq;

	private DepAcct depAcct;

	private RecCtrlIn recCtrlIn;

	private TranFDHistInq tranFDHistInq;

	private AmtRange amtRange;

	private Amount fromAmount;

	private Amount toAmount;

	@Mock
	private PositionKeepingResponseHeaderService positionKeepingResponseHeaderService;

	private RetrieveTransactionDetails retrieveTransactionDetailsRq;

	private TransactionDetailsRequest transactionDetailsRequest;

	private CommonRq commonRq;

	private TransactionNotification transactionNotification;

	@Before
	public void setup() {
		this.transformer = new TransactionRequestTransformer(this.positionKeepingResponseHeaderService);
		this.transactionNotification = new TransactionNotification();
		this.consumerFinanceTransformer = new ConsumerFinanceTransformer();

		this.administerTransaction = buildAdministerTransaction();
		this.depAcct = buildDepAcct();
		this.recCtrlIn = buildRecCtrlIn();
		this.fromAmount = buildAmount();
		this.toAmount = buildAmount();
		this.amtRange = buildAmtRange();
		this.retrievePersonalFinanceTransRq = buildRetrievePersonalFinanceTrans();
		this.tranFDHistInq = buildTranFDHistInq();
		this.commonRq = buildCommonRq();
		this.retrieveTransactionDetailsRq = buildRetrieveTransactionDetails();
		this.transactionDetailsRequest = buildTransactionDetailsRequest();

	}

	@Test
	public void testTransformFromSoapToTDS() throws SQLException {
		TransactionNotification tranNotification = this.transformer
				.transformFromSoapToTDS(this.administerTransaction);
		assertNotNull(tranNotification);
		assertEquals(TRAN_SEQ_NUM, tranNotification.getTranKey());
		assertEquals(CATEGORY_NAME, tranNotification.getTranCategory());
		assertNotNull(tranNotification.getPhoto());
		assertEquals(NOTES, tranNotification.getNotes());
	}

	@Test
	public void testTransformFromSoapToMT() {
		MoneyThorTransactionUpdateRequest moneyThorTransactionUpdateRequest = this.consumerFinanceTransformer
				.transformFromSoapToMT(
						this.administerTransaction,
						this.transactionNotification);
		assertNotNull(moneyThorTransactionUpdateRequest);
		List<CustomField> customFields = moneyThorTransactionUpdateRequest.getCustomFields();
		assertThat(customFields, hasSize(3));
	}

	@Test
	public void testTransformToTransactionHistoryRequestRetrievePersonalFinanceTransCredit() throws Fault {
		this.retrievePersonalFinanceTransRq.setCrDrInd("C");
		TransactionHistoryRequest transactionHistoryRequest = this.transformer
				.transformToTransactionHistoryRequest(this.retrievePersonalFinanceTransRq);
		assertNotNull(transactionHistoryRequest);
		assertEquals(ACCT_ID, transactionHistoryRequest.getAcctId());
		assertEquals(SORT_ORDER, transactionHistoryRequest.getSortOrder());
		assertEquals(CURSOR, transactionHistoryRequest.getCursor());
		assertEquals(MAX_REC, transactionHistoryRequest.getMaxRec());
	}

	@Test
	public void testTransformToTransactionHistoryRequestRetrievePersonalFinanceTransDebit() throws Fault {
		this.retrievePersonalFinanceTransRq.setCrDrInd("D");
		TransactionHistoryRequest transactionHistoryRequest = this.transformer
				.transformToTransactionHistoryRequest(this.retrievePersonalFinanceTransRq);
		assertNotNull(transactionHistoryRequest);
		assertEquals(ACCT_ID, transactionHistoryRequest.getAcctId());
		assertEquals(SORT_ORDER, transactionHistoryRequest.getSortOrder());
		assertEquals(CURSOR, transactionHistoryRequest.getCursor());
		assertEquals(MAX_REC, transactionHistoryRequest.getMaxRec());
	}

	@Test
	public void testTransformToTransactionHistoryRequestRetrievePersonalFinanceTransNullCursorNullNaxRecords()
			throws Fault {
		this.recCtrlIn.setCursor(null);
		this.recCtrlIn.setMaxRec(null);
		this.retrievePersonalFinanceTransRq.setCrDrInd("D");
		TransactionHistoryRequest transactionHistoryRequest = this.transformer
				.transformToTransactionHistoryRequest(this.retrievePersonalFinanceTransRq);
		assertNotNull(transactionHistoryRequest);
		assertEquals(ACCT_ID, transactionHistoryRequest.getAcctId());
		assertEquals(SORT_ORDER, transactionHistoryRequest.getSortOrder());
	}

	@Test(expected = Fault.class)
	public void testTransformToTransactionHistoryRequestRetrievePersonalFinanceTransFault() throws Fault {
		this.retrievePersonalFinanceTransRq.setDepAcctId(null);
		when(this.positionKeepingResponseHeaderService.getDetailinfo("S022", ErrorLevel.ERROR))
				.thenReturn(getEmptyDetailInfo());
		this.transformer.transformToTransactionHistoryRequest(this.retrievePersonalFinanceTransRq);
	}

	@Test
	public void testTransformToTransactionHistoryRequestTranFDHistInq() throws Fault {
		TransactionHistoryRequest transactionHistoryReq = this.transformer
				.transformToTransactionHistoryRequest(this.tranFDHistInq);
		assertNotNull(transactionHistoryReq);
		assertEquals(ACCT_ID, transactionHistoryReq.getAcctId());
		assertEquals(SORT_ORDER, transactionHistoryReq.getSortOrder());
		assertEquals(CURSOR, transactionHistoryReq.getCursor());
		assertEquals(MAX_REC, transactionHistoryReq.getMaxRec());
	}

	@Test(expected = Fault.class)
	public void testTransformToTransactionHistoryRequestTranFDHistInqFault() throws Fault {
		this.tranFDHistInq.setDepAcctId(null);
		when(this.positionKeepingResponseHeaderService.getDetailinfo("S022", ErrorLevel.ERROR))
				.thenReturn(getEmptyDetailInfo());
		this.transformer.transformToTransactionHistoryRequest(this.tranFDHistInq);
	}

	@Test
	public void testTransformToTransactionHistoryRequestTranFDHistInqAsc() throws Fault {
		this.tranFDHistInq.setTranDateTimeSeq("A");
		TransactionHistoryRequest transactionHistory = this.transformer
				.transformToTransactionHistoryRequest(this.tranFDHistInq);
		assertNotNull(transactionHistory);
		assertEquals(ACCT_ID, transactionHistory.getAcctId());
		assertEquals("ASC", transactionHistory.getSortOrder());
		assertEquals("1", transactionHistory.getCursor());
		assertEquals(MAX_REC, transactionHistory.getMaxRec());
	}

	/***
	 *
	 * This method contains test cases for transforming {@link RetrieveTransactionDetails}
	 * to {@link TransactionDetailsRequest}
	 * @throws {@link Fault}
	 */
	@Test
	public void testTransformToTransactionDetailsRequest() throws Fault {

		this.transactionDetailsRequest = this.transformer
				.transformToTransactionDetailsRequest(this.retrieveTransactionDetailsRq);
		assertNotNull(this.transactionDetailsRequest);

	}

	private static DatatypeFactory getDataTypeFactory() {
		try {
			return DatatypeFactory.newInstance();
		}
		catch (DatatypeConfigurationException ex) {
			return null;
		}
	}

	private DetailInfo getEmptyDetailInfo() {
		DetailInfo detailInfo = new DetailInfo();
		detailInfo.setSeverity("TEST");
		detailInfo.setStatusCode("TEST");
		detailInfo.setStatusDesc("TEST");
		return detailInfo;
	}

	private TranFDHistInq buildTranFDHistInq() {
		TranFDHistInq tranFDHistIn = new TranFDHistInq();
		tranFDHistIn.setDepAcctId(TransactionRequestTransformerTest.this.depAcct);
		tranFDHistIn.setRecCtrlIn(TransactionRequestTransformerTest.this.recCtrlIn);
		tranFDHistIn.setStartDate(START_DATE_XML);
		tranFDHistIn.setEndDate(END_DATE_XML);
		return tranFDHistIn;
	}

	private CommonRq buildCommonRq() {
		CommonRq commonReq = new CommonRq();
		commonReq.setOrgCode("2009");
		commonReq.setChannelId("12");
		commonReq.setRqSysRef("DGB");
		return commonReq;
	}

	private RetrievePersonalFinanceTrans buildRetrievePersonalFinanceTrans() {
		RetrievePersonalFinanceTrans personalFinanceTrans = new RetrievePersonalFinanceTrans();
		personalFinanceTrans.setDepAcctId(TransactionRequestTransformerTest.this.depAcct);
		personalFinanceTrans.setRecCtrlIn(TransactionRequestTransformerTest.this.recCtrlIn);
		personalFinanceTrans.setStartDate(START_DATE_XML);
		personalFinanceTrans.setEndDate(END_DATE_XML);
		personalFinanceTrans.setAmtRange(TransactionRequestTransformerTest.this.amtRange);
		return personalFinanceTrans;
	}

	private AmtRange buildAmtRange() {
		AmtRange amountRange = new AmtRange();
		amountRange.setAmtFrom(TransactionRequestTransformerTest.this.fromAmount);
		amountRange.setAmtTo(TransactionRequestTransformerTest.this.toAmount);
		return amountRange;
	}

	private Amount buildAmount() {
		Amount amount = new Amount();
		amount.setAmt(100.00);
		amount.setCur("SGD");
		return amount;
	}

	private RecCtrlIn buildRecCtrlIn() {
		RecCtrlIn rec = new RecCtrlIn();
		rec.setCursor(CURSOR);
		rec.setMaxRec(MAX_REC);
		return rec;
	}

	private DepAcct buildDepAcct() {
		DepAcct depAccount = new DepAcct();
		depAccount.setAcctId(ACCT_ID);
		return depAccount;
	}

	private RetrieveTransactionDetails buildRetrieveTransactionDetails() {
		RetrieveTransactionDetails retrieveTranDetails = new RetrieveTransactionDetails();
		retrieveTranDetails.setCommonRq(TransactionRequestTransformerTest.this.commonRq);
		retrieveTranDetails.setCustInternalId("123456");
		retrieveTranDetails.setTranSeqNum("12345");
		return retrieveTranDetails;
	}

	private TransactionDetailsRequest buildTransactionDetailsRequest() {
		TransactionDetailsRequest tranRequest = new TransactionDetailsRequest();
		tranRequest.setAccountNumber("1234567");
		tranRequest.setTranKey("12345");
		return tranRequest;
	}

	private AdministerTransaction buildAdministerTransaction() {
		AdministerTransaction administration = new AdministerTransaction();
		TransactionUpdate transactionUpdate = new TransactionUpdate();
		transactionUpdate.setTranSeqNum(TRAN_SEQ_NUM);
		transactionUpdate.setCategoryName(CATEGORY_NAME);
		transactionUpdate.setPhoto(PHOTO);
		transactionUpdate.setNotes(NOTES);
		administration.setCustInternalId(CUST_INTERNAL_ID);
		administration.setTransactionUpdate(transactionUpdate);

		return administration;
	}

}
