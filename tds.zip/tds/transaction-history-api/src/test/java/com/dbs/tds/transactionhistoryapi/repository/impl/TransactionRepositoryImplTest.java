package com.dbs.tds.transactionhistoryapi.repository.impl;

import java.math.BigInteger;
import java.util.Date;

import com.dbs.tds.dto.TransactionDetailsRequest;
import com.dbs.tds.dto.TransactionDetailsResponse;
import com.dbs.tds.dto.TransactionHistoryRequest;
import com.dbs.tds.dto.TransactionHistoryResponse;
import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistoryapi.TransactionHistoryApiRepoConfig;
import com.dbs.tds.transactionhistoryapi.dao.TransactionRepositoryImpl;
import com.dbs.tds.transactionhistoryapi.exception.TransactionHistoryException;
import com.dbs.tds.util.CommonUtils;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@TestPropertySource(locations = "classpath:application.properties")
@ContextConfiguration(classes = { TransactionHistoryApiRepoConfig.class })
public class TransactionRepositoryImplTest {

	@Autowired
	private TransactionRepositoryImpl transactionRepositoryImpl;

	@Test
	public void testGetTransactionhistory() {
		TransactionHistoryResponse response = this.transactionRepositoryImpl
				.getTransactionhistory(getTranHistRequest());
		assertNotNull(response);
	}

	@Test
	public void testRetrieveTransactionDetails() throws TransactionHistoryException {
		TransactionDetailsResponse transactionDetailsResponse = this.transactionRepositoryImpl
				.retrieveTransactionDetails(getTransactionDetailsRequest());
		assertNotNull(transactionDetailsResponse);
	}

	@Test
	public void testUpdateTransactionCategory() throws TransactionHistoryException {
		TransactionNotification notification = this.transactionRepositoryImpl
				.updateTransactionCategory(getTransactionNotification());
		assertNotNull(notification);
	}

	private TransactionHistoryRequest getTranHistRequest() {
		TransactionHistoryRequest req = new TransactionHistoryRequest();
		req.setAcctId("881001003563");
		req.setMaxRec(BigInteger.valueOf(10));
		req.setCursor("1");
		req.setStartDt(new Date());
		req.setEndDt(new Date());
		req.setSortOrder("ASC");
		req.setLowerLimit(1);
		req.setLastTranRef(5);
		req.setAmountFrom(100.00);
		req.setAmountTo(1000.00);
		req.setCurrency("INR");
		req.setCrDrInd("Cr");

		return req;
	}

	private TransactionNotification getTransactionNotification() {
		TransactionNotification notification = new TransactionNotification();
		notification.setTranCategory("CATEGORY");
		notification.setPhoto(CommonUtils.convertStringToBlob("CONVERT-BLOB"));
		notification.setNotes("Notes");
		notification.setTranKey("201705001266852");

		return notification;
	}

	private TransactionDetailsRequest getTransactionDetailsRequest() {
		TransactionDetailsRequest transactionDetailsRequest = new TransactionDetailsRequest();
		transactionDetailsRequest.setAccountNumber("881001003563");
		transactionDetailsRequest.setTranKey("201705001266852");

		return transactionDetailsRequest;
	}

}
