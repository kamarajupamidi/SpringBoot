package com.dbs.tds.transactionhistoryapi.service;

import javax.xml.ws.Holder;

import com.dbs.moneythor.dto.MoneyThorTransactionResponse;
import com.dbs.moneythor.dto.MoneyThorTransactionUpdateRequest;
import com.dbs.schemas.soi.common._4_0.ExtendedHeader;
import com.dbs.schemas.soi.common._4_0.InfoWarn;
import com.dbs.schemas.soi.common._4_0.MsgDetl;
import com.dbs.schemas.soi.common._4_0.ServiceProvider;
import com.dbs.schemas.soi.common._4_0.Trace;
import com.dbs.schemas.soi.wsdl.consumerfinanceservices.v1_0.Fault;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.AdministerBudget;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.AdministerBudgetResponse;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.AdministerTransaction;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.AdministerTransactionResponse;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.CreateBudget;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.CreateBudgetResponse;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.RetrieveBudgetSummary;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.RetrieveBudgetSummaryResponse;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.RetrieveCategories;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.RetrieveCategoriesResponse;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.RetrieveCategorySummary;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.RetrieveCategorySummaryResponse;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.TerminateBudget;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.TerminateBudgetResponse;
import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistoryapi.mapper.ConsumerFinanceTransformer;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

/***
 * Unit test cases for {@link ConsumerFinanceService} methods.
 *
 * @author sivanarayana
 *
 * @version 1.0
 */
@RunWith(MockitoJUnitRunner.class)
public class ConsumerFinanceServiceTest {

	@Mock
	private MoneyThorTransactionService moneyThorTransactionService;

	@Mock
	private TransactionService transactionService;

	@Mock
	private ConsumerFinanceTransformer cosumerFinanceTransformer;

	@Mock
	private ConsumerFinanceHeaderService consumerFinanceHeaderService;

	private AdministerBudget administerBudgetRq;

	private Holder<MsgDetl> part1;

	private Holder<Trace> part2 = new Holder<>();

	private Holder<ExtendedHeader> part3;

	private Holder<InfoWarn> part4;

	private RetrieveBudgetSummary retrieveBudgetSummaryRq;

	private RetrieveCategorySummary retrieveCategorySummaryRq;

	private CreateBudget createBudgetRq;

	private RetrieveCategories retrieveCategoriesRq;

	private TerminateBudget terminateBudgetRq;

	@InjectMocks
	private ConsumerFinanceService consumerFinanceService;

	@Mock
	private MoneyThorTransactionUpdateRequest moneyThorTransactionUpdateRequest;

	@Mock
	private TransactionNotification transactionNotification;

	@Mock
	private MoneyThorTransactionResponse moneyThorTransactionResonse;

	@Mock
	private AdministerTransactionResponse administerTransactionResponse;

	@Mock
	private ServiceProvider serviceProvider;

	@Before
	public void setUp() {
		Trace trace = new Trace();
		this.part2.value = trace;
	}

	@Test
	public void testAdministerBudget() throws Fault {
		AdministerBudgetResponse response = this.consumerFinanceService.administerBudget(this.administerBudgetRq,
				this.part1, this.part2,
				this.part3, this.part4);
		assertNull(response);
	}

	@Test
	public void testRetrieveBudgetSummary() throws Fault {
		RetrieveBudgetSummaryResponse response = this.consumerFinanceService.retrieveBudgetSummary(
				this.retrieveBudgetSummaryRq,
				this.part1, this.part2, this.part3, this.part4);
		assertNull(response);
	}

	@Test
	public void testRetrieveCategorySummary() throws Fault {
		RetrieveCategorySummaryResponse response = this.consumerFinanceService
				.retrieveCategorySummary(this.retrieveCategorySummaryRq, this.part1, this.part2, this.part3,
						this.part4);
		assertNull(response);
	}

	@Test
	public void testCreateBudget() throws Fault {
		CreateBudgetResponse response = this.consumerFinanceService.createBudget(this.createBudgetRq, this.part1,
				this.part2, this.part3, this.part4);
		assertNull(response);
	}

	@Test
	public void testAdministerTransaction() throws Fault {
		AdministerTransaction administerTransactionRq = new AdministerTransaction();
		administerTransactionRq.setCustInternalId("abc");
		TransactionNotification notification = new TransactionNotification();
		notification.setExtTranId("123");

		when(this.cosumerFinanceTransformer
				.transformFromSoapToMT(administerTransactionRq, notification))
						.thenReturn(this.moneyThorTransactionUpdateRequest);
		when(this.transactionService.updateTransactionDetails(administerTransactionRq)).thenReturn(notification);
		when(this.moneyThorTransactionService
				.updateTransactionInMT(this.moneyThorTransactionUpdateRequest, "abc"))
						.thenReturn(this.moneyThorTransactionResonse);
		when(this.cosumerFinanceTransformer.transformFromMTToSoap(administerTransactionRq,
				this.moneyThorTransactionResonse)).thenReturn(this.administerTransactionResponse);
		when(this.consumerFinanceHeaderService.getServiceProvider()).thenReturn(this.serviceProvider);

		AdministerTransactionResponse response = this.consumerFinanceService.administerTransaction(
				administerTransactionRq,
				this.part1, this.part2, this.part3, this.part4);
		assertNotNull(response);
	}

	@Test
	public void testRetrieveCategories() throws Fault {
		RetrieveCategoriesResponse response = this.consumerFinanceService.retrieveCategories(this.retrieveCategoriesRq,
				this.part1,
				this.part2, this.part3, this.part4);
		assertNull(response);
	}

	@Test
	public void testTerminateBudget() throws Fault {
		TerminateBudgetResponse response = this.consumerFinanceService.terminateBudget(this.terminateBudgetRq,
				this.part1, this.part2,
				this.part3, this.part4);
		assertNull(response);
	}

}
