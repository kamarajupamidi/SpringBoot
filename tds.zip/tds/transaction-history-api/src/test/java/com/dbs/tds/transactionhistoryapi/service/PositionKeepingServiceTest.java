package com.dbs.tds.transactionhistoryapi.service;

import java.util.List;

import javax.xml.ws.Holder;

import com.dbs.schemas.soi.common._4_0.ExtendedHeader;
import com.dbs.schemas.soi.common._4_0.InfoWarn;
import com.dbs.schemas.soi.common._4_0.MsgDetl;
import com.dbs.schemas.soi.common._4_0.ServiceProvider;
import com.dbs.schemas.soi.common._4_0.Trace;
import com.dbs.schemas.soi.common._4_1.CommonRq;
import com.dbs.schemas.soi.common._4_1.CommonRs;
import com.dbs.schemas.soi.wsdl.positionkeeping.v1_1.Fault;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.AdministerSocialPosition;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.AdministerSocialPositionResponse;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.FundSetlAdd;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.FundSetlAddResponse;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.PositionKeepingTranHistInq;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.PositionKeepingTranHistInqResponse;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrieveDepositAcctTran;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrieveDepositAcctTranResponse;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePendingTransactionDetailsReq;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePendingTransactionsResponse;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePeriodicBalance;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePeriodicBalanceResponse;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePersonalFinanceTrans;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePersonalFinanceTransResponse;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrieveTransactionDetails;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrieveTransactionDetailsResponse;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.TranDetailExt;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.TranFDHistInq;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.TranFDHistInqResponse;
import com.dbs.tds.dto.TransactionDetailsRequest;
import com.dbs.tds.dto.TransactionDetailsResponse;
import com.dbs.tds.dto.TransactionHistoryRequest;
import com.dbs.tds.dto.TransactionHistoryResponse;
import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistoryapi.exception.TransactionHistoryException;
import com.dbs.tds.transactionhistoryapi.mapper.TransactionRequestTransformer;
import com.dbs.tds.transactionhistoryapi.mapper.TransactionResponseTransformer;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;
import static org.mockito.internal.util.reflection.Whitebox.setInternalState;

/***
 * Unit test cases for {@link PositionKeepingService} methods.
 *
 * @author sivanarayana
 *
 * @version 1.0
 */
@RunWith(MockitoJUnitRunner.class)
public class PositionKeepingServiceTest {

	private static final Integer LAST_INDEX = 5;

	private static final Integer TOTAL_COUNT = 10;

	@Mock
	private AdministerSocialPosition administerSocialPositionRq;

	private Holder<MsgDetl> part1;

	private Holder<Trace> part2 = new Holder<>();

	private Holder<ExtendedHeader> part3;

	private Holder<InfoWarn> part4 = new Holder<>();

	private FundSetlAdd fundSetlAddRq;

	private PositionKeepingTranHistInq positionKeepingTranHistInqRq;

	private RetrieveDepositAcctTran retrieveDepositAcctTranRq;

	private RetrievePeriodicBalance retrievePeriodicBalanceRq;

	private RetrievePendingTransactionDetailsReq retrievePendingTransactionsRq;

	private RetrievePersonalFinanceTrans retrievePersonalFinanceTransRq;

	private TranFDHistInq tranFDHistInqRq;

	@Mock
	private TranFDHistInqResponse tranFDHistInqResponse;

	@Mock
	private TransactionService transactionService;

	@Mock
	private TransactionRequestTransformer transactionRequestTransformer;

	@Mock
	private TransactionResponseTransformer transactionTransformer;

	@Mock
	private TransactionHistoryRequest transactionHistoryRequest;

	@Mock
	private TransactionHistoryResponse transactionHistoryResponse;

	@Mock
	private List<TransactionNotification> transactionNotifications;

	@Mock
	private RetrievePersonalFinanceTransResponse retrievePersonalFinanceTransResponse;

	@Mock
	private RetrieveTransactionDetailsResponse retrieveTransactionDetailsResponse;

	@Mock
	private TransactionDetailsRequest transactionDetailsRequest;

	@Mock
	private TransactionDetailsResponse transactionDetailsResponse;

	@Mock
	private CommonRs commonRs;

	@Mock
	private CommonRq commonRq;

	@Mock
	private TransactionNotification transactionNotification;

	@Mock
	private TranDetailExt tranDetailExt;

	@Mock
	private ServiceProvider serviceProvider;

	@Mock
	private PositionKeepingResponseHeaderService positionKeepingResponseHeaderService;

	@InjectMocks
	private RetrieveTransactionDetails retrieveTransactionDetailsRq;

	@InjectMocks
	private PositionKeepingService positionKeepingService;

	@Before
	public void setup() {
		setInternalState(this.positionKeepingService, "positionKeepingResponseHeaderService",
				this.positionKeepingResponseHeaderService);
		Trace trace = new Trace();
		this.part2.value = trace;
	}

	@Test
	public void testAdministerSocialPosition() throws Fault {
		AdministerSocialPositionResponse resonse = this.positionKeepingService
				.administerSocialPosition(this.administerSocialPositionRq, this.part1, this.part2, this.part3,
						this.part4);
		assertNull(resonse);
	}

	@Test
	public void testAdministerPosition() throws Fault {
		FundSetlAddResponse response = this.positionKeepingService.administerPosition(this.fundSetlAddRq, this.part1,
				this.part2, this.part3,
				this.part4);
		assertNull(response);
	}

	@Test
	public void testRetrieveDepositAccountTransactions() throws Fault {
		RetrieveDepositAcctTranResponse response = this.positionKeepingService.retrieveDepositAccountTransactions(
				this.retrieveDepositAcctTranRq, this.part1, this.part2, this.part3,
				this.part4);
		assertNull(response);
	}

	@Test
	public void testRetrievePersonalFinanceTrans() throws Fault {

		testRetrievePersFinTransForZeroOrMoreTrans(1, false);
	}

	@Test
	public void testRetrievePersonalFinanceTransZeroTransactions() throws Fault {

		testRetrievePersFinTransForZeroOrMoreTrans(0, true);
	}

	@Test
	public void testRetrieveFDTransactionHistoryZeroRecords() throws Fault {
		testRetrieveFDTransactionHistoryZeroOrMoreRecords(0, true);
	}

	@Test
	public void testRetrieveFDTransactionHistoryMoreRecords() throws Fault {
		testRetrieveFDTransactionHistoryZeroOrMoreRecords(1, false);
	}

	@Test
	public void testRetrieveTransactionHistory() throws Fault {
		PositionKeepingTranHistInqResponse response = this.positionKeepingService
				.retrieveTransactionHistory(this.positionKeepingTranHistInqRq, this.part1, this.part2, this.part3,
						this.part4);
		assertNull(response);
	}

	@Test
	public void testRetrievePendingTransactions() throws Fault {
		RetrievePendingTransactionsResponse response = this.positionKeepingService
				.retrievePendingTransactions(this.retrievePendingTransactionsRq, this.part1, this.part2, this.part3,
						this.part4);
		assertNull(response);
	}

	@Test
	public void testRetrieveTransactionDetails() throws Fault {
		when(this.transactionRequestTransformer.transformToTransactionDetailsRequest(this.retrieveTransactionDetailsRq))
				.thenReturn(this.transactionDetailsRequest);
		when(this.transactionService.retrieveTransactionDetails(this.retrieveTransactionDetailsRq, this.part1,
				this.part2, this.part3, this.part4))
						.thenReturn(this.retrieveTransactionDetailsResponse);
		when(this.transactionTransformer.getCommonRs("2001", "1234")).thenReturn(this.commonRs);
		when(this.positionKeepingResponseHeaderService.getServiceProvider()).thenReturn(this.serviceProvider);
		try {
			when(this.transactionTransformer.getTransactionDetails(this.transactionNotification))
					.thenReturn(this.tranDetailExt);
		}
		catch (TransactionHistoryException e) {
			throw new Fault();
		}
		RetrieveTransactionDetailsResponse response = this.positionKeepingService
				.retrieveTransactionDetails(this.retrieveTransactionDetailsRq, this.part1, this.part2, this.part3,
						this.part4);
		assertNotNull(response);
	}

	@Test
	public void testRetrievePeriodicBalance() throws Fault {
		RetrievePeriodicBalanceResponse response = this.positionKeepingService
				.retrievePeriodicBalance(this.retrievePeriodicBalanceRq, this.part1, this.part2, this.part3,
						this.part4);
		assertNull(response);
	}

	private void testRetrievePersFinTransForZeroOrMoreTrans(int dataSize, boolean isEmpty) throws Fault {
		when(this.transactionRequestTransformer
				.transformToTransactionHistoryRequest(this.retrievePersonalFinanceTransRq))
						.thenReturn(this.transactionHistoryRequest);
		when(this.transactionService
				.getTransactionHistory(this.transactionHistoryRequest))
						.thenReturn(this.transactionHistoryResponse);
		when(this.transactionHistoryResponse.getTransactions()).thenReturn(this.transactionNotifications);
		when(this.transactionNotifications.size()).thenReturn(dataSize);
		when(this.transactionNotifications.isEmpty()).thenReturn(isEmpty);
		when(this.transactionHistoryResponse.getTotalCount()).thenReturn(TOTAL_COUNT);
		when(this.transactionHistoryResponse.getLastIndex()).thenReturn(LAST_INDEX);
		when(this.transactionTransformer.transformTransactionHistory(this.transactionHistoryResponse,
				this.retrievePersonalFinanceTransRq)).thenReturn(this.retrievePersonalFinanceTransResponse);
		when(this.positionKeepingResponseHeaderService.getServiceProvider()).thenReturn(this.serviceProvider);
		RetrievePersonalFinanceTransResponse response = this.positionKeepingService
				.retrievePersonalFinanceTrans(this.retrievePersonalFinanceTransRq, this.part1, this.part2, this.part3,
						this.part4);
		assertNotNull(response);
	}

	private void testRetrieveFDTransactionHistoryZeroOrMoreRecords(int size, boolean isEmpty) throws Fault {
		when(this.transactionRequestTransformer
				.transformToTransactionHistoryRequest(this.tranFDHistInqRq))
						.thenReturn(this.transactionHistoryRequest);
		when(this.transactionService
				.getTransactionHistory(this.transactionHistoryRequest)).thenReturn(this.transactionHistoryResponse);
		when(this.transactionHistoryResponse.getTransactions()).thenReturn(this.transactionNotifications);
		when(this.transactionNotifications.isEmpty()).thenReturn(isEmpty);
		when(this.transactionNotifications.size()).thenReturn(size);
		when(this.transactionHistoryResponse.getLastIndex()).thenReturn(5);
		when(this.transactionHistoryResponse.getTotalCount()).thenReturn(10);
		when(this.transactionTransformer.transformTransactionHistory(this.transactionHistoryResponse,
				this.tranFDHistInqRq)).thenReturn(this.tranFDHistInqResponse);
		when(this.positionKeepingResponseHeaderService.getServiceProvider()).thenReturn(this.serviceProvider);
		TranFDHistInqResponse response = this.positionKeepingService.retrieveFDTransactionHistory(this.tranFDHistInqRq,
				this.part1, this.part2, this.part3, this.part4);
		assertNotNull(response);
	}

}
