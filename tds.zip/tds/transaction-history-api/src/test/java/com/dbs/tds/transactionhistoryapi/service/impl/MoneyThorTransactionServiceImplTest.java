package com.dbs.tds.transactionhistoryapi.service.impl;

import com.dbs.moneythor.constants.TransactionStatus;
import com.dbs.moneythor.dto.MoneyThorTransactionHistoryRequest;
import com.dbs.moneythor.dto.MoneyThorTransactionResponse;
import com.dbs.moneythor.dto.MoneyThorTransactionUpdateRequest;
import com.dbs.tds.transactionhistoryapi.config.MoneyThorRestTemplate;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;
import static org.mockito.internal.util.reflection.Whitebox.setInternalState;

/***
 * Unit test cases for {@link MoneyThorTransactionServiceImpl} methods.
 *
 * @author sivanarayana
 *
 * @version 1.0
 */
@RunWith(MockitoJUnitRunner.class)
public class MoneyThorTransactionServiceImplTest {

	private static final String CUSTOMER_ID = "customer-id";

	private static final Integer PAGE = 1;

	private static final Integer COUNT = 10;

	private String moneyThorUrl = "money-thor-url";

	private String moneyThorReadTransactionApiEndPoint = "mt-read-tran-endpoint";

	private String moneyThorTxnUpdateEndPoint = "mt-txn-update-endpoint";

	@Mock
	private MoneyThorTransactionResponse response;

	@Mock
	ResponseEntity<MoneyThorTransactionResponse> responseEntity;

	@Mock
	private MoneyThorRestTemplate moneyThorRestTemplate;

	@Mock
	private RestTemplate restTemplate;

	private MoneyThorTransactionUpdateRequest moneyThorTransactionUpdateRequest;

	private MoneyThorTransactionHistoryRequest moneyThorTransactionHistoryRequest;

	@InjectMocks
	private MoneyThorTransactionServiceImpl moneyThorTransactionServiceImpl = new MoneyThorTransactionServiceImpl(
			this.moneyThorRestTemplate) {

		@Override
		protected ResponseEntity<MoneyThorTransactionResponse> restTemplateExchange(String transactionsURL,
				RestTemplate restTemplate, HttpEntity<?> entity) {
			return MoneyThorTransactionServiceImplTest.this.responseEntity;
		}
	};

	@Before
	public void setup() {
		this.moneyThorTransactionUpdateRequest = new MoneyThorTransactionUpdateRequest();
		this.moneyThorTransactionHistoryRequest = new MoneyThorTransactionHistoryRequest();
		this.moneyThorTransactionHistoryRequest.setStatus(TransactionStatus.AUTHORIZED);
		this.moneyThorTransactionHistoryRequest.setPage(PAGE);
		this.moneyThorTransactionHistoryRequest.setCount(COUNT);
		this.moneyThorTransactionHistoryRequest.setExpandTip(true);

		setInternalState(this.moneyThorTransactionServiceImpl, "moneyThorUrl", this.moneyThorUrl);
		setInternalState(this.moneyThorTransactionServiceImpl, "moneyThorReadTransactionApiEndPoint",
				this.moneyThorReadTransactionApiEndPoint);
		setInternalState(this.moneyThorTransactionServiceImpl, "moneyThorTxnUpdateEndPoint",
				this.moneyThorTxnUpdateEndPoint);

		when(this.moneyThorRestTemplate.getRestTemplate()).thenReturn(this.restTemplate);

		when(this.responseEntity.getBody()).thenReturn(this.response);
	}

	@Test
	public void testGetTransactionHistoryFromMT() {
		MoneyThorTransactionResponse moneyThorTransactionResonse = this.moneyThorTransactionServiceImpl
				.getTransactionHistoryFromMT(this.moneyThorTransactionHistoryRequest, CUSTOMER_ID);
		assertNotNull(moneyThorTransactionResonse);
	}

	@Test
	public void testGetTransactionHistoryFromMTNullTransactionStatus() {
		this.moneyThorTransactionHistoryRequest.setStatus(null);
		this.moneyThorTransactionHistoryRequest.setExpandTip(false);
		MoneyThorTransactionResponse moneyThorTransactionResonse = this.moneyThorTransactionServiceImpl
				.getTransactionHistoryFromMT(this.moneyThorTransactionHistoryRequest, CUSTOMER_ID);
		assertNotNull(moneyThorTransactionResonse);
	}

	@Test
	public void testUpdateTransactionInMT() {
		MoneyThorTransactionResponse moneyThorTransactionResonse = this.moneyThorTransactionServiceImpl
				.updateTransactionInMT(this.moneyThorTransactionUpdateRequest, CUSTOMER_ID);
		assertNotNull(moneyThorTransactionResonse);
	}

}
