package com.dbs.tds.transactionhistoryapi.mapper;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.dbs.moneythor.dto.HeaderInfoMoneyThor;
import com.dbs.moneythor.dto.MoneyThorTransactionResponse;
import com.dbs.schemas.soi.common._4_1.CISCustId;
import com.dbs.schemas.soi.common._4_1.CommonRq;
import com.dbs.schemas.soi.common._4_1.CommonRs;
import com.dbs.schemas.soi.common._4_1.DeliveryMethod;
import com.dbs.schemas.soi.common._4_1.DepAcct;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.AdministerTransaction;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.AdministerTransactionResponse;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.Result;
import com.dbs.schemas.soi.xsd.consumerfinanceservices.v1_0.ResultCode;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePersonalFinanceTrans;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrievePersonalFinanceTransResponse;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrieveTransactionDetails;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.RetrieveTransactionDetailsResponse;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.TranDetailExt;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.TranFDHistInq;
import com.dbs.schemas.soi.xsd.positionkeeping.v1_1.TranFDHistInqResponse;
import com.dbs.tds.dto.TransactionDetailsResponse;
import com.dbs.tds.dto.TransactionHistoryResponse;
import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistoryapi.exception.TransactionHistoryException;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/***
 * Unit test cases for {@link TransactionResponseTransformer} methods.
 *
 * @author sivanarayana
 *
 * @version 1.0
 */
public class TransactionResponseTransformerTest {

	private static final String ORG_CODE = "org-code";

	private static final String RQ_SYS_REF = "rq-sys-ref";

	private static final String CUST_INTERNAL_ID = "cust-internal-id";

	private static final String ALT_CUST_INTERNAL_ID = "alt-cust-internal-id";

	private GregorianCalendar startCalendar = new GregorianCalendar(2017, 9, 28, 0, 0, 1);

	private XMLGregorianCalendar startXmlCalendar = getDataTypeFactory().newXMLGregorianCalendar();

	private XMLGregorianCalendar endXmlCalendar = getDataTypeFactory().newXMLGregorianCalendar();

	private final Date transactionDate = this.startCalendar.getTime();

	private static final String EXT_TRAN_ID = "ext-tran-id";

	private static final String TRANSACTION_PARTICULAR_CODE = "transaction-particular-code";

	private static final String TRANSACTION_PARTICULARS = "transaction particulars";

	private static final String PART_TRANSACTION_TYPE_CREDIT = "C";

	private static final String PART_TRANSACTION_TYPE_DEBIT = "D";

	protected static final Double TRANSACTION_AMOUNT = 10_000.00;

	protected static final String TRANSACTION_CURRENCY_CODE = "SGD";

	protected static final Double AVAILABLE_BALANCE = 100_000.00;

	protected static final String TRAN_CATEGORY = "tran-category";

	protected static final String TRANSACTION_REFERENCE_NUMBER = "transaction-ref-number";

	protected static final String ADDITIONAL_REFERENCE = "additional-reference";

	protected static final String RELATED_RECORD_ID = "related-record-id";

	protected static final BigInteger LAST_NO_OF_TRAN = BigInteger.valueOf(20);

	private TransactionResponseTransformer transformer;

	private ConsumerFinanceTransformer consumerFinanceTransformer;

	private AdministerTransaction administerTransaction;

	private MoneyThorTransactionResponse moneyThorTransactionResponse;

	private TransactionHistoryResponse transactionResponse;

	private TranFDHistInq tranFDHistInqRq;

	private DepAcct depAcct;

	private RetrievePersonalFinanceTrans retrievePersonalFinanceTransRq;

	private DeliveryMethod deliveryMethod;

	private CISCustId cisCustId;

	private CommonRq commonRq;

	private TransactionNotification transactionNotification;

	TransactionDetailsResponse transactionDetailsResponse;

	RetrieveTransactionDetails retrieveTransactionDetailsRq;

	RetrieveTransactionDetailsResponse retrieveTransactionDetailsResponse;

	@Before
	public void setup() {
		this.transformer = new TransactionResponseTransformer();
		this.consumerFinanceTransformer = new ConsumerFinanceTransformer();
		this.deliveryMethod = new DeliveryMethod();
		this.cisCustId = new CISCustId();

		this.commonRq = buildCommonRq();
		this.administerTransaction = buildAdministerTransaction();
		this.moneyThorTransactionResponse = buildMoneyThorTransactionResponse();
		this.transactionNotification = buildTransactionNotification();
		this.transactionResponse = buildTransactionHistoryResponse();
		this.depAcct = buildDepAcct();
		this.retrievePersonalFinanceTransRq = buildRetrievePersonalFinanceTrans();
		this.tranFDHistInqRq = buildTranFDHistInq();
		this.retrieveTransactionDetailsRq = buildRetrieveTransactionDetails();
		this.transactionDetailsResponse = buildTransactionDetailsResponse();

	}

	@Test
	public void testTransformFromMTToSoapSuccess() {
		AdministerTransactionResponse administerTransactionResonse = this.consumerFinanceTransformer
				.transformFromMTToSoap(this.administerTransaction, this.moneyThorTransactionResponse);
		assertNotNull(administerTransactionResonse);
		CommonRs commonRs = administerTransactionResonse.getCommonRs();
		assertNotNull(commonRs);
		Result result = administerTransactionResonse.getResult();
		assertNotNull(result);
		assertEquals(ResultCode.OK, result.getCode());
		assertEquals("Transaction Update Successful", result.getMessage());
		assertEquals(ORG_CODE, commonRs.getOrgCode());
		assertEquals(RQ_SYS_REF, commonRs.getRqSysRef());
	}

	@Test
	public void testTransformFromMTToSoapError() {
		this.moneyThorTransactionResponse.getHeader().setSuccess(false);
		AdministerTransactionResponse administerTransactionResonse = this.consumerFinanceTransformer
				.transformFromMTToSoap(this.administerTransaction, this.moneyThorTransactionResponse);
		assertNotNull(administerTransactionResonse);
		CommonRs commonRs = administerTransactionResonse.getCommonRs();
		assertNotNull(commonRs);
		Result result = administerTransactionResonse.getResult();
		assertNotNull(result);
		assertEquals(ResultCode.ERROR, result.getCode());
		assertEquals("Transaction Update Failed.", result.getMessage());
		assertEquals(ORG_CODE, commonRs.getOrgCode());
		assertEquals(RQ_SYS_REF, commonRs.getRqSysRef());
	}

	@Test
	public void testTransformTransactionHistoryTransactionHistoryResponseRetrievePersonalFinanceTransDebit() {
		this.transactionNotification.setPartTransactionType(PART_TRANSACTION_TYPE_DEBIT);
		assertEquals("DR", getCrDRIndForRetrievePersFinTrans());
	}

	@Test
	public void testTransformTransactionHistoryTransactionHistoryResponseRetrievePersonalFinanceTransCredit() {
		this.transactionNotification.setPartTransactionType(PART_TRANSACTION_TYPE_CREDIT);
		assertEquals("CR", getCrDRIndForRetrievePersFinTrans());

	}

	@Test
	public void testTransformTransactionHistoryTransactionHistoryResponseTranFDHistInqCredit() {
		this.transactionNotification.setPartTransactionType(PART_TRANSACTION_TYPE_CREDIT);
		assertEquals("CR", getCrDRIndForTranFDHistInq());
	}

	@Test
	public void testTransformTransactionHistoryTransactionHistoryResponseTranFDHistInqDebit() {
		this.transactionNotification.setPartTransactionType(PART_TRANSACTION_TYPE_DEBIT);
		assertEquals("DR", getCrDRIndForTranFDHistInq());
	}

	@Test
	public void testGetTransactionDetails() throws TransactionHistoryException {
		TranDetailExt tranDetailExt = this.transformer.getTransactionDetails(this.transactionNotification);
		assertNotNull(tranDetailExt);
	}

	private static DatatypeFactory getDataTypeFactory() {
		try {
			return DatatypeFactory.newInstance();
		}
		catch (DatatypeConfigurationException ex) {
			return null;
		}
	}

	private TransactionDetailsResponse buildTransactionDetailsResponse() {
		TransactionDetailsResponse tranResponse = new TransactionDetailsResponse();
		tranResponse.setTransactionDetails(this.transactionNotification);
		return tranResponse;
	}

	private RetrieveTransactionDetails buildRetrieveTransactionDetails() {
		RetrieveTransactionDetails retrieveTranDetails = new RetrieveTransactionDetails();
		retrieveTranDetails.setCommonRq(this.commonRq);
		retrieveTranDetails.setCustInternalId("12345");
		retrieveTranDetails.setTranSeqNum("123");
		return retrieveTranDetails;
	}

	private TranFDHistInq buildTranFDHistInq() {
		TranFDHistInq tranHistInq = new TranFDHistInq();
		tranHistInq.setCommonRq(this.commonRq);
		tranHistInq.setDepAcctId(this.depAcct);
		tranHistInq.setStartDate(this.startXmlCalendar);
		tranHistInq.setEndDate(this.endXmlCalendar);
		tranHistInq.setLastNoOfTran(LAST_NO_OF_TRAN);
		tranHistInq.setDeliveryMethod(this.deliveryMethod);

		return tranHistInq;
	}

	private RetrievePersonalFinanceTrans buildRetrievePersonalFinanceTrans() {
		RetrievePersonalFinanceTrans retrievePerFinanceTrans = new RetrievePersonalFinanceTrans();
		retrievePerFinanceTrans.setCustInternalId(CUST_INTERNAL_ID);
		retrievePerFinanceTrans.setCISInternalId(TransactionResponseTransformerTest.this.cisCustId);
		retrievePerFinanceTrans.setAltCustInternalId(ALT_CUST_INTERNAL_ID);
		retrievePerFinanceTrans.setDepAcctId(TransactionResponseTransformerTest.this.depAcct);
		retrievePerFinanceTrans.setStartDate(TransactionResponseTransformerTest.this.startXmlCalendar);
		retrievePerFinanceTrans.setEndDate(TransactionResponseTransformerTest.this.endXmlCalendar);
		retrievePerFinanceTrans.setDeliveryMethod(TransactionResponseTransformerTest.this.deliveryMethod);
		retrievePerFinanceTrans.setCommonRq(TransactionResponseTransformerTest.this.commonRq);
		return retrievePerFinanceTrans;
	}

	private DepAcct buildDepAcct() {
		DepAcct depacc = new DepAcct();
		depacc.setAcctId("acct-id");
		return depacc;
	}

	private TransactionHistoryResponse buildTransactionHistoryResponse() {
		TransactionHistoryResponse tHResponse = new TransactionHistoryResponse();
		tHResponse.setLastIndex(10);
		tHResponse.setTotalCount(100);
		tHResponse.setCursor(1);
		tHResponse.setCurrentPageCount(1);
		tHResponse.setTransactions(Arrays.asList(TransactionResponseTransformerTest.this.transactionNotification));

		return tHResponse;
	}

	private TransactionNotification buildTransactionNotification() {
		TransactionNotification tranNotification = new TransactionNotification();
		tranNotification.setExtTranId(EXT_TRAN_ID);
		tranNotification.setTransactionDate(TransactionResponseTransformerTest.this.transactionDate);
		tranNotification.setValueDate(TransactionResponseTransformerTest.this.transactionDate);
		tranNotification.setPostedDate(TransactionResponseTransformerTest.this.transactionDate);
		tranNotification.setPartTransactionSerialNumber(100l);
		tranNotification.setTransactionParticularCode(TRANSACTION_PARTICULAR_CODE);
		tranNotification.setTransactionParticulars(TRANSACTION_PARTICULARS);
		tranNotification.setTransactionAmount(TRANSACTION_AMOUNT);
		tranNotification.setTransactionCurrencyCode(TRANSACTION_CURRENCY_CODE);
		tranNotification.setAvailableBalance(AVAILABLE_BALANCE);
		tranNotification.setTranCategory(TRAN_CATEGORY);
		tranNotification.setTransactionReferenceNumber(TRANSACTION_REFERENCE_NUMBER);
		tranNotification.setAdditionalReference(ADDITIONAL_REFERENCE);
		tranNotification.setRelatedRecordId(RELATED_RECORD_ID);
		tranNotification.setTranKey("1234");
		tranNotification.setNotes("Notes");

		return tranNotification;
	}

	private MoneyThorTransactionResponse buildMoneyThorTransactionResponse() {
		MoneyThorTransactionResponse mTResponse = new MoneyThorTransactionResponse();
		HeaderInfoMoneyThor headerInfo = new HeaderInfoMoneyThor();
		headerInfo.setSuccess(true);
		mTResponse.setHeader(headerInfo);
		return mTResponse;
	}

	private AdministerTransaction buildAdministerTransaction() {
		AdministerTransaction adminTrans = new AdministerTransaction();
		adminTrans.setCommonRq(this.commonRq);
		return adminTrans;
	}

	private CommonRq buildCommonRq() {
		CommonRq commonReq = new CommonRq();
		commonReq.setOrgCode(ORG_CODE);
		commonReq.setRqSysRef(RQ_SYS_REF);
		return commonReq;
	}

	private String getCrDRIndForRetrievePersFinTrans() {
		RetrievePersonalFinanceTransResponse retrievePersonalFinanceTransResponse = this.transformer
				.transformTransactionHistory(this.transactionResponse, this.retrievePersonalFinanceTransRq);
		assertNotNull(retrievePersonalFinanceTransResponse);
		assertEquals(CUST_INTERNAL_ID, retrievePersonalFinanceTransResponse.getCustInternalId());
		assertEquals(TransactionResponseTransformerTest.this.cisCustId,
				retrievePersonalFinanceTransResponse.getCISInternalId());
		assertEquals(ALT_CUST_INTERNAL_ID, retrievePersonalFinanceTransResponse.getAltCustInternalId());
		DepAcct depAcc = retrievePersonalFinanceTransResponse.getDepAcctId();
		assertNotNull(depAcc);
		assertNotNull(retrievePersonalFinanceTransResponse.getStartDate());
		assertNotNull(retrievePersonalFinanceTransResponse.getEndDate());
		assertNotNull(retrievePersonalFinanceTransResponse.getDeliveryMethod());
		List<RetrievePersonalFinanceTransResponse.TranDetail> tranDetails = retrievePersonalFinanceTransResponse
				.getTranDetail();
		assertNotNull(tranDetails);
		assertEquals(1, tranDetails.size());
		RetrievePersonalFinanceTransResponse.TranDetail tranDetail = tranDetails.get(0);

		return tranDetail.getCrDrInd();
	}

	private String getCrDRIndForTranFDHistInq() {
		TranFDHistInqResponse tranFDHistInqResponse = this.transformer.transformTransactionHistory(
				this.transactionResponse,
				this.tranFDHistInqRq);
		assertNotNull(tranFDHistInqResponse);
		DepAcct depAcc = tranFDHistInqResponse.getDepAcctId();
		assertNotNull(depAcc);
		assertNotNull(tranFDHistInqResponse.getStartDate());
		assertNotNull(tranFDHistInqResponse.getEndDate());
		assertNotNull(tranFDHistInqResponse.getDeliveryMethod());
		assertEquals(LAST_NO_OF_TRAN, tranFDHistInqResponse.getLastNoOfTran());
		List<TranFDHistInqResponse.TranDetail> tranDetails = tranFDHistInqResponse.getTranDetail();
		assertNotNull(tranDetails);
		assertEquals(1, tranDetails.size());
		TranFDHistInqResponse.TranDetail tranDetail = tranDetails.get(0);

		return tranDetail.getCrDrInd();
	}

}
