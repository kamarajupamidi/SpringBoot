package com.dbs.tds.transactionbalance.flag.config.transformer;

import java.util.List;

import com.dbs.schemas.digibank.dirtyflag.v1_0.Account;
import com.dbs.schemas.digibank.dirtyflag.v1_0.DirtyFlagUpdate;
import com.dbs.tds.dto.AccountNotification;
import org.junit.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import static org.junit.Assert.assertEquals;

public class TransactionBalanceDirtyFlagTransformerTest {

	private TransactionBalanceDirtyFlagTransformer transactionBalanceDirtyFlagTransformer;

	@Autowired
	Jaxb2Marshaller jaxb2Marshaller;

	@Test
	public void testTransform() {
		this.transactionBalanceDirtyFlagTransformer = new TransactionBalanceDirtyFlagTransformer(this.jaxb2Marshaller);
		Account account = new Account();
		account.setACCTNO("139507334093");
		account.setISBALSYNC("Y");
		DirtyFlagUpdate dirtyFlagUpdate = new DirtyFlagUpdate();
		dirtyFlagUpdate.getAccount().add(account);
		List<AccountNotification> accountNotification = this.transactionBalanceDirtyFlagTransformer
				.transform(dirtyFlagUpdate);
		assertEquals("Y", accountNotification.get(0).getIsBalSyncFlag());
		assertEquals("139507334093", accountNotification.get(0).getAccountNumber());
	}

	@Test(expected = IllegalArgumentException.class)
	public void testTransformAccountNull() {
		this.transactionBalanceDirtyFlagTransformer = new TransactionBalanceDirtyFlagTransformer(this.jaxb2Marshaller);
		DirtyFlagUpdate dirtyFlagUpdate = new DirtyFlagUpdate();
		Account account = null;
		dirtyFlagUpdate.getAccount().add(account);
		this.transactionBalanceDirtyFlagTransformer.transform(dirtyFlagUpdate);
	}

}
