package com.dbs.tds.transactionbalance.flag.config.service;

import java.util.ArrayList;
import java.util.List;

import com.dbs.tds.dto.AccountNotification;
import com.dbs.tds.transactionbalance.flag.config.TransactionBalanceDirtyFlagConfigurationTest;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = { TransactionBalanceDirtyFlagConfigurationTest.class })
public class TransactionBalanceDirtyFlagServiceTest {

	@Autowired
	private TransactionBalanceDirtyFlagService transactionBalanceDirtyFlagService;

	@Autowired
	private NamedParameterJdbcTemplate accountCacheFlagUpdate;

	@Test
	public void testProcess() {
		List<AccountNotification> accountList = new ArrayList<>();
		AccountNotification accountNotification = new AccountNotification();
		accountNotification.setAccountNumber("881001003730");
		accountNotification.setIsBalSyncFlag("Y");

		accountList.add(accountNotification);

		this.transactionBalanceDirtyFlagService.process(accountList);
		String querySql = "SELECT IS_BAL_SYNC, LST_UPDT_SYS_ID FROM T_ACCT WHERE ACCT_NO = :acctNo";
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("acctNo", "881001003730");
		Assert.assertEquals(1, this.accountCacheFlagUpdate.queryForList(querySql, paramSource).stream().filter(
				row -> ("Y".equals(row.get("IS_BAL_SYNC")) && ("Cache Flag Queue".equals(row.get("LST_UPDT_SYS_ID")))))
				.count());

	}

}
