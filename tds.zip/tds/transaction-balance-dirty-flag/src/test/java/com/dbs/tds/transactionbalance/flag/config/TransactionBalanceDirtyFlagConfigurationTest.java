package com.dbs.tds.transactionbalance.flag.config;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

@Configuration
@ComponentScan({ "com.dbs.tds.transactionbalance.flag.config.service"})
public class TransactionBalanceDirtyFlagConfigurationTest {
	
	@Bean
	DataSource accountDatasource() {
		return new EmbeddedDatabaseBuilder()
				.addScripts("accountSchema.sql", "accountData.sql")
				.setType(EmbeddedDatabaseType.H2).build();
	}
	
	@Bean
	public NamedParameterJdbcTemplate accountJdbcTemplate() {
		return new NamedParameterJdbcTemplate(accountDatasource());
	}
}

