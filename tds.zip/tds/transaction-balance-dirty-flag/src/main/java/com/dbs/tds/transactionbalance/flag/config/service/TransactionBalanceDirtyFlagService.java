package com.dbs.tds.transactionbalance.flag.config.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import com.dbs.tds.constants.StatusCodes;
import com.dbs.tds.dto.AccountNotification;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import static com.dbs.tds.constants.AccountFields.ACCT_NO;
import static com.dbs.tds.constants.AccountFields.IS_BAL_SYNC;
import static com.dbs.tds.constants.AccountFields.LST_UPDT_DTTM;
import static com.dbs.tds.constants.AccountFields.LST_UPDT_SYS_ID;
import static com.dbs.tds.constants.AppConstants.STATUS_CODE_DES_KEY;
import static com.dbs.tds.constants.AppConstants.STATUS_CODE_KEY;
import static com.dbs.tds.constants.LoggingConstants.ERROR_TYPE;
import static com.dbs.tds.constants.LoggingConstants.RESPONSE_TIME;

/**
 * This class is used to update balance details, mainly Balance sync cache flag, coming
 * from SOI EMS Queue Notification, into TDS DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Service
@Transactional
public class TransactionBalanceDirtyFlagService {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(TransactionBalanceDirtyFlagService.class);

	/**
	 * This field is used to store value for ELKLOGGER which is of type {@link Logger }.
	 */
	private static final Logger ELKLOGGER = LoggerFactory.getLogger("elklogger");

	/**
	 * This field is used to store value for accountCacheFlagUpdate which is of type
	 * {@link NamedParameterJdbcTemplate }.
	 */
	private NamedParameterJdbcTemplate accountCacheFlagUpdate;

	/**
	 * This field is used to store value for accountCacheUpdateQuery which is of type
	 * {@link String }.
	 */
	private String accountCacheUpdateQuery;

	/**
	 * This constructor is used with injected {@link DataSource} instance to setup the the
	 * {@link JdbcTemplate} and named parameterized Query in {@link String} type.
	 *
	 * @param dataSource : {@link DataSource}
	 */
	public TransactionBalanceDirtyFlagService(DataSource dataSource) {
		this.accountCacheUpdateQuery = "UPDATE T_ACCT SET IS_BAL_SYNC=:IS_BAL_SYNC, LST_UPDT_SYS_ID=:LST_UPDT_SYS_ID, LST_UPDT_DTTM=:LST_UPDT_DTTM WHERE ACCT_NO= :ACCT_NO;";
		this.accountCacheFlagUpdate = new NamedParameterJdbcTemplate(dataSource);
	}

	/**
	 * This method is used to update balance sync cache flag, coming from SOI EMS Queue
	 * Notification, into TDS DB.
	 *
	 * @param accountDetails : {@link List} &lt; {@link AccountNotification} &gt;
	 */
	public void process(List<AccountNotification> accountDetails) {
		LOGGER.info("Updating cache flags.");

		List<MapSqlParameterSource> mapSqlParameterSources = buildListOfMapSqlParameterSources(accountDetails);
		int[] updatecount = this.accountCacheFlagUpdate.batchUpdate(this.accountCacheUpdateQuery,
				mapSqlParameterSources.toArray(new MapSqlParameterSource[mapSqlParameterSources.size()]));

		LOGGER.info("Update finished with rows affected : {}", updatecount);
		MDC.put(STATUS_CODE_KEY.value(), StatusCodes.SUCCESS.value());
		MDC.put(STATUS_CODE_DES_KEY.value(), StatusCodes.SUCCESS.name());
		MDC.put(ERROR_TYPE.value(), "");
		logElapsedTime();
	}

	/**
	 * This method is used to calculate and log the elapsed time.
	 */
	private void logElapsedTime() {
		String startTime = MDC.get("startTime");
		if (StringUtils.isNotBlank(startTime)) {
			long start = Long.parseLong(startTime);
			long elapsed = System.currentTimeMillis() - start;
			MDC.put(RESPONSE_TIME.value(), String.valueOf(elapsed));
			ELKLOGGER.info("");
		}
	}

	/***
	 * This method is used to build {@List}<{MapSqlParameterSource} using
	 * {@List}<{AccountNotification}.
	 *
	 * @param accountDetails : {@List} &lt;{AccountNotification}&gt;
	 * @return {@List}<{MapSqlParameterSource}>
	 */
	private List<MapSqlParameterSource> buildListOfMapSqlParameterSources(
			List<? extends AccountNotification> accountDetails) {
		List<MapSqlParameterSource> listOfMapSqlParameterSources = new ArrayList<>();

		for (AccountNotification account : accountDetails) {

			LOGGER.info("Marking Account={} with flag={}", account.getAccountNumber(),
					account.getIsBalSyncFlag());

			MapSqlParameterSource parameterSource = new MapSqlParameterSource();
			parameterSource
					.addValue(IS_BAL_SYNC.name(), account.getIsBalSyncFlag())
					.addValue(ACCT_NO.name(), account.getAccountNumber())
					.addValue(LST_UPDT_SYS_ID.name(), "Cache Flag Queue")
					.addValue(LST_UPDT_DTTM.name(), new Date());
			listOfMapSqlParameterSources.add(parameterSource);
		}

		return listOfMapSqlParameterSources;
	}

}
