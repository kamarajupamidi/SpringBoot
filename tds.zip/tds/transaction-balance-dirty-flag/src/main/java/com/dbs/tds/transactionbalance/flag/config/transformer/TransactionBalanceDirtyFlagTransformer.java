package com.dbs.tds.transactionbalance.flag.config.transformer;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.xml.transform.stream.StreamSource;

import com.dbs.schemas.digibank.dirtyflag.v1_0.Account;
import com.dbs.schemas.digibank.dirtyflag.v1_0.DirtyFlagUpdate;
import com.dbs.tds.constants.AppIdentifiers;
import com.dbs.tds.dto.AccountNotification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import static com.dbs.tds.constants.AppConstants.APP_REGION;
import static com.dbs.tds.constants.Countries.IN;
import static com.dbs.tds.constants.LoggingConstants.CLIENT_IP;
import static com.dbs.tds.constants.LoggingConstants.FUNCTIONAL_MAP;
import static com.dbs.tds.constants.LoggingConstants.INTERFACE_MAP;
import static com.dbs.tds.constants.LoggingConstants.MSG_UID;
import static com.dbs.tds.constants.LoggingConstants.REQUEST_TYPE;
import static com.dbs.tds.constants.LoggingConstants.SERVICE_ID;
import static com.dbs.tds.constants.RequestTypes.E2E;

/**
 * This class is used to transform the incoming request.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 */
@Component
public class TransactionBalanceDirtyFlagTransformer {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(TransactionBalanceDirtyFlagTransformer.class);

	/**
	 * This field is used to store value for balanceDirtyFlagJaxMarshaller which is of
	 * type {@link Jaxb2Marshaller }.
	 */
	private Jaxb2Marshaller balanceDirtyFlagJaxMarshaller;

	/**
	 * This constructor will help in constructing the instance for marshaller which will
	 * help in converting the incoming request from XML format to a java POJO instance.
	 *
	 * @param balanceDirtyFlagJaxMarshaller : {@link Jaxb2Marshaller}
	 */
	public TransactionBalanceDirtyFlagTransformer(Jaxb2Marshaller balanceDirtyFlagJaxMarshaller) {
		this.balanceDirtyFlagJaxMarshaller = balanceDirtyFlagJaxMarshaller;
	}

	/**
	 * This method is used to transform the incoming request from XML format to a
	 * corresponding java POJO instance.
	 *
	 * @param request : {@link String}
	 * @return {@link DirtyFlagUpdate}
	 */
	public DirtyFlagUpdate transform(String request) {
		startLoggingRequest();
		LOGGER.info("Incoming request {}", request);
		return (DirtyFlagUpdate) this.balanceDirtyFlagJaxMarshaller
				.unmarshal(new StreamSource(new StringReader(request)));
	}

	/**
	 * This method is used to transform the incoming request. Incoming request which will
	 * be in XML format, is parsed into an instance of {@link DirtyFlagUpdate} and this
	 * method will transform the object into a list of {@link AccountNotification} which
	 * further will be used to map database entities.
	 *
	 * @param dirtyflagUpdate : {@link DirtyFlagUpdate}
	 * @return {@link List} &lt; {@link AccountNotification} &gt;
	 */
	public List<AccountNotification> transform(DirtyFlagUpdate dirtyflagUpdate) {

		startLoggingRequest();
		List<AccountNotification> accountDetails = new ArrayList<>();
		for (Account account : dirtyflagUpdate.getAccount()) {

			Assert.notNull(account, "Account Details need to be provided.");
			LOGGER.info("XML Request incoming from MQ request, Account Number={} & Flag Value={}", account.getACCTNO(),
					account.getISBALSYNC());

			AccountNotification accountNotification = new AccountNotification();
			accountNotification.setAccountNumber(account.getACCTNO());
			accountNotification.setIsBalSyncFlag(account.getISBALSYNC());
			LOGGER.info("Account for marking dirty flag  Account Number={} & Flag Value={}", account.getACCTNO(),
					account.getISBALSYNC());

			accountDetails.add(accountNotification);
		}
		return accountDetails;
	}

	/**
	 * This method is used to populate ELK variable in MDC object. By this we print
	 * required fields for analytics in application logs.
	 */
	private void startLoggingRequest() {
		long startTime = System.currentTimeMillis();
		MDC.put(AppIdentifiers.APP_CODE.name(), AppIdentifiers.APP_CODE.value());
		MDC.put(APP_REGION.value(), IN.name());
		MDC.put(REQUEST_TYPE.value(), E2E.name());
		MDC.put(SERVICE_ID.value(), "tdsdirtyflagevent");
		MDC.put(INTERFACE_MAP.value(), "tds_to_soi");
		MDC.put(MSG_UID.value(), UUID.randomUUID().toString());
		MDC.put(CLIENT_IP.value(), "EMSQUEQUE");
		MDC.put(FUNCTIONAL_MAP.value(), "TDS_Dirty_Flag_Event");
		MDC.put("startTime", String.valueOf(startTime));
	}

}
