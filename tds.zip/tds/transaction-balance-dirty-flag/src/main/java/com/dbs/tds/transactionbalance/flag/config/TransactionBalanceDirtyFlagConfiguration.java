package com.dbs.tds.transactionbalance.flag.config;

import java.util.List;

import javax.jms.ConnectionFactory;

import com.dbs.schemas.digibank.dirtyflag.v1_0.DirtyFlagUpdate;
import com.dbs.tds.dto.AccountNotification;
import com.dbs.tds.transactionbalance.flag.config.service.TransactionBalanceDirtyFlagService;
import com.dbs.tds.transactionbalance.flag.config.transformer.TransactionBalanceDirtyFlagTransformer;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.jms.Jms;
import org.springframework.integration.handler.LoggingHandler;
import org.springframework.messaging.MessageChannel;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

/**
 * This class is used as the configuration class which configure the behavior and working
 * of the EMS Message queue which will receive the message coming from SOI and process the
 * message accordingly and update the details in TDS DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@EnableIntegration
@Configuration
public class TransactionBalanceDirtyFlagConfiguration {

	/**
	 * This method is used to receive the message which is coming on EMS message queue
	 * from SOI with balance update cache flag details. This method creates a connection
	 * with the queue with the help of injected connectionFactory and destination name.
	 * Then the message is converted using the injected marshallingMessageConverter and
	 * message is put onto suitable channel for processing. If there is any error during
	 * the process then the message is put onto the error channel.
	 *
	 * @param destinationName : {@link String}
	 * @param connectionFactory : {@link ConnectionFactory}
	 *
	 * @return {@link IntegrationFlow}
	 */
	@Bean
	public IntegrationFlow dirtyFlagEventFlow(@Value("${dirty.flag.inbound.destination}") String destinationName,
			ConnectionFactory connectionFactory) {
		return IntegrationFlows
				.from(Jms.messageDrivenChannelAdapter(connectionFactory)
						.destination(destinationName)
						.outputChannel(outputChannel())
						.errorChannel(errorChannel()))
				.get();
	}

	/**
	 * This method is used to return the message channel for message which is coming in
	 * EMS message queue from SOI and logging the complete message before processing it.
	 *
	 * @return {@link MessageChannel}
	 */
	@Bean
	public MessageChannel outputChannel() {
		return new DirectChannel();
	}

	/**
	 * This method is used to return the Message Channel for Error message Flow.
	 *
	 * @return {@link MessageChannel}
	 */
	@Bean
	public MessageChannel errorChannel() {
		return new DirectChannel();
	}

	/**
	 * This method is used to define the flow of the message channel which will be invoked
	 * whenever there is a message on SOI EMS message queue. This method will transform
	 * the incoming message and put the message to get serviced and get updated in the DB.
	 *
	 * @param transactionBalanceDirtyFlagTransformer :
	 * {@link TransactionBalanceDirtyFlagTransformer}
	 * @param transactionBalanceDirtyFlagService :
	 * {@link TransactionBalanceDirtyFlagService}
	 *
	 * @return {@link IntegrationFlow}
	 */
	@Bean
	public IntegrationFlow dirtyFlagMessagFlow(
			TransactionBalanceDirtyFlagTransformer transactionBalanceDirtyFlagTransformer,
			TransactionBalanceDirtyFlagService transactionBalanceDirtyFlagService) {

		return IntegrationFlows
				.from(outputChannel())
				.<String, DirtyFlagUpdate>transform(transactionBalanceDirtyFlagTransformer::transform)
				.<DirtyFlagUpdate, List<AccountNotification>>transform(
						transactionBalanceDirtyFlagTransformer::transform)
				.handle(transactionBalanceDirtyFlagService)
				.get();
	}

	/**
	 * This method is used to define the flow of the error channel which will be invoked
	 * whenever there is an error during the processing of the incoming message on SOI EMS
	 * message queue.
	 *
	 * @return {@link IntegrationFlow}
	 */
	@Bean
	public IntegrationFlow dirtyFlagMessagErrorFlow() {
		return IntegrationFlows
				.from(errorChannel())
				.handle(new LoggingHandler("ERROR"))
				.get();
	}

	/**
	 * This method is used to provide the instance of the marshaller which will help in
	 * parsing the XML format String object to a java instance with the help of the
	 * Context path and injected location of the schema files used to identify the
	 * correctness of the XML format.
	 *
	 * @param contextPath : {@link String}
	 * @param schemaLocation : {@link String}
	 * @return {@link Jaxb2Marshaller}
	 */
	@Bean
	public Jaxb2Marshaller balanceDirtyFlagJaxMarshaller(@Value("${context.path}") String contextPath,
			@Value("${schema.location}") String schemaLocation) {
		Resource schemaResource = new ClassPathResource(schemaLocation);
		Jaxb2Marshaller balanceDirtyFlagJaxMarshaller = new Jaxb2Marshaller();
		balanceDirtyFlagJaxMarshaller.setContextPaths(contextPath);
		balanceDirtyFlagJaxMarshaller.setSchema(schemaResource);
		return balanceDirtyFlagJaxMarshaller;
	}

}
