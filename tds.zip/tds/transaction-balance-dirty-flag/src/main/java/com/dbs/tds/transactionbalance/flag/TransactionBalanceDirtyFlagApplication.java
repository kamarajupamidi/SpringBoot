package com.dbs.tds.transactionbalance.flag;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * This class is used for initializing the Spring Boot Container for handling and starting
 * the EMS Messages queue which will receive messages incoming from SOI and process them
 * accordingly.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@SpringBootApplication
public class TransactionBalanceDirtyFlagApplication {

	/**
	 * This method is used by JVM to start the Spring Boot Container for this application
	 * which will start the message queue for handling SOI messages with Balance Flag
	 * cache details.
	 *
	 * @param args : {@link String}[]
	 */
	public static void main(String[] args) {
		SpringApplication.run(TransactionBalanceDirtyFlagApplication.class, args);
	}
}
