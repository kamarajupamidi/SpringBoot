package com.dbs.tds.test.transactionhistorybatch.repository.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistorybatch.repository.impl.TransactionNotificationRepositoryImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.internal.util.reflection.Whitebox;
import org.mockito.runners.MockitoJUnitRunner;

import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

/***
 *
 * This class contains Junit test cases for {@link TransactionNotificationRepositoryImpl}
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class TransactionNotificationRepositoryImplTest {

	@Mock
	private SimpleJdbcInsert transactionHistoryInsert;

	@Mock
	private SimpleJdbcInsert dimInsert;

	@Mock
	private DataSource dataSource;

	private List<TransactionNotification> transactionNotifications;

	@InjectMocks
	private TransactionNotificationRepositoryImpl transactionNotificationRepositoryImpl;

	@Before
	public void setUp() {
		this.transactionNotificationRepositoryImpl = new TransactionNotificationRepositoryImpl(this.dataSource);
		this.transactionNotifications = new ArrayList<>();
		this.transactionNotifications.add(getTransNotificationObject());

		Whitebox.setInternalState(this.transactionNotificationRepositoryImpl, "transactionHistoryInsert",
				this.transactionHistoryInsert);
		Whitebox.setInternalState(this.transactionNotificationRepositoryImpl, "dimInsert",
				this.dimInsert);
	}

	@Test
	public void insertTransactionNotificationsTest() {
		this.transactionNotificationRepositoryImpl.insertTransactionNotifications(this.transactionNotifications);

	}

	@Test
	public void insertDimTest() {
		this.transactionNotificationRepositoryImpl.insertDim(this.transactionNotifications);
	}

	/***
	 *
	 * This method is used to build transactionNotification Object
	 * @return {@link TransactionNotification}
	 */
	private TransactionNotification getTransNotificationObject() {

		TransactionNotification tranNotificationObj = new TransactionNotification();
		tranNotificationObj.setAccountNumber("123456");
		tranNotificationObj.setTransactionId("123345");
		tranNotificationObj.setAccountCurrencyCode("INR");
		tranNotificationObj.setTransactionDate(new Date());
		tranNotificationObj.setPostedDate(new Date());
		tranNotificationObj.setAdditionalReference("additional-reference");
		tranNotificationObj.setBankId("2009");
		tranNotificationObj.setAvailableBalance(1000.00);

		return tranNotificationObj;
	}

}
