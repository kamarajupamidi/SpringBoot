package com.dbs.tds.test.transactionhistorybatch.repository.impl;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistorybatch.repository.impl.AccountRepositoryImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.internal.util.reflection.Whitebox;
import org.mockito.runners.MockitoJUnitRunner;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import static org.mockito.internal.util.reflection.Whitebox.setInternalState;

/***
 *
 * This class contains Junit test cases for {@link AccountRepositoryImpl}
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class AccountRepositoryImplTest {

	@Mock
	private NamedParameterJdbcTemplate accountUpdateJdbcTemplate;

	@Mock
	private DataSource dataSource;

	@Mock
	private Connection connection;

	private List<TransactionNotification> transactionNotifications;

	@InjectMocks
	private AccountRepositoryImpl accountRepositoryImpl;

	private String accountUpdateSQL = "SQL-QUERY";

	@Before
	public void setUp() {
		this.accountRepositoryImpl = new AccountRepositoryImpl(this.dataSource);

		this.transactionNotifications = new ArrayList<>();
		this.transactionNotifications.add(fetchTransNotificationObject());

		Whitebox.setInternalState(this.accountRepositoryImpl, "accountUpdateJdbcTemplate",
				this.accountUpdateJdbcTemplate);
	}

	@Test
	public void updateAccountDetailsTest() {
		setInternalState(this.accountRepositoryImpl, "accountUpdateSQL", this.accountUpdateSQL);
		this.accountRepositoryImpl.updateAccountDetails(this.transactionNotifications);
	}

	/***
	 *
	 * This method is used to build transactionNotification Object
	 * @return {@link TransactionNotification}
	 */
	private TransactionNotification fetchTransNotificationObject() {

		TransactionNotification tranObj = new TransactionNotification();
		tranObj.setAccountNumber("67890");
		tranObj.setRecordGenerationTime(new Date());
		tranObj.setLedgerBalance(100.00);
		tranObj.setAvailableBalance(100.00);
		tranObj.setTransactionDate(new Date());
		tranObj.setPostedDate(new Date());

		return tranObj;
	}

}
