package com.dbs.tds.test.transactionhistorybatch.config;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;

import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistorybatch.repository.impl.AccountRepositoryImpl;
import com.dbs.tds.transactionhistorybatch.repository.impl.TransactionNotificationRepositoryImpl;

/**
 * This class contains test cases of insertion operations of transaction notifications and
 * update operation of account details in to TDS DB
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */

@RunWith(MockitoJUnitRunner.class)
public class TransactionNotificationWriterTest {

	@Mock
	private TransactionNotificationRepositoryImpl transactionNotificationRepository;

	@Mock
	private AccountRepositoryImpl accountRepository;

	@Spy
	private List<TransactionNotification> transactionNotifications = new ArrayList<>();

	@Spy
	private TransactionNotification transactionNotification = transactionNotification();

	@Spy
	private GregorianCalendar startCalendar = new GregorianCalendar(2017, 9, 28, 0, 0, 1);

	@Spy
	private GregorianCalendar endCalendar = new GregorianCalendar(2017, 9, 29, 0, 0, 2);

	private final Date transactionDate = startCalendar.getTime();
	private final Date recordGenerationTime = startCalendar.getTime();

	/***
	 * This method is used to do unit test for DB operations of Transaction notifications
	 * and Account details
	 * @throws Exception
	 */
	@Test
	public void writeTest() {
		transactionNotifications.add(transactionNotification);
		assertEquals(1, transactionNotifications.size());
		transactionNotificationRepository.insertTransactionNotifications(transactionNotifications);
		accountRepository.updateAccountDetails(transactionNotifications);
		verify(transactionNotificationRepository).insertTransactionNotifications(transactionNotifications);
		verify(accountRepository).updateAccountDetails(transactionNotifications);
		verifyNoMoreInteractions(transactionNotificationRepository);
		verifyNoMoreInteractions(accountRepository);

	}

	/***
	 *
	 * This method is used to build {@TransactionNotification} object and return the same
	 * with populated values
	 * @return
	 */
	private TransactionNotification transactionNotification() {
		TransactionNotification tranNotif = new TransactionNotification();
		tranNotif.setTransactionId("80979794");
		tranNotif.setAccountNumber("23423424");
		tranNotif.setAccountCurrencyCode("INR");
		tranNotif.setLedgerBalance(1000.00);
		tranNotif.setAvailableBalance(100_000.00);
		tranNotif.setRelatedRecordId("related-record-id");
		tranNotif.setPartTransactionSerialNumber(1L);
		tranNotif.setTransactionParticularCode("transaction-particular-code");
		tranNotif.setTransactionParticulars("transaction particulars");
		tranNotif.setTransactionAmount(10_000.00);
		tranNotif.setTransactionCurrencyCode("INR");
		tranNotif.setPartTransactionType("CR");
		tranNotif.setTransactionDate(transactionDate);
		tranNotif.setValueDate(transactionDate);
		tranNotif.setPostedDate(transactionDate);
		tranNotif.setTransactionReferenceNumber("tran-ref-no");
		tranNotif.setAdditionalReference("additional-ref");
		tranNotif.setTranKey("tran-key");
		tranNotif.setRecordGenerationTime(recordGenerationTime);
		return tranNotif;
	}

}
