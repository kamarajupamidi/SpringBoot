package com.dbs.tds.test.transactionhistorybatch.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import com.dbs.tds.exception.FileAccessException;
import com.dbs.tds.transactionhistorybatch.controller.FinacleBatchJobController;
import com.dbs.tds.transactionhistorybatch.repository.AccountRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.internal.util.reflection.Whitebox;
import org.mockito.runners.MockitoJUnitRunner;

import org.springframework.messaging.MessageChannel;
import org.springframework.mock.web.MockMultipartFile;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

/**
 * This class is used for writing test cases of file loading and validations related to
 * the same
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */

@RunWith(MockitoJUnitRunner.class)
public class FinacleBatchJobControllerTest {

	private static final String FILE_PATH = "batchFile/batch.txt";

	@Mock
	private MockMultipartFile mockMultipartFile;

	@Mock
	private MessageChannel fileInputChannel;

	@Mock
	private AccountRepository accountRepository;

	private FinacleBatchJobController finacleBatchJobController;

	@Before
	public void setUp() {
		this.finacleBatchJobController = new FinacleBatchJobController(this.fileInputChannel);
	}

	/***
	 * This method is used to test whether the file loading is successful and meanwhile
	 * verifying the parameters of {@FileInputData} for EMPTY and NULL checks
	 */
	@Test
	public void invokeFinacleBatchJobTest() {

		File file = getFileObj();
		Whitebox.setInternalState(this.finacleBatchJobController, "filePath", file.getAbsolutePath());
		try {
			MockMultipartFile multiFile = new MockMultipartFile("batch", Files.readAllBytes(file.toPath()));
			assertEquals("INVOKED_FINACLE_NOTIFICATION",
					this.finacleBatchJobController.invokeFinacleBatchJob(multiFile));
		}
		catch (IOException e) {
			throw new FileAccessException("Error Accessing File", e);
		}

	}

	@Test
	public void invokeFinacleBatchJobTestFailUpload() {
		File file = getFileObj();
		Whitebox.setInternalState(this.finacleBatchJobController, "filePath", "C://");
		try {
			MockMultipartFile multiFile = new MockMultipartFile("batch", Files.readAllBytes(file.toPath()));
			assertEquals("INVOKE_FAILED_TO_UPLOAD",
					this.finacleBatchJobController.invokeFinacleBatchJob(multiFile));
		}
		catch (IOException e) {
			throw new FileAccessException("Error Accessing File", e);
		}

	}

	@Test
	public void invokeFinacleBatchJobTestFileNonExistance() {
		when(this.mockMultipartFile.isEmpty()).thenReturn(true);
		when(this.mockMultipartFile.getOriginalFilename()).thenReturn("file");
		assertEquals("INVOKE_FAILED_AS_FILE_IS_EMPTY",
				this.finacleBatchJobController.invokeFinacleBatchJob(this.mockMultipartFile));
	}

	private File getFileObj() {
		ClassLoader loader = getClass().getClassLoader();
		return new File(loader.getResource(FILE_PATH).getFile());
	}

}
