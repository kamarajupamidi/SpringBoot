package com.dbs.tds.test.transactionhistorybatch.config;

import java.io.File;

import com.dbs.tds.batch.core.FileValidatorTasklet;
import com.dbs.tds.batch.core.util.FileLastLineData;
import com.dbs.tds.batch.core.util.FileUtil;
import com.dbs.tds.exception.FileAccessException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.repeat.RepeatStatus;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/***
 *
 * This class is used for test cases of File Validator Tasklet functionality
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class FileValidatorTaskletTest {

	private static final String FILE_PATH = "batchFile/batch.txt";

	private static final String T = "T";

	private static final int ONE = 1;

	private static final int TWO = 2;

	@Mock
	private FileLastLineData fileLastLineData;

	@Mock
	private StepContribution contribution;

	@Mock
	private ChunkContext chunkContext;

	@Mock
	private FileValidatorTasklet tasklet;

	@Spy
	private File file = new File(getClass().getClassLoader().getResource(FILE_PATH).getFile());

	/****
	 *
	 * This method contains test cases for validating the file data
	 */
	@Test
	public void testExecuteMethod() {
		assertNotNull(this.file);
		assertThat(this.file.exists());
		this.fileLastLineData = FileUtil.getLastLineData(this.file);
		assertThat(this.fileLastLineData.getLastLine().startsWith(T));
		Long lineCountInTrailer = Long.valueOf(this.fileLastLineData.getLastLine().substring(ONE));
		Long actualLineCount = this.fileLastLineData.getLastLineNumber() - TWO;
		assertSame(lineCountInTrailer, actualLineCount);

		assertNotNull(this.fileLastLineData);
		try {
			when(this.tasklet.execute(this.contribution, this.chunkContext)).thenReturn(RepeatStatus.FINISHED);
			this.tasklet.execute(this.contribution, this.chunkContext);
			verify(this.tasklet).execute(this.contribution, this.chunkContext);
		}
		catch (Exception e) {
			throw new FileAccessException("Error Occured while executing the Task", e);
		}
	}

}
