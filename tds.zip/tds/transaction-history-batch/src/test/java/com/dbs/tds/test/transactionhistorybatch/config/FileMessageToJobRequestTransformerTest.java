package com.dbs.tds.test.transactionhistorybatch.config;

import java.io.File;

import com.dbs.tds.batch.core.util.FileInputData;
import com.dbs.tds.transactionhistorybatch.config.FileMessageToJobRequestTransformer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import org.springframework.batch.core.Job;
import org.springframework.batch.integration.launch.JobLaunchRequest;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * This class contains test cases for sending message to Job Request
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class FileMessageToJobRequestTransformerTest {

	private static final String FILE_PATH = "batchFile/batch.txt";

	private static final String FILE_NAME = "batch.txt";

	@Mock
	private Job job;

	@Mock
	private FileMessageToJobRequestTransformer fileMessageToJobRequestTransformer;

	@Mock
	private JobLaunchRequest jobLaunchRequest;

	@Spy
	private Message<FileInputData> message = buildMessage();

	/***
	 *
	 * This method contains test cases for Message sending to Job Request
	 */
	@Test
	public void toRequestTest() {
		assertNotNull(this.message);
		when(this.fileMessageToJobRequestTransformer.toRequest(this.message)).thenReturn(this.jobLaunchRequest);
		this.fileMessageToJobRequestTransformer.toRequest(this.message);
		verify(this.fileMessageToJobRequestTransformer).toRequest(this.message);
	}

	/***
	 *
	 * This method is used to build {@Message}<{@FileInputData}> object and return the
	 * same
	 * @return {@Message}<{@FileInputData}>
	 */
	private Message<FileInputData> buildMessage() {
		ClassLoader loader = getClass().getClassLoader();
		File file = spy(new File(loader.getResource(FILE_PATH).getFile()));
		return new Message<FileInputData>() {
			@Override
			public FileInputData getPayload() {
				FileInputData fileInputData = new FileInputData();
				fileInputData.setAbsolutePath(file.getAbsolutePath());
				fileInputData.setFileName(FILE_NAME);
				return fileInputData;
			}

			@Override
			public MessageHeaders getHeaders() {
				return null;
			}
		};
	}
}
