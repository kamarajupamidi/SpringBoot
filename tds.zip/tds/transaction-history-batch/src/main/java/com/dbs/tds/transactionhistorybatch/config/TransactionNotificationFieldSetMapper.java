package com.dbs.tds.transactionhistorybatch.config;

import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.util.DateTimeFormat;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindException;

/**
 * This class is used to map each record from the batch file to the Java POJO instance, so
 * that the records can be processed and DTO instance is created for DAO interaction.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Component
public class TransactionNotificationFieldSetMapper implements FieldSetMapper<TransactionNotification> {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(TransactionNotificationFieldSetMapper.class);

	/**
	 * This method is used to map one record which is parsed from a line in the batch file
	 * to an instance of {@link TransactionNotification} so that this instance can be
	 * transfered to DAO layer for DB interaction.
	 *
	 * @param fieldSet : {@link FieldSet}
	 * @return {@link TransactionNotification}
	 *
	 * @throws BindException {@link BindException}
	 */
	@Override
	public TransactionNotification mapFieldSet(FieldSet fieldSet) throws BindException {

		TransactionNotification transactionNotification = new TransactionNotification();
		transactionNotification.setTransactionDate(StringUtils.isNotBlank(fieldSet.readString(0))
				? fieldSet.readDate(0, DateTimeFormat.DATE_TIME_ISO.pattern())
				: null);
		transactionNotification.setValueDate(StringUtils.isNotBlank(fieldSet.readString(1))
				? fieldSet.readDate(1, DateTimeFormat.DATE_TIME_ISO.pattern())
				: null);
		transactionNotification.setTransactionId(fieldSet.readString(2));
		transactionNotification.setTransactionCurrencyCode(fieldSet.readString(3));
		transactionNotification.setTransactionType(fieldSet.readString(4));
		transactionNotification.setTransactionParticulars(fieldSet.readString(5));
		transactionNotification.setRelatedRecordId(fieldSet.readString(6));
		transactionNotification.setAdditionalReference(fieldSet.readString(7));
		transactionNotification.setTransactionReferenceNumber(fieldSet.readString(8));
		transactionNotification
				.setTransactionAmount(StringUtils.isNotBlank(fieldSet.readString(9)) ? fieldSet.readDouble(9) : null);
		transactionNotification.setPartTransactionType(fieldSet.readString(10));
		transactionNotification.setPartTransactionSerialNumber(fieldSet.readLong(11));
		transactionNotification.setTransactionStatus(fieldSet.readString(12));
		transactionNotification.setAccountNumber(fieldSet.readString(13));
		transactionNotification.setTransactionParticularCode(fieldSet.readString(14));
		transactionNotification
				.setLedgerBalance(StringUtils.isNotBlank(fieldSet.readString(15)) ? fieldSet.readDouble(15) : null);
		transactionNotification.setPostedDate(StringUtils.isNotBlank(fieldSet.readString(16))
				? fieldSet.readDate(16, DateTimeFormat.DATE_TIME_ISO.pattern())
				: null);
		transactionNotification
				.setAvailableBalance(StringUtils.isNotBlank(fieldSet.readString(17)) ? fieldSet.readDouble(17) : null);
		transactionNotification.setAccountCurrencyCode(fieldSet.readString(18));
		transactionNotification.setRecordGenerationTime(StringUtils.isNotBlank(fieldSet.readString(19))
				? fieldSet.readDate(19, DateTimeFormat.DATE_TIME_ISO.pattern())
				: null);
		transactionNotification.calculateTranKey();

		LOGGER.info("Transaction Notification Generated : {}", transactionNotification);

		return transactionNotification;
	}

}
