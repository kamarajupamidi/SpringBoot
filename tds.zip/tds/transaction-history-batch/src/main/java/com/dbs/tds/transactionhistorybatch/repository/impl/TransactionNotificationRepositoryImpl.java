package com.dbs.tds.transactionhistorybatch.repository.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistorybatch.repository.TransactionNotificationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import static com.dbs.tds.constants.TransactionDimFields.TRAN_CMMNT;
import static com.dbs.tds.constants.TransactionFields.ACCTCURR;
import static com.dbs.tds.constants.TransactionFields.ACCTID;
import static com.dbs.tds.constants.TransactionFields.ADDNLREF;
import static com.dbs.tds.constants.TransactionFields.AMOUNT;
import static com.dbs.tds.constants.TransactionFields.AVAILABLEBAL;
import static com.dbs.tds.constants.TransactionFields.CURRENCY;
import static com.dbs.tds.constants.TransactionFields.LEDGERBAL;
import static com.dbs.tds.constants.TransactionFields.LST_UPDT_DTTM;
import static com.dbs.tds.constants.TransactionFields.LST_UPDT_SYS_ID;
import static com.dbs.tds.constants.TransactionFields.POSTINGDATE;
import static com.dbs.tds.constants.TransactionFields.RELATEDRECID;
import static com.dbs.tds.constants.TransactionFields.RELATEDTRANREF;
import static com.dbs.tds.constants.TransactionFields.TRANCODE;
import static com.dbs.tds.constants.TransactionFields.TRANDATE;
import static com.dbs.tds.constants.TransactionFields.TRANDESC;
import static com.dbs.tds.constants.TransactionFields.TRANID;
import static com.dbs.tds.constants.TransactionFields.TRANKEY;
import static com.dbs.tds.constants.TransactionFields.TRANSEQNUM;
import static com.dbs.tds.constants.TransactionFields.TXNTYPE;
import static com.dbs.tds.constants.TransactionFields.VALUEDATE;

/**
 * This class is used to provide implementation for
 * {@link TransactionNotificationRepository} and also provide behaviors to interact with
 * TDS DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Repository
public class TransactionNotificationRepositoryImpl implements TransactionNotificationRepository {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(TransactionNotificationRepositoryImpl.class);

	/**
	 * This field is used to store value for transactionHistoryInsert which is of type
	 * {@link SimpleJdbcInsert }.
	 */
	private SimpleJdbcInsert transactionHistoryInsert;

	/**
	 * This field is used to store value for dimInsert which is of type
	 * {@link SimpleJdbcInsert }.
	 */
	private SimpleJdbcInsert dimInsert;

	/**
	 * This constructor is used with injected {@link DataSource} instance to setup the
	 * {@link SimpleJdbcInsert} instance for inserting the transaction details.
	 *
	 * @param dataSource : {@link DataSource}
	 */
	public TransactionNotificationRepositoryImpl(DataSource dataSource) {
		this.transactionHistoryInsert = new SimpleJdbcInsert(dataSource).withTableName("T_DTA_FACT").usingColumns(
				"TRANID", "ACCTID", "ACCTCURR", "LEDGERBAL", "AVAILABLEBAL", "RELATEDRECID", "TRANSEQNUM", "TRANDATE",
				"VALUEDATE", "POSTINGDATE", "TRANCODE", "TRANDESC", "AMOUNT", "CURRENCY", "TXNTYPE",
				"RELATEDTRANREF", "ADDNLREF", "TRANKEY", "LST_UPDT_SYS_ID", "LST_UPDT_DTTM");

		this.dimInsert = new SimpleJdbcInsert(dataSource).withTableName("T_DTA_DIM").usingColumns(
				"TRANKEY", "TRAN_CTGR", "TRAN_CMMNT", "LST_UPDT_SYS_ID", "LST_UPDT_DTTM");

	}

	/**
	 * This method is used to insert transaction details, coming in the Finacle online
	 * daily reconciliation batch, into TDS DB.
	 *
	 * @param transactionNotifications : {@link List} &lt; {@link TransactionNotification}
	 * &gt;
	 */
	@Override
	public void insertTransactionNotifications(List<? extends TransactionNotification> transactionNotifications) {

		LOGGER.info("Initated insertion batch events to db");

		List<MapSqlParameterSource> mapSqlParameterSources = buildMapSqlParameterSources(transactionNotifications);

		try {
			this.transactionHistoryInsert.executeBatch(
					mapSqlParameterSources.toArray(new MapSqlParameterSource[mapSqlParameterSources.size()]));
		}
		catch (DuplicateKeyException e) {
			LOGGER.info("Duplicate Exception Occured which ignored while inserting to T_DTA_FACT");
			// ignoring duplicate key exception
		}
		LOGGER.info("Completed insertion batch events to db");
	}

	/***
	 * This method is build parameter source for the given inputs
	 *
	 * @param transactionNotifications : {@link List}<{@TransactionNotification}>
	 * @return {@List}<{MapSqlParameterSource}>
	 */
	private List<MapSqlParameterSource> buildMapSqlParameterSources(
			List<? extends TransactionNotification> transactionNotifications) {

		List<MapSqlParameterSource> mapSqlParameterSources = new ArrayList<>();
		for (TransactionNotification transactionNotification : transactionNotifications) {
			MapSqlParameterSource parameterSource = new MapSqlParameterSource();
			parameterSource.addValue(TRANID.name(), transactionNotification.getTransactionId())
					.addValue(ACCTID.name(), transactionNotification.getAccountNumber())
					.addValue(ACCTCURR.name(), transactionNotification.getAccountCurrencyCode())
					.addValue(LEDGERBAL.name(), transactionNotification.getLedgerBalance())
					.addValue(AVAILABLEBAL.name(), transactionNotification.getAvailableBalance())
					.addValue(RELATEDRECID.name(), transactionNotification.getRelatedRecordId())
					.addValue(TRANSEQNUM.name(), transactionNotification.getPartTransactionSerialNumber())
					.addValue(TRANDATE.name(), transactionNotification.getTransactionDate())
					.addValue(VALUEDATE.name(), transactionNotification.getValueDate())
					.addValue(POSTINGDATE.name(), transactionNotification.getPostedDate())
					.addValue(TRANCODE.name(), transactionNotification.getTransactionParticularCode())
					.addValue(TRANDESC.name(), transactionNotification.getTransactionParticulars())
					.addValue(AMOUNT.name(), transactionNotification.getTransactionAmount())
					.addValue(CURRENCY.name(), transactionNotification.getTransactionCurrencyCode())
					.addValue(TXNTYPE.name(), transactionNotification.getPartTransactionType())
					.addValue(RELATEDTRANREF.name(), transactionNotification.getTransactionReferenceNumber())
					.addValue(ADDNLREF.name(), transactionNotification.getAdditionalReference())
					.addValue(TRANKEY.name(), transactionNotification.getTranKey())
					.addValue(LST_UPDT_SYS_ID.name(), "BATCH")
					.addValue(LST_UPDT_DTTM.name(), new Date());
			mapSqlParameterSources.add(parameterSource);

		}

		return mapSqlParameterSources;
	}

	/**
	 * This method is used to insert the transaction details received in Finacle online
	 * daily reconciliation batch. It will insert the transaction additional details.
	 *
	 * @param transactionNotifications : {@link List} &lt; {@link TransactionNotification}
	 * &gt;
	 */
	@Override
	public void insertDim(List<? extends TransactionNotification> transactionNotifications) {
		List<MapSqlParameterSource> mapSqlParameterSources = new ArrayList<>();

		for (TransactionNotification transactionNotification : transactionNotifications) {
			MapSqlParameterSource parameterSource = new MapSqlParameterSource();
			parameterSource
					.addValue(TRAN_CMMNT.name(), transactionNotification.getAdditionalReference())
					.addValue(TRANKEY.name(), transactionNotification.getTranKey())
					.addValue(LST_UPDT_SYS_ID.name(), "BATCH")
					.addValue(LST_UPDT_DTTM.name(), new Date());
			mapSqlParameterSources.add(parameterSource);

		}
		try {
			this.dimInsert.executeBatch(
					mapSqlParameterSources.toArray(new MapSqlParameterSource[mapSqlParameterSources.size()]));
		}
		catch (DuplicateKeyException e) {
			LOGGER.info("Duplicate Exception Occured which ignored while inserting to T_DTA_DIM");
			// ignoring duplicate key exception
		}
	}

}
