package com.dbs.tds.transactionhistorybatch.repository;

import java.util.List;

import com.dbs.tds.dto.TransactionNotification;

import org.springframework.stereotype.Repository;

/**
 * This interface is used to provide abstract functionalities for interacting with TDS DB
 * for Account Details DB operations.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Repository
public interface AccountRepository {

	/***
	 * This method is to execute batch operation for Account Details to update into TDS
	 * data base.
	 *
	 * @param transactionNotifications : {@link List} &lt;{@link TransactionNotification}
	 * &gt;
	 */
	public void updateAccountDetails(List<? extends TransactionNotification> transactionNotifications);
}
