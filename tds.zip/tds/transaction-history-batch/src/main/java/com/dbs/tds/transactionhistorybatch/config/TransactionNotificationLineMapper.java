package com.dbs.tds.transactionhistorybatch.config;

import com.dbs.tds.dto.TransactionNotification;

import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.stereotype.Component;

/**
 * This class is used to map each record from the batch file to the Java POJO instance, so
 * that the records can be processed.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Component
public class TransactionNotificationLineMapper implements LineMapper<TransactionNotification> {

	/**
	 * This field is used to store value for tokenizer which is of type
	 * {@link LineTokenizer }.
	 */
	private LineTokenizer tokenizer;

	/**
	 * This field is used to store value for fieldSetMapper which is of type
	 * {@link FieldSetMapper }<{@link TransactionNotification}>.
	 */
	private FieldSetMapper<TransactionNotification> fieldSetMapper;

	/**
	 * This constructor is used along with an injected fieldSetMapper to set up the
	 * default instances for tokenizer and mapper.
	 *
	 * @param fieldSetMapper {@link TransactionNotificationFieldSetMapper}
	 */
	public TransactionNotificationLineMapper(TransactionNotificationFieldSetMapper fieldSetMapper) {
		this.tokenizer = new DelimitedLineTokenizer("|");
		this.fieldSetMapper = fieldSetMapper;
	}

	/**
	 * This method is used to map each record present in a batch file to an instance of
	 * {@link TransactionNotification}.
	 *
	 * @param line : {@link String}
	 * @param lineNumber : {@link Integer}
	 * @return {@link TransactionNotification}
	 *
	 * @throws Exception {@link Exception}
	 */
	@Override
	public TransactionNotification mapLine(String line, int lineNumber) throws Exception {
		if (line != null && line.startsWith("T")) {
			return null;
		}
		TransactionNotification transactionNotification = this.fieldSetMapper
				.mapFieldSet(this.tokenizer.tokenize(line));
		transactionNotification.setInputLine(line);
		return transactionNotification;
	}
}
