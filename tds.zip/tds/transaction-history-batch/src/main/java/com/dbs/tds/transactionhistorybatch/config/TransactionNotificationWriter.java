package com.dbs.tds.transactionhistorybatch.config;

import java.util.List;

import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistorybatch.repository.AccountRepository;
import com.dbs.tds.transactionhistorybatch.repository.TransactionNotificationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * This class will act as a Writer and is used to move transaction notification details to
 * repository which takes care of inserting or updating data into TDS data base
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 */
@Component
public class TransactionNotificationWriter implements ItemWriter<TransactionNotification> {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(TransactionNotificationWriter.class);

	/**
	 * This field is used to store instance of type
	 * {@link TransactionNotificationRepository }.
	 */
	private TransactionNotificationRepository transactionNotificationRepository;

	/**
	 * This field is used to store instance of type {@link AccountRepository }.
	 */
	private AccountRepository accountRepository;

	/**
	 * This constructor will help in building the instance of {@link AccountRepository}
	 * and {@link TransactionNotificationRepository} which will help in interacting with
	 * TDS DB for storing the transaction details.
	 *
	 * @param transactionNotificationRepository :
	 * {@link TransactionNotificationRepository}
	 * @param accountRepository : {@link AccountRepository}
	 */
	public TransactionNotificationWriter(TransactionNotificationRepository transactionNotificationRepository,
			AccountRepository accountRepository) {
		this.transactionNotificationRepository = transactionNotificationRepository;
		this.accountRepository = accountRepository;
	}

	/**
	 * This method is used to call methods of TransactionNotificationRepository and
	 * AccountDetailsRepository to insert or update details, coming from Finacle online
	 * Event Queue Notification, into TDS DB.
	 *
	 * @param transactionNotifications : {@link List}
	 * @throws Exception {@link Exception}
	 */
	@Override
	@Transactional
	public void write(List<? extends TransactionNotification> transactionNotifications) throws Exception {

		LOGGER.info("Started writing batch events to db");

		this.transactionNotificationRepository.insertTransactionNotifications(transactionNotifications);

		this.transactionNotificationRepository.insertDim(transactionNotifications);

		this.accountRepository.updateAccountDetails(transactionNotifications);

		LOGGER.info("Completed writing batch events to db");

	}

}
