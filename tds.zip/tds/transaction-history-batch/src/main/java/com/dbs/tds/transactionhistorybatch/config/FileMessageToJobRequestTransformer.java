package com.dbs.tds.transactionhistorybatch.config;

import com.dbs.tds.batch.core.util.FileInputData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.integration.launch.JobLaunchRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.annotation.Transformer;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

/**
 * This class is used to transform the incoming request for batch trigger.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 */
@Component
public class FileMessageToJobRequestTransformer {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(FileMessageToJobRequestTransformer.class);

	/**
	 * This field is used to store value for job which is of type {@link Job }.
	 */
	private Job job;

	/**
	 * This field is used to store value for fileParameterName which is of type
	 * {@link String }.
	 */
	@Value("${file.parameter.name}")
	private String fileParameterName;

	/**
	 * This field is used to store value for fileAbsolutePath which is of type
	 * {@link String }.
	 */
	@Value("${file.parameter.absolutepath}")
	private String fileAbsolutePath;

	/**
	 * This constructor is used with injected {@link Job} instance to setup the batch job
	 * which will process the batch file.
	 *
	 * @param job {@link Job}
	 */
	public FileMessageToJobRequestTransformer(Job job) {
		this.job = job;
	}

	/**
	 * This method is used to transform the incoming message into the request for job.
	 * This job launch request will launch the batch job for processing of the batch file.
	 *
	 * @param message : {@link Message} &lt; {@link FileInputData} &gt;
	 * @return {@link JobLaunchRequest}
	 */
	@Transformer
	public JobLaunchRequest toRequest(Message<FileInputData> message) {
		JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
		jobParametersBuilder.addString(this.fileAbsolutePath, message.getPayload().getAbsolutePath());
		jobParametersBuilder.addString(this.fileParameterName, message.getPayload().getFileName());

		LOGGER.info("Job parameters to launch the job fileAbsolutePath={},fileParameterName={}",
				message.getPayload().getAbsolutePath(), message.getPayload().getFileName());

		return new JobLaunchRequest(this.job, jobParametersBuilder.toJobParameters());
	}
}
