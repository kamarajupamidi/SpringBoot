package com.dbs.tds.transactionhistorybatch.config;

import com.dbs.tds.dto.TransactionNotification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.core.annotation.OnReadError;
import org.springframework.batch.core.annotation.OnSkipInWrite;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.file.FileHeaders;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.MessageChannel;
import org.springframework.stereotype.Component;

/**
 * This class is used as configuration and instance for chunk processing of the batch
 * file, which is coming from Finacle. Records will be read and processed in chunks and
 * only after one chunk is processed then the control moves to next chunk. If the error
 * occurs while processing then that chunk is skipped and control moves to next chunk.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 */
@StepScope
@Component
public class TransactionNotificationChunkListener {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(TransactionNotificationChunkListener.class);

	/**
	 * This field is used to store value for filePath which is of type {@link String }.
	 */
	@Value("#{jobParameters['fileName']}")
	private String filePath;

	/**
	 * This field is used to store value for fileParseErrorChannel which is of type
	 * {@link MessageChannel }.
	 */
	private MessageChannel fileParseErrorChannel;

	/**
	 * This constructor is used with injected instance of {@link MessageChannel} which
	 * will be used to receive the message when there is any error during the processing
	 * of the batch file chunk.
	 *
	 * @param fileParseErrorChannel : {@link MessageChannel}
	 */
	public TransactionNotificationChunkListener(MessageChannel fileParseErrorChannel) {
		this.fileParseErrorChannel = fileParseErrorChannel;
	}

	/**
	 * This method will be executed whenever any specific chunk is skipped due to any
	 * error during the processing of the chunk. Skipped chunk will be written in the
	 * logs.
	 *
	 * @param exception : {@link Exception}
	 */
	@OnReadError
	public void onReadError(Exception exception) {
		if (exception instanceof FlatFileParseException) {
			FlatFileParseException ffpe = (FlatFileParseException) exception;

			LOGGER.error("Error reading data on filePath={}, line={}, data={}", this.filePath, ffpe.getLineNumber(),
					ffpe.getInput());

			this.fileParseErrorChannel.send(
					MessageBuilder.withPayload(ffpe.getInput()).setHeader(FileHeaders.FILENAME, this.filePath).build());
		}
	}

	/**
	 *
	 * This method will be executed whenever any specific chunk is skipped due to any
	 * error during the processing of the chunk. Skipped chunk will be written in the
	 * logs.
	 * @param transactionNotification : {@link TransactionNotification}
	 * @param throwable {@link Throwable}
	 */
	@OnSkipInWrite
	public void onSkipInWrite(TransactionNotification transactionNotification, Throwable throwable) {
		LOGGER.error("Error writing data={} ", transactionNotification.getInputLine(), throwable);
		this.fileParseErrorChannel.send(
				MessageBuilder.withPayload(transactionNotification.getInputLine())
				.setHeader(FileHeaders.FILENAME, this.filePath).build());
	}
}
