package com.dbs.tds.transactionhistorybatch.repository;

import java.util.List;

import com.dbs.tds.dto.TransactionNotification;

import org.springframework.stereotype.Repository;

/**
 * This interface is used to provide abstract functionalities for interacting with TDS DB
 * for Transaction Notifications DB operations.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Repository
public interface TransactionNotificationRepository {

	/***
	 * This method is to execute batch operation for Transaction Notifications to insert
	 * into TDS data base.
	 *
	 * @param transactionNotifications : {@link List} &lt; {@link TransactionNotification}
	 * &gt;
	 */
	public void insertTransactionNotifications(List<? extends TransactionNotification> transactionNotifications);

	/**
	 * This method is used to execute the batch operation to insert the transaction
	 * additional details for normal transaction request.
	 *
	 * @param transactionNotifications : {@link List} &lt; {@link TransactionNotification}
	 * &gt;
	 */
	public void insertDim(List<? extends TransactionNotification> transactionNotifications);

}
