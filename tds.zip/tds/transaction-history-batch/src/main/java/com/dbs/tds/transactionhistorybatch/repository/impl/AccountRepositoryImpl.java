package com.dbs.tds.transactionhistorybatch.repository.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistorybatch.repository.AccountRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import static com.dbs.tds.constants.AccountFields.ACCT_AVLBL_BAL;
import static com.dbs.tds.constants.AccountFields.ACCT_LDGR_BAL;
import static com.dbs.tds.constants.AccountFields.ACCT_NO;
import static com.dbs.tds.constants.AccountFields.IS_BAL_SYNC;
import static com.dbs.tds.constants.AccountFields.LST_UPDT_DTTM;
import static com.dbs.tds.constants.AccountFields.LST_UPDT_SYS_ID;

/**
 * This class is used to provide implementation for {@link AccountRepository} and also
 * provide behaviors to interact with TDS DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Repository
public class AccountRepositoryImpl implements AccountRepository {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(AccountRepositoryImpl.class);

	/**
	 * This field is used to store value for accountUpdateJdbcTemplate which is of type
	 * {@link NamedParameterJdbcTemplate }.
	 */
	private NamedParameterJdbcTemplate accountUpdateJdbcTemplate;

	/**
	 * This field is used to store value for accountUpdateSQL which is of type
	 * {@link String }.
	 */
	private String accountUpdateSQL;

	/**
	 * This constructor is used with injected {@link DataSource} instance to setup the
	 * named parameterized Query in {@link String} type, for update Balances operation and
	 * setup the {@link NamedParameterJdbcTemplate} instance for updating account details.
	 *
	 * @param dataSource : {@link DataSource}
	 */
	public AccountRepositoryImpl(DataSource dataSource) {
		this.accountUpdateJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
		this.accountUpdateSQL = "UPDATE T_ACCT SET"
				+ " ACCT_AVLBL_BAL = CASE WHEN BAL_ASOFDATETIME IS NULL OR BAL_ASOFDATETIME <= :messageDate THEN :ACCT_AVLBL_BAL ELSE ACCT_AVLBL_BAL END,"
				+ " ACCT_LDGR_BAL = CASE WHEN BAL_ASOFDATETIME IS NULL OR BAL_ASOFDATETIME <= :messageDate THEN :ACCT_LDGR_BAL ELSE ACCT_LDGR_BAL END,"
				+ " BAL_ASOFDATETIME = CASE WHEN BAL_ASOFDATETIME IS NULL OR BAL_ASOFDATETIME <= :messageDate THEN :messageDate ELSE BAL_ASOFDATETIME END,"
				+ " IS_BAL_SYNC = CASE WHEN BAL_ASOFDATETIME IS NULL OR BAL_ASOFDATETIME <= :messageDate THEN :IS_BAL_SYNC ELSE IS_BAL_SYNC END,"
				+ " LST_UPDT_SYS_ID = :LST_UPDT_SYS_ID, LST_UPDT_DTTM = :LST_UPDT_DTTM"
				+ " WHERE ACCT_NO = :ACCT_NO";
	}

	/**
	 * This method is used to update account details, coming from Finacle online Event
	 * Queue Notification, into TDS DB.
	 * @param transactionNotifications : {@link List} &lt; {@link TransactionNotification}
	 * &gt;
	 */
	@Override
	@Transactional
	public void updateAccountDetails(List<? extends TransactionNotification> transactionNotifications) {
		LOGGER.info("Initated batch update events to DB.");

		List<MapSqlParameterSource> mapSqlParameterSources = buildMapSqlParameterSources(transactionNotifications);
		this.accountUpdateJdbcTemplate.batchUpdate(this.accountUpdateSQL,
				mapSqlParameterSources.toArray(new MapSqlParameterSource[mapSqlParameterSources.size()]));
		LOGGER.info("Completed batch update events to DB.");
	}

	/***
	 * This method is used to build {@List}<{MapSqlParameterSource} using
	 * {@List}<{TransactionNotification}
	 * @param {@List}<{@TransactionNotification}>
	 * @return {@List}<{MapSqlParameterSource}>
	 */
	private List<MapSqlParameterSource> buildMapSqlParameterSources(
			List<? extends TransactionNotification> transactionNotifications) {

		List<MapSqlParameterSource> mapSqlParameterSources = new ArrayList<>();
		for (TransactionNotification transactionNotification : transactionNotifications) {
			MapSqlParameterSource parameterSource = new MapSqlParameterSource();
			parameterSource.addValue(ACCT_NO.name(), transactionNotification.getAccountNumber())
					.addValue(ACCT_LDGR_BAL.name(), transactionNotification.getLedgerBalance())
					.addValue(ACCT_AVLBL_BAL.name(), transactionNotification.getAvailableBalance())
					.addValue("messageDate", transactionNotification.getRecordGenerationTime())
					.addValue(IS_BAL_SYNC.name(), "Y")
					.addValue(LST_UPDT_SYS_ID.name(), "BATCH")
					.addValue(LST_UPDT_DTTM.name(), new Date());
			mapSqlParameterSources.add(parameterSource);

		}

		return mapSqlParameterSources;
	}

}
