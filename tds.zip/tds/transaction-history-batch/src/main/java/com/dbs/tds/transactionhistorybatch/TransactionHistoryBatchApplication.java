package com.dbs.tds.transactionhistorybatch;

import com.dbs.tds.config.BatchCoreConfiguration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

/**
 * This class is used for initializing the Spring Boot Container for handling and starting
 * the Batch Process which will receive trigger messages as rest message and then start
 * executing the batch process.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@SpringBootApplication
@Import(BatchCoreConfiguration.class)
public class TransactionHistoryBatchApplication {

	/**
	 * This method is used by JVM to start the Spring Boot Container for this application
	 * which will start the Batch Process.
	 *
	 * @param args : {@link String}[]
	 */
	public static void main(String[] args) {
		SpringApplication.run(TransactionHistoryBatchApplication.class, args);
	}
}
