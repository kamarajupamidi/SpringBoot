package com.dbs.tds.transactionhistorybatch.config;

import com.dbs.tds.batch.core.FileValidatorTasklet;
import com.dbs.tds.batch.core.MoveFilesToErrorFolderTasklet;
import com.dbs.tds.batch.core.MoveFilesToProcessedFolderTasklet;
import com.dbs.tds.dto.TransactionNotification;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;

/**
 * This class is used as the configuration class which configure the behavior and working
 * of the Batch Job which will read a batch file coming from Finacle and process the file
 * accordingly and insert/update the details in TDS DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

	/**
	 * This field is used to store instance of type {@link JobBuilderFactory }.
	 */
	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	/**
	 * This field is used to store instance of type {@link StepBuilderFactory }.
	 */
	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	/**
	 * This method is used to provide the configuration of the job instance, it will take
	 * different steps as the parameters which will be used to setup a job. This job will
	 * check for the file validation, validated file will be processed so that the records
	 * present in the file will be inserted into TDS DB and invalid file will be moved to
	 * an error location. After successful processing, file will be moved to processed
	 * folder.
	 *
	 * @param fileValidatorStep : {@link Step}
	 * @param fileToDatabaseStep : {@link Step}
	 * @param moveFilesToErroFolderStep : {@link Step}
	 * @param moveFilesToProcessedFolderStep : {@link Step}
	 * @return {@link Job}
	 */
	@Bean
	public Job job(Step fileValidatorStep, Step fileToDatabaseStep, Step moveFilesToErroFolderStep,
			Step moveFilesToProcessedFolderStep) {
		return this.jobBuilderFactory.get("etl").incrementer(new RunIdIncrementer())
				.start(fileValidatorStep)
				.on(ExitStatus.FAILED.getExitCode())
				.to(moveFilesToErroFolderStep)
				.from(fileValidatorStep)
				.on(ExitStatus.COMPLETED.getExitCode())
				.to(fileToDatabaseStep)
				.on(ExitStatus.COMPLETED.getExitCode())
				.to(moveFilesToProcessedFolderStep)
				.end()
				.build();
	}

	/**
	 * This method is used to provide configuration for the step, which will be used to
	 * process the file and move the records to Database for TDS DB interaction. File will
	 * be read in chunks by an {@link ItemReader} instance and valid file is sent to
	 * writer for writing the content in TDS DB.
	 *
	 * @param itemReader : {@link ItemReader} &lt;{@link TransactionNotification} &gt;
	 * @param transactionNotificationWriter : {@link TransactionNotificationWriter}
	 * @param chunkListener : {@link TransactionNotificationChunkListener}
	 * @return {@link Step}
	 */
	@Bean
	public Step fileToDatabaseStep(ItemReader<TransactionNotification> itemReader,
			TransactionNotificationWriter transactionNotificationWriter,
			TransactionNotificationChunkListener chunkListener) {
		return this.stepBuilderFactory.get("file-db")
				.<TransactionNotification, TransactionNotification>chunk(100)
				.reader(itemReader)
				.writer(transactionNotificationWriter)
				.faultTolerant()
				.skip(FlatFileParseException.class)
				.skip(Exception.class)
				.skipLimit(Integer.MAX_VALUE)
				.listener(chunkListener)
				.build();
	}

	/**
	 * This method is used to configure the step for File Validation with the help of a
	 * {@link FileValidatorTasklet} instance. File will be validated for valid header and
	 * valid footer.
	 *
	 * @param fileValidatorTasklet : {@link FileValidatorTasklet}
	 * @return {@link Step}
	 */
	@Bean
	public Step fileValidatorStep(FileValidatorTasklet fileValidatorTasklet) {
		return this.stepBuilderFactory.get("file-validate").tasklet(fileValidatorTasklet).build();
	}

	/**
	 * This method is used to configure the step for moving the file to Error folder with
	 * the help of a {@link MoveFilesToErrorFolderTasklet} instance. If the file is
	 * invalid then the file is moved to an error folder.
	 *
	 * @param moveFilesToErroFolderTasklet : {@link MoveFilesToErrorFolderTasklet}
	 * @return {@link Step}
	 */
	@Bean
	public Step moveFilesToErroFolderStep(MoveFilesToErrorFolderTasklet moveFilesToErroFolderTasklet) {
		return this.stepBuilderFactory.get("move-file-error").tasklet(moveFilesToErroFolderTasklet).build();
	}

	/**
	 * This method is used to configure the step for moving the file to processed folder
	 * with the help of a {@link MoveFilesToProcessedFolderTasklet} instance. If the file
	 * is valid and it is processed successfully then the file is moved to a processed
	 * folder.
	 *
	 * @param filesToProcessedFolderTasklet : {@link MoveFilesToProcessedFolderTasklet}
	 * @return {@link Step}
	 */
	@Bean
	public Step moveFilesToProcessedFolderStep(MoveFilesToProcessedFolderTasklet filesToProcessedFolderTasklet) {
		return this.stepBuilderFactory.get("move-file-processed").tasklet(filesToProcessedFolderTasklet).build();
	}

	/**
	 * This method is used to configure the ItemReader with the help of the injected
	 * fileName and an instance of {@link TransactionNotificationLineMapper}. Reader will
	 * read the content of the file, line-by-line and map the file using the mapper to a
	 * JAVA POJO instance.
	 *
	 * @param fileName : {@link Resource}
	 * @param lineMapper : {@link TransactionNotificationLineMapper}
	 * @return {@link FlatFileItemReader} &lt; {@link TransactionNotification} &gt;
	 */
	@Bean
	@StepScope
	public FlatFileItemReader<TransactionNotification> reader(
			@Value("file:#{jobParameters['fileAbsolutePath']}") Resource fileName,
			TransactionNotificationLineMapper lineMapper) {
		FlatFileItemReader<TransactionNotification> itemReader = new FlatFileItemReader<>();
		itemReader.setName("file-reader");
		itemReader.setLineMapper(lineMapper);
		itemReader.setResource(fileName);
		itemReader.setLinesToSkip(1);
		return itemReader;
	}

}
