package com.dbs.tds.transactionhistorybatch.controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

import com.dbs.tds.batch.core.util.FileInputData;
import com.dbs.tds.constants.ErrorConstants;
import com.dbs.tds.constants.StatusCodes;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.MessageChannel;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import static com.dbs.tds.constants.AppConstants.STATUS_CODE_DES_KEY;
import static com.dbs.tds.constants.AppConstants.STATUS_CODE_KEY;
import static com.dbs.tds.constants.LoggingConstants.ERROR_TYPE;
import static com.dbs.tds.constants.LoggingConstants.FUNCTIONAL_MAP;

/**
 * This class is used as Controller for Rest Message which will trigger the batch job for
 * processing the batch file which is coming from Finacle.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@RestController
public class FinacleBatchJobController {

	private static final Logger LOGGER = LoggerFactory.getLogger(FinacleBatchJobController.class);

	/**
	 * This field is used to store value for fileInputChannel which is of type
	 * {@link MessageChannel }.
	 */
	private MessageChannel fileInputChannel;

	/**
	 * This field is used to store value for filePath which is of type {@link String }.
	 */

	@Value("${file.inbound.import.path}")
	private String filePath;

	/**
	 * This constructor is used to setup the fileInputChannel with the injected instance.
	 *
	 * @param fileInputChannel : {@link MessageChannel}
	 */
	public FinacleBatchJobController(MessageChannel fileInputChannel) {
		this.fileInputChannel = fileInputChannel;
	}

	/**
	 * This method is used to trigger the batch job on the annotated RequestMapping URL
	 * which will check for the batch file which is present on the path which can be
	 * extracted from the provided instance.
	 *
	 * @param multiPartfile : {@link MultipartFile}
	 * @return {@link String}
	 *
	 */
	@PostMapping(value = "/invokeFinacleBatchJob")
	public String invokeFinacleBatchJob(@RequestParam("file") MultipartFile multiPartfile) {

		Assert.notNull(multiPartfile.getOriginalFilename(), "File name cannot be null");
		MDC.put(FUNCTIONAL_MAP.value(), "Invoke_LienNotificationBatchJob");

		LOGGER.info("Finacle Batch Job initiated with inputs : fileName={}",
				multiPartfile.getOriginalFilename());

		FileInputData finacleBatchFileInputData = new FileInputData();

		if (!multiPartfile.isEmpty()) {
			try (BufferedInputStream stream = new BufferedInputStream(multiPartfile.getInputStream())) {
				File outputFile = new File(this.filePath + multiPartfile.getOriginalFilename());
				Files.copy(stream, outputFile.toPath(), StandardCopyOption.REPLACE_EXISTING);

				IOUtils.closeQuietly(stream);

				finacleBatchFileInputData.setAbsolutePath(this.filePath.concat(multiPartfile.getOriginalFilename()));
				finacleBatchFileInputData.setFileName(multiPartfile.getOriginalFilename());

				this.fileInputChannel.send(MessageBuilder.withPayload(
						finacleBatchFileInputData).build());

				MDC.put(STATUS_CODE_KEY.value(), StatusCodes.SUCCESS.value());
				MDC.put(STATUS_CODE_DES_KEY.value(), StatusCodes.SUCCESS.name());
				MDC.put(ERROR_TYPE.value(), "");

				LOGGER.info("Finacle Batch Job invoked with inputs : fileName={}, filePath={}",
						finacleBatchFileInputData.getFileName(),
						finacleBatchFileInputData.getAbsolutePath());

				return "INVOKED_FINACLE_NOTIFICATION";
			}
			catch (Exception exception) {
				MDC.put(STATUS_CODE_KEY.value(), StatusCodes.FAILURE.value());
				MDC.put(STATUS_CODE_DES_KEY.value(), StatusCodes.FAILURE.name());
				MDC.put(ERROR_TYPE.value(), ErrorConstants.TECH.name());
				LOGGER.error(
						"Failed to invoke Finacle transaction Batch Job with inputs : fileName={}, filePath={}, errMsg={}",
						finacleBatchFileInputData.getFileName(),
						finacleBatchFileInputData.getAbsolutePath(), exception.getMessage());
				return "INVOKE_FAILED_TO_UPLOAD";
			}
		}
		else {
			MDC.put(STATUS_CODE_KEY.value(), StatusCodes.FAILURE.value());
			MDC.put(STATUS_CODE_DES_KEY.value(), StatusCodes.FAILURE.name());
			MDC.put(ERROR_TYPE.value(), ErrorConstants.TECH.name());
			LOGGER.error(
					"Failed to invoke Finacle transaction Batch Job with inputs : fileName={}, filePath={}, errMsg={}",
					finacleBatchFileInputData.getFileName(),
					finacleBatchFileInputData.getAbsolutePath(), "Multipart form data expected.");
			return "INVOKE_FAILED_AS_FILE_IS_EMPTY";
		}
	}

}
