# Transaction Data Source (TDS)

## Tools/Software used
* Java 8
* Maven
* MariaDB
* Spring Boot
* Spring JMS
* Spring Integration
* Spring Batch
* Jboss


Clone the repo and type 

## Building

Clone the repo and type 

```
mvnw clean install
```

## Code formatting guidelines

* The directory ./src/eclipse has three files for use with code formatting, `eclipse-code-formatter.xml` for the majority of the code formatting rules and `eclipse.importorder` to order the import statements and `eclipse-code-comment-templates.xml` for the default comment templates for majority of the code.

* In eclipse you import these files by navigating `Windows -> Preferences` and then the menu items `Preferences > Java > Code Style > Formatter` and `Preferences > Java > Code Style > Organize Imports` and `Preferences > Java > Code Style > Code Templates` respectfully.

* Configure Save Actions as mentioned below, by navigating `Windows -> Preferences` and then the menu items `Preferences > Java > Editor > Save Actions`:
* Enable Format source code and organize imports
* Enable Additional Actions and Click on Configure and follow below mentioned points:
* Tab: Code Organizing: Enable 'Removing trailing Whitespace' > check 'All Lines' and 'Correct Indentation' 
* Tab: Code Style: Enable 'Use blocks in if/while/for/do statements' > Always and 'Convert functional interface instances' > Use lambda where possible
* Tab: Member Access: Enable 'Use this qualifier for field accesses' > Always
* Tab: Missing Code: Enable everything what is there on this tab
* Tab: Unnecessary Code: Enable 'Remove unused import' and bottom three check-boxes under Unnecessary Code
  
