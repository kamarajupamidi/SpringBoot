package com.dbs.tds.transactionhistorymoneythorevent.service;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;
import static org.mockito.internal.util.reflection.Whitebox.setInternalState;

import javax.sql.DataSource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistorymoneythorevent.service.MTTransactionNotificationService;

/***
 * Unit test cases for {@link MTTransactionNotificationService} methods.
 *
 * @author sivanarayana
 *
 * @version 1.0
 */
@RunWith(MockitoJUnitRunner.class)
public class MTTransactionNotificationServiceTest {

	@InjectMocks
	private MTTransactionNotificationService service;

	private TransactionNotification transactionNotification;

	@Mock
	private NamedParameterJdbcTemplate transactionUpdateJdbcTemplate;

	@Mock
	private DataSource dataSource;

	@Before
	public void setup() {
		transactionNotification = new TransactionNotification();
	}

	@Test
	public void testProcess() {
		setInternalState(service, "transactionUpdateJdbcTemplate", transactionUpdateJdbcTemplate);
		when(
				transactionUpdateJdbcTemplate.update(anyString(), any(MapSqlParameterSource.class)))
						.thenReturn(1);
		when(
				transactionUpdateJdbcTemplate.update(anyString(), any(MapSqlParameterSource.class)))
						.thenReturn(1);
		service.process(transactionNotification);
	}

}
