package com.dbs.tds.transactionhistorymoneythorevent.transformer;

import java.io.IOException;
import java.net.URISyntaxException;

import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistorymoneythorevent.exception.InvalidMTResponseException;
import org.assertj.core.api.Assertions;
import org.assertj.core.util.DateUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;

import static java.nio.file.Files.readAllBytes;
import static java.nio.file.Paths.get;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/***
 * Unit test cases for {@link MTTransactionNotificationTransformer} methods.
 *
 * @author sivanarayana
 *
 * @version 1.0
 */
@RunWith(BlockJUnit4ClassRunner.class)
public class MTTransactionNotificationTransformerTest {

	private MTTransactionNotificationTransformer transformer;

	@Before
	public void setup() {
		this.transformer = new MTTransactionNotificationTransformer();
	}

	@Test
	public void testTransform() throws IOException, URISyntaxException {
		String jsonRequest = new String(
				readAllBytes(get(getClass().getClassLoader().getResource("moneythor-sample.json").toURI())));
		String tranKey = "TRAN-KEY";
		TransactionNotification transactionNotification = this.transformer.transform(jsonRequest, tranKey);
		assertNotNull(transactionNotification);
		assertEquals(tranKey, transactionNotification.getTranKey());
		Assertions.assertThat(transactionNotification.getPostedDate())
				.isEqualTo(DateUtil.parseDatetime("2017-02-23T17:22:13"));
		assertEquals("2c393870-6c24-4a84-a", transactionNotification.getTransactionReferenceNumber());
		assertEquals("M465", transactionNotification.getTransactionId());
		assertTrue(1L == transactionNotification.getPartTransactionSerialNumber());
	}

	@Test(expected = InvalidMTResponseException.class)
	public void testTransformWithWrongFormattedJson() throws IOException, URISyntaxException {
		String jsonRequest = "---dummy-json---";
		String tranKey = "TRAN-KEY";
		this.transformer.transform(jsonRequest, tranKey);
	}

}
