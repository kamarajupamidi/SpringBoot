package com.dbs.tds.transactionhistorymoneythorevent.config;

import java.util.ArrayList;
import java.util.Arrays;

import javax.jms.ConnectionFactory;

import com.dbs.tds.transactionhistorymoneythorevent.service.MTTransactionNotificationService;
import com.dbs.tds.transactionhistorymoneythorevent.transformer.MTTransactionNotificationTransformer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.jms.Jms;
import org.springframework.integration.handler.LoggingHandler;
import org.springframework.integration.jms.DefaultJmsHeaderMapper;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.jms.support.converter.SimpleMessageConverter;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.ChannelInterceptor;
import org.springframework.messaging.support.ChannelInterceptorAdapter;

/**
 * This class is used as the configuration class which configure the behavior and working
 * of the Message queue which will receive the message coming from MoneyThor and process
 * the message accordingly and insert/update the details in TDS DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@EnableIntegration
@Configuration
public class MTTransactionHistoryEventConfiguration {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(MTTransactionHistoryEventConfiguration.class);

	/**
	 * This method is used to receive the message which is coming on message queue from
	 * MoneyThor with transaction enriched details. This method creates a connection with
	 * the queue with the help of injected connectionFactory and destination name. Then
	 * the message is converted using the messageConverter and message is put onto
	 * suitable channel for processing. If there is any error during the process then the
	 * message is put onto the error channel.
	 *
	 * @param destinationName : {@link String}
	 * @param connectionFactory : {@link ConnectionFactory}
	 * @return {@link IntegrationFlow}
	 */
	@Bean
	public IntegrationFlow mtEventFlow(@Value("${moneythor.inbound.destination}") String destinationName,
			ConnectionFactory connectionFactory) {
		return IntegrationFlows.from(Jms.messageDrivenChannelAdapter(connectionFactory)
				.jmsMessageConverter(messageConverter())
				.headerMapper(new DefaultJmsHeaderMapper())
				.destination(destinationName)
				.outputChannel(mtOutputChannel())
				.errorChannel(mtErrorChannel())).get();
	}

	/**
	 * This method is used to return the message channel for message which is coming in
	 * message queue from Money Thor and logging the complete message before processing
	 * it.
	 *
	 * @return {@link MessageChannel}
	 */
	@Bean
	public MessageChannel mtOutputChannel() {
		DirectChannel channel = new DirectChannel();
		channel.setInterceptors(new ArrayList<ChannelInterceptor>(Arrays.asList(new ChannelInterceptorAdapter() {

			@Override
			public Message<?> preSend(Message<?> message, MessageChannel channel) {
				LOGGER.info("Message received from message Queue {}", message);
				return message;
			}

		})));
		return channel;
	}

	/**
	 * This method is used to return the Message Channel for Error message Flow.
	 *
	 * @return {@link MessageChannel}
	 */
	@Bean
	public MessageChannel mtErrorChannel() {
		return new DirectChannel();
	}

	/**
	 * This method is used to define the flow of the message channel which will be invoked
	 * whenever there is a message on MoneyThor message queue. This method will transform
	 * the incoming message and put the message to get serviced and get updated in the DB.
	 *
	 * @param mtTransactionNotificationTransformer :
	 * {@link MTTransactionNotificationTransformer}
	 * @param mtTransactionNotificationService : {@link MTTransactionNotificationService}
	 *
	 * @return {@link IntegrationFlow}
	 */
	@Bean
	public IntegrationFlow mtInboundFlow(
			MTTransactionNotificationTransformer mtTransactionNotificationTransformer,
			MTTransactionNotificationService mtTransactionNotificationService) {

		return IntegrationFlows.from(mtOutputChannel())
				.transform(mtTransactionNotificationTransformer)
				.handle(mtTransactionNotificationService)
				.get();
	}

	/**
	 * This method is used to define the flow of the error channel which will be invoked
	 * whenever there is an error during the processing of the incoming message on
	 * MoneyThor message queue.
	 *
	 * @return {@link IntegrationFlow}
	 */
	@Bean
	public IntegrationFlow mtErrorFlow() {
		return IntegrationFlows
				.from(mtErrorChannel())
				.handle(new LoggingHandler("ERROR"))
				.get();
	}

	/**
	 * This method is used to provide Bean instance of Message Converter which will help
	 * to convert the json message string to an Instance.
	 *
	 * @return {@link MessageConverter}
	 */
	@Bean
	public MessageConverter messageConverter() {
		return new SimpleMessageConverter();
	}

}
