/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: MoneyThorEventException.java
 * Author: DBS Asia Hub 2
 * Date: Nov 23, 2017
 */
package com.dbs.tds.transactionhistorymoneythorevent.exception;

/**
 * This class is used as the custom exception class which will be used to throw exception
 * instances whenever there is any exception occurs in the application.
 *
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public class MoneyThorEventException extends RuntimeException {

	/**
	 * This field is used to store value for serialVersionUID which is of type {@link long
	 * }.
	 */
	private static final long serialVersionUID = 4891645210575936736L;

	/**
	 * Default Constructor with parameterized exception Message.
	 *
	 * @param message : {@link String}
	 */
	public MoneyThorEventException(String message) {
		super(message);
	}

}
