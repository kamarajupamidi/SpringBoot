package com.dbs.tds.transactionhistorymoneythorevent.transformer;

import java.io.IOException;
import java.util.Optional;
import java.util.UUID;

import com.dbs.moneythor.dto.AccountInfoMoneyThor;
import com.dbs.moneythor.dto.CustomField;
import com.dbs.moneythor.dto.EnrichPayload;
import com.dbs.moneythor.dto.MoneyThorTxnEnrichmentResponse;
import com.dbs.moneythor.dto.Transaction;
import com.dbs.tds.constants.ErrorConstants;
import com.dbs.tds.constants.StatusCodes;
import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistorymoneythorevent.exception.InvalidMTResponseException;
import com.dbs.tds.transactionhistorymoneythorevent.exception.MoneyThorEventException;
import com.dbs.tds.util.DateTimeFormat;
import com.dbs.tds.util.DateUtil;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import static com.dbs.tds.constants.AppConstants.APP_REGION;
import static com.dbs.tds.constants.AppConstants.STATUS_CODE_DES_KEY;
import static com.dbs.tds.constants.AppConstants.STATUS_CODE_KEY;
import static com.dbs.tds.constants.AppIdentifiers.APP_CODE;
import static com.dbs.tds.constants.Countries.IN;
import static com.dbs.tds.constants.LoggingConstants.CLIENT_IP;
import static com.dbs.tds.constants.LoggingConstants.ERROR_TYPE;
import static com.dbs.tds.constants.LoggingConstants.FUNCTIONAL_MAP;
import static com.dbs.tds.constants.LoggingConstants.INTERFACE_MAP;
import static com.dbs.tds.constants.LoggingConstants.MSG_UID;
import static com.dbs.tds.constants.LoggingConstants.REQUEST_TYPE;
import static com.dbs.tds.constants.LoggingConstants.SERVICE_ID;
import static com.dbs.tds.constants.RequestTypes.E2E;

/**
 * This class is used to transform the incoming request.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 */
@Component
public class MTTransactionNotificationTransformer {

	/**
	 * This field is used to instantiate LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(MTTransactionNotificationTransformer.class);

	/**
	 * This method is used to populate ELK variable in MDC object. By this we print
	 * required fields for analytics in application logs.
	 */
	private void startLoggingRequest() {
		long startTime = System.currentTimeMillis();
		MDC.put(APP_CODE.name(), APP_CODE.value());
		MDC.put(APP_REGION.value(), IN.name());
		MDC.put(REQUEST_TYPE.value(), E2E.name());
		MDC.put(SERVICE_ID.value(), "transactionhistorymoneythorevent");
		MDC.put(INTERFACE_MAP.value(), "moneythor_tdsqueque_to_tds");
		MDC.put(MSG_UID.value(), UUID.randomUUID().toString());
		MDC.put(CLIENT_IP.value(), "MONEYTHORQUEQUE");
		MDC.put(FUNCTIONAL_MAP.value(), "MoneyThor_Transaction_History_Event");
		MDC.put("startTime", String.valueOf(startTime));
	}

	/**
	 * This method is used to transform the incoming request. Incoming request will be a
	 * {@link String} variable in JSON format and this method will parse the request and
	 * transform the object of {@link TransactionNotification} which further will be used
	 * to map database entities.
	 *
	 * @param jSonRequest : {@link String}
	 * @param tranKey : {@link String}
	 * @return {@link TransactionNotification}
	 */
	public TransactionNotification transform(String jSonRequest, @Header("TRANKEY") String tranKey) {
		startLoggingRequest();
		LOGGER.info("JSON Request incoming from MoneyThor jSonRequest={}, tranKey={}", jSonRequest, tranKey);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		MoneyThorTxnEnrichmentResponse moneyThorTxnEnrichmentResponse = null;

		try {
			moneyThorTxnEnrichmentResponse = mapper.readValue(jSonRequest, MoneyThorTxnEnrichmentResponse.class);
		}
		catch (IOException ioException) {
			MDC.put(STATUS_CODE_KEY.value(), StatusCodes.FAILURE.value());
			MDC.put(STATUS_CODE_DES_KEY.value(), StatusCodes.FAILURE.name());
			MDC.put(ERROR_TYPE.value(), ErrorConstants.TECH.name());
			LOGGER.error("Unable to parse moneythor response with {}", ioException);
			throw new InvalidMTResponseException("Unable to parse moneythor response", ioException);
		}

		TransactionNotification transactionNotification = new TransactionNotification();
		transactionNotification.setTranKey(tranKey);

		AccountInfoMoneyThor accountInfoMoneyThor = Optional.ofNullable(moneyThorTxnEnrichmentResponse)
				.map(MoneyThorTxnEnrichmentResponse::getPayload).map(EnrichPayload::getAccount)
				.orElseThrow(() -> new MoneyThorEventException("No payload Found. Event Processing failed."));

		Transaction transaction = Optional.ofNullable(moneyThorTxnEnrichmentResponse)
				.map(MoneyThorTxnEnrichmentResponse::getPayload).map(EnrichPayload::getTransactions)
				.orElseThrow(() -> new MoneyThorEventException("No payload Found. Event Processing failed.")).get(0);

		Assert.notNull(transaction, "Account transaction record cannot be null");

		for (CustomField field : transaction.getCustomFields()) {
			if ("tranid".equalsIgnoreCase(field.getName())) {
				transactionNotification.setTransactionId(field.getValue());
			}
			else if ("transserialnumber".equalsIgnoreCase(field.getName())) {
				transactionNotification.setPartTransactionSerialNumber(Long.valueOf(field.getValue()));
			}
			else if ("trandate".equalsIgnoreCase(field.getName())) {
				transactionNotification.setTransactionDate(
						DateUtil.parseDate(field.getValue(),
								DateTimeFormat.DATE_FULL_ISO_WITHOUT_MILLI_SECONDS.pattern()));
			}
			else if ("valuedate".equalsIgnoreCase(field.getName())) {
				transactionNotification.setValueDate(
						DateUtil.parseDate(field.getValue(),
								DateTimeFormat.DATE_FULL_ISO_WITHOUT_MILLI_SECONDS.pattern()));
			}
			else if ("postingdate".equalsIgnoreCase(field.getName())) {
				transactionNotification.setPostedDate(
						DateUtil.parseDate(field.getValue(),
								DateTimeFormat.DATE_FULL_ISO_WITHOUT_MILLI_SECONDS.pattern()));
			}
			else if ("relatedtranref".equalsIgnoreCase(field.getName())) {
				transactionNotification.setTransactionReferenceNumber(field.getValue());
			}
			else if ("category".equalsIgnoreCase(field.getName())) {
				transactionNotification.setTranCategory(field.getValue());
			}
		}

		transactionNotification.setAccountNumber(accountInfoMoneyThor.getNumber());
		transactionNotification.setAccountCurrencyCode(accountInfoMoneyThor.getCurrency());
		transactionNotification.setTransactionAmount(transaction.getAmount());
		transactionNotification.setTransactionCurrencyCode(transaction.getCurrency());
		transactionNotification.setPartTransactionType(transaction.getType());
		transactionNotification.setExtTranId(transaction.getKey());
		transactionNotification.setTransactionParticulars(transaction.getDescription());

		LOGGER.info("Transaction Notification Generated out of JSON tranKey ={}, Request={}", tranKey,
				transactionNotification);

		return transactionNotification;
	}

}
