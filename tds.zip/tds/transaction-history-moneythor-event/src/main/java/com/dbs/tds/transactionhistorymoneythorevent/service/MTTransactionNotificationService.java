package com.dbs.tds.transactionhistorymoneythorevent.service;

import java.util.Date;

import javax.sql.DataSource;

import com.dbs.tds.constants.StatusCodes;
import com.dbs.tds.dto.TransactionNotification;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import static com.dbs.tds.constants.AppConstants.STATUS_CODE_DES_KEY;
import static com.dbs.tds.constants.AppConstants.STATUS_CODE_KEY;
import static com.dbs.tds.constants.LoggingConstants.ERROR_TYPE;
import static com.dbs.tds.constants.LoggingConstants.RESPONSE_TIME;
import static com.dbs.tds.constants.TransactionDimFields.LST_UPDT_DTTM;
import static com.dbs.tds.constants.TransactionDimFields.TRANKEY;
import static com.dbs.tds.constants.TransactionDimFields.TRAN_CTGR;
import static com.dbs.tds.constants.TransactionFields.EXT_TRANID;
import static com.dbs.tds.constants.TransactionFields.TRANDESC;

/**
 * This class is used to update transaction enriched data, coming from Money Thor enrich
 * Event Queue Notification, into TDS DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Service
@Transactional
public class MTTransactionNotificationService {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(MTTransactionNotificationService.class);

	/**
	 * This field is used to store value for ELKLOGGER which is of type {@link Logger }.
	 */
	private static final Logger ELKLOGGER = LoggerFactory.getLogger("elklogger");

	/**
	 * This field is used to store value for transactionUpdateJdbcTemplate which is of
	 * type {@link NamedParameterJdbcTemplate }.
	 */
	private NamedParameterJdbcTemplate transactionUpdateJdbcTemplate;

	/**
	 * This field is used to store value for extTranIdUpdateQuery which is of type
	 * {@link String }.
	 */
	private String extTranIdUpdateQuery;

	/**
	 * This field is used to store value for categoryUpdateQuery which is of type
	 * {@link String }.
	 */
	private String categoryUpdateQuery;

	/**
	 * This constructor is used with injected {@link DataSource} instance to setup the the
	 * {@link JdbcTemplate} and named parameterized Query in {@link String} type.
	 *
	 * @param dataSource : {@link DataSource}
	 */
	public MTTransactionNotificationService(DataSource dataSource) {

		this.extTranIdUpdateQuery = "Update T_DTA_FACT set EXT_TRANID= :EXT_TRANID,TRANDESC= :TRANDESC, LST_UPDT_SYS_ID= 'MoneyThor', LST_UPDT_DTTM= :LST_UPDT_DTTM where TRANKEY= :TRANKEY;";
		this.categoryUpdateQuery = "Update T_DTA_DIM set TRAN_CTGR= :TRAN_CTGR, LST_UPDT_SYS_ID= 'MoneyThor', LST_UPDT_DTTM= :LST_UPDT_DTTM where TRANKEY= :TRANKEY;";
		this.transactionUpdateJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

	/**
	 * This method is used to update transaction enriched data, coming from Money Thor
	 * enrich Event Queue Notification, into TDS DB.
	 *
	 * @param transactionEnrichNotification : {@link TransactionNotification}
	 */
	public void process(TransactionNotification transactionEnrichNotification) {

		LOGGER.info("Incoming request transactionEnrichNotification ={}", transactionEnrichNotification);

		Date messaeDate = new Date();
		MapSqlParameterSource parameterSource = new MapSqlParameterSource();
		parameterSource
				.addValue(EXT_TRANID.name(), transactionEnrichNotification.getExtTranId())
				.addValue(TRAN_CTGR.name(), transactionEnrichNotification.getTranCategory())
				.addValue(LST_UPDT_DTTM.name(), messaeDate)
				.addValue(TRANKEY.name(), transactionEnrichNotification.getTranKey())
				.addValue(TRANDESC.name(), transactionEnrichNotification.getTransactionParticulars());

		LOGGER.info(
				"Update parameters extTranid={},tranCategory={}, TranDescriptio={},messageDate={},trankey={}",
				transactionEnrichNotification.getExtTranId(), transactionEnrichNotification.getTranCategory(),
				transactionEnrichNotification.getTransactionParticulars(),
				messaeDate, transactionEnrichNotification.getTranKey());

		int result = this.transactionUpdateJdbcTemplate.update(this.extTranIdUpdateQuery, parameterSource);
		result = result + this.transactionUpdateJdbcTemplate.update(this.categoryUpdateQuery, parameterSource);

		MDC.put(STATUS_CODE_KEY.value(), StatusCodes.SUCCESS.value());
		MDC.put(STATUS_CODE_DES_KEY.value(), StatusCodes.SUCCESS.name());
		MDC.put(ERROR_TYPE.value(), "");

		LOGGER.info("Row Updated ={}", result);
		logElapsedTimeForTransactinMonithorEvent();
	}

	/**
	 * This method is used to calculate and log the elapsed time.
	 */
	private void logElapsedTimeForTransactinMonithorEvent() {
		String startTime = MDC.get("startTime");
		if (StringUtils.isNotBlank(startTime)) {
			long start = Long.parseLong(startTime);
			long elapsed = System.currentTimeMillis() - start;
			MDC.put(RESPONSE_TIME.value(), String.valueOf(elapsed));
			ELKLOGGER.info("");
		}
	}

}
