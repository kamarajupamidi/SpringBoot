package com.dbs.tds.transactionbalancereadapi.mapper;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.dbs.schemas.soi.common._4_1.CommonRq;
import com.dbs.schemas.soi.common._4_1.DepAcct;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AcctBalInq;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AcctBalInq.RqAcctId;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AcctBalInqResponse;
import com.dbs.tds.dto.AccountNotification;
import com.finacle.fixml.balance.AcctBal;
import com.finacle.fixml.balance.Amount;
import com.finacle.fixml.balance.BalInqResCustomDataType;
import com.finacle.fixml.balance.BalInqResCustomDataType.LedgerBal;
import com.finacle.fixml.balance.BalInqResponse;
import com.finacle.fixml.balance.BalInqRs;
import com.finacle.fixml.balance.Body;
import com.finacle.fixml.balance.ErrorDetailType;
import com.finacle.fixml.balance.ErrorType;
import com.finacle.fixml.balance.FIBusinessExceptionType;
import com.finacle.fixml.balance.FISystemExceptionType;
import com.finacle.fixml.balance.FIXML;
import com.finacle.fixml.balance.Header;
import com.finacle.fixml.balance.ResponseHeaderType;
import com.finacle.fixml.balance.TransactionType;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;

/**
 * This class contains unit test cases for {@link RequestResponseTransformer} class
 * methods
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class RequestResponseTransformerTest {

	@Spy
	private AcctBalInq acctBalInq = buildAcctBalInq();

	private AccountNotification accountDetails;

	private RequestResponseTransformer requestResponseTransformer;

	private CommonRq commonRq;

	private FIXML fixml;

	private ErrorDetailType errorDetailType;

	private Amount amount;

	@Before
	public void setValues() {

		AcctBal acctBal;

		this.requestResponseTransformer = new RequestResponseTransformer();
		this.fixml = new FIXML();
		this.amount = new Amount();
		acctBal = buildAcctBal();
		this.accountDetails = buildAccountNotification();
		this.commonRq = buildCommonRq();
		this.errorDetailType = buildErrorDetailType();

		LedgerBal ledgerBal = buildLedgerBal();
		BalInqResponse balInqResponse = new BalInqResponse();
		BalInqRs balInqRs = new BalInqRs();
		BalInqResCustomDataType balInqResCustomDataType = new BalInqResCustomDataType();
		Body body = new Body();

		balInqRs.getAcctBal().add(acctBal);
		balInqResCustomDataType.setLedgerBal(ledgerBal);
		balInqResponse.setBalInqRs(balInqRs);
		balInqResponse.setBalInqCustomData(balInqResCustomDataType);
		body.setBalInqResponse(balInqResponse);

		this.fixml.setBody(body);

	}

	@Test
	public void transformFromSoapToTdsTest() {
		assertNotNull(this.acctBalInq);
		assertNotNull(this.acctBalInq.getRqAcctId());
		assertSame(this.acctBalInq.getRqAcctId().size(), 1);
		assertNotNull(this.acctBalInq.getRqAcctId().get(0));
		AccountNotification notification = this.requestResponseTransformer.transformFromSoapToTds(this.acctBalInq);
		assertNotNull(notification);
		assertNotNull(notification.getAccountNumber());

		/***
		 * Negative Test Case if the account is not of type DepAcctId
		 */
		this.acctBalInq.getRqAcctId().get(0).setDepAcctId(null);
		this.requestResponseTransformer.transformFromSoapToTds(this.acctBalInq);
	}

	@Test
	public void mergeRequestResponseOfTdsDBTest() {
		assertNotNull(this.accountDetails);
		assertNotNull(this.accountDetails.getAccountNumber());
		AccountNotification notification = this.requestResponseTransformer
				.mergeRequestResponseOfTdsDB(this.accountDetails, this.accountDetails);
		assertNotNull(notification);
	}

	@Test
	public void transformFromTdsToSoapTest() {
		assertNotNull(this.accountDetails);
		assertNotNull(this.acctBalInq);
		assertNotNull(this.commonRq);
		this.acctBalInq.setCommonRq(this.commonRq);
		AcctBalInqResponse acctBalInqResponse = this.requestResponseTransformer.transformFromTdsToSoap(this.acctBalInq,
				this.accountDetails);
		assertNotNull(acctBalInqResponse);
		assertSame(acctBalInqResponse.getBalDetl().size(), 1);

	}

	@Test
	public void transformFromTdsToFinacleTest() {
		assertNotNull(this.accountDetails);
		FIXML xml = this.requestResponseTransformer.transformFromTdsToFinacle(this.accountDetails);
		assertNotNull(xml);
		assertNotNull(xml.getHeader());
		assertNotNull(xml.getBody());
		assertNotNull(xml.getBody().getBalInqRequest().getBalInqRq());
		assertNotNull(xml.getBody().getBalInqRequest().getBalInqRq().getAcctId());
	}

	@Test
	public void transformFromFinacleToTDSTestFailure() {
		assertNotNull(this.fixml);
		assertNotNull(this.accountDetails);

		Header header = new Header();
		ResponseHeaderType headerType = new ResponseHeaderType();
		TransactionType transactionType = new TransactionType();
		ErrorType error = new ErrorType();
		FIBusinessExceptionType biexception = new FIBusinessExceptionType();
		FISystemExceptionType sysException = new FISystemExceptionType();

		transactionType.setStatus("FAILURE");
		headerType.setHostTransaction(transactionType);
		header.setResponseHeader(headerType);
		biexception.getErrorDetail().add(this.errorDetailType);
		error.setFISystemException(null);
		error.setFIBusinessException(biexception);

		this.fixml.setHeader(header);
		this.fixml.getBody().setError(error);

		AccountNotification biNotification = this.requestResponseTransformer
				.transformFromFinacleToTDS(this.accountDetails, this.fixml);
		assertNotNull(biNotification);

		error.setFIBusinessException(null);
		sysException.getErrorDetail().add(this.errorDetailType);
		error.setFISystemException(sysException);

		AccountNotification sysNotification = this.requestResponseTransformer
				.transformFromFinacleToTDS(this.accountDetails, this.fixml);
		assertNotNull(sysNotification);

	}

	@Test
	public void transformFromFinacleToTDSTestSuccess() {
		assertNotNull(this.fixml);
		assertNotNull(this.accountDetails);

		Header header = new Header();
		ResponseHeaderType headerType = new ResponseHeaderType();
		TransactionType transactionType = new TransactionType();

		transactionType.setStatus("SUCCESS");
		headerType.setHostTransaction(transactionType);
		header.setResponseHeader(headerType);
		this.fixml.setHeader(header);

		AccountNotification availNotification = this.requestResponseTransformer
				.transformFromFinacleToTDS(this.accountDetails, this.fixml);
		assertNotNull(availNotification);

	}

	private AcctBalInq buildAcctBalInq() {
		AcctBalInq acctBalReq = new AcctBalInq();
		List<RqAcctId> accts = acctBalReq.getRqAcctId();
		DepAcct depacc = new DepAcct();
		RqAcctId rqacct = new RqAcctId();

		depacc.setAcctId("ACCTID");
		depacc.setOrgCode("ORGCODE");
		depacc.setBankId("BANKID");
		depacc.setProdType("CA");
		rqacct.setDepAcctId(depacc);
		accts.add(rqacct);

		return acctBalReq;
	}

	private LedgerBal buildLedgerBal() {
		LedgerBal ledgBal = new LedgerBal();
		ledgBal.setAmountValue(BigDecimal.valueOf(1000.00));
		return ledgBal;
	}

	private ErrorDetailType buildErrorDetailType() {
		ErrorDetailType erorTyp = new ErrorDetailType();
		erorTyp.setErrorCode("S001");
		erorTyp.setErrorDesc("ERROR MSG");
		return erorTyp;
	}

	private CommonRq buildCommonRq() {
		CommonRq commonRqObj = new CommonRq();
		commonRqObj.setOrgCode("2009");
		commonRqObj.setChannelId("12");
		commonRqObj.setRqSysRef("DGB");
		return commonRqObj;
	}

	private AccountNotification buildAccountNotification() {
		AccountNotification acctDetails = new AccountNotification();
		acctDetails.setAccountNumber("ACCTID");
		acctDetails.setAccountType("SA");
		acctDetails.setIsBalSyncFlag("Y");
		acctDetails.setAccountAvailableBalance(1000.00);
		acctDetails.setAccountAvailableCurrency("INR");
		acctDetails.setAccountLedgerBalance(1000.00);
		acctDetails.setAccountLedgerCurrency("INR");
		acctDetails.setBalanceAsOfDateTm(new Date());

		return acctDetails;
	}

	private AcctBal buildAcctBal() {
		AcctBal acctBalance = new AcctBal();
		acctBalance.setBalType("AVAIL");
		acctBalance.setBalAmt(RequestResponseTransformerTest.this.amount);
		return acctBalance;
	}

}
