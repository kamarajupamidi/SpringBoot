package com.dbs.tds.transactionbalancereadapi.service.impl;

import javax.xml.ws.Holder;

import com.dbs.schemas.soi.common._4_0.ServiceProvider;
import com.dbs.schemas.soi.common._4_0.Trace;
import com.dbs.schemas.soi.wsdl.depositaccount.v1_1.Fault;
import com.dbs.schemas.soi.xsd.commonimpl.v1_1.ChqBkRqAddResponse;
import com.dbs.schemas.soi.xsd.commonimpl.v1_1.ChqStopAddResponse;
import com.dbs.schemas.soi.xsd.commonimpl.v1_1.EarmarkFundAddResponse;
import com.dbs.schemas.soi.xsd.commonimpl.v1_1.EarmarkInqResponse;
import com.dbs.schemas.soi.xsd.commonimpl.v1_1.EarmarkModResponse;
import com.dbs.schemas.soi.xsd.commonimpl.v1_1.EarmarkRelResponse;
import com.dbs.schemas.soi.xsd.commonimpl.v1_1.StmtRqAddResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AccountEStatementListResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AcctBalInq;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AcctBalInqResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AcctDetailInqResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AcctIdRqAddResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AdministerDepositAccountDetailsResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AdministerDepositAccountSchemeResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AdministerDepositAccountStatusResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AdministerDepositNomineeDetailsResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AdministerFDAccountDetailsResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AdministerFDNomineeDetailsResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AdministerMobilePayIdResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.CASAAddResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.CreateMobilePayIdResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.CustIdSrhResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.EvaluateDepositAccountClosureEligibilityResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.FDAcctAddResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.FDDepInqResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.FDMaturityModResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.FDQuoteInqResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RequestInterestCertificateResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RequestNetWorthStmtResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RetrieveAccountsResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RetrieveCertificateListResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RetrieveDepositAcctTranResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RetrieveExternalAccountBalanceResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RetrieveFDReceiptListResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RetrieveTransAndNotificationResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.TerminateFDAcctResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.TranFDHistInqResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.TranHistInqResponse;
import com.dbs.tds.dto.AccountNotification;
import com.dbs.tds.transactionbalancereadapi.mapper.RequestResponseTransformer;
import com.dbs.tds.transactionbalancereadapi.service.BalanceReadService;
import com.dbs.tds.transactionbalancereadapi.service.DepositAccountHeaderService;
import com.dbs.tds.transactionbalancereadapi.service.DepositAccountService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

/***
 *
 * This class contains Junit test cases for {@link DepositeAccountService}
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class DepositeAccountServiceTest {

	private DepositAccountService depositAccountService;

	private Holder<Trace> part2 = new Holder<>();

	@Mock
	private RequestResponseTransformer requestResponseTransformer;

	@Mock
	private BalanceReadService balanceReadService;

	@Mock
	private AcctBalInq acctBalInqRq;

	@Mock
	private AccountNotification accountDetails;

	@Mock
	private AcctBalInqResponse acctBalInqResponse;

	@Mock
	private DepositAccountHeaderService depositAccountHeaderService;

	@Mock
	private ServiceProvider serviceProvider;

	@Before
	public void setUp() {
		this.depositAccountService = new DepositAccountService(this.requestResponseTransformer,
				this.balanceReadService, this.depositAccountHeaderService);
		Trace trace = new Trace();
		this.part2.value = trace;
	}

	@Test
	public void retrieveDepositAccountBal() throws Fault {

		when(this.requestResponseTransformer.transformFromSoapToTds(this.acctBalInqRq)).thenReturn(this.accountDetails);
		when(this.balanceReadService.fetchAccountBalances(this.accountDetails)).thenReturn(this.accountDetails);
		when(this.requestResponseTransformer.transformFromTdsToSoap(this.acctBalInqRq,
				this.accountDetails)).thenReturn(this.acctBalInqResponse);
		when(this.depositAccountHeaderService.getServiceProvider()).thenReturn(this.serviceProvider);

		this.acctBalInqResponse = this.depositAccountService.retrieveDepositAccountBal(this.acctBalInqRq, null,
				this.part2,
				null, null);

		assertNotNull(this.acctBalInqResponse);

	}

	@Test
	public void administerDepositNomineeDetailsTest() throws Fault {
		AdministerDepositNomineeDetailsResponse res = this.depositAccountService.administerDepositNomineeDetails(null,
				null, null, null, null);
		assertNull(res);
	}

	@Test
	public void retrieveFDReceiptListTest() throws Fault {
		RetrieveFDReceiptListResponse res = this.depositAccountService.retrieveFDReceiptList(null, null, null, null,
				null);
		assertNull(res);

	}

	@Test
	public void retrieveFDTransactionHistoryTest() throws Fault {
		TranFDHistInqResponse res = this.depositAccountService.retrieveFDTransactionHistory(null, null, null, null,
				null);
		assertNull(res);
	}

	@Test
	public void requestStopChequeTest() throws Fault {
		ChqStopAddResponse res = this.depositAccountService.requestStopCheque(null, null, null, null, null);
		assertNull(res);
	}

	@Test
	public void administerEarmarkTest() throws Fault {
		EarmarkModResponse res = this.depositAccountService.administerEarmark(null, null, null, null, null);
		assertNull(res);
	}

	@Test
	public void administerMobilePayIdTest() throws Fault {
		AdministerMobilePayIdResponse res = this.depositAccountService.administerMobilePayId(null, null, null, null,
				null);
		assertNull(res);
	}

	@Test
	public void retrieveAccountsTest() throws Fault {
		RetrieveAccountsResponse res = this.depositAccountService.retrieveAccounts(null, null, null, null, null);
		assertNull(res);
	}

	@Test
	public void retrieveFDAccountDetailsTest() throws Fault {
		FDDepInqResponse res = this.depositAccountService.retrieveFDAccountDetails(null, null, null, null, null);
		assertNull(res);
	}

	@Test
	public void administerDepositAccountStatusTest() throws Fault {
		AdministerDepositAccountStatusResponse res = this.depositAccountService.administerDepositAccountStatus(null,
				null, null, null, null);
		assertNull(res);
	}

	@Test
	public void retrieveDepositAccountEStatementListTest() throws Fault {
		AccountEStatementListResponse res = this.depositAccountService.retrieveDepositAccountEStatementList(null, null,
				null, null, null);
		assertNull(res);
	}

	@Test
	public void administerDepositAccountDetailsTest() throws Fault {
		AdministerDepositAccountDetailsResponse res = this.depositAccountService.administerDepositAccountDetails(null,
				null, null, null, null);
		assertNull(res);
	}

	@Test
	public void terminateFDAccountTest() throws Fault {
		TerminateFDAcctResponse res = this.depositAccountService.terminateFDAccount(null, null, null, null, null);
		assertNull(res);
	}

	@Test
	public void requestNetWorthStmtTest() throws Fault {
		RequestNetWorthStmtResponse res = this.depositAccountService.requestNetWorthStmt(null, null, null, null, null);
		assertNull(res);
	}

	@Test
	public void retrieveTransAndNotificationTest() throws Fault {
		RetrieveTransAndNotificationResponse res = this.depositAccountService.retrieveTransAndNotification(null, null,
				null, null, null);
		assertNull(res);
	}

	@Test
	public void retrieveExternalAccountBalanceTest() throws Fault {
		RetrieveExternalAccountBalanceResponse res = this.depositAccountService.retrieveExternalAccountBalance(null,
				null, null, null, null);
		assertNull(res);
	}

	@Test
	public void createAccountNumberTest() throws Fault {
		AcctIdRqAddResponse res = this.depositAccountService.createAccountNumber(null, null, null, null, null);
		assertNull(res);
	}

	@Test
	public void terminateEarmarkTest() throws Fault {
		EarmarkRelResponse res = this.depositAccountService.terminateEarmark(null, null, null, null, null);
		assertNull(res);
	}

	@Test
	public void retrieveCertificateListTest() throws Fault {
		RetrieveCertificateListResponse res = this.depositAccountService.retrieveCertificateList(null, null, null, null,
				null);
		assertNull(res);
	}

	@Test
	public void createFDAccountTest() throws Fault {
		FDAcctAddResponse res = this.depositAccountService.createFDAccount(null, null, null, null, null);
		assertNull(res);
	}

	@Test
	public void requestInterestCertificateTest() throws Fault {
		RequestInterestCertificateResponse res = this.depositAccountService.requestInterestCertificate(null, null, null,
				null, null);
		assertNull(res);
	}

	@Test
	public void administerFDMaturityTest() throws Fault {
		FDMaturityModResponse res = this.depositAccountService.administerFDMaturity(null, null, null, null, null);
		assertNull(res);
	}

	@Test
	public void administerFDAccountDetailsTest() throws Fault {
		AdministerFDAccountDetailsResponse res = this.depositAccountService.administerFDAccountDetails(null, null, null,
				null, null);
		assertNull(res);
	}

	@Test
	public void retrieveEarmarkTest() throws Fault {
		EarmarkInqResponse res = this.depositAccountService.retrieveEarmark(null, null, null, null, null);
		assertNull(res);
	}

	@Test
	public void retrieveFDQuoteTest() throws Fault {
		FDQuoteInqResponse res = this.depositAccountService.retrieveFDQuote(null, null, null, null, null);
		assertNull(res);
	}

	@Test
	public void retrieveTransactionHistoryTest() throws Fault {
		TranHistInqResponse res = this.depositAccountService.retrieveTransactionHistory(null, null, null, null, null);
		assertNull(res);
	}

	@Test
	public void retrieveDepositAccountTransactionsTest() throws Fault {
		RetrieveDepositAcctTranResponse res = this.depositAccountService.retrieveDepositAccountTransactions(null, null,
				null, null, null);
		assertNull(res);
	}

	@Test
	public void retrieveFDAccountBalTest() throws Fault {
		AcctBalInqResponse res = this.depositAccountService.retrieveFDAccountBal(null, null, null, null, null);
		assertNull(res);
	}

	@Test
	public void createDepositAccountEarmarkTest() throws Fault {
		EarmarkFundAddResponse res = this.depositAccountService.createDepositAccountEarmark(null, null, null, null,
				null);
		assertNull(res);
	}

	@Test
	public void administerDepositAccountSchemeTest() throws Fault {
		AdministerDepositAccountSchemeResponse res = this.depositAccountService.administerDepositAccountScheme(null,
				null, null, null, null);
		assertNull(res);
	}

	@Test
	public void createAccountTest() throws Fault {
		CASAAddResponse res = this.depositAccountService.createAccount(null, null, null, null, null);
		assertNull(res);
	}

	@Test
	public void initiateStatementRequestTest() throws Fault {
		StmtRqAddResponse res = this.depositAccountService.initiateStatementRequest(null, null, null, null, null);
		assertNull(res);
	}

	@Test
	public void initiateChequeBookRequestTest() throws Fault {
		ChqBkRqAddResponse res = this.depositAccountService.initiateChequeBookRequest(null, null, null, null, null);
		assertNull(res);
	}

	@Test
	public void retrieveAccountStatusTest() throws Fault {
		CustIdSrhResponse res = this.depositAccountService.retrieveAccountStatus(null, null, null, null, null);
		assertNull(res);
	}

	@Test
	public void administerFDNomineeDetailsTest() throws Fault {
		AdministerFDNomineeDetailsResponse res = this.depositAccountService.administerFDNomineeDetails(null, null, null,
				null, null);
		assertNull(res);
	}

	@Test
	public void retrieveDepositAccountDetailsTest() throws Fault {
		AcctDetailInqResponse res = this.depositAccountService.retrieveDepositAccountDetails(null, null, null, null,
				null);
		assertNull(res);
	}

	@Test
	public void createMobilePayIdTest() throws Fault {
		CreateMobilePayIdResponse res = this.depositAccountService.createMobilePayId(null, null, null, null, null);
		assertNull(res);
	}

	@Test
	public void evaluateDepositAccountClosureEligibilityTest() throws Fault {
		EvaluateDepositAccountClosureEligibilityResponse res = this.depositAccountService
				.evaluateDepositAccountClosureEligibility(null, null, null, null, null);
		assertNull(res);
	}

	@Test
	public void createFDAccountEarmarkTest() throws Fault {
		EarmarkFundAddResponse res = this.depositAccountService.createFDAccountEarmark(null, null, null, null, null);
		assertNull(res);
	}
}
