package com.dbs.tds.transactionbalancereadapi.service.impl;

import java.util.Date;

import javax.xml.transform.Source;

import com.dbs.tds.dto.AccountNotification;
import com.dbs.tds.transactionbalancereadapi.dao.BalanceReadDAO;
import com.dbs.tds.transactionbalancereadapi.mapper.RequestResponseTransformer;
import com.finacle.fixml.balance.AcctId;
import com.finacle.fixml.balance.BalInqRequest;
import com.finacle.fixml.balance.BalInqRq;
import com.finacle.fixml.balance.Body;
import com.finacle.fixml.balance.FIXML;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.web.client.RestOperations;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

/***
 *
 * This class contains Junit test cases for {@link BalanceReadServiceImpl}
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class BalanceReadServiceImplTest {

	@Mock
	private BalanceReadDAO balanceReadDAO;

	@Mock
	private RequestResponseTransformer requestResponseTransformer;

	@Spy
	private AccountNotification accountDetails = accountDetails();

	@Mock
	private FIXML fiXml = getFiXML();

	@Mock
	private RestOperations restOperations;

	@Mock
	private Jaxb2Marshaller marshaller;

	@Mock
	private ResponseEntity<String> responseXml = new ResponseEntity<>(HttpStatus.OK);

	@InjectMocks
	private BalanceReadServiceImpl balanceReadServiceImpl;

	@Before
	public void setValues() {
		this.balanceReadServiceImpl = new BalanceReadServiceImpl(this.balanceReadDAO,
				this.requestResponseTransformer, this.restOperations, this.marshaller);
	}

	@Test
	public void fetchAccountBalancesTest() {
		when(this.balanceReadDAO.fetchBalanceFromDB(this.accountDetails))
				.thenReturn(this.accountDetails);
		// Merging Data
		when(this.requestResponseTransformer.mergeRequestResponseOfTdsDB(this.accountDetails,
				this.accountDetails)).thenReturn(this.accountDetails);
		AccountNotification accountNotificationResult = this.balanceReadServiceImpl
				.fetchAccountBalances(this.accountDetails);

		assertNotNull(accountNotificationResult);
		assertNotNull(accountNotificationResult.getAccountNumber());
		assertSame("Y", accountNotificationResult.getIsBalSyncFlag());

	}

	@Test
	public void fetchAccountBalancesFromFinacleTest() {

		this.accountDetails.setIsBalSyncFlag("N");
		when(this.balanceReadDAO.fetchBalanceFromDB(this.accountDetails))
				.thenReturn(this.accountDetails);
		// Merging Data
		when(this.requestResponseTransformer.mergeRequestResponseOfTdsDB(this.accountDetails,
				this.accountDetails)).thenReturn(this.accountDetails);
		when(this.requestResponseTransformer.transformFromTdsToFinacle(this.accountDetails))
				.thenReturn(this.fiXml);

		when(this.restOperations.postForEntity(anyString(), any(FIXML.class), any(Class.class)))
				.thenReturn(this.responseXml);
		when(this.responseXml.getBody()).thenReturn("SUCCESS");
		when(this.marshaller.unmarshal(any(Source.class))).thenReturn(this.fiXml);

		when(this.requestResponseTransformer.transformFromFinacleToTDS(this.accountDetails,
				this.fiXml)).thenReturn(this.accountDetails);
		when(this.accountDetails.isSuccess()).thenReturn(true);

		AccountNotification accountNotificationResult = this.balanceReadServiceImpl
				.fetchAccountBalances(this.accountDetails);

		assertNotNull(accountNotificationResult);
		assertNotNull(accountNotificationResult.getAccountNumber());
		assertSame("N", accountNotificationResult.getIsBalSyncFlag());

	}

	private AccountNotification accountDetails() {
		AccountNotification acctNotification = new AccountNotification();
		acctNotification.setAccountNumber("12890");
		acctNotification.setAccountAvailableBalance(100.00);
		acctNotification.setAccountAvailableCurrency("INR");
		acctNotification.setAccountLedgerBalance(190.00);
		acctNotification.setAccountLedgerCurrency("INR");
		acctNotification.setBalanceAsOfDateTm(new Date());
		acctNotification.setAccountType("SA");
		acctNotification.setIsBalSyncFlag("Y");
		return acctNotification;
	}

	private FIXML getFiXML() {

		FIXML fiXML = new FIXML();
		AcctId acctId = new AcctId();
		acctId.setAcctId("123456");
		acctId.setAcctCurr("INR");
		BalInqRq balInqRq = new BalInqRq();
		balInqRq.setAcctId(acctId);
		BalInqRequest balInqRequest = new BalInqRequest();
		balInqRequest.setBalInqRq(balInqRq);
		Body body = new Body();
		body.setBalInqRequest(balInqRequest);
		fiXML.setBody(body);

		return fiXML;
	}

}
