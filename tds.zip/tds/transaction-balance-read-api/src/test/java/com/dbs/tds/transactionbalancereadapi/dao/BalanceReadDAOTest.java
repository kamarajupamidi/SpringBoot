package com.dbs.tds.transactionbalancereadapi.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.dbs.tds.dto.AccountNotification;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

/***
 *
 * This class contains Junit test cases for {@link BalanceReadDAOImpl}
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class BalanceReadDAOTest {

	@Mock
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Mock
	private JdbcTemplate jdbcTemplate;

	@Mock
	private AccountNotification accountDetails = getAccount();

	private List<AccountNotification> accounts = fetchAccountDetails();

	@Mock
	private RowMapper<AccountNotification> rows = getRowMapper();

	@InjectMocks
	private BalanceReadDAOImpl balanceReadDAOImpl;

	@Before
	public void setUp() {
		this.balanceReadDAOImpl = new BalanceReadDAOImpl(this.jdbcTemplate);
	}

	@Test
	public void fetchBalanceFromDBTest() {

		MapSqlParameterSource parameterSource = new MapSqlParameterSource();
		when(this.namedParameterJdbcTemplate.query("QUERY", parameterSource, this.rows))
				.thenReturn(this.accounts);
		this.balanceReadDAOImpl.fetchBalanceFromDB(this.accountDetails);
		assertNotNull(this.accountDetails);
	}

	@Test
	public void updateBalancesInDBTest() {
		when(this.namedParameterJdbcTemplate.update(anyString(), any(MapSqlParameterSource.class))).thenReturn(1);
		this.balanceReadDAOImpl.updateBalancesInDB(this.accountDetails);
	}

	private List<AccountNotification> fetchAccountDetails() {
		List<AccountNotification> accountData = new ArrayList<>();
		accountData.add(getAccount());
		return accountData;
	}

	private RowMapper<AccountNotification> getRowMapper() {
		return (RowMapper<AccountNotification>) (resuleSet, rowNum) -> {
			return getAccount();
		};
	}

	private AccountNotification getAccount() {
		AccountNotification acct = new AccountNotification();
		acct.setAccountNumber("1234567");
		acct.setAccountType("SA");
		acct.setIsBalSyncFlag("Y");
		acct.setAccountAvailableBalance(10.00);
		acct.setAccountAvailableCurrency("INR");
		acct.setAccountLedgerBalance(200.00);
		acct.setAccountLedgerCurrency("INR");
		acct.setBalanceAsOfDateTm(new Date());

		return acct;
	}

}
