package com.dbs.tds.transactionbalancereadapi.service;

import com.dbs.tds.dto.AccountNotification;

import org.springframework.stereotype.Service;

/**
 * This interface is used to expose services for Transaction in TDS context to perform
 * different functionalities.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Service
public interface BalanceReadService {

	/**
	 * This method is used to fetch balance for the account Number provided in the request
	 * instance.
	 *
	 * @param accountDetails : {@link AccountNotification}
	 * @return {@link AccountNotification}
	 */
	public AccountNotification fetchAccountBalances(AccountNotification accountDetails);

}
