package com.dbs.tds.transactionbalancereadapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;

/**
 * This class is used for initializing the Spring Boot Container for handling and exposing
 * the SOAP Service which will receive request incoming from SOI or Kony and process them
 * accordingly.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@SpringBootApplication
public class TransactionBalanceReadApiApplication extends SpringBootServletInitializer {

	/**
	 * This method is an overridden method from its parent class which is used to
	 * configure the servlet which will be initialized by this class.
	 *
	 * @param application : {@link SpringApplicationBuilder}
	 * @return {@link SpringApplicationBuilder}
	 */
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(TransactionBalanceReadApiApplication.class);
	}

	/**
	 * This method is used by JVM to start the Spring Boot Container for this application
	 * which will expose the SOAP Service for handling SOI or Kony requests for reading
	 * the Balance of a particular account.
	 *
	 * @param args : {@link String}[]
	 */
	public static void main(String[] args) {
		SpringApplication.run(TransactionBalanceReadApiApplication.class, args);
	}
}
