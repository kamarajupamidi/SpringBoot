/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: BalanceReadConstantFields.java
 * Author: DBS Asia Hub 2
 * Date: Oct 3, 2017
 */
package com.dbs.tds.transactionbalancereadapi.constants;

/**
 * This class is used as enumeration for collection of constant values which will be used
 * while making a call to Finacle for balance read functionality.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public enum BalanceReadConstantFields {

	SERVICE_REQUEST_ID("BalInq"),
	SERVICE_REQUEST_ID_VER("IN"),
	CHANNEL_ID("DGB"),
	BANK_ID("01"),
	FAILED("FAILURE"),
	AVAIL("AVAIL"),
	SAVING_ACCOUNT("SA"),
	CURRENT_ACCOUNT("CA"),
	SYNC_FLAG_Y("Y"),
	SYNC_FLAG_N("N"),
	CURRENT_DATE("currentDate"),
	DEFAULT_SYS_ID("Finacle Balance");

	/**
	 * This field is used to store value for value which is of type {@link String }.
	 */
	private String value;

	/**
	 * This is used to initialize the enum property.
	 *
	 * @param value : {@link String}
	 */
	private BalanceReadConstantFields(String value) {
		this.value = value;
	}

	/**
	 * This method is used to return the value of the enum type.
	 *
	 * @return {@link String}
	 */
	public String value() {
		return this.value;
	}

}
