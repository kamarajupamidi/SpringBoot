package com.dbs.tds.transactionbalancereadapi.service.impl;

import java.io.StringReader;
import java.util.Arrays;
import java.util.List;

import javax.xml.transform.stream.StreamSource;

import com.dbs.tds.constants.ErrorConstants;
import com.dbs.tds.constants.StatusCodes;
import com.dbs.tds.dto.AccountNotification;
import com.dbs.tds.transactionbalancereadapi.dao.BalanceReadDAO;
import com.dbs.tds.transactionbalancereadapi.exception.BalanceReadException;
import com.dbs.tds.transactionbalancereadapi.mapper.RequestResponseTransformer;
import com.dbs.tds.transactionbalancereadapi.service.BalanceReadService;
import com.dbs.tds.util.CommonUtils;
import com.finacle.fixml.balance.FIXML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestOperations;

import static com.dbs.tds.constants.AppConstants.STATUS_CODE_DES_KEY;
import static com.dbs.tds.constants.AppConstants.STATUS_CODE_KEY;
import static com.dbs.tds.constants.LoggingConstants.ERROR_TYPE;
import static com.dbs.tds.transactionbalancereadapi.constants.BalanceReadConstantFields.CURRENT_ACCOUNT;
import static com.dbs.tds.transactionbalancereadapi.constants.BalanceReadConstantFields.SAVING_ACCOUNT;
import static com.dbs.tds.transactionbalancereadapi.constants.BalanceReadConstantFields.SYNC_FLAG_N;

/**
 * This class is used to provide implementation of the TDS Transaction Service and provide
 * various methods to interact with TDS DB for different functionalities.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Service
public class BalanceReadServiceImpl implements BalanceReadService {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(BalanceReadServiceImpl.class);

	/**
	 * This field is used to store instance of type {@link BalanceReadDAO }.
	 */
	private BalanceReadDAO balanceReadDAO;

	/**
	 * This field is used to store value for requestResponseTransformer which is of type
	 * {@link RequestResponseTransformer }.
	 */
	private RequestResponseTransformer requestResponseTransformer;

	/***
	 * This field is used to store value for restOperations which is of type
	 * {@link RestOperations}
	 */
	private RestOperations restOperations;

	/***
	 * This field is used to store value for restOperations which is of type
	 * {@link Jaxb2Marshaller}
	 */
	private Jaxb2Marshaller marshaller;

	/***
	 * This field is used to store value for validAccounts which contains SA and CA
	 * values.
	 */
	private List<String> validAccounts = Arrays.asList(SAVING_ACCOUNT.value(), CURRENT_ACCOUNT.value());

	/***
	 * This field is used to store value for finacle read API.
	 */
	@Value("${finacle.readbalance.url}")
	private String finacleRetriveBalanceUrl;

	/***
	 * This method is used with injected balanceReadDAO
	 * ,requestResponseTransformer,restOperations and marshaller to set the instance of
	 * {@link BalanceReadDAO},{@link RequestResponseTransformer},{@link RestOperations},
	 * {@link Jaxb2Marshaller}, so we will be able to perform different functions with it.
	 *
	 * @param balanceReadDAO : {@link BalanceReadDAO}
	 * @param requestResponseTransformer : {@link RequestResponseTransformer}
	 * @param restOperations : {@link RestOperations}
	 * @param marshaller : {@link Jaxb2Marshaller}
	 */
	public BalanceReadServiceImpl(BalanceReadDAO balanceReadDAO,
			RequestResponseTransformer requestResponseTransformer,
			RestOperations restOperations, Jaxb2Marshaller marshaller) {
		this.balanceReadDAO = balanceReadDAO;
		this.requestResponseTransformer = requestResponseTransformer;
		this.restOperations = restOperations;
		this.marshaller = marshaller;
	}

	/**
	 * This method is used to fetch the account balance information from TDS DB and if the
	 * record is marked as Dirty in TDS DB then the balance details will be fetched from
	 * Finacle.
	 *
	 * @param accountDetailsRequest : {@link AccountNotification}
	 * @return {@link AccountNotification}
	 */
	@Override
	public AccountNotification fetchAccountBalances(AccountNotification accountDetailsRequest) {

		AccountNotification accountDetailsResp = this.balanceReadDAO.fetchBalanceFromDB(accountDetailsRequest);

		AccountNotification accountDetails = null;

		if (accountDetailsResp != null) {

			LOGGER.info("Balance fetched from TDS DB Available Balance: {}, Ledger Balance: {}",
					accountDetailsResp.getAccountAvailableBalance(), accountDetailsResp.getAccountLedgerBalance());

			// Merging of request and response instances into one.
			accountDetails = this.requestResponseTransformer.mergeRequestResponseOfTdsDB(
					accountDetailsRequest, accountDetailsResp);

			if (this.validAccounts.contains(accountDetails.getAccountType())
					&& (isBalancesNull(accountDetails)
							|| SYNC_FLAG_N.value().equalsIgnoreCase(accountDetails.getIsBalSyncFlag()))) {

				LOGGER.info("Record present in TDS DB is Dirty. Fetching balance from Finacle.");

				FIXML requestFixml = this.requestResponseTransformer.transformFromTdsToFinacle(accountDetails);

				long startTime = System.currentTimeMillis();
				ResponseEntity<String> responseXml = this.restOperations
						.postForEntity(this.finacleRetriveBalanceUrl, requestFixml, String.class);
				LOGGER.info("Time Taken for Finacle Service : {}", (System.currentTimeMillis() - startTime));

				FIXML responseFixml = (FIXML) this.marshaller
						.unmarshal(new StreamSource(new StringReader(responseXml.getBody())));

				accountDetails = this.requestResponseTransformer.transformFromFinacleToTDS(accountDetails,
						responseFixml);

				if (accountDetails.isSuccess()) {
					LOGGER.info("DB Update Success : {} ", accountDetails);
					this.balanceReadDAO.updateBalancesInDB(accountDetails);
				}
				else {
					LOGGER.info("DB Update Failed");
					MDC.put(STATUS_CODE_KEY.value(), StatusCodes.FAILURE.value());
					MDC.put(STATUS_CODE_DES_KEY.value(), StatusCodes.FAILURE.name());
					MDC.put(ERROR_TYPE.value(), ErrorConstants.TECH.name());
					throw new BalanceReadException(accountDetails.getErrorDesc());
				}
			}
		}

		MDC.put(STATUS_CODE_KEY.value(), StatusCodes.SUCCESS.value());
		MDC.put(STATUS_CODE_DES_KEY.value(), StatusCodes.SUCCESS.name());
		MDC.put(ERROR_TYPE.value(), "");
		LOGGER.info("Service Response with Balance details : {}", accountDetails);
		return accountDetails;

	}

	/**
	 * This method is used to confirm if the balances present in the parameter instance is
	 * null or not.
	 *
	 * @param accountNotification : {@link AccountNotification}
	 * @return {@link Boolean}
	 */
	private boolean isBalancesNull(AccountNotification accountNotification) {
		boolean result = false;
		if (CommonUtils.isDoubleNullOrNan(accountNotification.getAccountAvailableBalance())
				|| CommonUtils.isDoubleNullOrNan(accountNotification.getAccountLedgerBalance())) {
			result = true;
		}
		return result;
	}

}
