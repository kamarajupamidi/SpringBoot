/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: BalanceReadException.java
 * Author: DBS Asia Hub 2
 * Date: Oct 23, 2017
 */
package com.dbs.tds.transactionbalancereadapi.exception;

/**
 * This class is used as the exception which will be thrown whenever there is any
 * exception occurred during the processing.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public class BalanceReadException extends RuntimeException {

	/**
	 * This field is used to store value for serialVersionUID which is of type {@link long
	 * }.
	 */
	private static final long serialVersionUID = 3069778477268575602L;

	/**
	 * This field is used to store value for message which is of type {@link String }.
	 */
	private final String message;

	/**
	 * Custom Exception for handling balance read operations.
	 * @param message : {@link String }
	 */
	public BalanceReadException(String message) {
		super(message);
		this.message = message;
	}

	/**
	 * This method is used to get property message of class {@link BalanceReadException }.
	 *
	 * @return message : {@link String }
	 */
	@Override
	public String getMessage() {
		return this.message;
	}

}
