/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: RequestResponseTransformer.java
 * Author: DBS Asia Hub 2
 * Date: Aug 31, 2017
 */
package com.dbs.tds.transactionbalancereadapi.mapper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import com.dbs.schemas.soi.common._4_1.Amount;
import com.dbs.schemas.soi.common._4_1.BalAsOfDateTime;
import com.dbs.schemas.soi.common._4_1.CommonRq;
import com.dbs.schemas.soi.common._4_1.CommonRs;
import com.dbs.schemas.soi.common._4_1.DepAcct;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AcctBalInq;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AcctBalInq.RqAcctId;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AcctBalInqResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AcctBalInqResponse.BalDetl;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AcctBalInqResponse.BalDetl.DepBalDetl;
import com.dbs.tds.dto.AccountNotification;
import com.dbs.tds.transactionbalancereadapi.exception.BalanceReadException;
import com.dbs.tds.util.DateUtil;
import com.finacle.fixml.balance.AcctBal;
import com.finacle.fixml.balance.AcctId;
import com.finacle.fixml.balance.BalInqRequest;
import com.finacle.fixml.balance.BalInqResCustomDataType;
import com.finacle.fixml.balance.BalInqResCustomDataType.LedgerBal;
import com.finacle.fixml.balance.BalInqResponse;
import com.finacle.fixml.balance.BalInqRq;
import com.finacle.fixml.balance.BalInqRs;
import com.finacle.fixml.balance.Body;
import com.finacle.fixml.balance.ErrorDetailType;
import com.finacle.fixml.balance.FIXML;
import com.finacle.fixml.balance.Header;
import com.finacle.fixml.balance.MessageKeyType;
import com.finacle.fixml.balance.RequestHeaderType;
import com.finacle.fixml.balance.RequestMessageInfoType;
import com.finacle.fixml.balance.ResponseHeaderType;
import com.finacle.fixml.balance.TransactionType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Component;

import static com.dbs.tds.transactionbalancereadapi.constants.BalanceReadConstantFields.AVAIL;
import static com.dbs.tds.transactionbalancereadapi.constants.BalanceReadConstantFields.BANK_ID;
import static com.dbs.tds.transactionbalancereadapi.constants.BalanceReadConstantFields.CHANNEL_ID;
import static com.dbs.tds.transactionbalancereadapi.constants.BalanceReadConstantFields.CURRENT_ACCOUNT;
import static com.dbs.tds.transactionbalancereadapi.constants.BalanceReadConstantFields.FAILED;
import static com.dbs.tds.transactionbalancereadapi.constants.BalanceReadConstantFields.SAVING_ACCOUNT;
import static com.dbs.tds.transactionbalancereadapi.constants.BalanceReadConstantFields.SERVICE_REQUEST_ID;
import static com.dbs.tds.transactionbalancereadapi.constants.BalanceReadConstantFields.SERVICE_REQUEST_ID_VER;
import static com.dbs.tds.transactionbalancereadapi.constants.BalanceReadConstantFields.SYNC_FLAG_Y;

/**
 * This class is used to transform the details from Source instance to Destination
 * Instance.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Component
public class RequestResponseTransformer {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(RequestResponseTransformer.class);

	/**
	 * This method is used to convert the request coming from SOI/Kony; for Balance read;
	 * to instance which will be interacting with TDS DB to fetch the balance for that
	 * account.
	 *
	 * @param acctBalInq : {@link AcctBalInq}
	 * @return {@link AccountNotification}
	 */
	public AccountNotification transformFromSoapToTds(AcctBalInq acctBalInq) {
		AccountNotification accountDetails = new AccountNotification();
		for (RqAcctId account : acctBalInq.getRqAcctId()) {
			if (null != account.getDepAcctId()) {
				accountDetails = transformSavingsAccountDetails(accountDetails, account.getDepAcctId());
				break;
			}
		}
		LOGGER.info("Request details for fetching balance from TDS DB : {}", accountDetails);
		return accountDetails;
	}

	/**
	 * This method is used to extract values from request for savings account balance read
	 * and put in TDS db instance POJO.
	 *
	 * @param accountDetails : {@link AccountNotification}
	 * @param depAcct : {@link DepAcct}
	 * @return {@link AccountNotification}
	 */
	private AccountNotification transformSavingsAccountDetails(AccountNotification accountDetails, DepAcct depAcct) {
		LOGGER.info("Its a Savings Account with details : {}", depAcct);
		accountDetails.setAccountType(depAcct.getProdType());
		accountDetails.setAccountNumber(depAcct.getAcctId());
		accountDetails.setAccountLedgerCurrency(depAcct.getAcctCur());
		accountDetails.setAccountAvailableCurrency(depAcct.getAcctCur());
		return accountDetails;
	}

	/**
	 * This method is used to merge two instances of {@link AccountNotification} into one
	 * instance. These two instances are Request and Response Instances for TDS DB
	 * interaction.
	 *
	 * @param accountDetailsRequest : {@link AccountNotification}
	 * @param accountDetailsResponse : {@link AccountNotification}
	 * @return {@link AccountNotification}
	 */
	public AccountNotification mergeRequestResponseOfTdsDB(AccountNotification accountDetailsRequest,
			AccountNotification accountDetailsResponse) {
		AccountNotification accountDetails = new AccountNotification();

		// Request Details mapping
		accountDetails.setAccountNumber(accountDetailsRequest.getAccountNumber());
		accountDetails.setAccountType(accountDetailsRequest.getAccountType());

		// Response Details Mapping
		accountDetails.setIsBalSyncFlag(accountDetailsResponse.getIsBalSyncFlag());
		accountDetails.setAccountAvailableBalance(accountDetailsResponse.getAccountAvailableBalance());
		accountDetails.setAccountAvailableCurrency(accountDetailsResponse.getAccountAvailableCurrency());
		accountDetails.setAccountLedgerBalance(accountDetailsResponse.getAccountLedgerBalance());
		accountDetails.setAccountLedgerCurrency(accountDetailsResponse.getAccountLedgerCurrency());
		accountDetails.setBalanceAsOfDateTm(accountDetailsResponse.getBalanceAsOfDateTm());

		return accountDetails;
	}

	/**
	 * This method is used to transform the response from Balance read Service into
	 * instance of Soap Response, which will sent to SOI/Kony as a response to the service
	 * call they made.
	 *
	 * @param acctBalInq : {@link AcctBalInq}
	 * @param accountDetails : {@link AccountNotification}
	 * @return {@link AcctBalInqResponse}
	 */
	public AcctBalInqResponse transformFromTdsToSoap(AcctBalInq acctBalInq, AccountNotification accountDetails) {
		LOGGER.info("Entering the Transformer for tds response to soap response");
		AcctBalInqResponse acctBalInqResponse = new AcctBalInqResponse();

		// preparing for common response instance
		CommonRs commonRs = new CommonRs();
		CommonRq commonRq = acctBalInq.getCommonRq();
		commonRs.setOrgCode(commonRq.getOrgCode());

		List<BalDetl> balanceDetails = new ArrayList<>();

		if (accountDetails != null) {
			for (RqAcctId account : acctBalInq.getRqAcctId()) {
				BalDetl balanceDtl = new BalDetl();
				if (null != account.getDepAcctId()) {
					DepAcct depAcct = account.getDepAcctId();
					depAcct.setProdCode(depAcct.getProdType());
					depAcct.setOrgCode(commonRq.getOrgCode());

					balanceDtl.setDepAcctId(depAcct);
					if (SAVING_ACCOUNT.value().equalsIgnoreCase(depAcct.getProdType())
							|| CURRENT_ACCOUNT.value().equalsIgnoreCase(depAcct.getProdType())) {
						DepBalDetl savingAccountBalanceDetails = transformSavingAccountDetailsResponse(accountDetails);
						balanceDtl.setDepBalDetl(savingAccountBalanceDetails);
					}
					balanceDetails.add(balanceDtl);
					break;
				}
			}
		}

		acctBalInqResponse.setCommonRs(commonRs);
		acctBalInqResponse.getBalDetl().addAll(balanceDetails);
		LOGGER.info("Exiting the Transformer for tds response to soap response");
		return acctBalInqResponse;
	}

	/**
	 * This method is used to transfer the savings account details coming from TDS service
	 * response instance to SOAP Service instance part.
	 *
	 * @param accountDetails : {@link AccountNotification}
	 * @return {@link DepBalDetl}
	 */
	private DepBalDetl transformSavingAccountDetailsResponse(AccountNotification accountDetails) {
		DepBalDetl depBalDetl = new DepBalDetl();

		// Setting Ledger Balance
		Amount balance = new Amount();
		balance.setAmt(accountDetails.getAccountLedgerBalance());
		balance.setCur(accountDetails.getAccountLedgerCurrency());
		depBalDetl.setLedgerBal(balance);

		// Setting Available Balance
		balance = new Amount();
		balance.setAmt(accountDetails.getAccountAvailableBalance());
		balance.setCur(accountDetails.getAccountAvailableCurrency());
		depBalDetl.setAvailBal(balance);

		// Setting Balance as Of Date Time
		BalAsOfDateTime balAsOfDateTime = new BalAsOfDateTime();
		balAsOfDateTime
				.setBalAsOfDateTime(DateUtil.getXMLGregorianCalendarDateTime(accountDetails.getBalanceAsOfDateTm()));
		depBalDetl.setAvailBalAsOfDate(balAsOfDateTime);
		depBalDetl.setLedgerBalAsOfDate(balAsOfDateTime);

		return depBalDetl;
	}

	/**
	 * This method is used to transform the account details instance to {@link FIXML}
	 * instance, which will be sent to Finacle over https and the balance details are
	 * extracted from the response of https call.
	 *
	 * @param accountDetails : {@link AccountNotification}
	 * @return {@link FIXML}
	 */
	public FIXML transformFromTdsToFinacle(AccountNotification accountDetails) {
		FIXML fixml = new FIXML();
		fixml.setHeader(getRequestHeaderForFinacle());

		AcctId acctId = new AcctId();
		acctId.setAcctId(accountDetails.getAccountNumber());
		acctId.setAcctCurr(accountDetails.getAccountAvailableCurrency());

		BalInqRq balInqRq = new BalInqRq();
		balInqRq.setAcctId(acctId);

		BalInqRequest balInqRequest = new BalInqRequest();
		balInqRequest.setBalInqRq(balInqRq);

		Body body = new Body();
		body.setBalInqRequest(balInqRequest);

		fixml.setBody(body);

		return fixml;
	}

	/**
	 * This method is used to generate the Request header for Finacle Call, which will be
	 * used to retrieve Balance from the Finacle.
	 *
	 * @return {@link Header}
	 */
	private Header getRequestHeaderForFinacle() {
		Header header = new Header();
		RequestHeaderType requestHeaderType = new RequestHeaderType();
		MessageKeyType messageKeyType = new MessageKeyType();

		UUID uuid = UUID.randomUUID();
		messageKeyType.setRequestUUID(uuid.toString());
		LOGGER.info("Request UUID for Finacle Call : {}", uuid.toString());
		messageKeyType.setServiceRequestId(SERVICE_REQUEST_ID.value());
		messageKeyType.setServiceRequestVersion(SERVICE_REQUEST_ID_VER.value());
		messageKeyType.setChannelId(CHANNEL_ID.value());

		RequestMessageInfoType requestMessageInfoType = new RequestMessageInfoType();
		requestMessageInfoType.setBankId(BANK_ID.value());
		requestMessageInfoType.setTimeZone(Calendar.getInstance().getTimeZone().getDisplayName());
		requestMessageInfoType
				.setMessageDateTime(DateUtil.getXMLGregorianCalendarDateTime(Calendar.getInstance().getTime()));

		requestHeaderType.setMessageKey(messageKeyType);
		requestHeaderType.setRequestMessageInfo(requestMessageInfoType);

		header.setRequestHeader(requestHeaderType);
		return header;
	}

	/**
	 * This method is used to transform the response coming from Finacle HTTPS calls to
	 * {@link AccountNotification} instance which will be sent back to Soap Service
	 * implementation and the response will be sent back for that service.
	 *
	 * @param accountNotification : {@link AccountNotification}
	 * @param fixml : {@link FIXML}
	 * @return {@link AccountNotification}
	 */
	public AccountNotification transformFromFinacleToTDS(AccountNotification accountNotification, FIXML fixml) {
		AccountNotification accountDetails = checkForErrorResponse(accountNotification, fixml);
		if (accountDetails.isSuccess()) {

			// Extracting Available Balance From Finacle Response
			Map<String, List<AcctBal>> acctBalances = Optional.ofNullable(fixml).map(FIXML::getBody)
					.map(Body::getBalInqResponse).map(BalInqResponse::getBalInqRs)
					.map(BalInqRs::getAcctBal).orElse(Collections.emptyList()).stream()
					.collect(Collectors.groupingBy(AcctBal::getBalType));
			if (acctBalances.containsKey(AVAIL.value())) {
				com.finacle.fixml.balance.Amount amount = acctBalances.get(AVAIL.value()).get(0).getBalAmt();
				accountDetails.setAccountAvailableBalance(amount.getAmountValue());
				accountDetails.setAccountAvailableCurrency(amount.getCurrencyCode());
			}

			// Extracting Ledger Balance From Finacle Response
			LedgerBal ledgerBal = Optional.ofNullable(fixml).map(FIXML::getBody)
					.map(Body::getBalInqResponse).map(BalInqResponse::getBalInqCustomData)
					.map(BalInqResCustomDataType::getLedgerBal)
					.orElseThrow(() -> new BalanceReadException("Ledger Balance can not be null"));

			accountDetails.setAccountLedgerBalance(Optional.ofNullable(ledgerBal).map(LedgerBal::getAmountValue)
					.map(BigDecimal::doubleValue)
					.orElseThrow(() -> new BalanceReadException("Invalid Ledger Balance")));
			accountDetails.setAccountLedgerCurrency(ledgerBal.getCurrencyCode());
			accountDetails.setIsBalSyncFlag(SYNC_FLAG_Y.value());
		}
		LOGGER.info("Account Details after transformation from Finacle Response : {}", accountDetails);
		return accountDetails;
	}

	/**
	 * This method is used to check if the response from Finacle is an error response.
	 *
	 * @param accountDetails : {@link AccountNotification}
	 * @param fixml : {@link FIXML}
	 * @return {@link AccountNotification}
	 */
	private AccountNotification checkForErrorResponse(AccountNotification accountDetails, FIXML fixml) {

		String responseStatus = Optional.ofNullable(fixml).map(FIXML::getHeader).map(Header::getResponseHeader)
				.map(ResponseHeaderType::getHostTransaction).map(TransactionType::getStatus)
				.orElseThrow(() -> new BalanceReadException("Invalid Response Header from Finacle."));

		if (FAILED.value().equalsIgnoreCase(responseStatus)) {
			accountDetails.setSuccess(false);
			List<ErrorDetailType> errorDetails = null;
			if (fixml.getBody().getError().getFISystemException() == null) {
				errorDetails = fixml.getBody().getError().getFIBusinessException().getErrorDetail();
			}
			else {
				errorDetails = fixml.getBody().getError().getFISystemException().getErrorDetail();
			}

			if (!errorDetails.isEmpty()) {
				ErrorDetailType error = errorDetails.get(0);
				accountDetails.setErrorCode(error.getErrorCode());
				accountDetails.setErrorDesc(error.getErrorDesc());
			}
		}
		else {
			accountDetails.setSuccess(true);
		}
		return accountDetails;
	}

}
