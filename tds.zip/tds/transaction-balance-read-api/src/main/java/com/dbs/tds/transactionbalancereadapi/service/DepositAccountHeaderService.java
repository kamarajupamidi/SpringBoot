package com.dbs.tds.transactionbalancereadapi.service;

import javax.xml.datatype.DatatypeConfigurationException;

import com.dbs.schemas.soi.common._4_0.ServiceProvider;
import com.dbs.tds.util.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Component;

/***
 *
 * This class contains common methods for header portion of DepositAccountService
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Component
public class DepositAccountHeaderService {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(DepositAccountHeaderService.class);

	/***
	 *
	 * This method is used to build {@link ServiceProvider}
	 * @return {@link ServiceProvider}
	 */
	public ServiceProvider getServiceProvider() {
		ServiceProvider serviceProvider = new ServiceProvider();
		try {
			serviceProvider.setSPId("TDSIN");
			serviceProvider.setMustUnderstand(true);
			serviceProvider.setSPDateTime(DateUtil.getCurrentXMLGregorianCalendarDate());
		}
		catch (DatatypeConfigurationException e) {
			LOGGER.error("Error In creating XMLGregorianCalendar Object");
		}

		return serviceProvider;
	}
}
