/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: DepositAccountService.java
 * Author: DBS Asia Hub 2
 * Date: Sep 26, 2017
 */
package com.dbs.tds.transactionbalancereadapi.service;

import javax.xml.ws.Holder;

import com.dbs.schemas.soi.common._4_0.ExtendedHeader;
import com.dbs.schemas.soi.common._4_0.InfoWarn;
import com.dbs.schemas.soi.common._4_0.MsgDetl;
import com.dbs.schemas.soi.common._4_0.Trace;
import com.dbs.schemas.soi.wsdl.depositaccount.v1_1.Fault;
import com.dbs.schemas.soi.wsdl.depositaccount.v1_1.PortType;
import com.dbs.schemas.soi.xsd.commonimpl.v1_1.ChqBkRqAdd;
import com.dbs.schemas.soi.xsd.commonimpl.v1_1.ChqBkRqAddResponse;
import com.dbs.schemas.soi.xsd.commonimpl.v1_1.ChqStopAdd;
import com.dbs.schemas.soi.xsd.commonimpl.v1_1.ChqStopAddResponse;
import com.dbs.schemas.soi.xsd.commonimpl.v1_1.EarmarkFundAdd;
import com.dbs.schemas.soi.xsd.commonimpl.v1_1.EarmarkFundAddResponse;
import com.dbs.schemas.soi.xsd.commonimpl.v1_1.EarmarkInq;
import com.dbs.schemas.soi.xsd.commonimpl.v1_1.EarmarkInqResponse;
import com.dbs.schemas.soi.xsd.commonimpl.v1_1.EarmarkMod;
import com.dbs.schemas.soi.xsd.commonimpl.v1_1.EarmarkModResponse;
import com.dbs.schemas.soi.xsd.commonimpl.v1_1.EarmarkRel;
import com.dbs.schemas.soi.xsd.commonimpl.v1_1.EarmarkRelResponse;
import com.dbs.schemas.soi.xsd.commonimpl.v1_1.StmtRqAdd;
import com.dbs.schemas.soi.xsd.commonimpl.v1_1.StmtRqAddResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AccountEStatementList;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AccountEStatementListResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AcctBalInq;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AcctBalInqResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AcctDetailInq;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AcctDetailInqResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AcctIdRqAdd;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AcctIdRqAddResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AdministerDepositAccountDetails;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AdministerDepositAccountDetailsResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AdministerDepositAccountScheme;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AdministerDepositAccountSchemeResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AdministerDepositAccountStatus;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AdministerDepositAccountStatusResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AdministerDepositNomineeDetails;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AdministerDepositNomineeDetailsResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AdministerFDAccountDetails;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AdministerFDAccountDetailsResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AdministerFDNomineeDetails;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AdministerFDNomineeDetailsResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AdministerMobilePayId;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.AdministerMobilePayIdResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.CASAAdd;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.CASAAddResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.CreateMobilePayId;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.CreateMobilePayIdResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.CustIdSrh;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.CustIdSrhResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.EvaluateDepositAccountClosureEligibility;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.EvaluateDepositAccountClosureEligibilityResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.FDAcctAdd;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.FDAcctAddResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.FDDepInq;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.FDDepInqResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.FDMaturityMod;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.FDMaturityModResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.FDQuoteInq;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.FDQuoteInqResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RequestInterestCertificate;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RequestInterestCertificateResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RequestNetWorthStmt;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RequestNetWorthStmtResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RetrieveAccounts;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RetrieveAccountsResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RetrieveCertificateList;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RetrieveCertificateListResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RetrieveDepositAcctTran;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RetrieveDepositAcctTranResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RetrieveExternalAccountBalance;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RetrieveExternalAccountBalanceResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RetrieveFDReceiptList;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RetrieveFDReceiptListResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RetrieveTransAndNotification;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.RetrieveTransAndNotificationResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.TerminateFDAcct;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.TerminateFDAcctResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.TranFDHistInq;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.TranFDHistInqResponse;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.TranHistInq;
import com.dbs.schemas.soi.xsd.depositaccount.v1_1.TranHistInqResponse;
import com.dbs.tds.dto.AccountNotification;
import com.dbs.tds.transactionbalancereadapi.mapper.RequestResponseTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import org.springframework.stereotype.Service;

import static com.dbs.tds.constants.LoggingConstants.FUNCTIONAL_MAP;

/**
 * This class is used as implementation for Services exposed for CASA Account related
 * functionalities.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Service
@javax.jws.WebService(serviceName = "DepositAccount", portName = "HTTP", targetNamespace = "http://schemas.dbs.com/soi/wsdl/DepositAccount/v1_1", wsdlLocation = "classpath:wsdl/DepositAccount_v1_1.wsdl", endpointInterface = "com.dbs.schemas.soi.wsdl.depositaccount.v1_1.PortType")
public class DepositAccountService implements PortType {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(DepositAccountService.class);

	/**
	 * This field is used to store value for requestResponseTransformer which is of type
	 * {@link RequestResponseTransformer }.
	 */
	private RequestResponseTransformer requestResponseTransformer;

	/**
	 * This field is used to store value for balanceReadService which is of type
	 * {@link BalanceReadService }.
	 */
	private BalanceReadService balanceReadService;

	/**
	 * This field is used to store value for depositAccountHeaderService which is of type
	 * {@link DepositAccountHeaderService }.
	 */
	private DepositAccountHeaderService depositAccountHeaderService;

	/**
	 * This constructor is used to build current instance with injected instance of
	 * {@link RequestResponseTransformer} and {@link BalanceReadService}, which will be
	 * used to transform the details from one instance to another and call the service
	 * functionalities for Balance Read.
	 *
	 * @param requestResponseTransformer : {@link RequestResponseTransformer}
	 * @param balanceReadService : {@link BalanceReadService}
	 * @param depositAccountHeaderService : {@link DepositAccountHeaderService}
	 */
	public DepositAccountService(RequestResponseTransformer requestResponseTransformer,
			BalanceReadService balanceReadService, DepositAccountHeaderService depositAccountHeaderService) {
		this.requestResponseTransformer = requestResponseTransformer;
		this.balanceReadService = balanceReadService;
		this.depositAccountHeaderService = depositAccountHeaderService;
	}

	@Override
	public AdministerDepositNomineeDetailsResponse administerDepositNomineeDetails(
			AdministerDepositNomineeDetails administerDepositNomineeDetailsRq, Holder<MsgDetl> part1,
			Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Administer_Deposit_Nominee");
		return null;
	}

	@Override
	public RetrieveFDReceiptListResponse retrieveFDReceiptList(RetrieveFDReceiptList retrieveFDReceiptListRq,
			Holder<MsgDetl> part1, Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4)
			throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Retrieve_FD_Receipt");
		return null;
	}

	@Override
	public TranFDHistInqResponse retrieveFDTransactionHistory(TranFDHistInq tranFDHistInqRq, Holder<MsgDetl> part1,
			Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Retrieve_FD_Transaction_History");
		return null;
	}

	@Override
	public ChqStopAddResponse requestStopCheque(ChqStopAdd chqStopAddRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Request_Stop_Cheque");
		return null;
	}

	@Override
	public EarmarkModResponse administerEarmark(EarmarkMod earmarkModRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Administer_Earmark");
		return null;
	}

	@Override
	public AdministerMobilePayIdResponse administerMobilePayId(AdministerMobilePayId administerMobilePayIdRq,
			Holder<MsgDetl> part1, Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4)
			throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Administer_Mobile_PayId");
		return null;
	}

	@Override
	public RetrieveAccountsResponse retrieveAccounts(RetrieveAccounts retrieveAccountsRq, Holder<MsgDetl> part1,
			Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Retrive_Accounts");
		return null;
	}

	@Override
	public FDDepInqResponse retrieveFDAccountDetails(FDDepInq fdDepInqRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Retrieve_FD_AccountDetails");
		return null;
	}

	@Override
	public AdministerDepositAccountStatusResponse administerDepositAccountStatus(
			AdministerDepositAccountStatus administerDepositAccountStatusRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Administer_Deposit_Account_Status");
		return null;
	}

	@Override
	public AccountEStatementListResponse retrieveDepositAccountEStatementList(
			AccountEStatementList accountEStatementListRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Retrieve_Deposit_Account_EStatement");
		return null;
	}

	@Override
	public AdministerDepositAccountDetailsResponse administerDepositAccountDetails(
			AdministerDepositAccountDetails administerDepositAccountDetailsRq, Holder<MsgDetl> part1,
			Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Administer_Accountr_Details");
		return null;
	}

	@Override
	public TerminateFDAcctResponse terminateFDAccount(TerminateFDAcct terminateFDAcctRq, Holder<MsgDetl> part1,
			Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Terminate_FD_Account");
		return null;
	}

	@Override
	public RequestNetWorthStmtResponse requestNetWorthStmt(RequestNetWorthStmt requestNetWorthStmtRq,
			Holder<MsgDetl> part1, Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4)
			throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Request_NetWorth_Statement");
		return null;
	}

	@Override
	public RetrieveTransAndNotificationResponse retrieveTransAndNotification(
			RetrieveTransAndNotification retrieveTransAndNotificationRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Retrieve_TransAndNotifications");
		return null;
	}

	@Override
	public RetrieveExternalAccountBalanceResponse retrieveExternalAccountBalance(
			RetrieveExternalAccountBalance retrieveExternalAccountBalanceRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Retrieve_External_Account_Balance");
		return null;
	}

	@Override
	public AcctIdRqAddResponse createAccountNumber(AcctIdRqAdd acctIdRqAddRq, Holder<MsgDetl> part1,
			Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Create_Account_Number");
		return null;
	}

	@Override
	public EarmarkRelResponse terminateEarmark(EarmarkRel earmarkRelRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Terminate_Earmark");
		return null;
	}

	@Override
	public RetrieveCertificateListResponse retrieveCertificateList(RetrieveCertificateList retrieveCertificateListRq,
			Holder<MsgDetl> part1, Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4)
			throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Retrive_Certificate_List");
		return null;
	}

	@Override
	public FDAcctAddResponse createFDAccount(FDAcctAdd fdAcctAddRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Create_FD_Account");
		return null;
	}

	@Override
	public RequestInterestCertificateResponse requestInterestCertificate(
			RequestInterestCertificate requestInterestCertificateRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Request_Interest_Certificate");
		return null;
	}

	@Override
	public FDMaturityModResponse administerFDMaturity(FDMaturityMod fdMaturityModRq, Holder<MsgDetl> part1,
			Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Administer_FD_MaturityMod");
		return null;
	}

	@Override
	public AdministerFDAccountDetailsResponse administerFDAccountDetails(
			AdministerFDAccountDetails administerFDAccountDetailsRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Administer_Accountr_Details_Response");
		return null;
	}

	@Override
	public EarmarkInqResponse retrieveEarmark(EarmarkInq earmarkInqRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Retrieve_Earmark");
		return null;
	}

	@Override
	public FDQuoteInqResponse retrieveFDQuote(FDQuoteInq fdQuoteInqRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Retrieve_FD_Quote");
		return null;
	}

	@Override
	public TranHistInqResponse retrieveTransactionHistory(TranHistInq tranHistInqRq, Holder<MsgDetl> part1,
			Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Retrieve_Transaction_History");
		return null;
	}

	@Override
	public RetrieveDepositAcctTranResponse retrieveDepositAccountTransactions(
			RetrieveDepositAcctTran retrieveDepositAcctTranRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Retrieve_Deposit_Account_Transactions");
		return null;
	}

	@Override
	public AcctBalInqResponse retrieveFDAccountBal(AcctBalInq acctBalInqRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Retrieve_FD_Account_Balance");
		return null;
	}

	@Override
	public EarmarkFundAddResponse createDepositAccountEarmark(EarmarkFundAdd earmarkFundAddRq, Holder<MsgDetl> part1,
			Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Create_Deposit_Account_Earmark");
		return null;
	}

	@Override
	public AdministerDepositAccountSchemeResponse administerDepositAccountScheme(
			AdministerDepositAccountScheme administerDepositAccountSchemeRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Administer_Account_Scheme");
		return null;
	}

	@Override
	public CASAAddResponse createAccount(CASAAdd casaAddRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Create_Account");
		return null;
	}

	@Override
	public StmtRqAddResponse initiateStatementRequest(StmtRqAdd stmtRqAddRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Initiate_Statement_Request");
		return null;
	}

	@Override
	public ChqBkRqAddResponse initiateChequeBookRequest(ChqBkRqAdd chqBkRqAddRq, Holder<MsgDetl> part1,
			Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Initiate_ChequeBook_Request");
		return null;
	}

	@Override
	public CustIdSrhResponse retrieveAccountStatus(CustIdSrh custIdSrhRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Retrieve_Account_Status");
		return null;
	}

	@Override
	public AdministerFDNomineeDetailsResponse administerFDNomineeDetails(
			AdministerFDNomineeDetails administerFDNomineeDetailsRq, Holder<MsgDetl> part1, Holder<Trace> part2,
			Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Administer_FD_Nominee_Details");
		return null;
	}

	@Override
	public AcctDetailInqResponse retrieveDepositAccountDetails(AcctDetailInq acctDetailInqRq, Holder<MsgDetl> part1,
			Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Retrieve_Deposit_Account_Details");
		return null;
	}

	/**
	 * This method is used to read balance from TDS DB. It will check, if the balance is
	 * in sync with Finacle. If the balance is in sync, then the balance is fetched from
	 * TDS DB, otherwise it will be fetched from Finacle.
	 *
	 * @param acctBalInqRq : {@link AcctBalInq}
	 * @param part1 : {@link Holder} &lt; {@link MsgDetl} &gt;
	 * @param part2 : {@link Holder} &lt; {@link Trace} &gt;
	 * @param part3 : {@link Holder} &lt; {@link ExtendedHeader} &gt;
	 * @param part4 : {@link Holder} &lt; {@link InfoWarn} &gt;
	 * @return {@link AcctBalInqResponse}
	 * @throws Fault : {@link Fault}
	 */
	@Override
	public AcctBalInqResponse retrieveDepositAccountBal(AcctBalInq acctBalInqRq, Holder<MsgDetl> part1,
			Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Retrive_Deposit_Account_Bal");

		part2.value.getServiceProvider().add(this.depositAccountHeaderService.getServiceProvider());
		AccountNotification accountDetails = this.requestResponseTransformer.transformFromSoapToTds(acctBalInqRq);

		long startTime = System.currentTimeMillis();
		accountDetails = this.balanceReadService.fetchAccountBalances(accountDetails);
		LOGGER.info("Time Taken for Java Service : {}", (System.currentTimeMillis() - startTime));

		AcctBalInqResponse acctBalInqResponse = this.requestResponseTransformer.transformFromTdsToSoap(acctBalInqRq,
				accountDetails);
		LOGGER.info("Response for this Service Execution : {}", acctBalInqResponse);

		return acctBalInqResponse;
	}

	@Override
	public CreateMobilePayIdResponse createMobilePayId(CreateMobilePayId createMobilePayIdRq, Holder<MsgDetl> part1,
			Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Create_Mobile_PayId");
		return null;
	}

	@Override
	public EvaluateDepositAccountClosureEligibilityResponse evaluateDepositAccountClosureEligibility(
			EvaluateDepositAccountClosureEligibility evaluateDepositAccountClosureEligibilityRq, Holder<MsgDetl> part1,
			Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Evaluate_Deposit_Account_Closure");
		return null;
	}

	@Override
	public EarmarkFundAddResponse createFDAccountEarmark(EarmarkFundAdd earmarkFundAddRq, Holder<MsgDetl> part1,
			Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Create_FDAccount_Earmark");
		return null;
	}

	@Override
	public AcctBalInqResponse retrieveDepositAccountBalTds(AcctBalInq acctBalInqRq, Holder<MsgDetl> part1,
			Holder<Trace> part2, Holder<ExtendedHeader> part3, Holder<InfoWarn> part4) throws Fault {
		MDC.put(FUNCTIONAL_MAP.value(), "Retrieve_Deposit_Account_Bal_Tds");
		return null;
	}

}
