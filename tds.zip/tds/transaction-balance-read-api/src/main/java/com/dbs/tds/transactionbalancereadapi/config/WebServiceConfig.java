package com.dbs.tds.transactionbalancereadapi.config;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import javax.xml.ws.Endpoint;

import com.dbs.tds.transactionbalancereadapi.filter.LoggingFilter;
import com.dbs.tds.transactionbalancereadapi.service.DepositAccountService;
import com.finacle.fixml.balance.FIXML;
import org.apache.cxf.bus.spring.SpringBus;
import org.apache.cxf.feature.LoggingFeature;
import org.apache.cxf.jaxws.EndpointImpl;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClients;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.web.client.RestOperations;
import org.springframework.web.client.RestTemplate;

/**
 * This class is used as the configuration for the SOAP services which will be exposed for
 * handling SOI or KONY request for different kind of operations.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Configuration
public class WebServiceConfig {

	/**
	 * This method is used to publish the exposed service, on the configured URL so that
	 * it can honor the SOAP requests coming from SOA or KONY system and process them
	 * accordingly.
	 *
	 * @param springBus : {@link SpringBus}
	 * @param depositAccountService : {@link DepositAccountService}
	 * @return {@link Endpoint}
	 */
	@Bean
	public Endpoint positionKeepingendpoint(SpringBus springBus, DepositAccountService depositAccountService) {
		LoggingFeature feature = new LoggingFeature();
		feature.setPrettyLogging(true);
		feature.initialize(springBus);

		springBus.getFeatures().add(feature);
		EndpointImpl endpoint = new EndpointImpl(springBus, depositAccountService);
		endpoint.publish("/DepositAccountService_1.1");
		return endpoint;
	}

	/**
	 * This method is used to set the Logging Filter so that every request which will be
	 * received by the services can be logged.
	 *
	 * @return {@link FilterRegistrationBean}
	 */
	@Bean
	public FilterRegistrationBean logFilterRegistrationBean() {
		FilterRegistrationBean logRegistrationBean = new FilterRegistrationBean();
		logRegistrationBean.setName("logger");
		LoggingFilter logFilter = new LoggingFilter();
		logRegistrationBean.setFilter(logFilter);
		return logRegistrationBean;
	}

	/**
	 * This method is used to set Rest Template which will be used to connect to Secure
	 * network over SSL.
	 *
	 * @param clientHttpRequestFactory : {@link ClientHttpRequestFactory}
	 *
	 * @return {@link RestOperations}
	 */
	@Bean
	public RestOperations restOperations(ClientHttpRequestFactory clientHttpRequestFactory) {
		return new RestTemplate(clientHttpRequestFactory);
	}

	/**
	 * This method is used to set Http client to Client Request factory.
	 *
	 * @param httpClient : {@link HttpClient}
	 * @return {@link ClientHttpRequestFactory}
	 */
	@Bean
	public ClientHttpRequestFactory clientHttpRequestFactory(HttpClient httpClient) {
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
		requestFactory.setReadTimeout(60 * 1000);
		requestFactory.setConnectTimeout(60 * 1000);
		return requestFactory;
	}

	/**
	 *
	 * This method is used to set key store definition using file path and password for
	 * key store.
	 *
	 * @return {@link HttpClient}
	 *
	 * @throws NoSuchAlgorithmException : {@link NoSuchAlgorithmException}
	 * @throws KeyStoreException : {@link KeyStoreException}
	 * @throws IOException : {@link IOException}
	 * @throws CertificateException : {@link CertificateException}
	 * @throws UnrecoverableKeyException : {@link UnrecoverableKeyException}
	 * @throws KeyManagementException : {@link KeyManagementException}
	 */
	@Bean
	public HttpClient httpClient() throws NoSuchAlgorithmException, KeyStoreException,
			IOException, CertificateException, UnrecoverableKeyException, KeyManagementException {
		TrustManagerFactory trustManagerFactory = TrustManagerFactory
				.getInstance(TrustManagerFactory.getDefaultAlgorithm());
		trustManagerFactory.init((KeyStore) null);

		SSLContext sslcontext = SSLContext.getInstance("TLS");

		sslcontext.init(null, trustManagerFactory.getTrustManagers(), null);
		SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext, new String[] { "TLSv1.2" }, null,
				new NoopHostnameVerifier());

		return HttpClients.custom().setSSLHostnameVerifier(new NoopHostnameVerifier())
				.setSSLSocketFactory(sslsf)
				.build();
	}

	/**
	 * This method is used to marshal and un marshal xml to java object for {@link FIXML}.
	 *
	 * @return {@link Jaxb2Marshaller}
	 */
	@Bean
	public Jaxb2Marshaller marshaller() {
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setClassesToBeBound(new Class[] { FIXML.class });
		return jaxb2Marshaller;
	}

}
