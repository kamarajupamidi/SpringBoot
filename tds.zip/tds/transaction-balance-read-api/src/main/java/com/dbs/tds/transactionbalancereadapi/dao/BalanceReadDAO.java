package com.dbs.tds.transactionbalancereadapi.dao;

import com.dbs.tds.dto.AccountNotification;

import org.springframework.stereotype.Repository;

/**
 * This interface is used to provide abstract functionalities for interacting with TDS DB
 * for Transaction Read/Update operations.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Repository
public interface BalanceReadDAO {

	/**
	 * This method is used to fetch account Balance from TDS DB.
	 *
	 * @param accountDetails : {@link AccountNotification}
	 * @return {@link AccountNotification}
	 */
	public AccountNotification fetchBalanceFromDB(AccountNotification accountDetails);

	/**
	 * This method is used to update the balance details in TDS DB.
	 *
	 * @param accountDetails : {@link AccountNotification}
	 */
	public void updateBalancesInDB(AccountNotification accountDetails);
}
