package com.dbs.tds.transactionbalancereadapi.dao;

import java.util.Calendar;
import java.util.Date;

import com.dbs.tds.dto.AccountNotification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import static com.dbs.tds.constants.AccountFields.ACCT_AVALBL_CRRNCY;
import static com.dbs.tds.constants.AccountFields.ACCT_AVLBL_BAL;
import static com.dbs.tds.constants.AccountFields.ACCT_LDGR_BAL;
import static com.dbs.tds.constants.AccountFields.ACCT_LDGR_CRRNCY;
import static com.dbs.tds.constants.AccountFields.ACCT_NO;
import static com.dbs.tds.constants.AccountFields.ACCT_TYP;
import static com.dbs.tds.constants.AccountFields.BAL_ASOFDATETIME;
import static com.dbs.tds.constants.AccountFields.IS_BAL_SYNC;
import static com.dbs.tds.constants.AccountFields.LST_UPDT_SYS_ID;
import static com.dbs.tds.transactionbalancereadapi.constants.BalanceReadConstantFields.CURRENT_DATE;
import static com.dbs.tds.transactionbalancereadapi.constants.BalanceReadConstantFields.DEFAULT_SYS_ID;

/**
 * This class is used to provide implementation for {@link BalanceReadDAO} and also
 * provide different functions to interact with TDS DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Repository
public class BalanceReadDAOImpl implements BalanceReadDAO {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(BalanceReadDAOImpl.class);

	/**
	 * This field is used to store value for fetchAccountDetails which is of type
	 * {@link String }.
	 */
	private String fetchAccountDetails;

	/**
	 * This field is used to store value for updateBalanceDetails which is of type
	 * {@link String }.
	 */
	private String updateBalanceDetails;

	/**
	 * This field is used to store value for transactionUpdateJdbcTemplate which is of
	 * type {@link NamedParameterJdbcTemplate }.
	 */
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	/**
	 * This constructor is used with injected {@link JdbcTemplate} for setting up its
	 * instance and transactionUpdateJdbcTemplate as the class variable, which will help
	 * in interacting with TDS DB.
	 *
	 * @param jdbcTemplate : {@link JdbcTemplate}
	 */
	public BalanceReadDAOImpl(JdbcTemplate jdbcTemplate) {
		this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate);
		this.fetchAccountDetails = "select ACCT_AVLBL_BAL, ACCT_LDGR_BAL, BAL_ASOFDATETIME, IS_BAL_SYNC, ACCT_AVALBL_CRRNCY, ACCT_LDGR_CRRNCY from T_ACCT where ACCT_NO = :ACCT_NO and ACCT_TYP = :ACCT_TYP;";
		this.updateBalanceDetails = "UPDATE T_ACCT SET ACCT_AVLBL_BAL = :ACCT_AVLBL_BAL, ACCT_AVALBL_CRRNCY = :ACCT_AVALBL_CRRNCY, ACCT_LDGR_BAL = :ACCT_LDGR_BAL, ACCT_LDGR_CRRNCY = :ACCT_LDGR_CRRNCY, BAL_ASOFDATETIME = :currentDate, IS_BAL_SYNC = :IS_BAL_SYNC,"
				+ " LST_UPDT_SYS_ID = :LST_UPDT_SYS_ID, LST_UPDT_DTTM = :currentDate WHERE ACCT_NO = :ACCT_NO;";
	}

	/**
	 * This method is used to fetch account Balance from TDS DB. It will check for DIRTY
	 * flag. If the record in DB is dirty, this method will return
	 * {@link AccountNotification} instance with balances as NaN otherwise it will return
	 * the {@link AccountNotification} instance with balance amount present in DB.
	 *
	 * @param accountDetails : {@link AccountNotification}
	 * @return {@link AccountNotification}
	 */
	@Override
	public AccountNotification fetchBalanceFromDB(AccountNotification accountDetails) {

		MapSqlParameterSource parameterSource = new MapSqlParameterSource();
		parameterSource
				.addValue(ACCT_NO.name(), accountDetails.getAccountNumber())
				.addValue(ACCT_TYP.name(), accountDetails.getAccountType());

		try {
			long startTime = System.currentTimeMillis();
			AccountNotification accntDetails = this.namedParameterJdbcTemplate
					.queryForObject(this.fetchAccountDetails, parameterSource,
							(RowMapper<AccountNotification>) (resuleSet, rowNum) -> {
								AccountNotification accountNotification = new AccountNotification();
								accountNotification
										.setAccountAvailableBalance(resuleSet.getDouble(ACCT_AVLBL_BAL.name()));
								accountNotification.setAccountLedgerBalance(resuleSet.getDouble(ACCT_LDGR_BAL.name()));

								accountNotification.setBalanceAsOfDateTm(resuleSet.getTimestamp(3) != null
										? new Date(resuleSet.getTimestamp(BAL_ASOFDATETIME.name()).getTime())
										: Calendar.getInstance().getTime());

								accountNotification.setIsBalSyncFlag(resuleSet.getString(IS_BAL_SYNC.name()));
								accountNotification
										.setAccountAvailableCurrency(resuleSet.getString(ACCT_AVALBL_CRRNCY.name()));
								accountNotification
										.setAccountLedgerCurrency(resuleSet.getString(ACCT_LDGR_CRRNCY.name()));
								return accountNotification;
							});
			LOGGER.info("Time Taken for DB Select Service : {}", (System.currentTimeMillis() - startTime));

			LOGGER.info("Account Details returned as response from DAO : {}", accntDetails);
			return accntDetails;
		}
		catch (EmptyResultDataAccessException ex) {
			return null;
		}
	}

	/**
	 * This method is used to update the balance details coming from finacle to TDS DB.
	 * This method will also update the balance sync flag to confirm that the balance in
	 * TDS DB is in sync with Finacle.
	 *
	 * @param accountDetails : {@link AccountNotification}
	 */
	@Override
	public void updateBalancesInDB(AccountNotification accountDetails) {
		Date currentDate = new Date();
		MapSqlParameterSource parameterSource = new MapSqlParameterSource();
		parameterSource
				.addValue(ACCT_NO.name(), accountDetails.getAccountNumber())
				.addValue(ACCT_AVLBL_BAL.name(), accountDetails.getAccountAvailableBalance())
				.addValue(ACCT_AVALBL_CRRNCY.name(), accountDetails.getAccountAvailableCurrency())
				.addValue(ACCT_LDGR_BAL.name(), accountDetails.getAccountLedgerBalance())
				.addValue(ACCT_LDGR_CRRNCY.name(), accountDetails.getAccountLedgerCurrency())
				.addValue(CURRENT_DATE.value(), currentDate)
				.addValue(IS_BAL_SYNC.name(), accountDetails.getIsBalSyncFlag())
				.addValue(LST_UPDT_SYS_ID.name(), DEFAULT_SYS_ID.value());

		long startTime = System.currentTimeMillis();
		int result = this.namedParameterJdbcTemplate.update(this.updateBalanceDetails, parameterSource);
		LOGGER.info("Time Taken for DB Update Service : {}", (System.currentTimeMillis() - startTime));
		LOGGER.info("Rows Affected : {}", result);
	}

}
