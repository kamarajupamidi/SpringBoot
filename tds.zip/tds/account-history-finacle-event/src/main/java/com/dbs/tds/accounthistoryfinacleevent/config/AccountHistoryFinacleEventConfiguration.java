package com.dbs.tds.accounthistoryfinacleevent.config;

import javax.jms.ConnectionFactory;

import com.dbs.tds.accounthistoryfinacleevent.service.AccountTransactionNotificationService;
import com.dbs.tds.accounthistoryfinacleevent.transformer.AccountTransactionNotificationTransformer;
import com.dbs.tds.config.CoreConfiguration;
import com.dbs.tds.dto.AccountNotification;
import com.finacle.fixml.account.FIXML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.jms.Jms;
import org.springframework.integration.handler.LoggingHandler;
import org.springframework.integration.router.AbstractMappingMessageRouter;
import org.springframework.integration.xml.router.XPathRouter;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.jms.support.converter.SimpleMessageConverter;
import org.springframework.messaging.MessageChannel;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

/**
 * This class is used as the configuration class which configure the behavior and working
 * of the Message queue which will receive the message coming from Finacle and process the
 * Account message accordingly and insert/update the details in TDS DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */

@EnableIntegration
@Configuration
@Import(CoreConfiguration.class)
public class AccountHistoryFinacleEventConfiguration {
	private static final Logger LOGGER = LoggerFactory.getLogger(AccountHistoryFinacleEventConfiguration.class);

	/**
	 * This method is used to receive the message which is coming on message queue from
	 * Finacle with account details. This method creates a connection with the queue with
	 * the help of injected connectionFactory and destination name. Then the message is
	 * converted using the injected marshallingMessageConverter and message is put onto
	 * suitable channel for processing. If there is any error during the process then the
	 * message is put onto the error channel.
	 *
	 * @param destinationName : {@link String}
	 * @param connectionFactory : {@link ConnectionFactory}
	 *
	 * @return {@link IntegrationFlow}
	 */
	@Bean
	public IntegrationFlow accountEventFlow(@Value("${account.inbound.destination}") String destinationName,
			ConnectionFactory connectionFactory) {
		return IntegrationFlows.from(Jms.messageDrivenChannelAdapter(connectionFactory).destination(destinationName)
				.outputChannel(outputChannel()).errorChannel(errorChannel())).get();
	}

	/**
	 * This method is used to return the message channel for message which is coming in
	 * message queue from Finacle and logging the complete message before processing it.
	 *
	 * @return {@link MessageChannel}
	 */

	@Bean
	public MessageChannel outputChannel() {
		return new DirectChannel();
	}

	/**
	 * This method is used to return the Message Channel for SB account Flow.
	 *
	 * @return {@link MessageChannel}
	 */

	@Bean
	public MessageChannel sbAccountChannel() {
		return new DirectChannel();
	}

	/**
	 * This method is used to return the Message Channel for TD account flow.
	 *
	 * @return {@link MessageChannel}
	 */
	@Bean
	public MessageChannel tdAccountChannel() {
		return new DirectChannel();
	}

	/**
	 * This method is used to return the Message Channel for Error message Flow.
	 *
	 * @return {@link MessageChannel}
	 */
	@Bean
	public MessageChannel errorChannel() {
		return new DirectChannel();
	}

	@Bean
	public MessageConverter messageConverter() {
		return new SimpleMessageConverter();
	}

	/**
	 * Incoming request will be validated against valid XPath object and based on the type
	 * of Object in request it will be redirected to SB Account Flow or FD account Flow
	 *
	 * @return {@link IntegrationFlow}
	 */
	@Bean
	public IntegrationFlow accountParseFlow() {
		return IntegrationFlows.from(outputChannel()).route(accountXPathRouter()).get();
	}

	@Bean
	public IntegrationFlow accountErrorFlow() {
		return IntegrationFlows.from(errorChannel()).handle(new LoggingHandler("ERROR")).get();
	}

	/**
	 * This method is used to define the flow of the message channel which will be invoked
	 * whenever there is a message on Finacle message queue. This method will transform
	 * the incoming message and put the message to get serviced and get updated in the DB.
	 *
	 * @param accountTransactionNotificationTransformer :
	 * {@link AccountTransactionNotificationTransformer}
	 * @param accountTransactionNotificationService :
	 * {@link AccountTransactionNotificationService}
	 *
	 * @return {@link IntegrationFlow}
	 */
	@Bean
	public IntegrationFlow finacleSBAccountInboundFlow(
			AccountTransactionNotificationTransformer accountTransactionNotificationTransformer,
			AccountTransactionNotificationService accountTransactionNotificationService) {

		return IntegrationFlows.from(sbAccountChannel())
				.<String, FIXML>transform(request -> accountTransactionNotificationTransformer.transform(request))
				.<FIXML, AccountNotification>transform(
						fixml -> accountTransactionNotificationTransformer.transform(fixml))
				.handle(accountTransactionNotificationService).get();
	}

	/**
	 * This method is used to define the flow of the TD flow which will be invoked when
	 * incoming request body contains TDAcctInqRequest account message on Finacle message
	 * queue. As of now we are just ignoring this type of requests.
	 *
	 * @return {@link IntegrationFlow}
	 */
	@Bean
	public IntegrationFlow finacleTDAccountInboundFlow() {
		return IntegrationFlows.from(tdAccountChannel()).handle(msg -> {
			LOGGER.warn("{} presently not supported in Account notification ", msg.getPayload());
		})
				.get();
	}

	/**
	 * This method is used to provide the instance of the marshaller which will help in
	 * parsing the XML format String object to a java instance with the help of the
	 * Context path and injected location of the schema files used to identify the
	 * correctness of the XML format.
	 *
	 * @param contextPath : {@link String}
	 * @param schemaLocation : {@link String}
	 * @return {@link Jaxb2Marshaller}
	 */
	@Bean
	public Jaxb2Marshaller marshaller(@Value("${context.path}") String contextPath,
			@Value("${schema.location}") String schemaLocation) {
		Resource schemaResource = new ClassPathResource(schemaLocation);
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setContextPaths(contextPath);
		jaxb2Marshaller.setSchema(schemaResource);
		return jaxb2Marshaller;
	}

	/**
	 * This method will snoop incoming request to check if the incoming request body
	 * contains "SBAcctInqRequest" or TDAcctInqRequest". Based on the request body it will
	 * be redirected to sbAccountChannel flow or fdAccountChannel flow default flow is
	 * errorChannel flow.
	 *
	 * @return {@link AbstractMappingMessageRouter}
	 */
	@Bean
	public AbstractMappingMessageRouter accountXPathRouter() {
		XPathRouter router = new XPathRouter("local-name(/*/*[2]/*)");
		router.setEvaluateAsString(true);
		router.setResolutionRequired(false);
		router.setDefaultOutputChannel(errorChannel());
		router.setChannelMapping("SBAcctInqRequest", "sbAccountChannel");
		router.setChannelMapping("TDAcctInqRequest", "tdAccountChannel");
		return router;
	}

}
