package com.dbs.tds.accounthistoryfinacleevent.repository;

import org.springframework.stereotype.Repository;

import com.dbs.tds.dto.AccountNotification;

/***
*
* This class is used for create or Update SB accounts into TDS DB.
*
* @author DBS Asia Hub 2
* @version 1.0
*
*/

@Repository
public interface AccountNotificationRepository {
	
	Integer createOrUpdateSBAccountDetails(AccountNotification accountNotification);

}
