package com.dbs.tds.accounthistoryfinacleevent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountHistoryFinacleEventApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountHistoryFinacleEventApplication.class, args);
	}
}
