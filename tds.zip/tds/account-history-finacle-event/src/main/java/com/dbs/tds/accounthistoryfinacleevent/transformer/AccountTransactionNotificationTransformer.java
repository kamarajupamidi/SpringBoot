package com.dbs.tds.accounthistoryfinacleevent.transformer;

import java.io.StringReader;
import java.util.UUID;

import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.transform.stream.StreamSource;

import com.dbs.tds.constants.AppIdentifiers;
import com.dbs.tds.dto.AccountNotification;
import com.finacle.fixml.account.AcctGenInfo;
import com.finacle.fixml.account.AcctId;
import com.finacle.fixml.account.FIXML;
import com.finacle.fixml.account.RequestHeaderType;
import com.finacle.fixml.account.SBAcctInqReqCustomDataType;
import com.finacle.fixml.account.SBAcctInqRequest;
import com.finacle.fixml.account.SBAcctInqRq;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import static com.dbs.tds.constants.AppConstants.APP_REGION;
import static com.dbs.tds.constants.Countries.IN;
import static com.dbs.tds.constants.LoggingConstants.CLIENT_IP;
import static com.dbs.tds.constants.LoggingConstants.FUNCTIONAL_MAP;
import static com.dbs.tds.constants.LoggingConstants.INTERFACE_MAP;
import static com.dbs.tds.constants.LoggingConstants.MSG_UID;
import static com.dbs.tds.constants.LoggingConstants.REQUEST_TYPE;
import static com.dbs.tds.constants.LoggingConstants.SERVICE_ID;
import static com.dbs.tds.constants.RequestTypes.E2E;

@Component
public class AccountTransactionNotificationTransformer {

	/**
	 * This field is used to instantiate LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(AccountTransactionNotificationTransformer.class);

	private Jaxb2Marshaller finacleaccountMarshaller;

	public AccountTransactionNotificationTransformer(Jaxb2Marshaller finacleaccountMarshaller) {
		this.finacleaccountMarshaller = finacleaccountMarshaller;
	}

	public FIXML transform(String request) {
		startLoggingRequest();
		LOGGER.info("Incoming request {}", request);
		return (FIXML) this.finacleaccountMarshaller.unmarshal(new StreamSource(new StringReader(request)));
	}

	/**
	 * This method is used to populate ELK variable in MDC object. By this we print
	 * required fields for analytics in application logs.
	 */
	private void startLoggingRequest() {
		long startTime = System.currentTimeMillis();
		MDC.put(APP_REGION.value(), IN.name());
		MDC.put(AppIdentifiers.APP_CODE.name(), AppIdentifiers.APP_CODE.value());
		MDC.put(MSG_UID.value(), UUID.randomUUID().toString());
		MDC.put(REQUEST_TYPE.value(), E2E.name());
		MDC.put(SERVICE_ID.value(), "finacleaccountevent");
		MDC.put(INTERFACE_MAP.value(), "finacle_tdsqueque_to_tds");
		MDC.put(FUNCTIONAL_MAP.value(), "Finacle_Account_History_Event");
		MDC.put("startTime", String.valueOf(startTime));
		MDC.put(CLIENT_IP.value(), "FINACLEQUEQUE");
	}

	/**
	 * This method is used to transform the incoming account request. Incoming request
	 * which will be in XML format, is parsed into an instance of {@link FIXML} and this
	 * method will transform the object into {@link AccountNotification} which further
	 * will be used to map database entities.
	 *
	 * @param fixml : {@link FIXML}
	 * @return {@link AccountNotification}
	 */
	public AccountNotification transform(FIXML fixml) {

		LOGGER.info("JSON Request incoming from Finacle: {}", fixml);
		AccountNotification accountNotification = new AccountNotification();
		SBAcctInqRequest sbAcctInqReq = fixml.getBody().getSBAcctInqRequest();
		RequestHeaderType requestHeaderType = fixml.getHeader().getRequestHeader();
		Assert.notNull(sbAcctInqReq, "SBAcctInqRequest cannot be null");
		Assert.notNull(requestHeaderType, "RequestHeaderType cannot be null");
		SBAcctInqRq sbAcctInqRq = sbAcctInqReq.getSBAcctInqRq();

		Assert.notNull(sbAcctInqRq, "SBAcctInqRq cannot be null");
		if (requestHeaderType.getRequestMessageInfo() != null) {
			XMLGregorianCalendar msgDate = requestHeaderType.getRequestMessageInfo().getMessageDateTime();
			accountNotification
			.setRecordGenerationTime(msgDate != null ? msgDate.toGregorianCalendar().getTime() : null);
		}
		AcctId acctId = sbAcctInqRq.getSBAcctId();
		Assert.notNull(acctId, "SBAcctId cannot be null");
		accountNotification.setAccountNumber(acctId.getAcctId());
		if (acctId.getAcctType() != null) {
			accountNotification.setAccountType(acctId.getAcctType().getSchmType());
			accountNotification.setAccountSchemaCode(acctId.getAcctType().getSchmCode());
		}
		if (sbAcctInqRq.getAcctBalAmt() != null) {
			accountNotification.setAccountAvailableBalance(sbAcctInqRq.getAcctBalAmt().getAmountValue());
			accountNotification.setAccountAvailableCurrency(sbAcctInqRq.getAcctBalAmt().getCurrencyCode());
		}

		SBAcctInqReqCustomDataType sbAcctInqReqCustomDataType = sbAcctInqReq.getSBAcctInqCustomData();
		Assert.notNull(sbAcctInqReqCustomDataType, "sbAcctInqReqCustomDataType cannot be null");
		if (sbAcctInqReqCustomDataType.getLedgerBal() != null) {
			accountNotification
			.setAccountLedgerBalance(sbAcctInqReqCustomDataType.getLedgerBal().getAmountValue().doubleValue());
			accountNotification.setAccountLedgerCurrency(sbAcctInqReqCustomDataType.getLedgerBal().getCurrencyCode());
		}
		AcctGenInfo sbAcctGenInfo = sbAcctInqRq.getSBAcctGenInfo();
		if (sbAcctGenInfo.getAcctName() != null) {
			accountNotification.setAccountName(sbAcctGenInfo.getAcctName());
		}
		accountNotification.setIsBalSyncFlag("N");
		LOGGER.info("accountDetails Generated out of JSON Request : {}", accountNotification);
		return accountNotification;
	}

}
