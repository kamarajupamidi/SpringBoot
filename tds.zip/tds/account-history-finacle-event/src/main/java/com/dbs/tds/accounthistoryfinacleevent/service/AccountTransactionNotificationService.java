package com.dbs.tds.accounthistoryfinacleevent.service;

import com.dbs.tds.accounthistoryfinacleevent.repository.AccountNotificationRepository;
import com.dbs.tds.constants.StatusCodes;
import com.dbs.tds.dto.AccountNotification;
import com.dbs.tds.dto.CodeTypes;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import static com.dbs.tds.constants.AppConstants.STATUS_CODE_DES_KEY;
import static com.dbs.tds.constants.AppConstants.STATUS_CODE_KEY;
import static com.dbs.tds.constants.LoggingConstants.ERROR_TYPE;
import static com.dbs.tds.constants.LoggingConstants.RESPONSE_TIME;

@Service
@Transactional
public class AccountTransactionNotificationService {
	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(AccountTransactionNotificationService.class);

	/**
	 * This field is used to store value for ELKLOGGER which is of type {@link Logger }.
	 */
	private static final Logger ELKLOGGER = LoggerFactory.getLogger("elklogger");

	private AccountNotificationRepository accountNotificationRepository;

	private CodeTypes codeTypes;

	public AccountTransactionNotificationService(AccountNotificationRepository accountNotificationRepository,
			CodeTypes codeTypes) {
		this.accountNotificationRepository = accountNotificationRepository;
		this.codeTypes = codeTypes;
	}

	/**
	 * This method will check if Schema codes of the incoming request is in the allowed
	 * list or not. if the Schema code was in the allowed list then if the account number
	 * in the incoming request is not present in the database then it will insert the
	 * account notification details into database otherwise it is going to update the
	 * notification details.
	 *
	 * @param accountNotification : {@link AccountNotification}
	 */
	public void process(AccountNotification accountNotification) {

		if (this.codeTypes.getSchemeCodes().get(accountNotification.getAccountSchemaCode()) != null) {
			String productType = this.codeTypes.getProdtypes().get(accountNotification.getAccountType());
			accountNotification.setAccountType(productType != null ? productType : "");
			int rowsAffected = this.accountNotificationRepository.createOrUpdateSBAccountDetails(accountNotification);
			MDC.put(STATUS_CODE_KEY.value(), StatusCodes.SUCCESS.value());
			MDC.put(STATUS_CODE_DES_KEY.value(), StatusCodes.SUCCESS.name());
			MDC.put(ERROR_TYPE.value(), "");
			LOGGER.info("No of rows affected : {}", rowsAffected);
		}
		else {
			LOGGER.info(
					"Processing account number={}, schemacode={}, accountType={} has Invalid schemcode, hence skipping",
					accountNotification.getAccountNumber(), accountNotification.getAccountSchemaCode(),
					accountNotification.getAccountType());
		}
		logElapsedTime();

	}

	/**
	 * This method is used to calculate and log the elapsed time.
	 */
	private void logElapsedTime() {
		String startTime = MDC.get("startTime");
		if (StringUtils.isNotBlank(startTime)) {
			long start = Long.parseLong(startTime);
			long elapsed = System.currentTimeMillis() - start;
			MDC.put(RESPONSE_TIME.value(), String.valueOf(elapsed));
			ELKLOGGER.info("");
		}
	}
}
