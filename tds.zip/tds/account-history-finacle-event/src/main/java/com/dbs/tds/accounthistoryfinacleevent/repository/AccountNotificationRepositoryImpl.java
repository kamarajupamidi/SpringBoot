package com.dbs.tds.accounthistoryfinacleevent.repository;

import java.util.Date;

import com.dbs.tds.dto.AccountNotification;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

/***
 *
 * This class is used for create or Update SB accounts into TDS DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Repository
public class AccountNotificationRepositoryImpl implements AccountNotificationRepository {

	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	public AccountNotificationRepositoryImpl(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
		this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
	}

	/**
	 * This method is insert account notification details into database if the account
	 * number is not present in the database otherwise if the account number is present it
	 * will be updating the account details
	 *
	 * @param accountNotification : {@link AccountNotification}
	 *
	 * @return {@link Integer}
	 *
	 */
	@Override
	public Integer createOrUpdateSBAccountDetails(AccountNotification accountNotification) {
		Integer rowsAffected = 0;
		String createorUpdateSBaccount = "Insert into T_ACCT(ACCT_NO, ACCT_NAME,ACCT_TYP,ACCT_AVLBL_BAL,"
				+ "ACCT_SCHM_CODE,ACCT_LDGR_BAL,IS_BAL_SYNC,LST_UPDT_SYS_ID,LST_UPDT_DTTM,ACCT_LDGR_CRRNCY,"
				+ "ACCT_AVALBL_CRRNCY,BAL_ASOFDATETIME,VENDR_LST_UPDT_DTTM) values(:acctNo,:acctName,:acctType,:avlbBal,:schmCode,:ldgrBal,:balSync,"
				+ "'AccountNotificationOnline',:currentDate,:ldgrCrrncy,:avlbCrrny,NULL,:messageDate) ON DUPLICATE KEY UPDATE ";
		MapSqlParameterSource parameterSource = new MapSqlParameterSource();
		parameterSource.addValue("acctNo", accountNotification.getAccountNumber())
				.addValue("acctName", accountNotification.getAccountName())
				.addValue("acctType", accountNotification.getAccountType())
				.addValue("avlbBal", accountNotification.getAccountAvailableBalance())
				.addValue("schmCode", accountNotification.getAccountSchemaCode())
				.addValue("ldgrBal", accountNotification.getAccountLedgerBalance())
				.addValue("balSync", accountNotification.getIsBalSyncFlag())
				.addValue("currentDate", new Date())
				.addValue("ldgrCrrncy", accountNotification.getAccountLedgerCurrency())
				.addValue("avlbCrrny", accountNotification.getAccountAvailableCurrency())
				.addValue("messageDate", accountNotification.getRecordGenerationTime());

		if (accountNotification.getAccountSchemaCode() != null) {
			createorUpdateSBaccount += "ACCT_SCHM_CODE = CASE WHEN (VENDR_LST_UPDT_DTTM IS NULL OR VENDR_LST_UPDT_DTTM < :messageDate OR VENDR_LST_UPDT_DTTM = :messageDate) THEN :schmCode ELSE ACCT_SCHM_CODE END,";
		}

		createorUpdateSBaccount += "VENDR_LST_UPDT_DTTM = CASE WHEN (VENDR_LST_UPDT_DTTM IS NULL OR VENDR_LST_UPDT_DTTM < :messageDate OR VENDR_LST_UPDT_DTTM = :messageDate) THEN :messageDate ELSE VENDR_LST_UPDT_DTTM END,";
		createorUpdateSBaccount += "LST_UPDT_SYS_ID= 'AccountNotificationOnline', LST_UPDT_DTTM = :currentDate";
		rowsAffected = executeStatement(createorUpdateSBaccount, parameterSource);

		return rowsAffected;
	}

	protected int executeStatement(String createorUpdateSBaccount, MapSqlParameterSource parameterSource) {
		return this.namedParameterJdbcTemplate.execute(createorUpdateSBaccount, parameterSource,
				paramPreparedStatement -> paramPreparedStatement.executeUpdate());
	}

}
