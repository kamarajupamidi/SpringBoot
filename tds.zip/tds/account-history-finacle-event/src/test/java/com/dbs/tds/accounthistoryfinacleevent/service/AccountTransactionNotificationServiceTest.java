package com.dbs.tds.accounthistoryfinacleevent.service;

import static org.mockito.Mockito.when;

import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.dbs.tds.accounthistoryfinacleevent.repository.AccountNotificationRepository;
import com.dbs.tds.dto.AccountNotification;
import com.dbs.tds.dto.CodeTypes;

/***
 * Unit test cases for {@link AccountTransactionNotificationService} methods.
 *
 * @author sivanarayana
 *
 * @version 1.0
 */
@RunWith(MockitoJUnitRunner.class)
public class AccountTransactionNotificationServiceTest {

	@Mock
	private AccountNotificationRepository repository;

	@Mock
	private CodeTypes codeTypes;

	@InjectMocks
	private AccountTransactionNotificationService service;

	@Mock
	private Map<String, String> codes;

	@Test
	public void testProcess() {
		AccountNotification accountNotification = createAccountNotification();
		when(repository.createOrUpdateSBAccountDetails(accountNotification)).thenReturn(1);
		when(codeTypes.getSchemeCodes()).thenReturn(codes);
		when(codeTypes.getProdtypes()).thenReturn(codes);
		when(codes.get(Mockito.anyString())).thenReturn("val");
		service.process(accountNotification);
	}
	
	@Test
	public void testProcessWithNullProdType() {
		AccountNotification accountNotification = createAccountNotification();
		when(repository.createOrUpdateSBAccountDetails(accountNotification)).thenReturn(1);
		when(codeTypes.getSchemeCodes()).thenReturn(codes);
		when(codeTypes.getProdtypes()).thenReturn(codes);
		when(codes.get(Mockito.anyString())).thenReturn(null, "val");
		service.process(accountNotification);
	}

	@Test
	public void testProcessWithInvalidShemeCode() {
		AccountNotification accountNotification = createAccountNotification();
		service.process(accountNotification);
	}

	private AccountNotification createAccountNotification() {
		AccountNotification accountNotification = new AccountNotification();
		accountNotification.setAccountSchemaCode("acct-schm-code");
		accountNotification.setAccountType("acct-type");
		return accountNotification;
	}

}
