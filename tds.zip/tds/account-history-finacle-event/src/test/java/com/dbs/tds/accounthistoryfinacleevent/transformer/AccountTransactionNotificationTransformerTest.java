package com.dbs.tds.accounthistoryfinacleevent.transformer;

import java.math.BigDecimal;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.transform.Source;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import com.dbs.tds.dto.AccountNotification;
import com.finacle.fixml.account.AcctGenInfo;
import com.finacle.fixml.account.AcctId;
import com.finacle.fixml.account.AcctType;
import com.finacle.fixml.account.Amount;
import com.finacle.fixml.account.Body;
import com.finacle.fixml.account.FIXML;
import com.finacle.fixml.account.Header;
import com.finacle.fixml.account.RequestHeaderType;
import com.finacle.fixml.account.RequestMessageInfoType;
import com.finacle.fixml.account.SBAcctInqReqCustomDataType;
import com.finacle.fixml.account.SBAcctInqReqCustomDataType.LedgerBal;
import com.finacle.fixml.account.SBAcctInqRequest;
import com.finacle.fixml.account.SBAcctInqRq;

/***
 * Unit test cases for {@link AccountTransactionNotificationTransformer} methods.
 *
 * @author sivanarayana
 *
 * @version 1.0
 */
@RunWith(MockitoJUnitRunner.class)
public class AccountTransactionNotificationTransformerTest {

	private static final String ACCOUNT_FIXML_REQUEST = "account-fixml-request";
	
	@InjectMocks
	private AccountTransactionNotificationTransformer transformer;
	
	@Mock
	private Jaxb2Marshaller finacleaccountMarshaller;
	
	
	@Test
	public void testTransformString() {
		FIXML fixml = Mockito.mock(FIXML.class);
		Mockito.when(finacleaccountMarshaller.unmarshal(Mockito.any(Source.class))).thenReturn(fixml);
		FIXML fixmlResult = transformer.transform(ACCOUNT_FIXML_REQUEST);
		Assert.assertNotNull(fixmlResult);
	}

	@Test
	public void testTransformFIXML() throws DatatypeConfigurationException {
		FIXML fixml = createFixml();
		AccountNotification accountNotification = transformer.transform(fixml);
		Assert.assertNotNull(accountNotification);
	}
	
	
	@Test
	public void testTransformFIXMLWithNullInfo() throws DatatypeConfigurationException {
		FIXML fixml = createFixml();
		
		fixml.getHeader().getRequestHeader().setRequestMessageInfo(null);
		
		fixml.getBody().getSBAcctInqRequest().getSBAcctInqRq().getSBAcctId().setAcctType(null);
		fixml.getBody().getSBAcctInqRequest().getSBAcctInqRq().setAcctBalAmt(null);
		fixml.getBody().getSBAcctInqRequest().getSBAcctInqRq().getSBAcctGenInfo().setAcctName(null);
		fixml.getBody().getSBAcctInqRequest().getSBAcctInqCustomData().setLedgerBal(null);
		
		AccountNotification accountNotification = transformer.transform(fixml);
		Assert.assertNotNull(accountNotification);
	}
	
	@Test
	public void testTransformFIXMLWithNullMsgDate() throws DatatypeConfigurationException {
		FIXML fixml = createFixml();
		
		fixml.getHeader().getRequestHeader().getRequestMessageInfo().setMessageDateTime(null);
		
		fixml.getBody().getSBAcctInqRequest().getSBAcctInqRq().getSBAcctId().setAcctType(null);
		fixml.getBody().getSBAcctInqRequest().getSBAcctInqRq().setAcctBalAmt(null);
		fixml.getBody().getSBAcctInqRequest().getSBAcctInqRq().getSBAcctGenInfo().setAcctName(null);
		fixml.getBody().getSBAcctInqRequest().getSBAcctInqCustomData().setLedgerBal(null);
		
		AccountNotification accountNotification = transformer.transform(fixml);
		Assert.assertNotNull(accountNotification);
	}

	private FIXML createFixml() throws DatatypeConfigurationException {

		AcctType acctType = new AcctType();
		acctType.setSchmType("schm-type");
		acctType.setSchmCode("schm-code");

		AcctId acctId = new AcctId();
		acctId.setAcctId("12345678");
		acctId.setAcctType(acctType);
		
		SBAcctInqRq sbAcctInqRq = new SBAcctInqRq();
		sbAcctInqRq.setSBAcctId(acctId);
		
		Amount acctBalAmt = new Amount();
		acctBalAmt.setAmountValue(10000.00);
		acctBalAmt.setCurrencyCode("INR");
		
		LedgerBal ledgerBalAmt = new LedgerBal();
		ledgerBalAmt.setAmountValue(BigDecimal.valueOf(10000.00));
		ledgerBalAmt.setCurrencyCode("INR");

		AcctGenInfo sbAcctGenInfo = new AcctGenInfo();
		sbAcctGenInfo.setAcctName("acct name");
		
		sbAcctInqRq.setAcctBalAmt(acctBalAmt);
		sbAcctInqRq.setSBAcctGenInfo(sbAcctGenInfo);
		
		SBAcctInqReqCustomDataType sbAcctInqReqCustomDataType = new SBAcctInqReqCustomDataType();
		sbAcctInqReqCustomDataType.setLedgerBal(ledgerBalAmt);
		SBAcctInqRequest sbAcctInqRequest = new SBAcctInqRequest();
		sbAcctInqRequest.setSBAcctInqRq(sbAcctInqRq);
		sbAcctInqRequest.setSBAcctInqCustomData(sbAcctInqReqCustomDataType);
		
		RequestMessageInfoType requestMessagingInfotype = new RequestMessageInfoType();
		requestMessagingInfotype.setMessageDateTime(getDataTypeFactory().newXMLGregorianCalendar());
		
		RequestHeaderType requestHeaderType = new RequestHeaderType();
		requestHeaderType.setRequestMessageInfo(requestMessagingInfotype);
		
		Header header = new Header();
		header.setRequestHeader(requestHeaderType);
		
		FIXML fixml = new FIXML();
		fixml.setHeader(header);
		
		Body body = new Body();
		body.setSBAcctInqRequest(sbAcctInqRequest);
		fixml.setBody(body);

		return fixml;
	}

	private static DatatypeFactory getDataTypeFactory() throws DatatypeConfigurationException {
		return DatatypeFactory.newInstance();
	}
}
