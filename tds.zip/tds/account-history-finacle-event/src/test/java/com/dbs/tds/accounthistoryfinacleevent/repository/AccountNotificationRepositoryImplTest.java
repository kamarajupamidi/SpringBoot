package com.dbs.tds.accounthistoryfinacleevent.repository;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.dbs.tds.dto.AccountNotification;

/***
 * Unit test cases for {@link AccountNotificationRepositoryImpl} methods.
 *
 * @author sivanarayana
 *
 * @version 1.0
 */
@RunWith(MockitoJUnitRunner.class)
public class AccountNotificationRepositoryImplTest {

	@Mock
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@InjectMocks
	private AccountNotificationRepositoryImpl repositoryImpl = new AccountNotificationRepositoryImpl(namedParameterJdbcTemplate) {
		protected int executeStatement(String createorUpdateSBaccount, MapSqlParameterSource parameterSource) {
			return 1;
		}
	};


	@Test
	public void testCreateOrUpdateSBAccountDetails() {
		AccountNotification accountNotification = new AccountNotification();
		accountNotification.setAccountType("SB");
		accountNotification.setAccountSchemaCode("Acc Scheme Code");
		int result = repositoryImpl.createOrUpdateSBAccountDetails(accountNotification);
		assertTrue(1 == result);
	}
	
	@Test
	public void testCreateOrUpdateSBAccountDetailsWithNullType() {
		AccountNotification accountNotification = new AccountNotification();
		accountNotification.setAccountType(null);
		accountNotification.setAccountSchemaCode(null);
		int result = repositoryImpl.createOrUpdateSBAccountDetails(accountNotification);
		assertTrue(1 == result);
	}

}
