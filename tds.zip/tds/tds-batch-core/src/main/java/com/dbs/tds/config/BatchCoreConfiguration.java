package com.dbs.tds.config;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.dbs.tds.batch.core")
public class BatchCoreConfiguration {

}
