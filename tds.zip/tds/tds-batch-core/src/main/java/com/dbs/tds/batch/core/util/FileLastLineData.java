package com.dbs.tds.batch.core.util;

/**
 * This class is used as POJO for storing the Data present in the last line of a File.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public class FileLastLineData {

	/**
	 * This field is used to store value for lastLine which is of type {@link String }.
	 */
	private String lastLine;

	/**
	 * This field is used to store value for lastLineNumber which is of type {@link long
	 * }.
	 */
	private long lastLineNumber;

	/**
	 * This constructor is used to set the values for lastline and lastlineNumber
	 * respectively.
	 *
	 * @param lastLine : {@link String}
	 * @param lastLineNumber : {@link Long}
	 */
	public FileLastLineData(String lastLine, long lastLineNumber) {

		this.lastLine = lastLine;
		this.lastLineNumber = lastLineNumber;
	}

	/**
	 * This method is used to get property lastLine of class {@link FileLastLineData }.
	 *
	 * @return lastLine : {@link String }
	 */
	public String getLastLine() {
		return this.lastLine;
	}

	/**
	 * This method is used to get property lastLineNumber of class {@link FileLastLineData
	 * }.
	 *
	 * @return lastLineNumber : {@link long }
	 */
	public long getLastLineNumber() {
		return this.lastLineNumber;
	}

}
