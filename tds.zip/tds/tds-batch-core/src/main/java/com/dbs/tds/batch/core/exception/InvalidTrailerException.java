package com.dbs.tds.batch.core.exception;

/**
 * This class is used as a user Defined exception, which can be thrown whenever there is
 * any exception during the application execution. The parent exception will be wrapped
 * onto it and the instance of this exception will be used for exception propagation.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public class InvalidTrailerException extends RuntimeException {

	/**
	 * This field is used to store value for serialVersionUID which is of type {@link long
	 * }.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * This constructor is used to initialize the exception instance with the provided
	 * message.
	 *
	 * @param message : {@link String}
	 */
	public InvalidTrailerException(String message) {
		super(message);
	}
}
