package com.dbs.tds.batch.core.util;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.RandomAccessFile;

/**
 * This class is used to provide Utiity functions for performing different functions on a
 * File.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public class FileUtil {

	/**
	 * Default constructor.
	 */
	private FileUtil() {
	}

	/**
	 * This static method is used to get the data present in the last line of the file.
	 *
	 * @param file : {@link File}
	 * @return {@link FileLastLineData}
	 */
	public static FileLastLineData getLastLineData(File file) {
		try (RandomAccessFile fileHandler = new RandomAccessFile(file, "r");
				LineNumberReader lineNumberReaderObj = new LineNumberReader(new FileReader(file));) {
			long fileLength = fileHandler.length() - 1;
			StringBuilder sb = new StringBuilder();

			for (long filePointer = fileLength; filePointer != -1; filePointer--) {
				fileHandler.seek(filePointer);
				int readByte = fileHandler.readByte();
				boolean skipAppend = false;
				long fileEndPointer = 0;

				if (readByte == 0xA) {
					skipAppend = true;
					fileEndPointer = fileLength;
				}
				else if (readByte == 0xD) {
					skipAppend = true;
					fileEndPointer = fileLength - 1;
				}

				if (skipAppend) {
					if (filePointer != fileEndPointer) {
						break;
					}
				}
				else {
					sb.append((char) readByte);
				}
			}

			String lastLine = sb.reverse().toString();
			long cursorPosition = fileHandler.getFilePointer();
			lineNumberReaderObj.skip(cursorPosition);
			int lastLineNumber = lineNumberReaderObj.getLineNumber() + 1;
			return new FileLastLineData(lastLine, lastLineNumber);
		}
		catch (IOException e) {
			return null;
		}
	}
}
