package com.dbs.tds.batch.core;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * This class is used as configuration and instance of Tasklet which will move the batch
 * file to error folder if the file validation fails.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@StepScope
@Component
public class MoveFilesToErrorFolderTasklet implements Tasklet {

	private static final Logger LOGGER = LoggerFactory.getLogger(MoveFilesToErrorFolderTasklet.class);

	/**
	 * This field is used to store value for fileAbsolutePath which is of type
	 * {@link String }.
	 */
	@Value("#{jobParameters['fileAbsolutePath']}")
	private String fileAbsolutePath;

	/**
	 * This field is used to store value for errorFolder which is of type {@link String }.
	 */
	@Value("${file.outbound.error.path}")
	String errorFolder;

	/**
	 * This method is used to execute the tasklet for moving the file to an error
	 * location. when the file validation is failed, then this tasklet is executed for
	 * moving the file to an error folder.
	 *
	 * @param contribution : {@link StepContribution}
	 * @param chunkContext : {@link ChunkContext}
	 * @return {@link RepeatStatus}
	 *
	 * @throws Exception
	 */
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		LOGGER.info("initiated moving files to error Folder errorFolder={}, errorPath={}", this.errorFolder,
				this.fileAbsolutePath);

		FileUtils.moveFileToDirectory(new File(this.fileAbsolutePath), new File(this.errorFolder), true);
		return RepeatStatus.FINISHED;
	}

}
