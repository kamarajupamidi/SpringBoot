package com.dbs.tds.batch.core.util;

/**
 * This class is used as POJO object to store the properties of a File.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public class FileInputData {

	/**
	 * This field is used to store value for absolutePath which is of type {@link String
	 * }.
	 */
	private String absolutePath;

	/**
	 * This field is used to store value for fileName which is of type {@link String }.
	 */
	private String fileName;

	/**
	 * This method is used to get property absolutePath of class {@link FileInputData }.
	 *
	 * @return absolutePath : {@link String }
	 */
	public String getAbsolutePath() {
		return this.absolutePath;
	}

	/**
	 * This method is used to set property absolutePath of class {@link FileInputData }.
	 *
	 * @param absolutePath : {@link String }
	 */
	public void setAbsolutePath(String absolutePath) {
		this.absolutePath = absolutePath;
	}

	/**
	 * This method is used to get property fileName of class {@link FileInputData }.
	 *
	 * @return fileName : {@link String }
	 */
	public String getFileName() {
		return this.fileName;
	}

	/**
	 * This method is used to set property fileName of class {@link FileInputData }.
	 *
	 * @param fileName : {@link String }
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "FileInputData [absolutePath=" + this.absolutePath + ", fileName=" + this.fileName + "]";
	}

}
