package com.dbs.tds.batch.core;

import java.io.File;

import com.dbs.tds.batch.core.exception.InvalidTrailerException;
import com.dbs.tds.batch.core.util.FileLastLineData;
import com.dbs.tds.batch.core.util.FileUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * This class is used as configuration and instance of Tasklet which will validate the
 * batch file for different validations.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@StepScope
@Component
public class FileValidatorTasklet implements Tasklet {

	private static final Logger LOGGER = LoggerFactory.getLogger(FileValidatorTasklet.class);

	/**
	 * This field is used to store value for fileAbsolutePath which is of type
	 * {@link String }.
	 */
	@Value("#{jobParameters['fileAbsolutePath']}")
	private String fileAbsolutePath;

	/**
	 * This method is used to execute the tasklet for file validation which will validate
	 * the file for Trailer validation as well as the no of record validation as it will
	 * be mentioned in Trailer.
	 *
	 * @param contribution : {@link StepContribution}
	 * @param chunkContext : {@link ChunkContext}
	 * @return {@link RepeatStatus}
	 *
	 * @throws Exception
	 */
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		FileLastLineData fileLastLineData = FileUtil.getLastLineData(new File(this.fileAbsolutePath));
		String lastLine = fileLastLineData.getLastLine();

		LOGGER.info("File validator details lastLine={}", lastLine);

		if (!lastLine.startsWith("T")) {
			LOGGER.error("File validation failed as lastLine={} does not start with T ", lastLine);
			throw new InvalidTrailerException("Invalid Trailer");
		}

		Long lineCountInTrailer;
		if (fileLastLineData.getLastLine().contains("|")) {
			lineCountInTrailer = Long.valueOf(fileLastLineData.getLastLine().substring(2));
		}
		else {
			lineCountInTrailer = Long.valueOf(fileLastLineData.getLastLine().substring(1));
		}

		Long actualLineCount = fileLastLineData.getLastLineNumber() - 2;

		LOGGER.info("File validator line count :: trailerCount={}, actualCount={}", lineCountInTrailer,
				actualLineCount);

		if (!(lineCountInTrailer.equals(actualLineCount) || lineCountInTrailer.equals(actualLineCount - 1))) {
			LOGGER.error(
					"File validator failed as line count is not matching line count :: trailerCount={}, actualCount={}",
					lineCountInTrailer, actualLineCount);

			throw new InvalidTrailerException("Invalid Trailer count");
		}
		return RepeatStatus.FINISHED;
	}

}
