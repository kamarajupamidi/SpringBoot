package com.dbs.tds.messageproducerstub.finacle.config;

import com.ibm.mq.jms.MQQueueConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.connection.JmsTransactionManager;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;
import org.springframework.jms.core.JmsOperations;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.support.converter.MarshallingMessageConverter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Profile({ "DEV", "SIT", "UAT" })
@Configuration
@EnableTransactionManagement
@SuppressWarnings("all")
public class JmsConfig {

	private static final Logger LOGGER = LoggerFactory.getLogger(JmsConfig.class);

	@Value("${tdsin.mq.host}")
	private String host;

	@Value("${tdsin.mq.port}")
	private Integer port;

	@Value("${tdsin.mq.queue-manager}")
	private String queueManager;

	@Value("${tdsin.mq.channel}")
	private String channel;

	@Value("${tdsin.mq.username}")
	private String username;

	@Value("${tdsin.mq.password}")
	private String password;

	@Value("${tdsin.mq.receive-timeout}")
	private long receiveTimeout;

	@Bean
	public MQQueueConnectionFactory mqQueueConnectionFactory() {
		MQQueueConnectionFactory mqQueueConnectionFactory = new MQQueueConnectionFactory();
		mqQueueConnectionFactory.setHostName(this.host);
		try {
			mqQueueConnectionFactory.setTransportType(1);
			mqQueueConnectionFactory.setCCSID(1208);
			mqQueueConnectionFactory.setChannel(this.channel);
			mqQueueConnectionFactory.setPort(this.port);
			mqQueueConnectionFactory.setQueueManager(this.queueManager);
		}
		catch (Exception e) {
			LOGGER.error("Error occured while creating connection factory", e);
		}
		return mqQueueConnectionFactory;
	}

	@Bean
	UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactoryAdapter(
			MQQueueConnectionFactory mqQueueConnectionFactory) {
		UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactoryAdapter = new UserCredentialsConnectionFactoryAdapter();
		userCredentialsConnectionFactoryAdapter.setUsername(this.username);
		userCredentialsConnectionFactoryAdapter.setPassword(this.password);
		userCredentialsConnectionFactoryAdapter.setTargetConnectionFactory(mqQueueConnectionFactory);
		return userCredentialsConnectionFactoryAdapter;
	}

	@Bean
	@Primary
	public CachingConnectionFactory cachingConnectionFactory(
			UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactoryAdapter) {
		CachingConnectionFactory cachingConnectionFactory = new CachingConnectionFactory();
		cachingConnectionFactory.setTargetConnectionFactory(userCredentialsConnectionFactoryAdapter);
		cachingConnectionFactory.setSessionCacheSize(500);
		cachingConnectionFactory.setReconnectOnException(true);
		return cachingConnectionFactory;
	}

	@Bean
	public PlatformTransactionManager jmsTransactionManager(CachingConnectionFactory cachingConnectionFactory) {
		JmsTransactionManager jmsTransactionManager = new JmsTransactionManager();
		jmsTransactionManager.setConnectionFactory(cachingConnectionFactory);
		return jmsTransactionManager;
	}

	@Bean
	public JmsOperations jmsOperations(CachingConnectionFactory cachingConnectionFactory,
			MarshallingMessageConverter messageConverter) {
		JmsTemplate jmsTemplate = new JmsTemplate(cachingConnectionFactory);
		jmsTemplate.setReceiveTimeout(this.receiveTimeout);
		jmsTemplate.setMessageConverter(messageConverter);
		return jmsTemplate;
	}
}
