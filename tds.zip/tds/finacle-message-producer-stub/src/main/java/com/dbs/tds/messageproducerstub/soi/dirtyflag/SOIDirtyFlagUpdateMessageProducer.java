/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: SOIDirtyFlagUpdateMessageProducer.java
 * Author: DBS Asia Hub 2
 * Date: Nov 20, 2017
 */
package com.dbs.tds.messageproducerstub.soi.dirtyflag;

import java.io.File;
import java.io.FileInputStream;

import javax.xml.transform.stream.StreamSource;

import com.dbs.schemas.digibank.dirtyflag.v1_0.DirtyFlagUpdate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.io.Resource;
import org.springframework.jms.core.JmsOperations;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.support.converter.MarshallingMessageConverter;
import org.springframework.jms.support.converter.MessageType;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

/**
 * This class is used for
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@SpringBootApplication
@ComponentScan("com.dbs.tds.messageproducerstub.finacle.config")
public class SOIDirtyFlagUpdateMessageProducer {

	/**
	 * This field is used to store value for jmsTemplate which is of type
	 * {@link JmsTemplate }.
	 */
	@Autowired
	private JmsOperations jmsOperationsForDirtyFlag;

	/**
	 * This method is used to start the spring boot container for this application.
	 *
	 * @param args : {@link String}[]
	 */
	public static void main(String[] args) {
		SpringApplication.run(SOIDirtyFlagUpdateMessageProducer.class, args);
	}

	/**
	 * This method is used to return the instance of Message Converter to convert the
	 * given XML String format to a Java Object.
	 *
	 * @return {@link MarshallingMessageConverter}
	 */
	@Bean
	public MarshallingMessageConverter converter(Jaxb2Marshaller marshallerForDirtyFlag) {
		MarshallingMessageConverter marshallingMessageConverterForDirtyFlag = new MarshallingMessageConverter(
				marshallerForDirtyFlag);
		marshallingMessageConverterForDirtyFlag.setTargetType(MessageType.TEXT);
		return marshallingMessageConverterForDirtyFlag;
	}

	/**
	 * This method is used to return the instance of JaxB Marshaler which will help to
	 * marshal the given XML in String format to Java Object with the help of predefined
	 * XML Schema.
	 *
	 * @param contextPathForDirtyFlag : {@link String}
	 * @param schemaResourceForDirtyFlag : {@link Resource}
	 * @return {@link Jaxb2Marshaller}
	 */
	@Bean
	public Jaxb2Marshaller marshaller(@Value("${dirtyflag.soi.context.path}") String contextPathForDirtyFlag,
			@Value("${dirtyflag.soi.schema.location}") Resource schemaResourceForDirtyFlag) {
		Jaxb2Marshaller jaxb2MarshallerForDirtyFlag = new Jaxb2Marshaller();
		jaxb2MarshallerForDirtyFlag.setContextPaths(contextPathForDirtyFlag);
		jaxb2MarshallerForDirtyFlag.setSchema(schemaResourceForDirtyFlag);
		return jaxb2MarshallerForDirtyFlag;
	}

	/**
	 * This method is used to fetch the XML Message and put it onto a Message Queue.
	 *
	 * @param destinationNameForDirtyFlag : {@link String}
	 * @param jaxb2MarshallerForDirtyFlag : {@link Jaxb2Marshaller}
	 * @return {@link CommandLineRunner}
	 */
	@Bean
	public CommandLineRunner start(
			@Value("${dirty.flag.outbound.destination}") String destinationNameForDirtyFlag,
			Jaxb2Marshaller jaxb2MarshallerForDirtyFlag) {
		return request -> {
			File file = new File("dirtyflag-sample.xml");
			DirtyFlagUpdate dirtyFlagUpdate = (DirtyFlagUpdate) jaxb2MarshallerForDirtyFlag
					.unmarshal(new StreamSource(new FileInputStream(file)));
			this.jmsOperationsForDirtyFlag.convertAndSend(destinationNameForDirtyFlag, dirtyFlagUpdate);
		};
	}

}
