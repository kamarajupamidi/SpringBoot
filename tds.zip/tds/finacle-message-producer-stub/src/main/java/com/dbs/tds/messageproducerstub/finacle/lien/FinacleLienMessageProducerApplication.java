package com.dbs.tds.messageproducerstub.finacle.lien;

import java.io.File;
import java.io.FileInputStream;

import javax.xml.transform.stream.StreamSource;

import com.finacle.fixml.liennotification.FIXML;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.io.Resource;
import org.springframework.jms.core.JmsOperations;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.support.converter.MarshallingMessageConverter;
import org.springframework.jms.support.converter.MessageType;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

/**
 * This class is used to create a message in XML format and put that message onto TDS
 * Finacle queue, so the queue listener could listen to the message and process it
 * accordingly.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 */
@SpringBootApplication
@ComponentScan("com.dbs.tds.messageproducerstub.finacle.config")
public class FinacleLienMessageProducerApplication {

	/**
	 * This field is used to store value for jmsTemplate which is of type
	 * {@link JmsTemplate }.
	 */
	@Autowired
	private JmsOperations jmsOperations;

	/**
	 * This method is used to start the spring boot container for this application.
	 *
	 * @param args : {@link String}[]
	 */
	public static void main(String[] args) {
		SpringApplication.run(FinacleLienMessageProducerApplication.class, args);
	}

	/**
	 * This method is used to return the instance of Message Converter to convert the
	 * given XML String format to a Java Object.
	 *
	 * @return {@link MarshallingMessageConverter}
	 */
	@Bean
	public MarshallingMessageConverter converter(Jaxb2Marshaller xmlMarshaller) {
		MarshallingMessageConverter converter = new MarshallingMessageConverter(xmlMarshaller);
		converter.setTargetType(MessageType.TEXT);
		return converter;
	}

	/**
	 * This method is used to return the instance of JaxB Marshaler which will help to
	 * marshal the given XML in String format to Java Object with the help of predefined
	 * XML Schema.
	 *
	 * @param contextPath : {@link String}
	 * @param schemaLocation : {@link Resource}
	 * @return {@link Jaxb2Marshaller}
	 */
	@Bean
	public Jaxb2Marshaller xmlMarshaller(@Value("${finacle.liennotification.context.path}") String contextPath,
			@Value("${finacle.liennotification.schema.location}") Resource schemaLocation) {
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setContextPaths(contextPath);
		jaxb2Marshaller.setSchema(schemaLocation);
		return jaxb2Marshaller;
	}

	/**
	 * This method is used to fetch the XML Message and put it onto a Message Queue.
	 *
	 * @param destination : {@link String}
	 * @param xmlMarshaller : {@link Jaxb2Marshaller}
	 * @return {@link CommandLineRunner}
	 */
	@Bean
	public CommandLineRunner start(@Value("${finacle.outbound.destination}") String destination,
			Jaxb2Marshaller xmlMarshaller) {
		return arg0 -> {
			File file = new File("finacle-lien-sample.xml");
			FIXML fixml = (FIXML) xmlMarshaller.unmarshal(new StreamSource(new FileInputStream(file)));
			FinacleLienMessageProducerApplication.this.jmsOperations.convertAndSend(destination, fixml);

		};
	}
}
