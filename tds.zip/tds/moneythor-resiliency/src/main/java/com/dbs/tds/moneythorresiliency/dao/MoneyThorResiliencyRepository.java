package com.dbs.tds.moneythorresiliency.dao;

import java.sql.Types;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import javax.sql.DataSource;

import com.dbs.schemas.digitalbank.cstmr_txn.v1_1.TXNHISTORY;
import com.dbs.tds.util.DateUtil;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

/**
 * This class is used to fetch transaction history details from TDS database.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Component
public class MoneyThorResiliencyRepository {
	/**
	 * This field is used to store value for jdbcTemplate which is of type
	 * {@link NamedParameterJdbcTemplate }.
	 */
	private NamedParameterJdbcTemplate jdbcTemplate;

	@Value("${digi.allowed.schema.codes}")
	private String[] allowedSchemaCodes;

	public MoneyThorResiliencyRepository(DataSource dataSource) {
		this.jdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

	/**
	 * This field is used to store value for transactionHistoryDetailssql which is of type
	 * {@link String }.
	 */
	private static final String TRANSACTION_HISTORY_DETAILS_SQL = "SELECT TXN.TRANKEY,TXN.TRANID,TXN.ACCTID,TXN.ACCTCURR,TXN.TRANDESC,"
			+ "TXN.LEDGERBAL,TXN.AVAILABLEBAL,TXN.RELATEDRECID,TXN.TRANSEQNUM,TXN.TRANDATE,TXN.VALUEDATE,TXN.POSTINGDATE,TXN.TRANCODE,"
			+ "TXN.AMOUNT,TXN.CURRENCY,TXN.TXNTYPE,TXN.RELATEDTRANREF,DIM.TRAN_CMMNT,TXN.EXT_TRANID,DIM.TRAN_CTGR "
			+ "FROM T_ACCT ACCT JOIN T_DTA_FACT TXN ON TXN.ACCTID = ACCT.ACCT_NO LEFT JOIN T_DTA_DIM DIM "
			+ "ON TXN.TRANKEY=DIM.TRANKEY WHERE TXN.EXT_TRANID IS NULL AND ACCT.ACCT_SCHM_CODE IN (:allowedSchemaCodes) AND TXN.LST_UPDT_DTTM < :lastUpdatedDate";

	/**
	 * This method is used to fetch Transaction History from TDS DB where EXT_TRANID is
	 * null until for a given time.
	 *
	 * @return {@link List}
	 */
	public List<TXNHISTORY> getHistoryTransactionsWithExtTranIDNull() {
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		Calendar currentDate = Calendar.getInstance();
		currentDate.add(Calendar.MINUTE, -5);
		paramSource.addValue("lastUpdatedDate", currentDate.getTime(), Types.TIMESTAMP);
		paramSource.addValue("allowedSchemaCodes", Arrays.asList(this.allowedSchemaCodes));
		return this.jdbcTemplate.query(TRANSACTION_HISTORY_DETAILS_SQL, paramSource,
				(resultSet, rowNum) -> {
					String tranSeqNum = resultSet.getString("TRANSEQNUM");
					TXNHISTORY txnHistory = new TXNHISTORY();
					txnHistory.setTRANKEY(resultSet.getString("TRANKEY"));
					txnHistory.setTRANID(resultSet.getString("TRANID"));
					txnHistory.setACCTID(resultSet.getString("ACCTID"));
					txnHistory.setACCTCURR(resultSet.getString("ACCTCURR"));
					txnHistory.setLEDGERBAL(resultSet.getFloat("LEDGERBAL"));
					txnHistory.setAVAILABLEBAL(resultSet.getFloat("AVAILABLEBAL"));
					txnHistory.setRELATEDRECID(resultSet.getString("RELATEDRECID"));
					txnHistory.setTRANSEQNUM(tranSeqNum);
					txnHistory.setTRANSSERIALNO(tranSeqNum);
					txnHistory.setTRANDATE(DateUtil.getXMLGregorianCalendarDateTime(resultSet.getDate("TRANDATE")));
					txnHistory.setVALUEDATE(DateUtil.getXMLGregorianCalendarDateTime(resultSet.getDate("VALUEDATE")));
					txnHistory
							.setPOSTINGDATE(DateUtil.getXMLGregorianCalendarDateTime(resultSet.getDate("POSTINGDATE")));
					txnHistory.setTRANCODE(resultSet.getString("TRANCODE"));
					txnHistory.setTRANDESC(resultSet.getString("TRANDESC"));
					txnHistory.setAMOUNT(resultSet.getFloat("AMOUNT"));
					txnHistory.setCURRENCY(resultSet.getString("CURRENCY"));
					txnHistory.setTXNTYPE(resultSet.getString("TXNTYPE"));
					txnHistory.setRELATEDTRANREF(resultSet.getString("RELATEDTRANREF"));
					txnHistory.setADDNLREF(resultSet.getString("TRAN_CMMNT"));
					txnHistory.setEXTTRANID(resultSet.getString("EXT_TRANID"));
					txnHistory.setTRANCATEGORY(resultSet.getString("TRAN_CTGR"));
					return txnHistory;
				});
	}

}
