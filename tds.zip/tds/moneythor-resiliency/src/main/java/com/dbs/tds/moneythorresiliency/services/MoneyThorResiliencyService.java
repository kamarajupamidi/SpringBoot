package com.dbs.tds.moneythorresiliency.services;

import java.util.List;

import javax.xml.bind.JAXBException;

import com.dbs.schemas.digitalbank.cstmr_txn.v1_1.CreateCustTxnHistory;
import com.dbs.schemas.digitalbank.cstmr_txn.v1_1.Identity;
import com.dbs.schemas.digitalbank.cstmr_txn.v1_1.TXNHISTORY;
import com.dbs.tds.constants.StatusCodes;
import com.dbs.tds.moneythorresiliency.dao.MoneyThorResiliencyRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import static com.dbs.tds.constants.AppConstants.STATUS_CODE_DES_KEY;
import static com.dbs.tds.constants.AppConstants.STATUS_CODE_KEY;
import static com.dbs.tds.constants.LoggingConstants.ERROR_TYPE;
import static com.dbs.tds.constants.LoggingConstants.FUNCTIONAL_MAP;

/**
 * This class is used to publish transaction history details into Money thor queue .
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Service
public class MoneyThorResiliencyService {

	private static final Logger LOGGER = LoggerFactory.getLogger(MoneyThorResiliencyService.class);

	@Autowired
	MoneyThorResiliencyRepository moneyThorResiliencyRepository;

	@Autowired
	private JmsTemplate jmsTemplate;

	@Value("${moneythor.resiliency.queue.destination}")
	private String moneythorinboundQueue;

	/**
	 * This method is used with injected moneyThorResiliencyRepository to set the instance
	 * of {@link MoneyThorResiliencyRepository}
	 *
	 * @param moneyThorResiliencyRepository : {@link MoneyThorResiliencyRepository}
	 * @param jmsTemplate : {@link JmsTemplate}
	 */
	public MoneyThorResiliencyService(MoneyThorResiliencyRepository moneyThorResiliencyRepository,
			JmsTemplate jmsTemplate) {
		this.moneyThorResiliencyRepository = moneyThorResiliencyRepository;
		this.jmsTemplate = jmsTemplate;
	}

	/**
	 * This method is used to fetch transaction history details and convert the them into
	 * XML using JAXB Marshaler. Publish the XML into queue for further processing.
	 * @throws JAXBException : {@link JAXBException}
	 */
	public void sendTransactionHistoryToMoneyThor() throws JAXBException {
		MDC.put(FUNCTIONAL_MAP.value(), "Retrieve_User_TransactionDetails");
		List<TXNHISTORY> txnHistoryList = this.moneyThorResiliencyRepository.getHistoryTransactionsWithExtTranIDNull();
		LOGGER.info("Sending {} records to queue", txnHistoryList.size());
		Identity identity = new Identity();
		identity.setSystemID("TdsReconSendTransaction");
		for (TXNHISTORY txnhistory : txnHistoryList) {
			LOGGER.info("Record without categorization with Trankey {} and relatedTranRef {}", txnhistory.getTRANKEY(),
					txnhistory.getRELATEDTRANREF());
			CreateCustTxnHistory createCustTxnHistory = new CreateCustTxnHistory();
			createCustTxnHistory.setIdentity(identity);
			createCustTxnHistory.setTXNHISTORY(txnhistory);
			publishXmlPayload(createCustTxnHistory);
		}
		MDC.put(STATUS_CODE_KEY.value(), StatusCodes.SUCCESS.value());
		MDC.put(STATUS_CODE_DES_KEY.value(), StatusCodes.SUCCESS.name());
		MDC.put(ERROR_TYPE.value(), "");
		LOGGER.info("Successfully sent {} records to queue", txnHistoryList.size());
	}

	/**
	 * Convert CreateCustTxnHistory object into XML using JAXB Marshaler. Publish the XML
	 * into queue for further processing.
	 * @throws JAXBException
	 */
	private void publishXmlPayload(CreateCustTxnHistory createCustTxnHistory) throws JAXBException {
		this.jmsTemplate.convertAndSend(this.moneythorinboundQueue, createCustTxnHistory);
	}

}
