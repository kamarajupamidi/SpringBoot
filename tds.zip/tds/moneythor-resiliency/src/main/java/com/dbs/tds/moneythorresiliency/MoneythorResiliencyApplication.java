package com.dbs.tds.moneythorresiliency;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * This class is used for initializing the Spring Boot Container which will make a
 * database call to fetch Transaction history records which has EXT_TRANID null and we
 * will be sending this list of transaction history to a message queue for further
 * processing by SOI/Money Thor
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@SpringBootApplication
public class MoneythorResiliencyApplication {

	/**
	 * This method is used by JVM to start the Spring Boot Container for starting the
	 * application
	 *
	 * @param args : {@link String}[]
	 */
	public static void main(String[] args) {
		SpringApplication.run(MoneythorResiliencyApplication.class, args);
	}

}
