package com.dbs.tds.moneythorresiliency;

import com.dbs.tds.moneythorresiliency.filter.LoggingFilter;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * This class is used as configuration for setting up the Filter which will intercept all
 * the incoming requests for filtering.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Configuration
public class WebApplicationConfig {

	/**
	 * This method is used to register the logging filter which will intercepts the
	 * incoming requests for filtering.
	 *
	 * @return {@link FilterRegistrationBean}
	 */
	@Bean
	public FilterRegistrationBean logFilterRegistrationBean() {
		FilterRegistrationBean logRegistrationBean = new FilterRegistrationBean();
		logRegistrationBean.setName("logger");
		LoggingFilter logFilter = new LoggingFilter();
		logRegistrationBean.setFilter(logFilter);
		return logRegistrationBean;
	}

}
