package com.dbs.tds.moneythorresiliency.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.jms.support.converter.MarshallingMessageConverter;
import org.springframework.jms.support.converter.MessageType;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

@Configuration
public class MoneythorResiliencyConfig {

	/**
	 * This method is used to return the instance of Message Converter to convert the
	 * given XML String format to a Java Object.
	 *
	 * @param marshaller : {@link Jaxb2Marshaller}
	 *
	 * @return {@link MarshallingMessageConverter}
	 */
	@Bean
	public MarshallingMessageConverter converter(Jaxb2Marshaller marshaller) {
		MarshallingMessageConverter converter = new MarshallingMessageConverter(marshaller);
		converter.setTargetType(MessageType.TEXT);
		return converter;
	}

	/**
	 * This method is used to return the instance of JaxB Marshaler which will help to
	 * marshal the given XML in String format to Java Object with the help of predefined
	 * XML Schema.
	 *
	 * @param contextPath : {@link String}
	 * @param schemaLocation : {@link Resource}
	 * @return {@link Jaxb2Marshaller}
	 */
	@Bean
	public Jaxb2Marshaller marshaller(@Value("${context.path}") String contextPath,
			@Value("${schema.location}") String schemaLocation) {
		Resource schemaResource = new ClassPathResource(schemaLocation);
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setContextPaths(contextPath);
		jaxb2Marshaller.setSchema(schemaResource);
		return jaxb2Marshaller;
	}

}
