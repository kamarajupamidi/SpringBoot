package com.dbs.tds.moneythorresiliency.controller;

import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import static org.springframework.http.HttpStatus.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dbs.tds.moneythorresiliency.services.MoneyThorResiliencyService;

/***
 * Controller to invoke Moneythor resiliency.
 *
 * @author sivanarayana
 *
 * @version 1.0
 */
@RestController
public class MoneyThorResiliencyController {

	private static final Logger LOGGER = LoggerFactory.getLogger(MoneyThorResiliencyController.class);
	
	@Autowired
	private MoneyThorResiliencyService moneyThorResiliencyService;
	
	@GetMapping("/invokeMoneyThorResiliency")
	public ResponseEntity<String> sendTransactionHistoryToMoneyThor() {
		ResponseEntity<String> responseEntity = null;
		try {
			moneyThorResiliencyService.sendTransactionHistoryToMoneyThor();
			responseEntity = new ResponseEntity<>("SUCCESS :: Sent Transaction history to MoneyThor", OK);
		} catch (JAXBException exp ) {
			responseEntity = new ResponseEntity<>("FAILED :: Not able to complete resiliency", BAD_REQUEST);
			LOGGER.error("Not able to complete resiliency due to :: {}", exp);
		}
		return responseEntity;
	}
}
