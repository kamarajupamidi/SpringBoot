package com.dbs.tds.moneythorresiliency.dao;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.dbs.tds.moneythorresiliency.MoneyThorResiliencyTestConfig;

/***
 * Integration test cases for {@link MoneyThorResiliencyRepository} methods.
 *
 * @author sivanarayana
 *
 * @version 1.0
 */

@RunWith(SpringRunner.class)
@TestPropertySource(locations = "classpath:application.properties")
@ContextConfiguration(classes = { MoneyThorResiliencyTestConfig.class })
public class MoneyThorResiliencyRepositoryTest {

	@Autowired
	private MoneyThorResiliencyRepository repo;

	@Test
	public void testGetHistoryTransactionsWithExtTranIDNull() {
		int result = repo.getHistoryTransactionsWithExtTranIDNull().size();
		Assert.assertTrue(2 == result);
	}

}
