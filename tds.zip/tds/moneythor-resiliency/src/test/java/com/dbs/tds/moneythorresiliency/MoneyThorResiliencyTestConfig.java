package com.dbs.tds.moneythorresiliency;

import java.net.URI;

import javax.jms.ConnectionFactory;
import javax.sql.DataSource;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.broker.BrokerService;
import org.apache.activemq.broker.TransportConnector;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.support.converter.MarshallingMessageConverter;

import com.dbs.tds.moneythorresiliency.config.MoneythorResiliencyConfig;

/***
 * Test Configuration for embedded DB and ActiveMQ
 *
 * @author sivanarayana
 *
 * @version 1.0
 */
@EnableJms
@Configuration
@ComponentScan({ "com.dbs.tds.moneythorresiliency.dao", "com.dbs.tds.moneythorresiliency.services" })
@Import(MoneythorResiliencyConfig.class)
public class MoneyThorResiliencyTestConfig {
	
	@Value("${mqbroker.url}")
	private String brokerUrl;
	
	@Bean
	public DataSource dataSource() {
		return new EmbeddedDatabaseBuilder()
				.addScripts("schema.sql", "data.sql")
				.setType(EmbeddedDatabaseType.H2).build();
	}
	
	@Bean
    public BrokerService createBrokerService() {
		try {
	        BrokerService broker = new BrokerService();
	        TransportConnector connector = new TransportConnector();
	        connector.setUri(new URI(brokerUrl));
	        broker.setPersistent(false);
	        broker.addConnector(connector);
	        return broker;
		}catch(Exception ex) {
			throw new BeanCreationException(ex.getMessage());
		}
    }
 
    @Bean
    public ActiveMQConnectionFactory connectionFactory(){
        ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory();
        connectionFactory.setBrokerURL(brokerUrl);
        connectionFactory.setTrustAllPackages(true);
        return connectionFactory;
    }
 
    @Bean
    public JmsTemplate jmsTemplate(ConnectionFactory connectionFactory, MarshallingMessageConverter converter){
        JmsTemplate template = new JmsTemplate();
        template.setConnectionFactory(connectionFactory);
        template.setMessageConverter(converter);
        return template;
    }

}
