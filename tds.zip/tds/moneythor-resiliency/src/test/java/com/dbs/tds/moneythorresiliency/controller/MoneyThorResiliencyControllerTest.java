package com.dbs.tds.moneythorresiliency.controller;

import javax.xml.bind.JAXBException;

import com.dbs.tds.moneythorresiliency.services.MoneyThorResiliencyService;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.Assert.fail;
import static org.mockito.Mockito.doThrow;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/***
 * Test case for Controller API's to invoke Moneythor resiliency.
 *
 * @author sivanarayana
 *
 * @version 1.0
 */
@RunWith(SpringRunner.class)
@WebMvcTest(MoneyThorResiliencyController.class)
public class MoneyThorResiliencyControllerTest {

	@Autowired
	private MockMvc mvc;

	@MockBean
	private MoneyThorResiliencyService moneyThorResiliencyService;

	@Test
	public void testSendTransactionHistoryToMoneyThor() {
		try {
			this.mvc.perform(get("/invokeMoneyThorResiliency")).andDo(print())
					.andExpect(status().isOk())
					.andExpect(content().string("SUCCESS :: Sent Transaction history to MoneyThor"));
		}
		catch (Exception ex) {
			fail(ex.getMessage());
		}
	}

	@Test
	public void testSendTransactionHistoryToMoneyThorNegative() {
		try {
			doThrow(JAXBException.class).when(this.moneyThorResiliencyService).sendTransactionHistoryToMoneyThor();
			this.mvc.perform(get("/invokeMoneyThorResiliency")).andDo(print())
					.andExpect(status().isBadRequest())
					.andExpect(content().string("FAILED :: Not able to complete resiliency"));
		}
		catch (Exception ex) {
			fail(ex.getMessage());
		}
	}

}
