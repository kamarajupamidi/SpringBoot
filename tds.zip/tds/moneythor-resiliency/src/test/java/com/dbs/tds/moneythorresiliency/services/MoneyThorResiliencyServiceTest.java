package com.dbs.tds.moneythorresiliency.services;

import javax.jms.Message;
import javax.xml.bind.JAXBException;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.dbs.tds.moneythorresiliency.MoneyThorResiliencyTestConfig;

/***
 * Integration test cases for {@link MoneyThorResiliencyService} methods.
 *
 * @author sivanarayana
 *
 * @version 1.0
 */
@Configuration
@RunWith(SpringRunner.class)
@TestPropertySource(locations = "classpath:application.properties")
@ContextConfiguration(classes = { MoneyThorResiliencyTestConfig.class})
public class MoneyThorResiliencyServiceTest {

	@Autowired
	private MoneyThorResiliencyService moneyThorResiliencyService;
	
	@Autowired
	private JmsTemplate jmsTemplate;
	
	@Test
	public void testSendTransactionHistoryToMoneyThor() throws JAXBException {
		moneyThorResiliencyService.sendTransactionHistoryToMoneyThor();
		Message publishedMsg = jmsTemplate.receive("dummy");
		Assert.assertNotNull("Message should not be null", publishedMsg);
	}
	

}
