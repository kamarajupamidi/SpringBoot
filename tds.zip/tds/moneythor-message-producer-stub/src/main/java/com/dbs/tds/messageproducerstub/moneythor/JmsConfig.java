package com.dbs.tds.messageproducerstub.moneythor;

import com.ibm.mq.jms.MQQueueConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.connection.JmsTransactionManager;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;
import org.springframework.jms.core.JmsOperations;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.jms.support.converter.SimpleMessageConverter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Profile({ "DEV", "SIT", "UAT" })
@Configuration
@EnableTransactionManagement
@SuppressWarnings("all")
public class JmsConfig {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(JmsConfig.class);

	/**
	 * This field is used to store value for hostForMoneyThorQueue which is of type
	 * {@link String }.
	 */
	@Value("${tdsin.mq.host}")
	private String hostForMoneyThorQueue;

	/**
	 * This field is used to store value for portForMoneyThorQueue which is of type
	 * {@link Integer }.
	 */
	@Value("${tdsin.mq.port}")
	private Integer portForMoneyThorQueue;

	/**
	 * This field is used to store value for queueManagerForMoneyThorQueue which is of
	 * type {@link String }.
	 */
	@Value("${tdsin.mq.queue-manager}")
	private String queueManagerForMoneyThorQueue;

	/**
	 * This field is used to store value for channelForMoneyThorQueue which is of type
	 * {@link String }.
	 */
	@Value("${tdsin.mq.channel}")
	private String channelForMoneyThorQueue;

	/**
	 * This field is used to store value for usernameForMoneyThorQueue which is of type
	 * {@link String }.
	 */
	@Value("${tdsin.mq.username}")
	private String usernameForMoneyThorQueue;

	/**
	 * This field is used to store value for passwordForMoneyThorQueue which is of type
	 * {@link String }.
	 */
	@Value("${tdsin.mq.password}")
	private String passwordForMoneyThorQueue;

	/**
	 * This field is used to store value for receiveTimeoutForMoneyThorQueue which is of
	 * type {@link long }.
	 */
	@Value("${tdsin.mq.receive-timeout}")
	private long receiveTimeoutForMoneyThorQueue;

	/**
	 * This method is used to return the instance of {@link MQQueueConnectionFactory}.
	 *
	 * @return {@link MQQueueConnectionFactory}
	 */
	@Bean
	public MQQueueConnectionFactory mqQueueConnectionFactoryForMoneyThor() {
		MQQueueConnectionFactory mqQueueConnectionFactoryForMoneyThor = new MQQueueConnectionFactory();
		mqQueueConnectionFactoryForMoneyThor.setHostName(this.hostForMoneyThorQueue);
		try {
			mqQueueConnectionFactoryForMoneyThor.setTransportType(1);
			mqQueueConnectionFactoryForMoneyThor.setCCSID(1208);
			mqQueueConnectionFactoryForMoneyThor.setChannel(this.channelForMoneyThorQueue);
			mqQueueConnectionFactoryForMoneyThor.setPort(this.portForMoneyThorQueue);
			mqQueueConnectionFactoryForMoneyThor.setQueueManager(this.queueManagerForMoneyThorQueue);
		}
		catch (Exception e) {
			LOGGER.error("Error occured while creating connection factory", e);
		}
		return mqQueueConnectionFactoryForMoneyThor;
	}

	/**
	 * This method is used to return the instance of
	 * {@link UserCredentialsConnectionFactoryAdapter}.
	 *
	 * @param mqQueueConnectionFactoryForMoneyThor : {@link MQQueueConnectionFactory}
	 * @return {@link UserCredentialsConnectionFactoryAdapter}
	 */
	@Bean
	UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactoryAdapterForMoneyThor(
			MQQueueConnectionFactory mqQueueConnectionFactoryForMoneyThor) {
		UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactoryAdapterForMoneyThor = new UserCredentialsConnectionFactoryAdapter();
		userCredentialsConnectionFactoryAdapterForMoneyThor.setUsername(this.usernameForMoneyThorQueue);
		userCredentialsConnectionFactoryAdapterForMoneyThor.setPassword(this.passwordForMoneyThorQueue);
		userCredentialsConnectionFactoryAdapterForMoneyThor
				.setTargetConnectionFactory(mqQueueConnectionFactoryForMoneyThor);
		return userCredentialsConnectionFactoryAdapterForMoneyThor;
	}

	/**
	 * This method is used to return the instance of {@link CachingConnectionFactory}.
	 *
	 * @param userCredentialsConnectionFactoryAdapterForMoneyThor :
	 * {@link UserCredentialsConnectionFactoryAdapter}
	 * @return {@link CachingConnectionFactory}
	 */
	@Bean
	@Primary
	public CachingConnectionFactory cachingConnectionFactoryForMoneyThor(
			UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactoryAdapterForMoneyThor) {
		CachingConnectionFactory cachingConnectionFactoryForMoneyThor = new CachingConnectionFactory();
		cachingConnectionFactoryForMoneyThor
				.setTargetConnectionFactory(userCredentialsConnectionFactoryAdapterForMoneyThor);
		cachingConnectionFactoryForMoneyThor.setSessionCacheSize(500);
		cachingConnectionFactoryForMoneyThor.setReconnectOnException(true);
		return cachingConnectionFactoryForMoneyThor;
	}

	/**
	 * This method is used to return the instance of {@link PlatformTransactionManager}
	 * 
	 * @param cachingConnectionFactoryForMoneyThor : {@link CachingConnectionFactory}
	 * @return {@link PlatformTransactionManager}
	 */
	@Bean
	public PlatformTransactionManager jmsTransactionManagerForMoneyThor(
			CachingConnectionFactory cachingConnectionFactoryForMoneyThor) {
		JmsTransactionManager jmsTransactionManagerForMoneyThor = new JmsTransactionManager();
		jmsTransactionManagerForMoneyThor.setConnectionFactory(cachingConnectionFactoryForMoneyThor);
		return jmsTransactionManagerForMoneyThor;
	}

	/**
	 * This method is used to return the instance of {@link JmsOperations}.
	 *
	 * @param cachingConnectionFactoryForMoneyThor : {@link CachingConnectionFactory}
	 * @param messageConverterForMoneyThor : {@link MessageConverter}
	 * @return {@link JmsOperations}
	 */
	@Bean
	public JmsOperations jmsOperationsForMoneyThor(CachingConnectionFactory cachingConnectionFactoryForMoneyThor,
			MessageConverter messageConverterForMoneyThor) {
		JmsTemplate jmsTemplateForMoneyThor = new JmsTemplate(cachingConnectionFactoryForMoneyThor);
		jmsTemplateForMoneyThor.setReceiveTimeout(this.receiveTimeoutForMoneyThorQueue);
		jmsTemplateForMoneyThor.setMessageConverter(messageConverterForMoneyThor);
		return jmsTemplateForMoneyThor;
	}

	/**
	 * This method is used to return the message converter.
	 *
	 * @return {@link MessageConverter}
	 */
	@Bean
	public MessageConverter messageConverterForMoneyThor() {
		return new SimpleMessageConverter();
	}
}
