/**
 * This file is property of DBS Bank Pvt Ltd.
 *
 * File Name: MTMessageProducerApplication.java
 * Author: DBS Asia Hub 2
 * Date: Aug 18, 2017
 */
package com.dbs.tds.messageproducerstub.moneythor;

import java.io.File;

import com.dbs.moneythor.dto.MoneyThorTxnEnrichmentResponse;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessagePostProcessor;

/**
 * This class is used to create a message in JSON format and put that message onto TDS
 * Money Thor queue, so the queue listener could listen to the message and process it
 * accordingly.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 */
@SpringBootApplication
public class MTMessageProducerApplication {

	/**
	 * This field is used to store value for jmsTemplate which is of type
	 * {@link JmsTemplate }.
	 */
	@Autowired
	private JmsTemplate jmsTemplate;

	/**
	 * This method is used to start the spring boot container for this application.
	 *
	 * @param args : {@link String}[]
	 */
	public static void main(String[] args) {
		SpringApplication.run(MTMessageProducerApplication.class, args);
	}

	/**
	 * This method is used to return the instance of Object mapper to map the given JSON
	 * String format to a Java Object.
	 *
	 * @return {@link ObjectMapper}
	 */
	@Bean
	public ObjectMapper objectMapper() {
		return new ObjectMapper();
	}

	/**
	 * This method is used to fetch the json Message and put it onto a Message Queue.
	 *
	 * @param destinationName : {@link String}
	 * @param objectMapper : {@link ObjectMapper}
	 * @return {@link CommandLineRunner}
	 */
	@Bean
	public CommandLineRunner start(@Value("${moneythor.outbound.destination}") String destinationName,
			@Value("${moneythor.trankey}") String trankey,
			ObjectMapper objectMapper) {
		return arg0 -> {
			File file = new File("moneythor-sample.json");
			MoneyThorTxnEnrichmentResponse moneyThorTxnEnrichmentResponse = objectMapper
					.readValue(file,
							MoneyThorTxnEnrichmentResponse.class);
			String message = objectMapper.writeValueAsString(moneyThorTxnEnrichmentResponse);
			MTMessageProducerApplication.this.jmsTemplate.convertAndSend(destinationName, message,
					(MessagePostProcessor) message1 -> {
						message1.setStringProperty("TRANKEY", trankey);
						return message1;
					});
		};
	}

}
