package com.dbs.tds.account.finacle.batch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 
 * This class is used for launching Account Batch application for capturing account
 * notifications
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@SpringBootApplication
public class AccountHistoryFinacleBatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountHistoryFinacleBatchApplication.class, args);
	}

}
