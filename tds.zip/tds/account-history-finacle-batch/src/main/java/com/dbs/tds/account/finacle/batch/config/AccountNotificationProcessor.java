package com.dbs.tds.account.finacle.batch.config;

import com.dbs.tds.dto.AccountNotification;
import com.dbs.tds.dto.CodeTypes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/***
 *
 * This class is used for processing and skipping account notification whose scheme codes
 * are not existing in TDS.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Component
public class AccountNotificationProcessor implements ItemProcessor<AccountNotification, AccountNotification> {

	private static final Logger LOGGER = LoggerFactory.getLogger(AccountNotificationProcessor.class);

	@Autowired
	private CodeTypes codeTypes;

	@Override
	public AccountNotification process(AccountNotification item) throws Exception {

		LOGGER.info("Processing account number={}, schemacode={}, accountType={}", item.getAccountNumber(),
				item.getAccountSchemaCode(), item.getAccountType());
		if (this.codeTypes.getSchemeCodes().get(item.getAccountSchemaCode()) != null) {

			item.setAccountType(this.codeTypes.getProdtypes().get(item.getAccountType()));

			LOGGER.info("Processing account number={}, schemacode={}, accountType={} is valid schemacode",
					item.getAccountNumber(), item.getAccountSchemaCode(), item.getAccountType());

			return item;
		}
		else {
			LOGGER.info(
					"Processing account number={}, schemacode={}, accountType={} Invalid schemacode, hence skipping",
					item.getAccountNumber(), item.getAccountSchemaCode(), item.getAccountType());

			return null;
		}
	}

}
