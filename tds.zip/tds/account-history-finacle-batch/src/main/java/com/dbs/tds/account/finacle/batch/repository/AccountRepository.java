package com.dbs.tds.account.finacle.batch.repository;

import java.util.List;

import com.dbs.tds.dto.AccountNotification;

import org.springframework.stereotype.Repository;

@Repository
public interface AccountRepository {

	/**
	 *
	 * This method is used to update account details
	 * @param accountNotifications : {@link List}
	 */
	void updateAccountDetails(List<? extends AccountNotification> accountNotifications);
}
