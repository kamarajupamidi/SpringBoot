package com.dbs.tds.account.finacle.batch.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import com.dbs.tds.dto.AccountNotification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class AccountRepositoryImpl implements AccountRepository {

	private static final String ACCOUNT_BATCH = "ACCOUNT_BATCH";

	private static final String N = "N";

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(AccountRepositoryImpl.class);

	private static final String AVBLCRNCY = "AVBLCRNCY";

	private static final String LDGRCRNCY = "LDGRCRNCY";

	private static final String LST_UPDT_DTTM = "LST_UPDT_DTTM";

	private static final String LST_UPDT_SYS_ID = "LST_UPDT_SYS_ID";

	private static final String ACCTYPE = "ACCTYPE";

	private static final String SCHMCODE = "SCHMCODE";

	private static final String BALSYNC = "BALSYNC";

	private static final String MSG_DATE = "messageDate";

	private static final String AVAILABLEBAL = "AVAILABLEBAL";

	private static final String LEDGERBAL = "LEDGERBAL";

	private static final String ACCTID = "ACCTID";

	private static final String ACCT_NAME = "ACCT_NAME";

	/**
	 * This field is used to store value for accountUpdateJdbcTemplate which is of type
	 * {@link NamedParameterJdbcTemplate }.
	 */
	private NamedParameterJdbcTemplate accountUpdateJdbcTemplate;

	/**
	 * This field is used to store value for accountUpdateSQL which is of type
	 * {@link String }.
	 */
	private String accountUpdateSQL;

	/**
	 * This constructor is used with injected {@link DataSource} instance to setup the
	 * named parameterized Query in {@link String} type, for update Balances operation and
	 * setup the {@link NamedParameterJdbcTemplate} instance for updating account details.
	 *
	 * @param dataSource : {@link DataSource}
	 */
	public AccountRepositoryImpl(DataSource dataSource) {
		this.accountUpdateJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
		this.accountUpdateSQL = new StringBuilder(
				"Insert into T_ACCT(ACCT_NO, ACCT_TYP, ACCT_AVLBL_BAL, ACCT_SCHM_CODE, ACCT_LDGR_BAL, IS_BAL_SYNC,")
						.append("ACCT_LDGR_CRRNCY, ACCT_AVALBL_CRRNCY, BAL_ASOFDATETIME, ACCT_NAME, LST_UPDT_SYS_ID, LST_UPDT_DTTM, VENDR_LST_UPDT_DTTM)  values ")
						.append(" ( :ACCTID, :ACCTYPE, :AVAILABLEBAL, :SCHMCODE, :LEDGERBAL , :BALSYNC ,:LDGRCRNCY, :AVBLCRNCY, null , :ACCT_NAME, :LST_UPDT_SYS_ID, :LST_UPDT_DTTM, :messageDate)")
						.append(" ON DUPLICATE KEY UPDATE ")
						.append(" ACCT_SCHM_CODE = CASE WHEN VENDR_LST_UPDT_DTTM is null OR VENDR_LST_UPDT_DTTM <= :messageDate THEN :SCHMCODE ELSE ACCT_SCHM_CODE END,")
						.append(" VENDR_LST_UPDT_DTTM = CASE WHEN VENDR_LST_UPDT_DTTM is null OR VENDR_LST_UPDT_DTTM <= :messageDate THEN  :messageDate ELSE VENDR_LST_UPDT_DTTM END,")
						.append(" LST_UPDT_SYS_ID = :LST_UPDT_SYS_ID, LST_UPDT_DTTM = :LST_UPDT_DTTM ")
						.toString();
	}

	/**
	 * This method is used to update account details, coming from Finacle batch processing
	 * Event Queue Notification, into TDS DB.
	 * @param accountNotification : {@link List}
	 */
	@Override
	@Transactional
	public void updateAccountDetails(List<? extends AccountNotification> accountNotification) {
		LOGGER.info("Initated batch update events to DB.");

		List<MapSqlParameterSource> mapSqlParameterSources = buildMapSqlParameterSources(accountNotification);
		this.accountUpdateJdbcTemplate.batchUpdate(this.accountUpdateSQL,
				mapSqlParameterSources.toArray(new MapSqlParameterSource[mapSqlParameterSources.size()]));
		LOGGER.info("Completed batch update events to DB.");
	}

	/***
	 * This method is used to build {@List}<{MapSqlParameterSource} using
	 * {@List}<{TransactionNotification}
	 * @param {@List}<{@TransactionNotification}>
	 * @return {@List}<{MapSqlParameterSource}>
	 */
	private List<MapSqlParameterSource> buildMapSqlParameterSources(
			List<? extends AccountNotification> accountNotifications) {

		List<MapSqlParameterSource> mapSqlParameterSources = new ArrayList<>();
		for (AccountNotification accountNtfn : accountNotifications) {

			MapSqlParameterSource parameterSource = new MapSqlParameterSource();
			parameterSource.addValue(ACCTID, accountNtfn.getAccountNumber())
					.addValue(LEDGERBAL, accountNtfn.getAccountLedgerBalance())
					.addValue(AVAILABLEBAL, accountNtfn.getAccountAvailableBalance())
					.addValue(MSG_DATE, accountNtfn.getRecordGenerationTime())
					.addValue(BALSYNC, N)
					.addValue(SCHMCODE, accountNtfn.getAccountSchemaCode())
					.addValue(ACCTYPE, accountNtfn.getAccountType())
					.addValue(LDGRCRNCY, accountNtfn.getAccountLedgerCurrency())
					.addValue(AVBLCRNCY, accountNtfn.getAccountAvailableCurrency())
					.addValue(ACCT_NAME, accountNtfn.getAccountName())
					.addValue(LST_UPDT_SYS_ID, ACCOUNT_BATCH)
					.addValue(LST_UPDT_DTTM, new Date());
			mapSqlParameterSources.add(parameterSource);

		}

		return mapSqlParameterSources;
	}

}
