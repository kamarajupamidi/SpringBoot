package com.dbs.tds.account.finacle.batch.controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

import com.dbs.tds.batch.core.util.FileInputData;
import com.dbs.tds.constants.ErrorConstants;
import com.dbs.tds.constants.StatusCodes;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.MessageChannel;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import static com.dbs.tds.constants.AppConstants.STATUS_CODE_DES_KEY;
import static com.dbs.tds.constants.AppConstants.STATUS_CODE_KEY;
import static com.dbs.tds.constants.LoggingConstants.ERROR_TYPE;
import static com.dbs.tds.constants.LoggingConstants.FUNCTIONAL_MAP;

/**
 * This class is used as Controller for Rest Message which will trigger the batch job for
 * processing the batch file which is coming from Finacle.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@RestController
public class FinacleAccountNotificationBatchJobController {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(FinacleAccountNotificationBatchJobController.class);

	/**
	 * This field is used to store value for accountBatchFileInputChannel which is of type
	 * {@link MessageChannel }.
	 */
	private MessageChannel accountBatchFileInputChannel;

	@Value("${file.inbound.import.path}")
	private String filePath;

	/**
	 * This constructor is used to setup the accountBatchFileInputChannel with the
	 * injected instance.
	 *
	 * @param accountBatchFileInputChannel : {@link MessageChannel}
	 */
	public FinacleAccountNotificationBatchJobController(MessageChannel accountBatchFileInputChannel) {
		this.accountBatchFileInputChannel = accountBatchFileInputChannel;
	}

	/**
	 * This method is used to trigger the batch job on the annotated RequestMapping URL
	 * which will check for the batch file which is present on the path which can be
	 * extracted from the provided instance.
	 *
	 * @param multiPartfile : {@link MultipartFile}
	 * @return {@link String}
	 *
	 */
	@PostMapping(value = "/invokeFinacleAccountNotificationBatchJob")
	public String invokeFinacleAccountNotificationBatchJob(@RequestParam("file") MultipartFile multiPartfile) {

		Assert.notNull(multiPartfile.getOriginalFilename(), "File name cannot be null");
		MDC.put(FUNCTIONAL_MAP.value(), "Invoke_FinacleAccountNotificationBatchJob");

		LOGGER.info("Finacle Account Batch Job initiated with inputs : fileName={}",
				multiPartfile.getOriginalFilename());

		FileInputData accountBatchFileInputData = new FileInputData();

		if (!multiPartfile.isEmpty()) {
			try (BufferedInputStream stream = new BufferedInputStream(multiPartfile.getInputStream())) {
				File outputFile = new File(this.filePath + multiPartfile.getOriginalFilename());
				Files.copy(stream, outputFile.toPath(), StandardCopyOption.REPLACE_EXISTING);

				IOUtils.closeQuietly(stream);

				accountBatchFileInputData.setAbsolutePath(this.filePath + multiPartfile.getOriginalFilename());
				accountBatchFileInputData.setFileName(multiPartfile.getOriginalFilename());

				this.accountBatchFileInputChannel.send(MessageBuilder.withPayload(
						accountBatchFileInputData).build());

				MDC.put(STATUS_CODE_KEY.value(), StatusCodes.SUCCESS.value());
				MDC.put(STATUS_CODE_DES_KEY.value(), StatusCodes.SUCCESS.name());
				MDC.put(ERROR_TYPE.value(), "");

				LOGGER.info("Finacle Account Batch Job invoked with inputs : fileName={}, filePath={}",
						accountBatchFileInputData.getFileName(),
						accountBatchFileInputData.getAbsolutePath());

				return "INVOKED_ACCOUNT_NOTIFICATION";
			}
			catch (Exception exception) {
				MDC.put(STATUS_CODE_KEY.value(), StatusCodes.FAILURE.value());
				MDC.put(STATUS_CODE_DES_KEY.value(), StatusCodes.FAILURE.name());
				MDC.put(ERROR_TYPE.value(), ErrorConstants.TECH.name());
				LOGGER.error(
						"Failed to invoke Finacle Account Batch Job with inputs : fileName={}, filePath={}, errMsg={}",
						accountBatchFileInputData.getFileName(),
						accountBatchFileInputData.getAbsolutePath(), exception.getMessage());
				return "INVOKE_FAILED_TO_UPLOAD";
			}
		}
		else {
			MDC.put(STATUS_CODE_KEY.value(), StatusCodes.FAILURE.value());
			MDC.put(STATUS_CODE_DES_KEY.value(), StatusCodes.FAILURE.name());
			MDC.put(ERROR_TYPE.value(), ErrorConstants.TECH.name());
			LOGGER.error(
					"Failed to invoke Finacle Account Batch Job with inputs : fileName={}, filePath={}, errMsg={}",
					accountBatchFileInputData.getFileName(),
					accountBatchFileInputData.getAbsolutePath(), "Multipart form data expected.");
			return "INVOKE_FAILED_AS_FILE_IS_EMPTY";
		}
	}

}
