package com.dbs.tds.account.finacle.batch.config;

import com.dbs.tds.dto.AccountNotification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.core.annotation.OnReadError;
import org.springframework.batch.core.annotation.OnSkipInWrite;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.file.FileHeaders;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.MessageChannel;
import org.springframework.stereotype.Component;

/**
 * This class is used as configuration and instance for chunk processing of the batch
 * file, which is coming from Finacle. Records will be read and processed in chunks and
 * only after one chunk is processed then the control moves to next chunk. If the error
 * occurs while processing then that chunk is skipped and control moves to next chunk.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 */
@StepScope
@Component
public class AccountNotificationChunkListener {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(AccountNotificationChunkListener.class);

	/**
	 * This field is used to store value for filePath which is of type {@link String }.
	 */
	@Value("#{jobParameters['fileName']}")
	private String filePath;

	/**
	 * This field is used to store value for fileParseErrorChannel which is of type
	 * {@link MessageChannel }.
	 */
	private MessageChannel accountBatchFileParseErrorChannel;

	/**
	 * This constructor is used with injected instance of {@link MessageChannel} which
	 * will be used to receive the message when there is any error during the processing
	 * of the batch file chunk.
	 *
	 * @param accountBatchFileParseErrorChannel : {@link MessageChannel}
	 */
	public AccountNotificationChunkListener(MessageChannel accountBatchFileParseErrorChannel) {
		this.accountBatchFileParseErrorChannel = accountBatchFileParseErrorChannel;
	}

	/**
	 * This method will be executed whenever any specific chunk is skipped due to any
	 * error during the processing of the chunk. Skipped chunk will be written in the
	 * logs.
	 *
	 * @param exception : {@link Exception}
	 */
	@OnReadError
	public void onReadError(Exception exception) {
		if (exception instanceof FlatFileParseException) {
			FlatFileParseException ffpe = (FlatFileParseException) exception;

			LOGGER.error("Error reading data on filePath={}, line={}, data={}", this.filePath, ffpe.getLineNumber(),
					ffpe.getInput());

			this.accountBatchFileParseErrorChannel.send(
					MessageBuilder.withPayload(ffpe.getInput()).setHeader(FileHeaders.FILENAME, this.filePath).build());
		}
	}

	/**
	 *
	 * This method will be executed whenever any specific chunk is skipped due to any
	 * error during the processing of the chunk. Skipped chunk will be written in the
	 * logs.
	 * @param accountNotification : {@link AccountNotification}
	 * @param throwable : {@link Throwable}
	 */
	@OnSkipInWrite
	public void onSkipInWrite(AccountNotification accountNotification, Throwable throwable) {
		LOGGER.error("Error writing account data, data={}  error={}", accountNotification.getInputLine(), throwable);
		this.accountBatchFileParseErrorChannel.send(
				MessageBuilder.withPayload(accountNotification.getInputLine())
						.setHeader(FileHeaders.FILENAME, this.filePath).build());
	}
}
