package com.dbs.tds.account.finacle.batch.config;

import com.dbs.tds.batch.core.util.FileInputData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.integration.launch.JobLaunchRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.annotation.Transformer;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

/**
 * This class is used to transform the incoming request for batch trigger.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 */
@Component
public class FileMessageToAccountNotificationJobRequestTransformer {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(FileMessageToAccountNotificationJobRequestTransformer.class);

	/**
	 * This field is used to store value for accountNotificationBatchJob which is of type
	 * {@link Job }.
	 */
	private Job accountNotificationBatchJob;

	/**
	 * This field is used to store value for accountBatchFileName which is of type
	 * {@link String }.
	 */
	@Value("${file.parameter.name}")
	private String accountBatchFileName;

	/**
	 * This field is used to store value for accountBatchFileAbsolutePath which is of type
	 * {@link String }.
	 */
	@Value("${file.parameter.absolutepath}")
	private String accountBatchFileAbsolutePath;

	/**
	 * This constructor is used with injected {@link Job} instance to setup the batch
	 * accountNotificationBatchJob which will process the batch file.
	 *
	 * @param accountNotificationBatchJob {@link Job}
	 */
	public FileMessageToAccountNotificationJobRequestTransformer(Job accountNotificationBatchJob) {
		this.accountNotificationBatchJob = accountNotificationBatchJob;
	}

	/**
	 * This method is used to transform the incoming message into the request for job.
	 * This job launch request will launch the batch job for processing of the batch file.
	 *
	 * @param message : {@link Message}
	 * @return {@link JobLaunchRequest}
	 */
	@Transformer
	public JobLaunchRequest toAccountBatchJobRequest(Message<FileInputData> message) {
		JobParametersBuilder jobParametersBuilder = new JobParametersBuilder();
		jobParametersBuilder.addString(this.accountBatchFileAbsolutePath, message.getPayload().getAbsolutePath());
		jobParametersBuilder.addString(this.accountBatchFileName, message.getPayload().getFileName());

		LOGGER.info("Job parameters to launch the job accountBatchFileAbsolutePath={},accountBatchFileName={}",
				message.getPayload().getAbsolutePath(), message.getPayload().getFileName());

		return new JobLaunchRequest(this.accountNotificationBatchJob, jobParametersBuilder.toJobParameters());
	}
}
