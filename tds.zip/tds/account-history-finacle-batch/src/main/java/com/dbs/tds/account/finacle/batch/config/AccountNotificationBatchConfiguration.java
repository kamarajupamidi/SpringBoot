package com.dbs.tds.account.finacle.batch.config;

import java.io.StringReader;

import javax.xml.bind.JAXB;

import com.dbs.tds.batch.core.FileValidatorTasklet;
import com.dbs.tds.batch.core.MoveFilesToErrorFolderTasklet;
import com.dbs.tds.batch.core.MoveFilesToProcessedFolderTasklet;
import com.dbs.tds.config.CoreConfiguration;
import com.dbs.tds.dto.AccountNotification;
import com.finacle.fixml.account.AcctGenInfo;
import com.finacle.fixml.account.AcctId;
import com.finacle.fixml.account.FIXML;
import com.finacle.fixml.account.SBAcctInqReqCustomDataType;
import com.finacle.fixml.account.SBAcctInqRequest;
import com.finacle.fixml.account.SBAcctInqRq;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;

/**
 * This class is used as the configuration class which configure the behavior and working
 * of the Batch Job which will read a batch file coming from Finacle and process the file
 * accordingly and insert/update the details in TDS DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Configuration
@EnableBatchProcessing
@Import(CoreConfiguration.class)
public class AccountNotificationBatchConfiguration {

	/**
	 * This field is used to store instance of type {@link JobBuilderFactory }.
	 */
	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	/**
	 * This field is used to store instance of type {@link StepBuilderFactory }.
	 */
	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	/**
	 * This method is used to provide the configuration of the job instance, it will take
	 * different steps as the parameters which will be used to setup a job. This job will
	 * check for the file validation, validated file will be processed so that the records
	 * present in the file will be inserted into TDS DB and invalid file will be moved to
	 * an error location. After successful processing, file will be moved to processed
	 * folder.
	 *
	 * @param accountBatchFileValidatorStep : {@link Step}
	 * @param accountBatchFileToDatabaseStep : {@link Step}
	 * @param moveAccountBatchFilesToErroFolderStep : {@link Step}
	 * @param moveAccountBatchFilesToProcessedFolderStep : {@link Step}
	 * @return {@link Job}
	 */
	@Bean
	public Job job(Step accountBatchFileValidatorStep, Step accountBatchFileToDatabaseStep,
			Step moveAccountBatchFilesToErroFolderStep,
			Step moveAccountBatchFilesToProcessedFolderStep) {
		return this.jobBuilderFactory.get("finacleAccountNtfn").incrementer(new RunIdIncrementer())
				.start(accountBatchFileValidatorStep)
				.on(ExitStatus.FAILED.getExitCode())
				.to(moveAccountBatchFilesToErroFolderStep)
				.from(accountBatchFileValidatorStep)
				.on(ExitStatus.COMPLETED.getExitCode())
				.to(accountBatchFileToDatabaseStep)
				.on(ExitStatus.COMPLETED.getExitCode())
				.to(moveAccountBatchFilesToProcessedFolderStep)
				.end()
				.build();
	}

	/**
	 * This method is used to provide configuration for the step, which will be used to
	 * process the file and move the records to Database for TDS DB interaction. File will
	 * be read in chunks by an {@link ItemReader} instance and valid file is sent to
	 * writer for writing the content in TDS DB.
	 *
	 * @param itemReader : {@link ItemReader}
	 * @param itemProcessor : {@link AccountNotificationProcessor}
	 * @param accountNotificationWriter : {@link AccountNotificationWriter}
	 * @param chunkListener : {@link AccountNotificationChunkListener}
	 * @return {@link Step}
	 */
	@Bean
	public Step accountBatchFileToDatabaseStep(ItemReader<AccountNotification> itemReader,
			AccountNotificationProcessor itemProcessor,
			AccountNotificationWriter accountNotificationWriter,
			AccountNotificationChunkListener chunkListener) {
		return this.stepBuilderFactory.get("account-file-db-conversion")
				.<AccountNotification, AccountNotification>chunk(100)
				.reader(itemReader)
				.processor(itemProcessor)
				.writer(accountNotificationWriter)
				.faultTolerant()
				.skip(FlatFileParseException.class)
				.skip(Exception.class)
				.skipLimit(Integer.MAX_VALUE)
				.listener(chunkListener)
				.build();
	}

	/**
	 * This method is used to configure the step for File Validation with the help of a
	 * {@link FileValidatorTasklet} instance. File will be validated for valid header and
	 * valid footer.
	 *
	 * @param fileValidatorTasklet : {@link FileValidatorTasklet}
	 * @return {@link Step}
	 */
	@Bean
	public Step accountBatchFileValidatorStep(FileValidatorTasklet fileValidatorTasklet) {
		return this.stepBuilderFactory.get("account-file-validate").tasklet(fileValidatorTasklet).build();
	}

	/**
	 * This method is used to configure the step for moving the file to Error folder with
	 * the help of a {@link MoveFilesToErrorFolderTasklet} instance. If the file is
	 * invalid then the file is moved to an error folder.
	 *
	 * @param moveFilesToErroFolderTasklet : {@link MoveFilesToErrorFolderTasklet}
	 * @return {@link Step}
	 */
	@Bean
	public Step moveAccountBatchFilesToErroFolderStep(MoveFilesToErrorFolderTasklet moveFilesToErroFolderTasklet) {
		return this.stepBuilderFactory.get("move-account-file-error").tasklet(moveFilesToErroFolderTasklet).build();
	}

	/**
	 * This method is used to configure the step for moving the file to processed folder
	 * with the help of a {@link MoveFilesToProcessedFolderTasklet} instance. If the file
	 * is valid and it is processed successfully then the file is moved to a processed
	 * folder.
	 *
	 * @param filesToProcessedFolderTasklet : {@link MoveFilesToProcessedFolderTasklet}
	 * @return {@link Step}
	 */
	@Bean
	public Step moveAccountBatchFilesToProcessedFolderStep(
			MoveFilesToProcessedFolderTasklet filesToProcessedFolderTasklet) {
		return this.stepBuilderFactory.get("move-file-processed").tasklet(filesToProcessedFolderTasklet).build();
	}

	/**
	 *
	 * This method is used to define step reader definition as FlatFileItemReader with
	 * filename and line mapper definition.
	 *
	 * @param fileName : {@link Resource}
	 * @return {@link FlatFileItemReader}
	 */
	@Bean
	@StepScope
	public FlatFileItemReader<AccountNotification> reader(
			@Value("file:#{jobParameters['fileAbsolutePath']}") Resource fileName) {
		FlatFileItemReader<AccountNotification> itemReader = new FlatFileItemReader<>();
		itemReader.setName("account-file-reader");
		itemReader.setLineMapper(lineMapper());
		itemReader.setResource(fileName);
		itemReader.setLinesToSkip(1);
		return itemReader;
	}

	/**
	 *
	 * This method is used to define line mapper and used to convert given line input to
	 * {@link AccountNotification} object. it has two step process first it converts the
	 * given text XML to {@link FIXML} object and then we are converting to
	 * AccountNotification using transformer.
	 *
	 * @return {@link LineMapper}
	 */
	@Bean
	public LineMapper<AccountNotification> lineMapper() {
		return (line, lineNumber) -> {
			if (line != null && line.startsWith("T")) {
				return null;
			}
			else {
				String replacedLine = line.replaceAll("&([^;&]+(?!(?:\\w|;)))", "&amp;$1");
				FIXML fixml = JAXB.unmarshal(new StringReader(replacedLine), FIXML.class);
				return transform(fixml, line);
			}

		};
	}

	/**
	 * This method is used to transform given input {@link FIXML} to
	 * {@link AccountNotification}.
	 *
	 * @param fixml : {@link FIXML}
	 * @param inputLine : {@link String}
	 * @return {@link AccountNotification}
	 */
	private AccountNotification transform(FIXML fixml, String inputLine) {

		AccountNotification accountNotification = new AccountNotification();

		SBAcctInqRequest casaAccountRequest = fixml.getBody().getSBAcctInqRequest();
		Assert.notNull(casaAccountRequest, "SBAcctInqRequest cannot be null");

		SBAcctInqRq casaAccount = casaAccountRequest.getSBAcctInqRq();
		Assert.notNull(casaAccount, "SBAcctInqRq cannot be null");

		AcctId acctId = casaAccount.getSBAcctId();
		Assert.notNull(acctId, "Account Id cannot be null");

		accountNotification.setAccountNumber(acctId.getAcctId());

		if (acctId.getAcctType() != null) {
			accountNotification.setAccountType(acctId.getAcctType().getSchmType());
			accountNotification.setAccountSchemaCode(acctId.getAcctType().getSchmCode());
		}

		if (casaAccount.getAcctBalAmt() != null) {
			accountNotification.setAccountAvailableBalance(casaAccount.getAcctBalAmt().getAmountValue());
			accountNotification.setAccountAvailableCurrency(casaAccount.getAcctBalAmt().getCurrencyCode());
		}

		SBAcctInqReqCustomDataType sbAcctInqReqCustomDataType = casaAccountRequest.getSBAcctInqCustomData();
		Assert.notNull(sbAcctInqReqCustomDataType, "sbAcctInqReqCustomDataType cannot be null");

		if (sbAcctInqReqCustomDataType.getLedgerBal() != null) {
			accountNotification
					.setAccountLedgerBalance(sbAcctInqReqCustomDataType.getLedgerBal().getAmountValue().doubleValue());
			accountNotification.setAccountLedgerCurrency(sbAcctInqReqCustomDataType.getLedgerBal().getCurrencyCode());
		}

		if (sbAcctInqReqCustomDataType.getLastChangeTime() != null) {
			accountNotification
					.setRecordGenerationTime(sbAcctInqReqCustomDataType.getLastChangeTime() != null
							? sbAcctInqReqCustomDataType.getLastChangeTime().toGregorianCalendar().getTime()
							: null);
		}

		AcctGenInfo accountGenralInfo = casaAccount.getSBAcctGenInfo();
		if (accountGenralInfo != null) {
			accountNotification.setAccountName(accountGenralInfo.getAcctName());
		}

		accountNotification.setInputLine(inputLine);
		return accountNotification;
	}

}
