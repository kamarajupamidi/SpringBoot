package com.dbs.tds.account.finacle.batch.config;

import java.util.List;

import com.dbs.tds.account.finacle.batch.repository.AccountRepository;
import com.dbs.tds.dto.AccountNotification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

/**
 * This class will act as a Writer and is used to move account notification details to
 * repository which takes care of inserting or updating data into TDS data base
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 */
@Component
public class AccountNotificationWriter implements ItemWriter<AccountNotification> {

	private static final Logger LOGGER = LoggerFactory.getLogger(AccountNotificationWriter.class);

	/**
	 * This field is used to store instance of type {@link AccountRepository }.
	 */
	private AccountRepository accountRepository;

	public AccountNotificationWriter(AccountRepository accountRepository) {
		this.accountRepository = accountRepository;
	}

	/***
	 *
	 * This method is used to write the processed records into DB.Here all account
	 * notification details are captured by comparing message date.
	 * @param accountNotifications : {@link AccountNotification}
	 *
	 */
	@Override
	public void write(List<? extends AccountNotification> accountNotifications) {

		LOGGER.info("Started writing account batch events to db, size={}", accountNotifications.size());

		this.accountRepository.updateAccountDetails(accountNotifications);

		LOGGER.info("Completed writing account batch events to db, size={}", accountNotifications.size());

	}

}
