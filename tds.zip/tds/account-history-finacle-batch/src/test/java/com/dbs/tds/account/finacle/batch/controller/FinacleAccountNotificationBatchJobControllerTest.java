package com.dbs.tds.account.finacle.batch.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import com.dbs.tds.batch.core.util.FileInputData;
import com.dbs.tds.exception.FileAccessException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.internal.util.reflection.Whitebox;
import org.mockito.runners.MockitoJUnitRunner;

import org.springframework.messaging.MessageChannel;
import org.springframework.mock.web.MockMultipartFile;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class FinacleAccountNotificationBatchJobControllerTest {

	private static final String EMPTY = "";

	private static final String NULL = null;

	@Mock
	private MessageChannel messageChannel;

	@Mock
	private MockMultipartFile mockMultipartFile;

	@InjectMocks
	private FinacleAccountNotificationBatchJobController controller;

	@Test
	public void invokeAccounteBatchJobTest() {

		ClassLoader loader = getClass().getClassLoader();
		File file = spy(new File(loader.getResource("batch/batch.txt").getFile()));
		FileInputData fileInputData = getFileInputData(file);

		assertNotEquals(NULL, fileInputData);
		assertNotEquals("Absolute Path can not be null", NULL, fileInputData.getAbsolutePath());
		assertNotEquals("Absolute Path can not be Empty", EMPTY, fileInputData.getAbsolutePath().trim());
		assertNotEquals("File Name can not be null", NULL, fileInputData.getFileName());
		assertNotEquals("File Name can not be Empty", EMPTY, fileInputData.getFileName().trim());
		assertEquals("File Does not Exists at Specified Path", true, file.exists());

	}

	@Test
	public void testCheckForFileExistence() {

		File file = getFileInstance();
		assertEquals("File Does not Exists at Specified Path", true, file.exists());
		Whitebox.setInternalState(this.controller, "filePath", file.getAbsolutePath());
		try {
			MockMultipartFile multiFile = new MockMultipartFile("batch", Files.readAllBytes(file.toPath()));
			assertThat("INVOKED_ACCOUNT_NOTIFICATION"
					.equals(this.controller.invokeFinacleAccountNotificationBatchJob(multiFile)));
		}
		catch (IOException e) {
			throw new FileAccessException("Error Accessing File", e);
		}

	}

	@Test
	public void testCheckForFileNonExistence() {
		Whitebox.setInternalState(this.controller, "filePath", "C://");
		try {
			MockMultipartFile multiFile = new MockMultipartFile("batch",
					Files.readAllBytes(getFileInstance().toPath()));
			assertThat("INVOKE_FAILED_TO_UPLOAD"
					.equals(this.controller.invokeFinacleAccountNotificationBatchJob(multiFile)));
		}
		catch (IOException e) {
			throw new FileAccessException("Error Accessing File", e);
		}

	}

	@Test
	public void testCheckForMultiPartUploadFail() {
		when(this.mockMultipartFile.isEmpty()).thenReturn(true);
		when(this.mockMultipartFile.getOriginalFilename()).thenReturn("file");
		assertThat("INVOKE_FAILED_AS_FILE_IS_EMPTY"
				.equals(this.controller.invokeFinacleAccountNotificationBatchJob(this.mockMultipartFile)));

	}

	private FileInputData getFileInputData(File file) {
		FileInputData fileInputData = new FileInputData();
		fileInputData.setAbsolutePath(file.getAbsolutePath());
		fileInputData.setFileName("batch.txt");
		return fileInputData;
	}

	private File getFileInstance() {
		ClassLoader loader = getClass().getClassLoader();
		return new File(loader.getResource("batch/batch.txt").getFile());
	}

}
