package com.dbs.tds.account.finacle.batch.config;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.dbs.tds.account.finacle.batch.repository.AccountRepository;
import com.dbs.tds.dto.AccountNotification;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class AccountNotificationWriterTest {

	@Mock
	private AccountRepository accountRepository;

	@InjectMocks
	private AccountNotificationWriter accountNotificationWriter;

	@Test
	public void testWrite() {
		List<AccountNotification> accountNotifications = new ArrayList<>();
		AccountNotification notification = getAccountNotification();
		accountNotifications.add(notification);

		this.accountNotificationWriter.write(accountNotifications);
	}

	private AccountNotification getAccountNotification() {
		AccountNotification notification = new AccountNotification();
		notification.setAccountAvailableBalance(100.00);
		notification.setAccountAvailableCurrency("INR");
		notification.setAccountLedgerBalance(100.00);
		notification.setAccountLedgerCurrency("INR");
		notification.setAccountName("DBS BANK");
		notification.setAccountNumber("1000000001");
		notification.setAccountSchemaCode("DBSSCHM");
		notification.setAccountType("CA");
		notification.setBalanceAsOfDateTm(new Date());
		notification.setIsBalSyncFlag("Y");
		notification.setLastUpdtDtTm(new Date());
		notification.setLastUpdtSysId("TDS");
		return notification;
	}

}
