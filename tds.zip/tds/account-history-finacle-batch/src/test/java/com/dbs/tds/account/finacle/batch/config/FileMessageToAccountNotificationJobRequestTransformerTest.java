package com.dbs.tds.account.finacle.batch.config;

import com.dbs.tds.batch.core.util.FileInputData;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import org.springframework.batch.core.Job;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;

@RunWith(MockitoJUnitRunner.class)
public class FileMessageToAccountNotificationJobRequestTransformerTest {

	@Mock
	private Job accountNotificationBatchJob;

	@InjectMocks
	private FileMessageToAccountNotificationJobRequestTransformer jobRequestTransformer;

	@Test
	public void testJobParamterConstruction() {
		this.jobRequestTransformer.toAccountBatchJobRequest(buildMessage());
	}

	private Message<FileInputData> buildMessage() {
		return new Message<FileInputData>() {
			@Override
			public FileInputData getPayload() {
				FileInputData fileInputData = new FileInputData();
				fileInputData.setAbsolutePath("batch/batch.txt");
				fileInputData.setFileName("batch.txt");
				return fileInputData;
			}

			@Override
			public MessageHeaders getHeaders() {
				return null;
			}
		};
	}

}
