package com.dbs.tds.account.finacle.batch.config;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.dbs.tds.dto.AccountNotification;
import com.dbs.tds.dto.CodeTypes;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AccountNotificationProcessorTest {

	private static final Logger LOGGER = LoggerFactory.getLogger(AccountNotificationProcessorTest.class);

	@InjectMocks
	private AccountNotificationProcessor accountNotificationProcessor;

	@Mock
	private CodeTypes codeTypes;

	@Test
	public void testInvalidAccountNotification() {
		try {
			Map<String, String> schemeCodes = new HashMap<>();
			schemeCodes.put("DBS", "SA");

			when(this.codeTypes.getSchemeCodes()).thenReturn(schemeCodes);

			AccountNotification ntfn = this.accountNotificationProcessor.process(getInvalidAccountNotification());
			assertNull(ntfn);
		}
		catch (Exception e) {
			LOGGER.error("Error in processing account processor", e);
		}
	}

	@Test
	public void testForValidAccountNotification() {
		try {
			Map<String, String> schemeCodes = new HashMap<>();
			schemeCodes.put("DBEXP", "SA");

			when(this.codeTypes.getSchemeCodes()).thenReturn(schemeCodes);
			AccountNotification ntfn = this.accountNotificationProcessor.process(getValidAccountNotification());
			assertNotNull(ntfn);
		}
		catch (Exception e) {
			LOGGER.error("Error in processing account processor", e);
		}
	}

	private AccountNotification getInvalidAccountNotification() {
		AccountNotification notification = getAccountNtfn();
		notification.setAccountSchemaCode("DBSSCHM");
		notification.setAccountType("CA");
		return notification;
	}

	private AccountNotification getValidAccountNotification() {
		AccountNotification notification = getAccountNtfn();
		notification.setAccountSchemaCode("DBEXP");
		notification.setAccountType("SA");
		return notification;
	}

	private AccountNotification getAccountNtfn() {
		AccountNotification notification = new AccountNotification();
		notification.setAccountAvailableBalance(100.00);
		notification.setAccountAvailableCurrency("INR");
		notification.setAccountLedgerBalance(100.00);
		notification.setAccountLedgerCurrency("INR");
		notification.setAccountName("DBS BANK");
		notification.setAccountNumber("1000000001");
		notification.setBalanceAsOfDateTm(new Date());
		notification.setIsBalSyncFlag("Y");
		notification.setLastUpdtDtTm(new Date());
		notification.setLastUpdtSysId("TDS");
		return notification;
	}

}
