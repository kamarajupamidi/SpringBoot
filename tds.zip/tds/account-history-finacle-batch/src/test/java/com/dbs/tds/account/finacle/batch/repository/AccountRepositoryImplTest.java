package com.dbs.tds.account.finacle.batch.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.dbs.tds.account.finacle.batch.AccountRepoConfig;
import com.dbs.tds.dto.AccountNotification;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@TestPropertySource(locations = "classpath:application.properties")
@ContextConfiguration(classes = { AccountRepoConfig.class })
public class AccountRepositoryImplTest {

	@Autowired
	private AccountRepository accountRepository;

	@Test
	public void testGetHistoryTransactionsWithExtTranIDNull() {

		List<AccountNotification> accountNotification = new ArrayList<>();
		accountNotification.add(getAccountNotification());
		this.accountRepository.updateAccountDetails(accountNotification);
	}

	private AccountNotification getAccountNotification() {
		AccountNotification accountNotification = new AccountNotification();
		accountNotification.setAccountAvailableBalance(100.00);
		accountNotification.setAccountAvailableCurrency("INR");
		accountNotification.setAccountLedgerBalance(100.00);
		accountNotification.setAccountLedgerCurrency("INR");
		accountNotification.setAccountName("DBS BANK");
		accountNotification.setAccountNumber("1000000001");
		accountNotification.setAccountSchemaCode("DBSSCHM");
		accountNotification.setAccountType("CA");
		accountNotification.setBalanceAsOfDateTm(new Date());
		accountNotification.setIsBalSyncFlag("Y");
		accountNotification.setLastUpdtDtTm(new Date());
		accountNotification.setLastUpdtSysId("TDS");
		return accountNotification;
	}

}
