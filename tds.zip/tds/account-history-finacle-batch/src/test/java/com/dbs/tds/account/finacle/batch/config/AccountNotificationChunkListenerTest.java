package com.dbs.tds.account.finacle.batch.config;

import java.io.FileNotFoundException;
import java.util.Date;

import com.dbs.tds.dto.AccountNotification;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.messaging.MessageChannel;

@RunWith(MockitoJUnitRunner.class)
public class AccountNotificationChunkListenerTest {

	private static final String ERROR_IN_PROCESSING = "Error in processing";

	@Mock
	private MessageChannel fileParseErrorChannel;

	@InjectMocks
	private AccountNotificationChunkListener accountNotificationChunkListener;

	@Test
	public void testOnreadError() {
		FlatFileParseException ffpe = new FlatFileParseException(ERROR_IN_PROCESSING, ERROR_IN_PROCESSING, 100);
		this.accountNotificationChunkListener.onReadError(ffpe);
	}

	@Test
	public void testOnreadNonHandlingError() {
		FileNotFoundException ffpe = new FileNotFoundException(ERROR_IN_PROCESSING);
		this.accountNotificationChunkListener.onReadError(ffpe);
	}

	@Test
	public void testOnSkipWrite() {
		FlatFileParseException ffpe = new FlatFileParseException(ERROR_IN_PROCESSING, ERROR_IN_PROCESSING, 100);
		this.accountNotificationChunkListener.onSkipInWrite(getAccountDetails(), ffpe);
	}

	private AccountNotification getAccountDetails() {
		AccountNotification ntfn = new AccountNotification();
		ntfn.setAccountAvailableBalance(100.00);
		ntfn.setAccountAvailableCurrency("INR");
		ntfn.setAccountLedgerBalance(100.00);
		ntfn.setAccountLedgerCurrency("INR");
		ntfn.setAccountName("DBS BANK");
		ntfn.setAccountNumber("1000000001");
		ntfn.setAccountSchemaCode("DBSSCHM");
		ntfn.setAccountType("CA");
		ntfn.setBalanceAsOfDateTm(new Date());
		ntfn.setIsBalSyncFlag("Y");
		ntfn.setLastUpdtDtTm(new Date());
		ntfn.setLastUpdtSysId("TDS");
		ntfn.setInputLine("Errored line");
		return ntfn;
	}
}
