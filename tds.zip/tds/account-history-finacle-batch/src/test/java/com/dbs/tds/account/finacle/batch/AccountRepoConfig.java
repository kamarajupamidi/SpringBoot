package com.dbs.tds.account.finacle.batch;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

@Configuration
@ComponentScan({ "com.dbs.tds.account.finacle.batch.repository" })
@Import(AccountHistoryFinacleBatchApplication.class)
public class AccountRepoConfig {

	@Bean
	public DataSource dataSource() {
		return new EmbeddedDatabaseBuilder()
				.addScripts("schema_accounts.sql", "data.sql")
				.setType(EmbeddedDatabaseType.H2).build();
	}

}
