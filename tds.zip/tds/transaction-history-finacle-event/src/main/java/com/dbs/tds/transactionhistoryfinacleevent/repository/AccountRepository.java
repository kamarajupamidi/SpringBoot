package com.dbs.tds.transactionhistoryfinacleevent.repository;

import com.dbs.tds.dto.LienNotification;
import com.dbs.tds.dto.TransactionNotification;

/**
 * This interface is used to define the methods which will be used for interacting with
 * TDS DB for updating account related details.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public interface AccountRepository {

	/**
	 * This method is used to update the account details for normal transaction request.
	 *
	 * @param transactionNotification : {@link TransactionNotification}
	 * @return {@link Integer}
	 */
	int updateAccountDetails(TransactionNotification transactionNotification);

	/**
	 * This method is used to update the account details for LIEN transaction request.
	 *
	 * @param lienNotification : {@link LienNotification}
	 * @return {@link Integer}
	 */
	int updateLienAccountDetails(LienNotification lienNotification);

}
