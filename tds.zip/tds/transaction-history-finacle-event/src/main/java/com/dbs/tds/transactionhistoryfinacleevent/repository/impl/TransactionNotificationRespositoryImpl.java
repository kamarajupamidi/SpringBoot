package com.dbs.tds.transactionhistoryfinacleevent.repository.impl;

import java.util.Date;

import javax.sql.DataSource;

import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistoryfinacleevent.repository.TransactionNotificationRepository;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import static com.dbs.tds.constants.TransactionDimFields.TRAN_CMMNT;
import static com.dbs.tds.constants.TransactionFields.ACCTCURR;
import static com.dbs.tds.constants.TransactionFields.ACCTID;
import static com.dbs.tds.constants.TransactionFields.ADDNLREF;
import static com.dbs.tds.constants.TransactionFields.AMOUNT;
import static com.dbs.tds.constants.TransactionFields.AVAILABLEBAL;
import static com.dbs.tds.constants.TransactionFields.CURRENCY;
import static com.dbs.tds.constants.TransactionFields.LEDGERBAL;
import static com.dbs.tds.constants.TransactionFields.LST_UPDT_DTTM;
import static com.dbs.tds.constants.TransactionFields.LST_UPDT_SYS_ID;
import static com.dbs.tds.constants.TransactionFields.POSTINGDATE;
import static com.dbs.tds.constants.TransactionFields.RELATEDRECID;
import static com.dbs.tds.constants.TransactionFields.RELATEDTRANREF;
import static com.dbs.tds.constants.TransactionFields.TRANCODE;
import static com.dbs.tds.constants.TransactionFields.TRANDATE;
import static com.dbs.tds.constants.TransactionFields.TRANDESC;
import static com.dbs.tds.constants.TransactionFields.TRANID;
import static com.dbs.tds.constants.TransactionFields.TRANKEY;
import static com.dbs.tds.constants.TransactionFields.TRANSEQNUM;
import static com.dbs.tds.constants.TransactionFields.TXNTYPE;
import static com.dbs.tds.constants.TransactionFields.VALUEDATE;

/**
 * This class is used as the implementation for the
 * {@link TransactionNotificationRepository}. It will help in interacting with TDS DB for
 * transaction related changes. whenever the transaction notification is received on
 * Finacle Online message queue, it will be checked whether it is a normal transaction
 * notification or LIEN transaction notification. For normal transaction, all the
 * transaction details are inserted while in case of lien transaction, only balances are
 * updated for the particular account.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Repository
public class TransactionNotificationRespositoryImpl implements TransactionNotificationRepository {

	/**
	 * This field is used to store value for transactionHistoryInsert which is of type
	 * {@link SimpleJdbcInsert }.
	 */
	private SimpleJdbcInsert transactionHistoryInsert;

	/**
	 * This field is used to store value for dimInsert which is of type
	 * {@link SimpleJdbcInsert }.
	 */
	private SimpleJdbcInsert dimInsert;

	/**
	 * This constructor will help in building the instance of {@link SimpleJdbcInsert}
	 * which will be used to insert the details in TDS DB.
	 *
	 * @param dataSource : {@link DataSource}
	 */
	public TransactionNotificationRespositoryImpl(DataSource dataSource) {
		this.transactionHistoryInsert = new SimpleJdbcInsert(dataSource).withTableName("T_DTA_FACT").usingColumns(
				"TRANID", "ACCTID", "ACCTCURR", "LEDGERBAL", "AVAILABLEBAL", "RELATEDRECID", "TRANSEQNUM", "TRANDATE",
				"VALUEDATE", "POSTINGDATE", "TRANCODE", "TRANDESC", "AMOUNT", "CURRENCY", "TXNTYPE",
				"RELATEDTRANREF", "ADDNLREF", "TRANKEY", "LST_UPDT_SYS_ID", "LST_UPDT_DTTM");

		this.dimInsert = new SimpleJdbcInsert(dataSource).withTableName("T_DTA_DIM").usingColumns(
				"TRANKEY", "TRAN_CTGR", "TRAN_CMMNT", "LST_UPDT_SYS_ID", "LST_UPDT_DTTM");
	}

	/**
	 * This method is used to insert the transaction details whenever the normal
	 * transaction notification is received on Finacle message queue. It will insert the
	 * transaction details.
	 *
	 * @param transactionNotification : {@link TransactionNotification}
	 * @return {@link Integer}
	 */
	@Override
	public int insertTransactionNotification(TransactionNotification transactionNotification) {
		MapSqlParameterSource parameterSource = new MapSqlParameterSource();
		parameterSource
				.addValue(TRANID.name(), transactionNotification.getTransactionId())
				.addValue(ACCTID.name(), transactionNotification.getAccountNumber())
				.addValue(ACCTCURR.name(), transactionNotification.getAccountCurrencyCode())
				.addValue(LEDGERBAL.name(), transactionNotification.getLedgerBalance())
				.addValue(AVAILABLEBAL.name(), transactionNotification.getAvailableBalance())
				.addValue(RELATEDRECID.name(), transactionNotification.getRelatedRecordId())
				.addValue(TRANSEQNUM.name(), transactionNotification.getPartTransactionSerialNumber())
				.addValue(TRANDATE.name(), transactionNotification.getTransactionDate())
				.addValue(VALUEDATE.name(), transactionNotification.getValueDate())
				.addValue(POSTINGDATE.name(), transactionNotification.getPostedDate())
				.addValue(TRANCODE.name(), transactionNotification.getTransactionParticularCode())
				.addValue(TRANDESC.name(), transactionNotification.getTransactionParticulars())
				.addValue(AMOUNT.name(), transactionNotification.getTransactionAmount())
				.addValue(CURRENCY.name(), transactionNotification.getTransactionCurrencyCode())
				.addValue(TXNTYPE.name(), transactionNotification.getPartTransactionType())
				.addValue(RELATEDTRANREF.name(), transactionNotification.getTransactionReferenceNumber())
				.addValue(ADDNLREF.name(), transactionNotification.getAdditionalReference())
				.addValue(TRANKEY.name(), transactionNotification.getTranKey())
				.addValue(LST_UPDT_SYS_ID.name(), "ONLINE")
				.addValue(LST_UPDT_DTTM.name(), new Date());

		return this.transactionHistoryInsert.execute(parameterSource);
	}

	/**
	 * This method is used to insert the transaction details whenever the normal
	 * transaction notification is received on Finacle message queue. It will insert the
	 * transaction additional details.
	 *
	 * @param transactionNotification : {@link TransactionNotification}
	 * @return {@link Integer}
	 */
	@Override
	public int insertDim(TransactionNotification transactionNotification) {
		MapSqlParameterSource parameterSource = new MapSqlParameterSource();
		parameterSource
				.addValue(TRAN_CMMNT.name(), transactionNotification.getAdditionalReference())
				.addValue(TRANKEY.name(), transactionNotification.getTranKey())
				.addValue(LST_UPDT_SYS_ID.name(), "ONLINE")
				.addValue(LST_UPDT_DTTM.name(), new Date());

		return this.dimInsert.execute(parameterSource);
	}
}
