package com.dbs.tds.transactionhistoryfinacleevent.transformer;

import java.io.StringReader;

import javax.xml.transform.stream.StreamSource;

import com.dbs.tds.dto.LienNotification;
import com.finacle.fixml.liennotification.AcctLienRec;
import com.finacle.fixml.liennotification.Amount;
import com.finacle.fixml.liennotification.FIXML;
import com.finacle.fixml.liennotification.RequestMessageInfoType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

/**
 * This class is used to transform the incoming request.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 */
@Component
public class FinacleLienNotificationTransformer {

	/**
	 * This field is used to instantiate LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(FinacleLienNotificationTransformer.class);

	/**
	 * This field is used to store value for finacleLienNotificationMarshaller which is of
	 * type {@link Jaxb2Marshaller }.
	 */
	private Jaxb2Marshaller finacleLienNotificationMarshaller;

	/**
	 * This constructor will help in constructing the instance for marshaller which will
	 * help in converting the incoming request from XML format to a java POJO instance.
	 *
	 * @param finacleLienNotificationMarshaller : {@link Jaxb2Marshaller}
	 */
	public FinacleLienNotificationTransformer(Jaxb2Marshaller finacleLienNotificationMarshaller) {
		this.finacleLienNotificationMarshaller = finacleLienNotificationMarshaller;
	}

	/**
	 * This method is used to transform the incoming request. Incoming request which will
	 * be in XML format, is parsed into an instance of {@link FIXML} and this method will
	 * transform the object into {@link LienNotification} which further will be used to
	 * map database entities.
	 *
	 * @param fixml : {@link FIXML}
	 * @return {@link LienNotification}
	 */
	public LienNotification transform(FIXML fixml) {

		LOGGER.info("Incoming Request  from Finacle: {}", fixml);

		LienNotification lienNotification = new LienNotification();
		AcctLienRec acctLienRec = fixml.getBody().getAcctLienRec();
		RequestMessageInfoType requestMessageInfo = fixml.getHeader().getRequestHeader().getRequestMessageInfo();

		Assert.notNull(acctLienRec, "Lien transaction record cannot be null");
		Assert.notNull(requestMessageInfo, "Request message info cannot be null");

		lienNotification.setAccountNumber(acctLienRec.getAcctNumber());

		Amount ledgerBalAmt = acctLienRec.getLedgerBalAmt();
		Amount availBalAmt = acctLienRec.getAvailBalAmt();

		if (ledgerBalAmt != null) {
			lienNotification.setLedgerBalance(ledgerBalAmt.getAmountValue());
			lienNotification.setLedgerBalanceCurrencyCode(ledgerBalAmt.getCurrencyCode());
		}

		if (availBalAmt != null) {
			lienNotification.setAvailableBalance(availBalAmt.getAmountValue());
			lienNotification.setAvailableBalanceCurrencyCode(availBalAmt.getCurrencyCode());
		}

		if (requestMessageInfo.getMessageDateTime() != null) {
			lienNotification
			.setRecordGenerationTime(requestMessageInfo.getMessageDateTime().toGregorianCalendar().getTime());
		}

		LOGGER.info("Lien Notification created out of Finacle Request : {}", lienNotification);

		return lienNotification;
	}

	/**
	 * This method is used to transform the incoming request from XML format to a
	 * corresponding java POJO instance.
	 *
	 * @param request : {@link String}
	 * @return {@link FIXML}
	 */
	public FIXML transform(String request) {
		LOGGER.info("Incoming request {}", request);
		return (FIXML) this.finacleLienNotificationMarshaller.unmarshal(new StreamSource(new StringReader(request)));
	}

}
