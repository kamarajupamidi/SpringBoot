package com.dbs.tds.transactionhistoryfinacleevent.service;

import com.dbs.tds.constants.StatusCodes;
import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistoryfinacleevent.repository.AccountRepository;
import com.dbs.tds.transactionhistoryfinacleevent.repository.TransactionNotificationRepository;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import static com.dbs.tds.constants.AppConstants.STATUS_CODE_DES_KEY;
import static com.dbs.tds.constants.AppConstants.STATUS_CODE_KEY;
import static com.dbs.tds.constants.LoggingConstants.ERROR_TYPE;
import static com.dbs.tds.constants.LoggingConstants.RESPONSE_TIME;

/**
 * This class is used to update normal transaction data, coming from Finacle Event Queue
 * Notification, into TDS DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 */
@Service
@Transactional
public class FinacleTransactionNotificationService {
	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(FinacleTransactionNotificationService.class);

	/**
	 * This field is used to store value for ELKLOGGER which is of type {@link Logger }.
	 */
	private static final Logger ELKLOGGER = LoggerFactory.getLogger("elklogger");

	/**
	 * This field is used to store value for accountRepository which is of type
	 * {@link AccountRepository }.
	 */
	private AccountRepository accountRepository;

	/**
	 * This field is used to store value for transactionNotificationRepository which is of
	 * type {@link TransactionNotificationRepository }.
	 */
	private TransactionNotificationRepository transactionNotificationRepository;

	/**
	 * This constructor will help in building the instance of {@link AccountRepository}
	 * and {@link TransactionNotificationRepository} which will help in interacting with
	 * TDS DB for storing the transaction details.
	 *
	 * @param accountRepository : {@link AccountRepository}
	 * @param transactionNotificationRepository :
	 * {@link TransactionNotificationRepository}
	 */
	public FinacleTransactionNotificationService(AccountRepository accountRepository,
			TransactionNotificationRepository transactionNotificationRepository) {
		this.accountRepository = accountRepository;
		this.transactionNotificationRepository = transactionNotificationRepository;
	}

	/**
	 * This method is used to update transaction data, coming from Finacle Event Queue
	 * Notification, into TDS DB.
	 *
	 * @param transactionNotification : {@link TransactionNotification}
	 */
	public void process(TransactionNotification transactionNotification) {
		try {
			this.transactionNotificationRepository.insertTransactionNotification(transactionNotification);
			this.transactionNotificationRepository.insertDim(transactionNotification);
		}
		catch (DataAccessException e) {
			LOGGER.info("Exception Occured which will be ignored : {}", e);
		}
		this.accountRepository.updateAccountDetails(transactionNotification);
		MDC.put(STATUS_CODE_KEY.value(), StatusCodes.SUCCESS.value());
		MDC.put(STATUS_CODE_DES_KEY.value(), StatusCodes.SUCCESS.name());
		MDC.put(ERROR_TYPE.value(), "");
		LOGGER.info("Updated Transaction and Account details for transactionNotification = {}",
				transactionNotification);
		logElapsedTimeForHistoryEvent();
	}

	/**
	 * This method is used to calculate and log the elapsed time.
	 */
	private void logElapsedTimeForHistoryEvent() {
		String startTime = MDC.get("startTime");
		if (StringUtils.isNotBlank(startTime)) {
			long start = Long.parseLong(startTime);
			long elapsed = System.currentTimeMillis() - start;
			MDC.put(RESPONSE_TIME.value(), String.valueOf(elapsed));
			ELKLOGGER.info("");
		}
	}

}
