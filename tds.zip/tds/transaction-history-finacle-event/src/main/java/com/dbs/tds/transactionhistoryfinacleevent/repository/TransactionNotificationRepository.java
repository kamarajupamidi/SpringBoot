package com.dbs.tds.transactionhistoryfinacleevent.repository;

import com.dbs.tds.dto.TransactionNotification;

/**
 * This interface is used to define the methods which will be used for interacting with
 * TDS DB for inserting transaction related details.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public interface TransactionNotificationRepository {

	/**
	 * This method is used to insert the transaction Common details for normal transaction
	 * request.
	 *
	 * @param transactionNotification : {@link TransactionNotification}
	 * @return {@link Integer}
	 */
	public int insertTransactionNotification(TransactionNotification transactionNotification);

	/**
	 * This method is used to insert the transaction additional details for normal
	 * transaction request.
	 *
	 * @param transactionNotification : {@link TransactionNotification}
	 * @return {@link Integer}
	 */
	public int insertDim(TransactionNotification transactionNotification);
}
