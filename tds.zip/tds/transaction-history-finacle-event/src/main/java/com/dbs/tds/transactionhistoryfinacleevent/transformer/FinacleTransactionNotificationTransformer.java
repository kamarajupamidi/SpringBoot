package com.dbs.tds.transactionhistoryfinacleevent.transformer;

import java.io.StringReader;
import java.util.UUID;

import javax.xml.transform.stream.StreamSource;

import com.dbs.tds.constants.AppIdentifiers;
import com.dbs.tds.dto.TransactionNotification;
import com.finacle.fixml.notification.AcctTrnRec;
import com.finacle.fixml.notification.Amount;
import com.finacle.fixml.notification.FIXML;
import com.finacle.fixml.notification.RequestMessageInfoType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import static com.dbs.tds.constants.AppConstants.APP_REGION;
import static com.dbs.tds.constants.Countries.IN;
import static com.dbs.tds.constants.LoggingConstants.CLIENT_IP;
import static com.dbs.tds.constants.LoggingConstants.FUNCTIONAL_MAP;
import static com.dbs.tds.constants.LoggingConstants.INTERFACE_MAP;
import static com.dbs.tds.constants.LoggingConstants.MSG_UID;
import static com.dbs.tds.constants.LoggingConstants.REQUEST_TYPE;
import static com.dbs.tds.constants.LoggingConstants.SERVICE_ID;
import static com.dbs.tds.constants.RequestTypes.E2E;

/**
 * This class is used to transform the incoming request.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 */
@Component
public class FinacleTransactionNotificationTransformer {

	/**
	 * This field is used to instantiate LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(FinacleTransactionNotificationTransformer.class);

	/**
	 * This field is used to store value for finacleTransactionMarshaller which is of type
	 * {@link Jaxb2Marshaller }.
	 */
	private Jaxb2Marshaller finacleTransactionMarshaller;

	/**
	 * This constructor will help in constructing the instance for marshaller which will
	 * help in converting the incoming request from XML format to a java POJO instance.
	 *
	 * @param finacleTransactionMarshaller : {@link Jaxb2Marshaller}
	 */
	public FinacleTransactionNotificationTransformer(Jaxb2Marshaller finacleTransactionMarshaller) {
		this.finacleTransactionMarshaller = finacleTransactionMarshaller;
	}

	/**
	 * This method is used to populate ELK variable in MDC object. By this we print
	 * required fields for analytics in application logs.
	 */
	private void startLoggingRequest() {
		long startTime = System.currentTimeMillis();
		MDC.put(CLIENT_IP.value(), "FINACLEQUEQUE");
		MDC.put(FUNCTIONAL_MAP.value(), "Finacle_Transaction_History_Event");
		MDC.put(AppIdentifiers.APP_CODE.name(), AppIdentifiers.APP_CODE.value());
		MDC.put(APP_REGION.value(), IN.name());
		MDC.put(SERVICE_ID.value(), "transactionhistoryfinacleevent");
		MDC.put("startTime", String.valueOf(startTime));
		MDC.put(INTERFACE_MAP.value(), "finacle_tdsqueque_to_tds");
		MDC.put(MSG_UID.value(), UUID.randomUUID().toString());
		MDC.put(REQUEST_TYPE.value(), E2E.name());

	}

	/**
	 * This method is used to transform the incoming request from XML format to a
	 * corresponding java POJO instance.
	 *
	 * @param request : {@link String}
	 * @return {@link FIXML}
	 */
	public FIXML transform(String request) {
		startLoggingRequest();
		LOGGER.info("Incoming request {}", request);
		return (FIXML) this.finacleTransactionMarshaller.unmarshal(new StreamSource(new StringReader(request)));
	}

	/**
	 * This method is used to transform the incoming request. Incoming request which will
	 * be in XML format, is parsed into an instance of {@link FIXML} and this method will
	 * transform the object into {@link TransactionNotification} which further will be
	 * used to map database entities.
	 *
	 * @param fixml : {@link FIXML}
	 * @return {@link TransactionNotification}
	 */
	public TransactionNotification transform(FIXML fixml) {

		LOGGER.info("Incoming Request from Finacle: {}", fixml);

		TransactionNotification transactionNotification = new TransactionNotification();
		AcctTrnRec acctTrnRec = fixml.getBody().getAcctTrnRec();
		RequestMessageInfoType requestMessageInfo = fixml.getHeader().getRequestHeader().getRequestMessageInfo();
		Amount ledgerBal = acctTrnRec.getLedgerBal();
		Amount availableBal = acctTrnRec.getAvailableBal();

		Assert.notNull(acctTrnRec, "Account transaction record cannot be null");
		Assert.notNull(requestMessageInfo, "Request message info cannot be null");

		transactionNotification.setTransactionId(acctTrnRec.getTrnID().trim());
		transactionNotification.setAccountNumber(acctTrnRec.getAcctNumber());
		transactionNotification.setAccountCurrencyCode(acctTrnRec.getTrnCurCode());
		transactionNotification.setRelatedRecordId(acctTrnRec.getTranParticular2());
		transactionNotification.setTransactionParticularCode(acctTrnRec.getTranParticularCode());
		transactionNotification.setPartTransactionType(acctTrnRec.getPartTrnType());
		transactionNotification.setTransactionReferenceNumber(acctTrnRec.getTranRefNo());
		transactionNotification.setAdditionalReference(acctTrnRec.getTranRmks());
		transactionNotification.setTransactionParticulars(acctTrnRec.getTrnParticulars());

		if (ledgerBal != null) {
			transactionNotification.setLedgerBalance(ledgerBal.getAmountValue());
		}
		if (availableBal != null) {
			transactionNotification.setAvailableBalance(availableBal.getAmountValue());
		}
		if (acctTrnRec.getPartTrnSrlNum() != null) {
			transactionNotification
			.setPartTransactionSerialNumber(Long.parseLong(acctTrnRec.getPartTrnSrlNum().trim()));
		}
		if (acctTrnRec.getTrnDt() != null) {
			transactionNotification.setTransactionDate(acctTrnRec.getTrnDt().toGregorianCalendar().getTime());
		}
		if (acctTrnRec.getValueDt() != null) {
			transactionNotification.setValueDate(acctTrnRec.getValueDt().toGregorianCalendar().getTime());
		}
		if (acctTrnRec.getPostedDate() != null) {
			transactionNotification.setPostedDate(acctTrnRec.getPostedDate().toGregorianCalendar().getTime());
		}
		if (acctTrnRec.getTrnAmt() != null) {
			transactionNotification.setTransactionAmount(acctTrnRec.getTrnAmt().getAmountValue());
		}
		if (acctTrnRec.getTrnAmt() != null) {
			transactionNotification.setTransactionCurrencyCode(acctTrnRec.getTrnAmt().getCurrencyCode());
		}
		transactionNotification.calculateTranKey();
		if (requestMessageInfo.getMessageDateTime() != null) {
			transactionNotification
			.setRecordGenerationTime(requestMessageInfo.getMessageDateTime().toGregorianCalendar().getTime());
		}

		LOGGER.info("Transaction Notification Generated out of Finacle Request : {}", transactionNotification);

		return transactionNotification;
	}

}
