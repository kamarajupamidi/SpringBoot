package com.dbs.tds.transactionhistoryfinacleevent.service;

import com.dbs.tds.dto.LienNotification;
import com.dbs.tds.transactionhistoryfinacleevent.repository.AccountRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * This class is used to update LIEN transaction data, coming from Finacle Event Queue
 * Notification, into TDS DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 */
@Service
@Transactional
public class FinacleLienNotificationService {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(FinacleLienNotificationService.class);

	/**
	 * This field is used to store value for accountRepository which is of type
	 * {@link AccountRepository }.
	 */
	private AccountRepository accountRepository;

	/**
	 * This constructor will help in building the instance of {@link AccountRepository}
	 * which will help in interacting with TDS DB.
	 *
	 * @param accountRepository : {@link AccountRepository}
	 */
	public FinacleLienNotificationService(AccountRepository accountRepository) {
		this.accountRepository = accountRepository;
	}

	/**
	 * This method is used to update transaction data, coming from Finacle Event Queue
	 * Notification, into TDS DB.
	 *
	 * @param lienNotification : {@link LienNotification}
	 */
	public void process(LienNotification lienNotification) {
		this.accountRepository.updateLienAccountDetails(lienNotification);
		LOGGER.info("Updated Lien Account Details for lienNotification = {}", lienNotification);
	}

}
