package com.dbs.tds.transactionhistoryfinacleevent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * This class is used for initializing the Spring Boot Container for handling and starting
 * the Messages queue which will receive messages incoming from Finacle and process them
 * accordingly.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@SpringBootApplication
public class TransactionHistoryFinacleEventApplication {

	/**
	 * This method is used by JVM to start the Spring Boot Container for this application
	 * which will start the message queue for handling Finacle messages with transaction
	 * Details.
	 *
	 * @param args : {@link String}[]
	 */
	public static void main(String[] args) {
		SpringApplication.run(TransactionHistoryFinacleEventApplication.class, args);
	}
}
