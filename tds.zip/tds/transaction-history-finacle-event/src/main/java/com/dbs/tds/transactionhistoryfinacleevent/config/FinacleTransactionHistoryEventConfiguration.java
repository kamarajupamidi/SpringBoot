package com.dbs.tds.transactionhistoryfinacleevent.config;

import javax.jms.ConnectionFactory;

import com.dbs.tds.dto.LienNotification;
import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistoryfinacleevent.service.FinacleLienNotificationService;
import com.dbs.tds.transactionhistoryfinacleevent.service.FinacleTransactionNotificationService;
import com.dbs.tds.transactionhistoryfinacleevent.transformer.FinacleLienNotificationTransformer;
import com.dbs.tds.transactionhistoryfinacleevent.transformer.FinacleTransactionNotificationTransformer;
import com.finacle.fixml.notification.FIXML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.jms.Jms;
import org.springframework.integration.handler.LoggingHandler;
import org.springframework.integration.router.AbstractMappingMessageRouter;
import org.springframework.integration.xml.router.XPathRouter;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.jms.support.converter.SimpleMessageConverter;
import org.springframework.messaging.MessageChannel;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

/**
 * This class is used as the configuration class which configure the behavior and working
 * of the Message queue which will receive the message coming from Finacle and process the
 * message accordingly and insert/update the details in TDS DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@EnableIntegration
@Configuration
public class FinacleTransactionHistoryEventConfiguration {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(FinacleTransactionHistoryEventConfiguration.class);

	/**
	 * This method is used to receive the message which is coming on message queue from
	 * Finacle with transaction details. This method creates a connection with the queue
	 * with the help of injected connectionFactory and destination name. Then the message
	 * is converted using the injected marshallingMessageConverter and message is put onto
	 * suitable channel for processing. If there is any error during the process then the
	 * message is put onto the error channel.
	 *
	 * @param destinationName : {@link String}
	 * @param connectionFactory : {@link ConnectionFactory}
	 *
	 * @return {@link IntegrationFlow}
	 */
	@Bean
	public IntegrationFlow finacleEventFlow(@Value("${finacle.inbound.destination}") String destinationName,
			ConnectionFactory connectionFactory) {
		return IntegrationFlows
				.from(Jms.messageDrivenChannelAdapter(connectionFactory)
						.destination(destinationName)
						.outputChannel(outputChannel())
						.errorChannel(errorChannel()))
				.get();
	}

	/**
	 * This method is used to return the message channel for message which is coming in
	 * message queue from Finacle and logging the complete message before processing it.
	 *
	 * @return {@link MessageChannel}
	 */
	@Bean
	public MessageChannel outputChannel() {
		return new DirectChannel();
	}

	/**
	 * This method is used to return the message channel for normal transaction message
	 * which is coming in message queue from Finacle and logging the complete message
	 * before processing it.
	 *
	 * @return {@link MessageChannel}
	 */
	@Bean
	public MessageChannel transactionChannel() {
		return new DirectChannel();
	}

	/**
	 * This method is used to return the message channel for LIEN transaction message
	 * which is coming in message queue from Finacle and logging the complete message
	 * before processing it.
	 *
	 * @return {@link MessageChannel}
	 */
	@Bean
	public MessageChannel lienChannel() {
		return new DirectChannel();
	}

	/**
	 * This method is used to return the message channel for message which is put onto a
	 * message queue from Finacle and logging the complete message before processing it.
	 *
	 * @return {@link MessageChannel}
	 */
	@Bean
	public MessageChannel wrongMessagesChannel() {
		return new DirectChannel();
	}

	/**
	 * This method is used to return the Message Channel for Error message Flow.
	 *
	 * @return {@link MessageChannel}
	 */
	@Bean
	public MessageChannel errorChannel() {
		return new DirectChannel();
	}

	/**
	 * This method is used to provide Bean instance of Message Converter which will help
	 * to convert the message string to an Instance.
	 *
	 * @return {@link MessageConverter}
	 */
	@Bean
	public MessageConverter messageConverter() {
		return new SimpleMessageConverter();
	}

	/**
	 * This method is used to send the incoming message to the router so the router can
	 * determine the exact channel on which the message needs to be put based on the
	 * XPath.
	 *
	 * @param transactionChannel : {@link MessageChannel}
	 * @param lienChannel : {@link MessageChannel}
	 * @return {@link IntegrationFlow}
	 */
	@Bean
	public IntegrationFlow finacleInboundFlow(MessageChannel transactionChannel, MessageChannel lienChannel) {
		return IntegrationFlows.from(outputChannel())
				.route(xpathRouter())
				.get();
	}

	/**
	 * This method is used to define the flow of the message channel which will be invoked
	 * whenever there is a message related to normal transaction on Finacle message queue.
	 * This method will transform the incoming message and put the message to get serviced
	 * and get updated in the DB.
	 *
	 * @param finacleTransactionNotificationTransformer :
	 * {@link FinacleTransactionNotificationTransformer}
	 * @param finacleTransactionNotificationService :
	 * {@link FinacleTransactionNotificationService}
	 *
	 * @return {@link IntegrationFlow}
	 */
	@Bean
	public IntegrationFlow finacleTransactionInboundFlow(
			FinacleTransactionNotificationTransformer finacleTransactionNotificationTransformer,
			FinacleTransactionNotificationService finacleTransactionNotificationService) {

		return IntegrationFlows.from(transactionChannel())
				.<String, FIXML>transform(finacleTransactionNotificationTransformer::transform)
				.<FIXML, TransactionNotification>transform(finacleTransactionNotificationTransformer::transform)
				.handle(finacleTransactionNotificationService)
				.get();
	}

	/**
	 * This method is used to define the flow of the message channel which will be invoked
	 * whenever there is a message related to LIEN transaction on Finacle message queue.
	 * This method will transform the incoming message and put the message to get serviced
	 * and get updated in the DB.
	 *
	 * @param finacleLienNotificationService : {@link FinacleLienNotificationService}
	 * @param finacleLienNotificationTransformer :
	 * {@link FinacleLienNotificationTransformer}
	 *
	 * @return {@link IntegrationFlow}
	 */
	@Bean
	public IntegrationFlow finacleLienTransactionInboundFlow(
			FinacleLienNotificationService finacleLienNotificationService,
			FinacleLienNotificationTransformer finacleLienNotificationTransformer) {
		return IntegrationFlows
				.from(lienChannel()).<String, com.finacle.fixml.liennotification.FIXML>transform(
						finacleLienNotificationTransformer::transform).<com.finacle.fixml.liennotification.FIXML, LienNotification>transform(
								finacleLienNotificationTransformer::transform)
				.handle(finacleLienNotificationService)
				.get();
	}

	/**
	 * This method is used to define the flow of the error channel which will be invoked
	 * whenever there is an error during the processing of the incoming message on Finacle
	 * message queue.
	 *
	 * @return {@link IntegrationFlow}
	 */
	@Bean
	public IntegrationFlow finacleErrorFlow() {
		return IntegrationFlows
				.from(errorChannel())
				.handle(new LoggingHandler("ERROR"))
				.get();
	}

	/**
	 * This method is used to define the flow of the error channel which will be invoked
	 * whenever the message is put onto a wrong channel by the channel router during the
	 * processing of the incoming message on Finacle message queue.
	 *
	 * @return {@link IntegrationFlow}
	 */
	@Bean
	public IntegrationFlow finacleWorngChannelFlow() {
		return IntegrationFlows
				.from(wrongMessagesChannel())
				.handle(msg -> {
					LOGGER.warn("Invalid message {} ", msg);
				})
				.get();
	}

	/**
	 * This method is used to provide the instance of the marshaler which will help in
	 * parsing the XML format String object to a java instance with the help of the
	 * Context path and injected location of the schema files used to identify the
	 * correctness of the XML format.
	 *
	 * @param contextPath : {@link String}
	 * @param schemaLocation : {@link String}
	 * @return {@link Jaxb2Marshaller}
	 */
	@Bean
	public Jaxb2Marshaller finacleTransactionMarshaller(
			@Value("${finacle.transaction.context.path}") String contextPath,
			@Value("${finacle.transaction.schema.location}") String schemaLocation) {
		Resource schemaResource = new ClassPathResource(schemaLocation);
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setContextPaths(contextPath);
		jaxb2Marshaller.setSchema(schemaResource);
		return jaxb2Marshaller;
	}

	/**
	 * This method is used to provide the instance of the marshaler which will help in
	 * parsing the XML format String object to a java instance with the help of the
	 * Context path and injected location of the schema files used to identify the
	 * correctness of the XML format.
	 *
	 * @param contextPath : {@link String}
	 * @param schemaLocation : {@link String}
	 * @return {@link Jaxb2Marshaller}
	 */
	@Bean
	public Jaxb2Marshaller finacleLienNotificationMarshaller(
			@Value("${finacle.liennotification.context.path}") String contextPath,
			@Value("${finacle.liennotification.schema.location}") String schemaLocation) {
		Resource schemaResource = new ClassPathResource(schemaLocation);
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setContextPaths(contextPath);
		jaxb2Marshaller.setSchema(schemaResource);
		return jaxb2Marshaller;
	}

	/**
	 * This method is used to check for the xpath of the incoming request and pass the
	 * request to appropriate channel so the message can be consumed accordingly.
	 *
	 * @return {@link AbstractMappingMessageRouter}
	 */
	@Bean
	public AbstractMappingMessageRouter xpathRouter() {
		XPathRouter router = new XPathRouter("local-name(/*/*[2]/*)");
		router.setEvaluateAsString(true);
		router.setResolutionRequired(false);
		router.setDefaultOutputChannel(wrongMessagesChannel());
		router.setChannelMapping("AcctTrnRec", "transactionChannel");
		router.setChannelMapping("AcctLienRec", "lienChannel");
		return router;
	}
}
