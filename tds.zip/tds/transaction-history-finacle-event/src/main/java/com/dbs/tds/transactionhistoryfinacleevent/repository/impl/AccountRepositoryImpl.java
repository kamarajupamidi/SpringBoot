package com.dbs.tds.transactionhistoryfinacleevent.repository.impl;

import java.util.Date;

import javax.sql.DataSource;

import com.dbs.tds.dto.LienNotification;
import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistoryfinacleevent.repository.AccountRepository;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import static com.dbs.tds.constants.AccountFields.ACCT_AVALBL_CRRNCY;
import static com.dbs.tds.constants.AccountFields.ACCT_AVLBL_BAL;
import static com.dbs.tds.constants.AccountFields.ACCT_LDGR_BAL;
import static com.dbs.tds.constants.AccountFields.ACCT_LDGR_CRRNCY;
import static com.dbs.tds.constants.AccountFields.ACCT_NO;
import static com.dbs.tds.constants.AccountFields.IS_BAL_SYNC;
import static com.dbs.tds.constants.AccountFields.LST_UPDT_DTTM;
import static com.dbs.tds.constants.AccountFields.LST_UPDT_SYS_ID;

/**
 * This class is used as the implementation for the {@link AccountRepository}. It will
 * help in interacting with TDS DB for account related changes. whenever the transaction
 * notification is received on Finacle Online message queue, it will be checked whether it
 * is a normal transaction notification or LIEN transaction notification. For normal
 * transaction, all the details are updated based on the flag date time while in case of
 * lien transaction, the balances are updated for the particular account.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Repository
public class AccountRepositoryImpl implements AccountRepository {

	/**
	 * This field is used to store value for accountUpdateSql which is of type
	 * {@link String }.
	 */
	private String accountUpdateSql;

	/**
	 * This field is used to store value for lienAccountUpdateSql which is of type
	 * {@link String }.
	 */
	private String lienAccountUpdateSql;

	/**
	 * This field is used to store value for namedParameterJdbcTemplate which is of type
	 * {@link NamedParameterJdbcTemplate }.
	 */
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	/**
	 * This constructor will help in building the instance of
	 * {@link NamedParameterJdbcTemplate} along with the queries which will be used to
	 * update the details in TDS DB.
	 *
	 * @param dataSource : {@link DataSource}
	 */
	public AccountRepositoryImpl(DataSource dataSource) {
		this.accountUpdateSql = "UPDATE T_ACCT SET"
				+ " ACCT_AVLBL_BAL = CASE WHEN BAL_ASOFDATETIME IS NULL OR BAL_ASOFDATETIME <= :messageDate THEN :ACCT_AVLBL_BAL ELSE ACCT_AVLBL_BAL END,"
				+ " ACCT_LDGR_BAL = CASE WHEN BAL_ASOFDATETIME IS NULL OR BAL_ASOFDATETIME <= :messageDate THEN :ACCT_LDGR_BAL ELSE ACCT_LDGR_BAL END,"
				+ " BAL_ASOFDATETIME = CASE WHEN BAL_ASOFDATETIME IS NULL OR BAL_ASOFDATETIME <= :messageDate THEN :messageDate ELSE BAL_ASOFDATETIME END,"
				+ " IS_BAL_SYNC = CASE WHEN BAL_ASOFDATETIME IS NULL OR BAL_ASOFDATETIME <= :messageDate THEN :IS_BAL_SYNC ELSE IS_BAL_SYNC END,"
				+ " LST_UPDT_SYS_ID = :LST_UPDT_SYS_ID, LST_UPDT_DTTM = :LST_UPDT_DTTM"
				+ " WHERE ACCT_NO = :ACCT_NO";

		this.lienAccountUpdateSql = "UPDATE T_ACCT SET "
				+ " ACCT_AVLBL_BAL = CASE WHEN BAL_ASOFDATETIME IS NULL OR BAL_ASOFDATETIME <= :messageDate THEN :ACCT_AVLBL_BAL ELSE ACCT_AVLBL_BAL END, "
				+ " ACCT_LDGR_BAL = CASE WHEN BAL_ASOFDATETIME IS NULL OR BAL_ASOFDATETIME <= :messageDate THEN :ACCT_LDGR_BAL ELSE ACCT_LDGR_BAL END, "
				+ " ACCT_LDGR_CRRNCY = CASE WHEN BAL_ASOFDATETIME IS NULL OR BAL_ASOFDATETIME <= :messageDate THEN :ACCT_LDGR_CRRNCY ELSE ACCT_LDGR_CRRNCY END, "
				+ " ACCT_AVALBL_CRRNCY = CASE WHEN BAL_ASOFDATETIME IS NULL OR BAL_ASOFDATETIME <= :messageDate THEN :ACCT_AVALBL_CRRNCY ELSE ACCT_AVALBL_CRRNCY END,  "
				+ " BAL_ASOFDATETIME = CASE WHEN BAL_ASOFDATETIME IS NULL OR BAL_ASOFDATETIME <= :messageDate THEN :messageDate ELSE BAL_ASOFDATETIME END, "
				+ " IS_BAL_SYNC = CASE WHEN BAL_ASOFDATETIME IS NULL OR BAL_ASOFDATETIME <= :messageDate THEN :IS_BAL_SYNC ELSE IS_BAL_SYNC END, "
				+ " LST_UPDT_SYS_ID = :LST_UPDT_SYS_ID, LST_UPDT_DTTM = :LST_UPDT_DTTM  "
				+ " WHERE ACCT_NO = :ACCT_NO ";

		this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

	/**
	 * This method is used to update the account details whenever the normal transaction
	 * notification is received on Finacle message queue. It will check for the balance as
	 * of date time with the provided date time and update the balance details only if the
	 * incoming date time value is greater.\
	 *
	 * @param transactionNotification : {@link TransactionNotification}
	 * @return {@link Integer}
	 */
	@Override
	public int updateAccountDetails(TransactionNotification transactionNotification) {
		MapSqlParameterSource parameterSource = new MapSqlParameterSource();
		parameterSource
				.addValue(ACCT_NO.name(), transactionNotification.getAccountNumber())
				.addValue(ACCT_LDGR_BAL.name(), transactionNotification.getLedgerBalance())
				.addValue(ACCT_AVLBL_BAL.name(), transactionNotification.getAvailableBalance())
				.addValue(LST_UPDT_SYS_ID.name(), "ONLINE")
				.addValue(LST_UPDT_DTTM.name(), new Date())
				.addValue(IS_BAL_SYNC.name(), "Y")
				.addValue("messageDate", transactionNotification.getRecordGenerationTime());

		return this.namedParameterJdbcTemplate.update(this.accountUpdateSql, parameterSource);
	}

	/**
	 * This method is used to update the account details whenever the Lien transaction
	 * notification is received on Finacle message queue. It will update the balance
	 * details.
	 *
	 * @param lienNotification : {@link LienNotification}
	 * @return {@link Integer}
	 */
	@Override
	public int updateLienAccountDetails(final LienNotification lienNotification) {
		MapSqlParameterSource parameterSource = new MapSqlParameterSource();
		parameterSource
				.addValue(ACCT_NO.name(), lienNotification.getAccountNumber())
				.addValue(ACCT_LDGR_BAL.name(), lienNotification.getLedgerBalance())
				.addValue(ACCT_AVLBL_BAL.name(), lienNotification.getAvailableBalance())
				.addValue(ACCT_AVALBL_CRRNCY.name(), lienNotification.getAvailableBalanceCurrencyCode())
				.addValue(ACCT_LDGR_CRRNCY.name(), lienNotification.getLedgerBalanceCurrencyCode())
				.addValue(LST_UPDT_SYS_ID.name(), "ONLINE")
				.addValue(LST_UPDT_DTTM.name(), new Date())
				.addValue(IS_BAL_SYNC.name(), "Y")
				.addValue("messageDate", lienNotification.getRecordGenerationTime());

		return this.namedParameterJdbcTemplate.update(this.lienAccountUpdateSql, parameterSource);
	}

}
