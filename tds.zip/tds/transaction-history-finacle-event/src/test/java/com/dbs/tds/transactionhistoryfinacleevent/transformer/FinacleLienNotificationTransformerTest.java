package com.dbs.tds.transactionhistoryfinacleevent.transformer;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.transform.Source;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import com.dbs.tds.dto.LienNotification;
import com.dbs.tds.transactionhistoryfinacleevent.transformer.FinacleLienNotificationTransformer;
import com.finacle.fixml.liennotification.AcctLienRec;
import com.finacle.fixml.liennotification.Amount;
import com.finacle.fixml.liennotification.Body;
import com.finacle.fixml.liennotification.FIXML;
import com.finacle.fixml.liennotification.Header;
import com.finacle.fixml.liennotification.RequestHeaderType;
import com.finacle.fixml.liennotification.RequestMessageInfoType;


/***
 * Unit test cases for {@link FinacleLienNotificationTransformer} methods.
 *
 * @author sivanarayana
 *
 * @version 1.0
 */
@RunWith(MockitoJUnitRunner.class)
public class FinacleLienNotificationTransformerTest {

	private static final String ACCT_NO = "12345";
	private static final double LEDGER_AMT = 100.00;
	private static final double AVAILABLE_AMT = 100.00;
	private static final String CURR_CODE = "INR";
	private static final String TEST_FIXML_REQUEST = "test-fixml-request";

	@InjectMocks
	private FinacleLienNotificationTransformer transformer;

	@Mock
	private Jaxb2Marshaller finacleLienNotificationMarshaller;


	@Test
	public void testTransformFIXML() throws DatatypeConfigurationException {
		FIXML fixml = fixml();
		LienNotification lienNotification = transformer.transform(fixml);
		assertNotNull(lienNotification);
		assertEquals(ACCT_NO, lienNotification.getAccountNumber());
		assertTrue(AVAILABLE_AMT == lienNotification.getAvailableBalance());
		assertTrue(LEDGER_AMT == lienNotification.getLedgerBalance());
		assertEquals(CURR_CODE, lienNotification.getLedgerBalanceCurrencyCode());
		assertEquals(CURR_CODE, lienNotification.getAvailableBalanceCurrencyCode());
	}

	@Test
	public void testTransformString() {
		FIXML fixml = mock(FIXML.class);
		when(finacleLienNotificationMarshaller.unmarshal(any(Source.class))).thenReturn(fixml);
		FIXML fixmlResult = transformer.transform(TEST_FIXML_REQUEST);
		assertNotNull(fixmlResult);
	}

	private FIXML fixml() throws DatatypeConfigurationException {
		FIXML fixml = new FIXML();
		
		RequestMessageInfoType requestMessageInfoType = new RequestMessageInfoType();
		requestMessageInfoType.setMessageDateTime(getDataTypeFactory().newXMLGregorianCalendar());
		
		RequestHeaderType requestHeaderType = new RequestHeaderType();
		requestHeaderType.setRequestMessageInfo(requestMessageInfoType);
		Header header = new Header();
		
		header.setRequestHeader(requestHeaderType);
		fixml.setHeader(header);
		
		Amount ledgerBalAmt = new Amount();
		ledgerBalAmt.setAmountValue(LEDGER_AMT);
		ledgerBalAmt.setCurrencyCode(CURR_CODE);
		
		Amount availBalAmt = new Amount();
		availBalAmt.setAmountValue(AVAILABLE_AMT);
		availBalAmt.setCurrencyCode(CURR_CODE);
		
		AcctLienRec acctLienRec = new AcctLienRec();
		acctLienRec.setAcctNumber(ACCT_NO);
		acctLienRec.setLedgerBalAmt(ledgerBalAmt);
		acctLienRec.setAvailBalAmt(availBalAmt);
		
		Body body = new Body();
		body.setAcctLienRec(acctLienRec);
		fixml.setBody(body);
		
		return fixml;
	}

	private static DatatypeFactory getDataTypeFactory() throws DatatypeConfigurationException {
		return DatatypeFactory.newInstance();
	}
}
