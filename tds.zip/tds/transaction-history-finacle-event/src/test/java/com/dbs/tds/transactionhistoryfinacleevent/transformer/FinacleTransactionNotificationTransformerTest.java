package com.dbs.tds.transactionhistoryfinacleevent.transformer;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.transform.Source;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistoryfinacleevent.transformer.FinacleTransactionNotificationTransformer;
import com.finacle.fixml.notification.AcctTrnRec;
import com.finacle.fixml.notification.Amount;
import com.finacle.fixml.notification.Body;
import com.finacle.fixml.notification.FIXML;
import com.finacle.fixml.notification.Header;
import com.finacle.fixml.notification.RequestHeaderType;
import com.finacle.fixml.notification.RequestMessageInfoType;

/***
 * Unit test cases for {@link FinacleTransactionNotificationTransformer} methods.
 *
 * @author sivanarayana
 *
 * @version 1.0
 */
@RunWith(MockitoJUnitRunner.class)
public class FinacleTransactionNotificationTransformerTest {

	private static final String TRAN_ID = "tran-id";
	private static final String ACCT_NO = "123456";
	private static final String PART_TRAN_SRL_NUM = "2341";
	private static final String TRAN_RMKS = "tran-remarks";
	private static final String TRAN_REF_NO = "tran-ref-no";
	private static final String PART_TRAN_TYPE = "part-tran-type";
	private static final String TEST_FIXML_REQUEST = "test-fixml-request";
	private static final String TRAN_PARTICULAR_CODE = "tran-particular-cd";
	private static final String CURR_CODE = "INR";
	private static final Double LEDGER_AMT = 100.00;
	private static final Double AVAILABLE_AMT = 90.00;
	private static final Double TRAN_AMT = 10.00;

	@InjectMocks
	private FinacleTransactionNotificationTransformer transformer;
	
	@Mock
	private Jaxb2Marshaller finacleTransactionMarshaller;

	@Test
	public void testTransformString() {
		FIXML fixml = mock(FIXML.class);
		when(finacleTransactionMarshaller.unmarshal(any(Source.class))).thenReturn(fixml);
		FIXML fixmlResult = transformer.transform(TEST_FIXML_REQUEST);
		assertNotNull(fixmlResult);
	}

	@Test
	public void testTransformFIXML() throws DatatypeConfigurationException {
		FIXML fixml = fixml();
		TransactionNotification transactionNotification = transformer.transform(fixml);
		assertNotNull(transactionNotification);
		assertEquals(ACCT_NO, transactionNotification.getAccountNumber());
		assertEquals(TRAN_ID, transactionNotification.getTransactionId());
		assertEquals(CURR_CODE, transactionNotification.getTransactionCurrencyCode());
		assertEquals(TRAN_PARTICULAR_CODE, transactionNotification.getTransactionParticularCode());
		assertEquals(TRAN_REF_NO, transactionNotification.getTransactionReferenceNumber());
	}

	private FIXML fixml() throws DatatypeConfigurationException {
		
		FIXML fixml = new FIXML();
		
		RequestMessageInfoType reqeustMessageInfo = new RequestMessageInfoType();
		reqeustMessageInfo.setMessageDateTime(getDataTypeFactory().newXMLGregorianCalendar());

		RequestHeaderType requestHeaderType = new RequestHeaderType();
		requestHeaderType.setRequestMessageInfo(reqeustMessageInfo);
		
		Header header = new Header();
		header.setRequestHeader(requestHeaderType);
		
		fixml.setHeader(header);
		
		Amount tranAmt = new Amount();
		tranAmt.setAmountValue(TRAN_AMT);
		tranAmt.setCurrencyCode(CURR_CODE);
		
		Amount ledgerBalAmt = new Amount();
		ledgerBalAmt.setAmountValue(LEDGER_AMT);
		ledgerBalAmt.setCurrencyCode(CURR_CODE);
		
		Amount availBalAmt = new Amount();
		availBalAmt.setAmountValue(AVAILABLE_AMT);
		availBalAmt.setCurrencyCode(CURR_CODE);
		
		AcctTrnRec acctTrnRec = new AcctTrnRec();
		acctTrnRec.setTrnID(TRAN_ID);
		acctTrnRec.setAcctNumber(ACCT_NO);
		acctTrnRec.setTrnCurCode(CURR_CODE);
		acctTrnRec.setLedgerBal(ledgerBalAmt);
		acctTrnRec.setAvailableBal(availBalAmt);
		acctTrnRec.setPartTrnSrlNum(PART_TRAN_SRL_NUM);
		acctTrnRec.setTrnDt(getDataTypeFactory().newXMLGregorianCalendar());
		acctTrnRec.setValueDt(getDataTypeFactory().newXMLGregorianCalendar());
		acctTrnRec.setPostedDate(getDataTypeFactory().newXMLGregorianCalendar());
		acctTrnRec.setTranParticularCode(TRAN_PARTICULAR_CODE);
		acctTrnRec.setTrnAmt(tranAmt);
		acctTrnRec.setPartTrnType(PART_TRAN_TYPE);
		acctTrnRec.setTranRefNo(TRAN_REF_NO);
		acctTrnRec.setTranRmks(TRAN_RMKS);
		
		Body body = new Body();
		body.setAcctTrnRec(acctTrnRec);
		
		fixml.setBody(body);
		
		return fixml;
	}

	private static DatatypeFactory getDataTypeFactory() throws DatatypeConfigurationException {
		return DatatypeFactory.newInstance();
	}
}
