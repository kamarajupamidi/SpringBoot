package com.dbs.tds.transactionhistoryfinacleevent.service;

import java.util.Date;

import com.dbs.tds.dto.LienNotification;
import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistoryfinacleevent.repository.AccountRepository;
import com.dbs.tds.transactionhistoryfinacleevent.repository.TransactionNotificationRepository;
import com.dbs.tds.transactionhistoryfinacleevent.service.FinacleLienNotificationService;
import com.dbs.tds.transactionhistoryfinacleevent.service.FinacleTransactionNotificationService;

import org.junit.Test;
import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

/***
 * Unit test cases for {@link FinacleTransactionNotificationService} methods.
 *
 * @author sivanarayana
 *
 * @version 1.0
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = { FinacleTransactionNotificationService.class, FinacleLienNotificationService.class })
public class FinacleTransactionNotificationServiceTest {

	private static final String ACCT_NO = "12345";
	private static final double BALANCE = 100.00;
	private static final String CURR_CODE = "INR";
	private static final String CREDIT = "CR";

	@Autowired
	private FinacleTransactionNotificationService finacleTransactionNotificationService;

	@Autowired
	private FinacleLienNotificationService finacleLienNotificationService;

	@MockBean
	private AccountRepository accountRepo;

	@MockBean
	private TransactionNotificationRepository transactionRepo;

	@Test
	public void testProcess() {
		final TransactionNotification transactionNotification = transactionNotification();
		final LienNotification lienNotification = lienNotification();
		when(accountRepo.updateAccountDetails(transactionNotification)).thenReturn(1);
		when(accountRepo.updateLienAccountDetails(lienNotification)).thenReturn(1);
		when(transactionRepo.insertDim(transactionNotification)).thenReturn(1);
		finacleTransactionNotificationService.process(transactionNotification);
		finacleLienNotificationService.process(lienNotification);
		verify(accountRepo).updateAccountDetails(transactionNotification);
		verify(transactionRepo).insertTransactionNotification(transactionNotification);
		verify(accountRepo).updateLienAccountDetails(lienNotification);
		verify(transactionRepo).insertDim(transactionNotification);
		verifyNoMoreInteractions(accountRepo, transactionRepo);
	}

	private TransactionNotification transactionNotification() {
		TransactionNotification transactionNotification = new TransactionNotification();
		transactionNotification.setAccountNumber(ACCT_NO);
		transactionNotification.setAccountCurrencyCode(CURR_CODE);
		transactionNotification.setAvailableBalance(BALANCE);
		transactionNotification.setLedgerBalance(BALANCE);
		transactionNotification.setRecordGenerationTime(new Date());
		transactionNotification.setPartTransactionType(CREDIT);
		return transactionNotification;
	}

	private LienNotification lienNotification() {
		LienNotification lienNotification = new LienNotification();
		lienNotification.setAccountNumber(ACCT_NO);
		lienNotification.setAvailableBalance(BALANCE);
		lienNotification.setLedgerBalance(BALANCE);
		lienNotification.setRecordGenerationTime(new Date());
		return lienNotification;
	}

}
