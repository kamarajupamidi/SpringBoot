package com.dbs.tds.transactionhistoryfinacleevent.repository.impl;

import java.util.Date;

import javax.sql.DataSource;

import com.dbs.tds.dto.LienNotification;
import com.dbs.tds.dto.TransactionNotification;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.mockito.internal.util.reflection.Whitebox.setInternalState;

/***
 * Unit test cases for {@link AccountRepositoryImpl} methods.
 *
 * @author sivanarayana
 *
 * @version 1.0
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = { AccountRepositoryImpl.class })
public class AccountRepositoryImplTest {

	private static final String ACCT_NO = "12345";

	private static final double BALANCE = 100.00;

	private static final String CURR_CODE = "INR";

	private static final String CREDIT = "CR";

	@Autowired
	private AccountRepositoryImpl accountRepoImpl;

	@MockBean
	private DataSource dataSource;

	@MockBean
	private NamedParameterJdbcTemplate accountUpdateJdbcTemplate;

	@Test
	public void testUpdateAccountDetails() {
		final TransactionNotification transactionNotification = getTranNotification();
		setInternalState(this.accountRepoImpl, "namedParameterJdbcTemplate", this.accountUpdateJdbcTemplate);
		when(this.accountUpdateJdbcTemplate.update(anyString(), any(MapSqlParameterSource.class)))
				.thenReturn(1);
		int result = this.accountRepoImpl.updateAccountDetails(transactionNotification);
		assertEquals(1, result);
		verify(this.accountUpdateJdbcTemplate).update(anyString(), any(MapSqlParameterSource.class));
		verifyNoMoreInteractions(this.accountUpdateJdbcTemplate);
	}

	@Test
	public void testUpdateLienAccountDetails() {
		final LienNotification lienNotification = getLienNotification();
		setInternalState(this.accountRepoImpl, "namedParameterJdbcTemplate", this.accountUpdateJdbcTemplate);
		when(this.accountUpdateJdbcTemplate.update(anyString(), any(MapSqlParameterSource.class)))
				.thenReturn(1);
		int result = this.accountRepoImpl.updateLienAccountDetails(lienNotification);
		assertEquals(1, result);
		verify(this.accountUpdateJdbcTemplate).update(anyString(), any(MapSqlParameterSource.class));
		verifyNoMoreInteractions(this.accountUpdateJdbcTemplate);
	}

	private TransactionNotification getTranNotification() {
		TransactionNotification tranNotification = new TransactionNotification();
		tranNotification.setAccountNumber(ACCT_NO);
		tranNotification.setAccountCurrencyCode(CURR_CODE);
		tranNotification.setAvailableBalance(BALANCE);
		tranNotification.setLedgerBalance(BALANCE);
		tranNotification.setRecordGenerationTime(new Date());
		tranNotification.setPartTransactionType(CREDIT);
		return tranNotification;
	}

	private LienNotification getLienNotification() {
		LienNotification lienNotificationObj = new LienNotification();
		lienNotificationObj.setAccountNumber(ACCT_NO);
		lienNotificationObj.setAvailableBalance(BALANCE);
		lienNotificationObj.setAvailableBalanceCurrencyCode(CURR_CODE);
		lienNotificationObj.setLedgerBalance(BALANCE);
		lienNotificationObj.setLedgerBalanceCurrencyCode(CURR_CODE);
		lienNotificationObj.setRecordGenerationTime(new Date());
		return lienNotificationObj;
	}
}
