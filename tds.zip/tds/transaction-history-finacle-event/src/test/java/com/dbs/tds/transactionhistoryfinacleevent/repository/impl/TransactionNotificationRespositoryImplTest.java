package com.dbs.tds.transactionhistoryfinacleevent.repository.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.mockito.internal.util.reflection.Whitebox.setInternalState;

import java.util.Date;

import javax.sql.DataSource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import com.dbs.tds.dto.TransactionNotification;
import com.dbs.tds.transactionhistoryfinacleevent.repository.impl.TransactionNotificationRespositoryImpl;

/***
 * Unit test cases for {@link TransactionNotificationRespositoryImpl} methods.
 *
 * @author sivanarayana
 *
 * @version 1.0
 */
@RunWith(MockitoJUnitRunner.class)
public class TransactionNotificationRespositoryImplTest {

	@InjectMocks
	private TransactionNotificationRespositoryImpl transactionNotificationRepoImpl;
	
	@Mock
	private SimpleJdbcInsert transactionHistoryInsert;
	
	@Mock
	private SimpleJdbcInsert dimInsert;
	
	@Mock
	private DataSource dataSource;
	
	@Before
	public void setup() {
		setInternalState(transactionNotificationRepoImpl, "transactionHistoryInsert", transactionHistoryInsert);
		setInternalState(transactionNotificationRepoImpl, "dimInsert", dimInsert);
	}
	
	@Test
	public void testInsertTransactionNotification() {
		final TransactionNotification transactionNotification = transactionNotification();
		when(transactionHistoryInsert.execute(any(MapSqlParameterSource.class))).thenReturn(1);
		int result = transactionNotificationRepoImpl.insertTransactionNotification(transactionNotification);
		assertEquals(1, result);
		verify(transactionHistoryInsert).execute(any(MapSqlParameterSource.class));
		verifyNoMoreInteractions(transactionHistoryInsert);
	}
	
	@Test
	public void testInsertDim() {
		final TransactionNotification transactionNotification = transactionNotification();
		when(dimInsert.execute(any(MapSqlParameterSource.class))).thenReturn(1);
		int result = transactionNotificationRepoImpl.insertDim(transactionNotification);
		assertEquals(1, result);
		verify(dimInsert).execute(any(MapSqlParameterSource.class));
		verifyNoMoreInteractions(dimInsert);
	}

	private TransactionNotification transactionNotification() {
		final Date testDate = new Date();
		TransactionNotification transactionNotification = new TransactionNotification();
		transactionNotification.setTransactionId("transaction-id");
		transactionNotification.setAccountNumber("12345");
		transactionNotification.setAccountCurrencyCode("INR");
		transactionNotification.setLedgerBalance(1000.00);
		transactionNotification.setAvailableBalance(100_000.00);
		transactionNotification.setRelatedRecordId("related-record-id");
		transactionNotification.setPartTransactionSerialNumber(1L);
		transactionNotification.setTransactionParticularCode("transaction-particular-code");
		transactionNotification.setTransactionParticulars("transaction particulars");
		transactionNotification.setTransactionAmount(10_000.00);
		transactionNotification.setTransactionCurrencyCode("SGD");
		transactionNotification.setPartTransactionType("CR");
		transactionNotification.setTransactionDate(testDate);
		transactionNotification.setValueDate(testDate);
		transactionNotification.setPostedDate(testDate);
		transactionNotification.setTransactionReferenceNumber("trans-ref-num");
		transactionNotification.setAdditionalReference("additional-ref");
		transactionNotification.setTranKey("M1232376876");
		transactionNotification.setRecordGenerationTime(testDate);
		return transactionNotification;
	}
}
