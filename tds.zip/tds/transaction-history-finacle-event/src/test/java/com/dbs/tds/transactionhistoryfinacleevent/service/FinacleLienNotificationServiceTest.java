package com.dbs.tds.transactionhistoryfinacleevent.service;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.dbs.tds.dto.LienNotification;
import com.dbs.tds.transactionhistoryfinacleevent.repository.AccountRepository;
import com.dbs.tds.transactionhistoryfinacleevent.service.FinacleLienNotificationService;

/***
 * Unit test cases for {@link FinacleLienNotificationService} methods.
 *
 * @author sivanarayana
 *
 * @version 1.0
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = { FinacleLienNotificationService.class })
public class FinacleLienNotificationServiceTest {

	private static final String ACCT_NO = "123456";
	private static final double BALANCE = 100.00;
	private static final String CURR_CODE = "INR";

	@Autowired
	private FinacleLienNotificationService finacleLienNotificationService;

	@MockBean
	private AccountRepository accountRepo;


	@Test
	public void testProcess() {
		final LienNotification lienNotification = lienNotification();
		when(accountRepo.updateLienAccountDetails(lienNotification)).thenReturn(1);
		finacleLienNotificationService.process(lienNotification);
		verify(accountRepo).updateLienAccountDetails(lienNotification);
		verifyNoMoreInteractions(accountRepo);
	}

	private LienNotification lienNotification() {
		LienNotification lienNotification = new LienNotification();
		lienNotification.setAccountNumber(ACCT_NO);
		lienNotification.setAvailableBalance(BALANCE);
		lienNotification.setAvailableBalanceCurrencyCode(CURR_CODE);
		lienNotification.setLedgerBalance(BALANCE);
		lienNotification.setLedgerBalanceCurrencyCode(CURR_CODE);
		lienNotification.setRecordGenerationTime(new Date());
		return lienNotification;
	}

}
