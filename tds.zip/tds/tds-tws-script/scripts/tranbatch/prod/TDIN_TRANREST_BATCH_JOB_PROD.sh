Date=`date '+%m%d%Y_%H%M%S%s'`
LogFile=/tdinnas/logs/TDIN_TRANREST_BATCH_JOB_PROD_$Date.log
touch $LogFile
chmod 777 $LogFile
echo "Transaction batch process" >> $LogFile
TARGET_URL=https://tdinweb.sgp.dbs.com:40101/transaction-history-batch/invokeFinacleBatchJob
for file in /tdinnas/finacletran/import/prod/*
  do
	echo "File name found : $file" >> $LogFile
	response=$(curl --insecure -F "file=@$file" $TARGET_URL)
	echo "Response = $response" >> $LogFile
	
       if [ $response == 'INVOKED_FINACLE_NOTIFICATION' ]; then
	   mv $file /tdinnas/finacletran/import/prod_processed/
	fi
done;

