#~~~~~~~~##################################################~~~~~~~~~~
# Name    : TDIN_TRANBAT_PROD_Files_Transfer.sh
# Version : 1.0
# Date    : 04-Dec-2017
# Author  : Srinivas Podugu
#
#
# Description
# -----------
# This program Transfers the source file to TDIN target location.
#
#
# Usage:  TDIN_TRANBAT_PROD_Files_Transfer.sh
#
# ------------------------------------------------------------------
# Date              Changed_by  Version_Change_Description
# ------------------------------------------------------------------
# 04-Dec-2017 Srinivas Podugu     1.0        first version
# ------------------------------------------------------------------

#!/bin/ksh
File_Gen_Path="tdinbg@x01gtdinbat1a.vsi.sgp.dbs.com:/tdinnas/finacletran/import/" #target location
#Variable declaration
Log_Path="/tdinnas/logs"
Source_Location="s2s8tdin1@gipssfs01a.sgp.dbs.com:/cbinfiles/tdin/DGBTRANBTCHNOTIFI*.txt"
Log_DtTm=`date '+%m%d%Y_%H%M%S%s'`
Log_File=$Log_Path/TDIN_TRANBAT_PROD_Files_Transfer_$Log_DtTm.log

echo -e "\n******************Ops Files Transfer Started******************"
echo -e "\nFiles are transferring from source location $Source_Dir/ to Indo target location: $File_Gen_Path" >>$Log_File

chmod 777 $Log_File
echo -e "Log file : $Log_File \n"

##-------------------------------- Clear 30 days older log-----------------------------
# find $Log_Path/TDIN_TRANBAT_PROD_Files_Transfer*.log -mtime +30 | xargs rm -f

scpg3  $Source_Location $File_Gen_Path
if [ $? -eq 0 ]; then
    echo -e "\nInter Files transfer successfully completed from SFS to TDIN Ops \n">>$Log_File
    ssh s2s8tdin1@gipssfs01a.sgp.dbs.com rm /cbinfiles/tdin/DGBTRANBTCHNOTIFI*.txt
else
    echo -e "File transfer failed for File : DGBSBABTCHNOTIFIXXXX --- Please check the log">>$Log_File
    exit 1
fi
