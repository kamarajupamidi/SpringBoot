Date=`date '+%m%d%Y_%H%M%S%s'`
LogFile=/tdinnas/logs/TDIN_ACCREST_BATCH_JOB_PROD_$Date.log
touch $LogFile
chmod 777 $LogFile
exitcode=0
echo "Account batch process" >> $LogFile
TARGET_URL=https://tdinweb.sgp.dbs.com:40101/account-history-finacle-batch/invokeFinacleAccountNotificationBatchJob
for file in /tdinnas/finacleacct/import/*.txt
  do
	echo "File name found : $file" >> $LogFile
	response=`curl --insecure -F "file=@$file" $TARGET_URL`
	echo "Response = $response" >> $LogFile

		if [ -z "$response" ]; then
			mv $file /tdinnas/finacleacct/error/
			exitcode=1
       	elif [ "$response" == "INVOKED_ACCOUNT_NOTIFICATION" ]; then
			mv $file /tdinnas/finacleacct/processed/
		else
			mv $file /tdinnas/finacleacct/error/
			exitcode=1
		fi
done;
exit $exitcode

