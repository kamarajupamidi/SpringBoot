Date=`date '+%m%d%Y_%H%M%S%s'`
LogFile=/tdinnas/logs/TDIN_ACCREST_BATCH_JOB_PROD_$Date.log
echo "Account batch process"
TARGET_URL=https://tdinweb.sgp.dbs.com:40101/account-history-finacle-batch/invokeFinacleAccountNotificationBatchJob
for file in /tdinnas/finacleacct/import/prod/*
  do
	echo "File name found : $file"
	response=$(curl --insecure -F "file=@$file" $TARGET_URL)
	echo "Response = $response"
	
       if [ $response == 'INVOKED_ACCOUNT_NOTIFICATION' ]; then
			mv $file /tdinnas/finacleacct/import/prod_processed/
	fi
done;
