Date=`date '+%m%d%Y_%H%M%S%s'`
LogFile=/tdinnas/logs/TDIN_LIENREST_BATCH_JOB_PROD_$Date.log
touch $LogFile
chmod 777 $LogFile
exitcode=0
echo "Account Lien batch process" >> $LogFile
TARGET_URL=https://tdinweb.sgp.dbs.com:40101/lien-notification-batch/invokeLienNotificationBatchJob
for file in /tdinnas/finaclelien/import/*.txt
  do
	echo "File name found : $file" >> $LogFile
	response=`curl --insecure -F "file=@$file" $TARGET_URL`
	echo "Response = $response" >> $LogFile
	
       	if [ -z "$response" ]; then
			mv $file /tdinnas/finaclelien/error/
			exitcode=1
		elif [ "$response" == "INVOKED_LIEN_NOTIFICATION" ]; then
	   		mv $file /tdinnas/finaclelien/processed/
	   	else
	   		mv $file /tdinnas/finaclelien/error/
	   		exitcode=1
		fi
done;

exit $exitcode


