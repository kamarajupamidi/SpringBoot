Date=`date '+%m%d%Y_%H%M%S%s'`
LogFile=/tdinnas/logs/TDIN_MTRESREST_BATCH_JOB_PROD_$Date.log
touch $LogFile
chmod 777 $LogFile
echo -e "\nInoking MoneyThor Resiliency\n" >> $LogFile
response=`curl --insecure https://tdinweb.sgp.dbs.com:40101/moneythor-resiliency/invokeMoneyThorResiliency`

if [ -z "$response" ]; then
	echo "Failed to invoke Moneythor resiliency"
	exit 1
elif [ "$response" == "SUCCESS :: Sent Transaction history to MoneyThor" ]; then
	echo "$response" >> $LogFile
else 
	echo "Failed invoking MoneyThor Resiliency $response" >> $LogFile
	exit 1
fi

