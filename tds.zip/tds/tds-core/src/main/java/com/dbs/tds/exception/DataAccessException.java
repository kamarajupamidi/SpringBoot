package com.dbs.tds.exception;

/**
 * This class is used as the exception which will be thrown whenever there is any
 * exception occurred during the data accessing.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public class DataAccessException extends RuntimeException {

	/**
	 * This field is used to store value for serialVersionUID which is of type {@link long
	 * }.
	 */
	private static final long serialVersionUID = 3069778477268575602L;

	/**
	 * This field is used to store value for message which is of type {@link String }.
	 */
	private final String message;

	/**
	 * Custom exception for retriving data operations
	 * @param message : {@link String}
	 * @param exception : {@link Exception}
	 */
	public DataAccessException(String message, Exception exception) {
		super(message, exception);
		this.message = message;
	}

	/**
	 * This method is used to get property message of class {@link DataAccessException }.
	 *
	 * @return message : {@link String }
	 */
	@Override
	public String getMessage() {
		return this.message;
	}

}
