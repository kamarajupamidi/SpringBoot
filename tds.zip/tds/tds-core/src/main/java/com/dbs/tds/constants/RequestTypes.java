package com.dbs.tds.constants;

/**
 * This enum is used for defining constants which will be used for request types. E2E
 * represents single request in which response is fetched CHILD represents orchestrated
 * request where more than one service is contacted to fetch the response
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public enum RequestTypes {
	E2E,
	CHILD
}