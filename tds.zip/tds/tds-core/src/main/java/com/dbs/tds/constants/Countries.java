package com.dbs.tds.constants;

/**
 * This enum is used for defining the names of the fields of supported counties for TDS
 * Application.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */

public enum Countries {
	SG,
	IN,
	ID,
	TW,
	CN,
	HK
}