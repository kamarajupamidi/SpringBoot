package com.dbs.tds.constants;

/**
 * This field is used to store application name to be used by ELKLOGGER
 */

public enum AppIdentifiers {
	APP_CODE("TDS");

	/**
	 * This field is used to store value for value which is of type {@link String }.
	 */
	private String value;

	/**
	 * This is used to initialize the enum property.
	 *
	 * @param value : {@link String}
	 */
	AppIdentifiers(String value) {
		this.value = value;
	}

	/**
	 * This method is used to return the value of the enum type.
	 *
	 * @return {@link String}
	 */
	public String value() {
		return this.value;
	}
}
