/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: MoneyThorTransactionResponse.java
 * Author: DBS Asia Hub 2
 * Date: Aug 29, 2017
 */
package com.dbs.moneythor.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * This Java class will act as the simple POJO for storing the details coming in the
 * Transaction Read/Update response from MoneyThor.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public class MoneyThorTransactionResponse {

	/**
	 * This field is used to store value for header which is of type
	 * {@link HeaderInfoMoneyThor }.
	 */
	@JsonProperty("header")
	private HeaderInfoMoneyThor header;

	/**
	 * This field is used to store value for payload which is of type
	 * {@link List}<{@link Transaction}>.
	 */
	@JsonProperty("payload")
	private List<Transaction> payload;

	/**
	 * This method is used to get property header of class
	 * {@link MoneyThorTransactionResponse }.
	 *
	 * @return header : {@link HeaderInfoMoneyThor }
	 */
	public HeaderInfoMoneyThor getHeader() {
		return this.header;
	}

	/**
	 * This method is used to set property header of class
	 * {@link MoneyThorTransactionResponse }.
	 *
	 * @param header : {@link HeaderInfoMoneyThor }
	 */
	public void setHeader(HeaderInfoMoneyThor header) {
		this.header = header;
	}

	/**
	 * This method is used to get property payload of class
	 * {@link MoneyThorTransactionResponse }.
	 *
	 * @return payload : {@link List} &lt; {@link Transaction} &gt;
	 */
	public List<Transaction> getPayload() {
		return this.payload;
	}

	/**
	 * This method is used to set property payload of class
	 * {@link MoneyThorTransactionResponse }.
	 *
	 * @param payload : {@link List} &lt; {@link Transaction} &gt;
	 */
	public void setPayload(List<Transaction> payload) {
		this.payload = payload;
	}

	/**
	 * This method is used to represent the current instance of the class in String
	 * format.
	 *
	 * @return {@link String}
	 */
	@Override
	public String toString() {
		return "MoneyThorTransactionResponse [header=" + this.header + ", payload=" + this.payload + "]";
	}

}
