/**
 * This file is property of DBS Bank Pvt Ltd.
 *
 * File Name: MoneyThorTxnEnrichmentResponse.java
 * Author: DBS Asia Hub 2
 * Date: Aug 18, 2017
 */
package com.dbs.moneythor.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * This Java class will act as the simple POJO for storing the details coming in the
 * transaction enrichment message from MoneyThor.
 *
 * @version 1.0
 */
public class MoneyThorTxnEnrichmentResponse {

	/**
	 * This field is used to store value for header which is of type
	 * {@link HeaderInfoMoneyThor }.
	 */
	@JsonProperty("header")
	private HeaderInfoMoneyThor header;

	/**
	 * This field is used to store value for payload which is of type {@link EnrichPayload
	 * }.
	 */
	@JsonProperty("payload")
	private EnrichPayload payload;

	/**
	 * This method is used to get property header of class
	 * {@link MoneyThorTxnEnrichmentResponse }.
	 *
	 * @return header : {@link HeaderInfoMoneyThor }
	 */
	public HeaderInfoMoneyThor getHeader() {
		return this.header;
	}

	/**
	 * This method is used to set property header of class
	 * {@link MoneyThorTxnEnrichmentResponse }.
	 *
	 * @param header : {@link HeaderInfoMoneyThor }
	 */
	public void setHeader(HeaderInfoMoneyThor header) {
		this.header = header;
	}

	/**
	 * This method is used to get property payload of class
	 * {@link MoneyThorTxnEnrichmentResponse }.
	 *
	 * @return enrichPayload : {@link EnrichPayload }
	 */
	public EnrichPayload getPayload() {
		return this.payload;
	}

	/**
	 * This method is used to set property payload of class
	 * {@link MoneyThorTxnEnrichmentResponse }.
	 *
	 * @param enrichPayload : {@link EnrichPayload }
	 */
	public void setPayload(EnrichPayload enrichPayload) {
		this.payload = enrichPayload;
	}

	@Override
	public String toString() {
		return "MoneyThorTxnEnrichmentResponse [header=" + this.header + ", payload=" + this.payload + "]";
	}

}
