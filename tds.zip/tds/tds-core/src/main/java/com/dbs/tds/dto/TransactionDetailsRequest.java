package com.dbs.tds.dto;

/***
 *
 * This class is a POJO class that contains properties of transaction details retrieval
 * request
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public class TransactionDetailsRequest {

	/**
	 * This field is used to store value for accountNumber which is of type {@link String
	 * }.
	 */
	private String accountNumber;

	/**
	 * This field is used to store value for tranKey which is of type {@link String }.
	 */
	private String tranKey;

	/**
	 * This method is used to get property accountNumber of class
	 * {@link TransactionDetailsRequest }.
	 *
	 * @return accountNumber : {@link String }
	 */
	public String getAccountNumber() {
		return this.accountNumber;
	}

	/**
	 * This method is used to set property accountNumber of class
	 * {@link TransactionDetailsRequest }.
	 *
	 * @param accountNumber : {@link String }
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * This method is used to get property tranKey of class
	 * {@link TransactionDetailsRequest }.
	 *
	 * @return tranKey : {@link String }
	 */
	public String getTranKey() {
		return this.tranKey;
	}

	/**
	 * This method is used to set property tranKey of class
	 * {@link TransactionDetailsRequest }.
	 *
	 * @param tranKey : {@link String }
	 */
	public void setTranKey(String tranKey) {
		this.tranKey = tranKey;
	}

	/**
	 * This method is used to represent the current object in String format.
	 *
	 * @return {@link String }
	 */
	@Override
	public String toString() {
		return "TransactionDetailsRequest [accountNumber=" + this.accountNumber + ", tranKey=" + this.tranKey + "]";
	}


}
