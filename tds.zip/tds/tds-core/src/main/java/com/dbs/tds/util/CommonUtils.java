package com.dbs.tds.util;

import java.sql.Blob;
import java.sql.SQLException;

import javax.sql.rowset.serial.SerialBlob;

import com.dbs.tds.exception.DataAccessException;

/**
 * This class contains common utility methods.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public class CommonUtils {

	/**
	 * private constructor.
	 */
	private CommonUtils() {
	}

	/***
	 * This method is used to convert a blob into String.
	 *
	 * @param blobData : {@link Blob}
	 * @return {@link String}
	 */
	public static String convertBlobToString(Blob blobData) {
		String value = null;
		long initialPosition = 1;
		try {
			if (blobData != null && blobData.length() > 0) {
				value = new String(blobData.getBytes(initialPosition, (int) blobData.length()));
			}
		}
		catch (SQLException e) {
			throw new DataAccessException("Unable to convert from blob to string", e);
		}
		return value;
	}

	/***
	 * This method is used to convert a String to Blob Object.
	 *
	 * @param data : {@link String}
	 * @return {@link Blob}
	 */
	public static Blob convertStringToBlob(String data) {
		Blob blobData = null;
		if (null != data) {
			try {
				return new SerialBlob(data.getBytes());
			}
			catch (SQLException e) {
				throw new DataAccessException("Unable to convert from String to blob", e);
			}
		}
		return blobData;
	}

	/**
	 * This method is used to confirm if the double value is Null or NaN.
	 *
	 * @param value : {@link Double}
	 * @return {@link Boolean}
	 */
	public static boolean isDoubleNullOrNan(Double value) {
		boolean result = false;
		if (null == value || value.isNaN()) {
			result = true;
		}
		return result;
	}
}
