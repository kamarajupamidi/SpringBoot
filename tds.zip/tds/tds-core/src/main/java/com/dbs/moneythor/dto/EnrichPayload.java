/**
 * This file is property of DBS Bank Pvt Ltd.
 *
 * File Name: EnrichPayload.java
 * Author: DBS Asia Hub 2
 * Date: Aug 18, 2017
 */
package com.dbs.moneythor.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * This Java class will act as the simple POJO for storing the details coming in the
 * message from MoneyThor.
 *
 * @version 1.0
 */
public class EnrichPayload {

	/**
	 * This field is used to store value for source which is of type {@link Source }.
	 */
	@JsonProperty("source")
	private Source source;

	/**
	 * This field is used to store value for customer which is of type {@link Customer }.
	 */
	@JsonProperty("customer")
	private Customer customer;

	/**
	 * This field is used to store value for account which is of type
	 * {@link AccountInfoMoneyThor }.
	 */
	@JsonProperty("account")
	private AccountInfoMoneyThor account;

	/**
	 * This field is used to store value for transactions which is of type
	 * {@link List}<{@link Transaction}>.
	 */
	@JsonProperty("transactions")
	private List<Transaction> transactions;

	/**
	 * This method is used to get property source of class {@link EnrichPayload }.
	 *
	 * @return source : {@link Source }
	 */
	public Source getSource() {
		return this.source;
	}

	/**
	 * This method is used to set property source of class {@link EnrichPayload }.
	 *
	 * @param source : {@link Source }
	 */
	public void setSource(Source source) {
		this.source = source;
	}

	/**
	 * This method is used to get property customer of class {@link EnrichPayload }.
	 *
	 * @return customer : {@link Customer }
	 */
	public Customer getCustomer() {
		return this.customer;
	}

	/**
	 * This method is used to set property customer of class {@link EnrichPayload }.
	 *
	 * @param customer : {@link Customer }
	 */
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	/**
	 * This method is used to get property account of class {@link EnrichPayload }.
	 *
	 * @return account : {@link AccountInfoMoneyThor }
	 */
	public AccountInfoMoneyThor getAccount() {
		return this.account;
	}

	/**
	 * This method is used to set property account of class {@link EnrichPayload }.
	 *
	 * @param account : {@link AccountInfoMoneyThor }
	 */
	public void setAccount(AccountInfoMoneyThor account) {
		this.account = account;
	}

	/**
	 * This method is used to get property transactions of class {@link EnrichPayload }.
	 *
	 * @return transactions : {@link List} &lt; {@link Transaction} &gt;
	 */
	public List<Transaction> getTransactions() {
		return this.transactions;
	}

	/**
	 * This method is used to set property transactions of class {@link EnrichPayload }.
	 *
	 * @param transactions : {@link List} &lt; {@link Transaction} &gt;
	 */
	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}

	/**
	 * This method is used to represent the current instance of the class in String
	 * format.
	 *
	 * @return {@link String}
	 */
	@Override
	public String toString() {
		return "EnrichPayload [source=" + this.source + ", customer=" + this.customer + ", account=" + this.account
				+ ", transactions="
				+ this.transactions + "]";
	}

}
