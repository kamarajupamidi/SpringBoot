/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: MoneyThorTransactionUpdateRequest.java
 * Author: DBS Asia Hub 2
 * Date: Aug 29, 2017
 */
package com.dbs.moneythor.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * This Java class will act as the simple POJO for storing the details which are being
 * sent to MoneyThor for Transaction Update.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public class MoneyThorTransactionUpdateRequest {

	/**
	 * This field is used to store value for key which is of type {@link String }.
	 */
	@JsonProperty("key")
	private String key;

	/**
	 * This field is used to store value for custome_fileds which is of type
	 * {@link List}<{@link CustomField}>.
	 */
	@JsonProperty("custom_fields")
	private List<CustomField> customFields;

	/**
	 * This method is used to get property key of class
	 * {@link MoneyThorTransactionUpdateRequest }.
	 *
	 * @return key : {@link String }
	 */
	public String getKey() {
		return this.key;
	}

	/**
	 * This method is used to set property key of class
	 * {@link MoneyThorTransactionUpdateRequest }.
	 *
	 * @param key : {@link String }
	 */
	public void setKey(String key) {
		this.key = key;
	}

	/**
	 * This method is used to get property {@link List} &lt; {@link CustomField} &gt; of
	 * class {@link MoneyThorTransactionUpdateRequest }.
	 *
	 * @return customFields : {@link List} &lt; {@link CustomField} &gt;
	 */
	public List<CustomField> getCustomFields() {
		return this.customFields;
	}

	/**
	 * This method is used to set property customFields of class
	 * {@link MoneyThorTransactionUpdateRequest }.
	 *
	 * @param customFields : {@link List} &lt; {@link CustomField} &gt;
	 */
	public void setCustomFields(List<CustomField> customFields) {
		this.customFields = customFields;
	}

	/**
	 * This method is used to represent the current instance in String format.
	 *
	 * @return {@link String}
	 */
	@Override
	public String toString() {
		return "MoneyThorTransactionUpdateRequest [key=" + this.key + ", custom_fields=" + this.customFields + "]";
	}

}
