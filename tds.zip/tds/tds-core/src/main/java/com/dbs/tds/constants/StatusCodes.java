package com.dbs.tds.constants;

/**
 * This enum is used for defining constants which will be used to specify error codes
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */

public enum StatusCodes {
	SUCCESS("0000"),
	FAILURE("4000");

	/**
	 * This field is used to store value for value which is of type {@link int }.
	 */
	private String value;

	/**
	 * This is used to initialize the enum property.
	 *
	 * @param value : {@link int}
	 */
	StatusCodes(String value) {
		this.value = value;
	}

	/**
	 * This method is used to return the value of the enum type.
	 *
	 * @return {@link int}
	 */
	public String value() {
		return this.value;
	}

}
