package com.dbs.moneythor.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * This Java class will act as the simple POJO for storing the details coming in the
 * message from MoneyThor.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 */
public class AccountInfoMoneyThor {

	/**
	 * This field is used to store value for accountKey which is of type {@link String }.
	 */
	@JsonProperty("account_key")
	private String accountKey;

	/**
	 * This field is used to store value for type which is of type {@link String }.
	 */
	@JsonProperty("type")
	private String type;

	/**
	 * This field is used to store value for number which is of type {@link String }.
	 */
	@JsonProperty("number")
	private String number;

	/**
	 * This field is used to store value for currency which is of type {@link String }.
	 */
	@JsonProperty("currency")
	private String currency;

	/**
	 * This method is used to get property account_key of class
	 * {@link AccountInfoMoneyThor }.
	 *
	 * @return account_key : {@link String }
	 */
	public String getAccountKey() {
		return this.accountKey;
	}

	/**
	 * This method is used to set property account_key of class
	 * {@link AccountInfoMoneyThor }.
	 *
	 * @param accountKey : {@link String }
	 */
	public void setAccountKey(String accountKey) {
		this.accountKey = accountKey;
	}

	/**
	 * This method is used to get property type of class {@link AccountInfoMoneyThor }.
	 *
	 * @return type : {@link String }
	 */
	public String getType() {
		return this.type;
	}

	/**
	 * This method is used to set property type of class {@link AccountInfoMoneyThor }.
	 *
	 * @param type : {@link String }
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * This method is used to get property number of class {@link AccountInfoMoneyThor }.
	 *
	 * @return number : {@link String }
	 */
	public String getNumber() {
		return this.number;
	}

	/**
	 * This method is used to set property number of class {@link AccountInfoMoneyThor }.
	 *
	 * @param number : {@link String }
	 */
	public void setNumber(String number) {
		this.number = number;
	}

	/**
	 * This method is used to get property currency of class {@link AccountInfoMoneyThor
	 * }.
	 *
	 * @return currency : {@link String }
	 */
	public String getCurrency() {
		return this.currency;
	}

	/**
	 * This method is used to set property currency of class {@link AccountInfoMoneyThor
	 * }.
	 *
	 * @param currency : {@link String }
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * This method is used to represent this class object in a String format.
	 *
	 * @return {@link String}
	 */
	@Override
	public String toString() {
		return "AccountInfoMoneyThor [account_key=" + this.accountKey + ", type=" + this.type + ", number="
				+ this.number + ", currency="
				+ this.currency + "]";
	}

}
