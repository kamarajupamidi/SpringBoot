package com.dbs.tds.dto;

import java.util.Date;

/***
 * This class contains properties of LienNotification
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public class LienNotification {

	/**
	 * This field is used to store value for accountNumber which is of type {@link String
	 * }.
	 */

	private String accountNumber;

	/**
	 * This field is used to store value for lienId which is of type {@link String }.
	 */

	private String lienId;

	/**
	 * This field is used to store value for lienRemarks which is of type {@link String }.
	 */

	/**
	 * This field is used to store value for lienRemarks which is of type {@link String }.
	 */

	private String lienRemarks;

	/**
	 * This field is used to store value for lienAmount which is of type {@link double }.
	 */

	private double lienAmount;

	/**
	 * This field is used to store value for lienStartDate which is of type {@link Date }.
	 */

	private Date lienStartDate;

	/**
	 * This field is used to store value for lienEndDate which is of type {@link Date }.
	 */

	private Date lienEndDate;

	/**
	 * This field is used to store value for ledgerBalanceCurrencyCode which is of type
	 * {@link String }.
	 */

	private String ledgerBalanceCurrencyCode;

	/**
	 * This field is used to store value for ledgerBalance which is of type {@link double
	 * }.
	 */

	private double ledgerBalance;

	/**
	 * This field is used to store value for availableBalanceCurrencyCode which is of type
	 * {@link String }.
	 */

	private String availableBalanceCurrencyCode;

	/**
	 * This field is used to store value for availableBalance which is of type
	 * {@link double }.
	 */

	private double availableBalance;

	/**
	 * This field is used to store value for recordGenerationTime which is of type
	 * {@link Date }.
	 */

	private Date recordGenerationTime;

	/**
	 * This field is used to store value for inputLine which is of type {@link String }.
	 */

	private String inputLine;

	/**
	 * This method is used to get property accountNumber of class {@link LienNotification
	 * }.
	 *
	 * @return accountNumber : {@link String }
	 */

	public String getAccountNumber() {
		return this.accountNumber;
	}

	/**
	 * This method is used to set property accountNumber of class {@link LienNotification
	 * }.
	 *
	 * @param accountNumber : {@link String }
	 */

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * This method is used to get property lienId of class {@link LienNotification }.
	 *
	 * @return lienId : {@link String }
	 */

	public String getLienId() {
		return this.lienId;
	}

	/**
	 * This method is used to set property lienId of class {@link LienNotification }.
	 *
	 * @param lienId : {@link String }
	 */

	public void setLienId(String lienId) {
		this.lienId = lienId;
	}

	/**
	 * This method is used to get property lienRemarks of class {@link LienNotification }.
	 *
	 * @return lienRemarks : {@link String }
	 */

	public String getLienRemarks() {
		return this.lienRemarks;
	}

	/**
	 * This method is used to set property lienRemarks of class {@link LienNotification }.
	 *
	 * @param lienRemarks : {@link String }
	 */

	public void setLienRemarks(String lienRemarks) {
		this.lienRemarks = lienRemarks;
	}

	/**
	 * This method is used to get property lienAmount of class {@link LienNotification }.
	 *
	 * @return lienAmount : {@link double }
	 */

	public double getLienAmount() {
		return this.lienAmount;
	}

	/**
	 * This method is used to set property lienAmount of class {@link LienNotification }.
	 *
	 * @param lienAmount : {@link double }
	 */

	public void setLienAmount(double lienAmount) {
		this.lienAmount = lienAmount;
	}

	/**
	 * This method is used to get property lienStartDate of class {@link LienNotification
	 * }.
	 *
	 * @return lienStartDate : {@link Date }
	 */

	public Date getLienStartDate() {
		return this.lienStartDate;
	}

	/**
	 * This method is used to set property lienStartDate of class {@link LienNotification
	 * }.
	 *
	 * @param lienStartDate : {@link Date }
	 */

	public void setLienStartDate(Date lienStartDate) {
		this.lienStartDate = lienStartDate;
	}

	/**
	 * This method is used to get property lienEndDate of class {@link LienNotification }.
	 *
	 * @return lienEndDate : {@link Date }
	 */

	public Date getLienEndDate() {
		return this.lienEndDate;
	}

	/**
	 * This method is used to set property lienEndDate of class {@link LienNotification }.
	 *
	 * @param lienEndDate : {@link Date }
	 */

	public void setLienEndDate(Date lienEndDate) {
		this.lienEndDate = lienEndDate;
	}

	/**
	 * This method is used to get property ledgerBalanceCurrencyCode of class
	 * {@link LienNotification }.
	 *
	 * @return ledgerBalanceCurrencyCode : {@link String }
	 */

	public String getLedgerBalanceCurrencyCode() {
		return this.ledgerBalanceCurrencyCode;
	}

	/**
	 * This method is used to set property ledgerBalanceCurrencyCode of class
	 * {@link LienNotification }.
	 *
	 * @param ledgerBalanceCurrencyCode : {@link String }
	 */

	public void setLedgerBalanceCurrencyCode(String ledgerBalanceCurrencyCode) {
		this.ledgerBalanceCurrencyCode = ledgerBalanceCurrencyCode;
	}

	/**
	 * This method is used to get property ledgerBalance of class {@link LienNotification
	 * }.
	 *
	 * @return ledgerBalance : {@link double }
	 */

	public double getLedgerBalance() {
		return this.ledgerBalance;
	}

	/**
	 * This method is used to set property ledgerBalance of class {@link LienNotification
	 * }.
	 *
	 * @param ledgerBalance : {@link double }
	 */

	public void setLedgerBalance(double ledgerBalance) {
		this.ledgerBalance = ledgerBalance;
	}

	/**
	 * This method is used to get property availableBalanceCurrencyCode of class
	 * {@link LienNotification }.
	 *
	 * @return availableBalanceCurrencyCode : {@link String }
	 */

	public String getAvailableBalanceCurrencyCode() {
		return this.availableBalanceCurrencyCode;
	}

	/**
	 * This method is used to set property availableBalanceCurrencyCode of class
	 * {@link LienNotification }.
	 *
	 * @param availableBalanceCurrencyCode : {@link String }
	 */

	public void setAvailableBalanceCurrencyCode(String availableBalanceCurrencyCode) {
		this.availableBalanceCurrencyCode = availableBalanceCurrencyCode;
	}

	/**
	 * This method is used to get property availableBalance of class
	 * {@link LienNotification }.
	 *
	 * @return availableBalance : {@link double }
	 */

	public double getAvailableBalance() {
		return this.availableBalance;
	}

	/**
	 * This method is used to set property availableBalance of class
	 * {@link LienNotification }.
	 *
	 * @param availableBalance : {@link double }
	 */

	public void setAvailableBalance(double availableBalance) {
		this.availableBalance = availableBalance;
	}

	/**
	 * This method is used to get property recordGenerationTime of class
	 * {@link LienNotification }.
	 *
	 * @return recordGenerationTime : {@link Date }
	 */

	public Date getRecordGenerationTime() {
		return this.recordGenerationTime;
	}

	/**
	 * This method is used to set property recordGenerationTime of class
	 * {@link LienNotification }.
	 *
	 * @param recordGenerationTime : {@link Date }
	 */

	public void setRecordGenerationTime(Date recordGenerationTime) {
		this.recordGenerationTime = recordGenerationTime;
	}

	/**
	 * This method is used to get property inputLine of class {@link LienNotification }.
	 *
	 * @return inputLine : {@link String }
	 */

	public String getInputLine() {
		return this.inputLine;
	}

	/**
	 * This method is used to set property inputLine of class {@link LienNotification }.
	 *
	 * @param inputLine : {@link String }
	 */

	public void setInputLine(String inputLine) {
		this.inputLine = inputLine;
	}

	/**
	 * This method is used to represent the current object in String format.
	 *
	 * @return {@link String }
	 */
	@Override
	public String toString() {
		return "LienNotification [accountNumber=" + this.accountNumber + ", lienId=" + this.lienId + ", lienRemarks="
				+ this.lienRemarks + ", lienAmount=" + this.lienAmount + ", lienStartDate=" + this.lienStartDate
				+ ", lienEndDate="
				+ this.lienEndDate + ", ledgerBalanceCurrencyCode=" + this.ledgerBalanceCurrencyCode
				+ ", ledgerBalance="
				+ this.ledgerBalance + ", availableBalanceCurrencyCode=" + this.availableBalanceCurrencyCode
				+ ", availableBalance=" + this.availableBalance + ", recordGenerationTime=" + this.recordGenerationTime
				+ ", inputLine=" + this.inputLine + "]";
	}

}
