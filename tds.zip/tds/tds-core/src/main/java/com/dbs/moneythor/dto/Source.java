/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: Source.java
 * Author: DBS Asia Hub 2
 * Date: Aug 18, 2017
 */
package com.dbs.moneythor.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * This Java class will act as the simple POJO for storing the details coming in the
 * message from MoneyThor.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 */
public class Source {

	/**
	 * This field is used to store value for name which is of type {@link String }.
	 */
	@JsonProperty("name")
	private String name;

	/**
	 * This method is used to get property name of class {@link Source }.
	 *
	 * @return name : {@link String }
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * This method is used to set property name of class {@link Source }.
	 *
	 * @param name : {@link String }
	 */
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Source [name=" + this.name + "]";
	}

}
