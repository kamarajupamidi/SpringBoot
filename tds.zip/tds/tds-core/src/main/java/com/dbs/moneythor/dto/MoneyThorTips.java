/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: MoneyThorTips.java
 * Author: DBS Asia Hub 2
 * Date: Nov 13, 2017
 */
package com.dbs.moneythor.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * This class will act as the simple POJO for storing the details coming in the message
 * from MoneyThor.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public class MoneyThorTips {

	/**
	 * This field is used to store value for tipKey which is of type {@link String }.
	 */
	@JsonProperty("tip_key")
	private String tipKey;

	/**
	 * This field is used to store value for title which is of type {@link String }.
	 */
	@JsonProperty("title")
	private String title;

	/**
	 * This field is used to store value for status which is of type {@link String }.
	 */
	@JsonProperty("status")
	private String status;

	/**
	 * This field is used to store value for creationDate which is of type {@link String
	 * }.
	 */
	@JsonProperty("creation")
	private String creationDate;

	/**
	 * This field is used to store value for origin which is of type {@link String }.
	 */
	@JsonProperty("origin")
	private String origin;

	/**
	 * This field is used to store value for runningFrom which is of type {@link String }.
	 */
	@JsonProperty("running_from")
	private String runningFrom;

	/**
	 * This field is used to store value for runningTo which is of type {@link String }.
	 */
	@JsonProperty("running_to")
	private String runningTo;

	/**
	 * This field is used to store value for latencyMode which is of type {@link String }.
	 */
	@JsonProperty("latency_mode")
	private String latencyMode;

	/**
	 * This field is used to store value for events which is of type {@link List}&lt;
	 * {@link Object} &gt;.
	 */
	@JsonProperty("events")
	private List<Object> events;

	/**
	 * This method is used to get property tipKey of class {@link MoneyThorTips }.
	 *
	 * @return tipKey : {@link String }
	 */
	public String getTipKey() {
		return this.tipKey;
	}

	/**
	 * This method is used to set property tipKey of class {@link MoneyThorTips }.
	 *
	 * @param tipKey : {@link String }
	 */
	public void setTipKey(String tipKey) {
		this.tipKey = tipKey;
	}

	/**
	 * This method is used to get property title of class {@link MoneyThorTips }.
	 *
	 * @return title : {@link String }
	 */
	public String getTitle() {
		return this.title;
	}

	/**
	 * This method is used to set property title of class {@link MoneyThorTips }.
	 *
	 * @param title : {@link String }
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * This method is used to get property status of class {@link MoneyThorTips }.
	 *
	 * @return status : {@link String }
	 */
	public String getStatus() {
		return this.status;
	}

	/**
	 * This method is used to set property status of class {@link MoneyThorTips }.
	 *
	 * @param status : {@link String }
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * This method is used to get property creationDate of class {@link MoneyThorTips }.
	 *
	 * @return creationDate : {@link String }
	 */
	public String getCreationDate() {
		return this.creationDate;
	}

	/**
	 * This method is used to set property creationDate of class {@link MoneyThorTips }.
	 *
	 * @param creationDate : {@link String }
	 */
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * This method is used to get property origin of class {@link MoneyThorTips }.
	 *
	 * @return origin : {@link String }
	 */
	public String getOrigin() {
		return this.origin;
	}

	/**
	 * This method is used to set property origin of class {@link MoneyThorTips }.
	 *
	 * @param origin : {@link String }
	 */
	public void setOrigin(String origin) {
		this.origin = origin;
	}

	/**
	 * This method is used to get property runningFrom of class {@link MoneyThorTips }.
	 *
	 * @return runningFrom : {@link String }
	 */
	public String getRunningFrom() {
		return this.runningFrom;
	}

	/**
	 * This method is used to set property runningFrom of class {@link MoneyThorTips }.
	 *
	 * @param runningFrom : {@link String }
	 */
	public void setRunningFrom(String runningFrom) {
		this.runningFrom = runningFrom;
	}

	/**
	 * This method is used to get property runningTo of class {@link MoneyThorTips }.
	 *
	 * @return runningTo : {@link String }
	 */
	public String getRunningTo() {
		return this.runningTo;
	}

	/**
	 * This method is used to set property runningTo of class {@link MoneyThorTips }.
	 *
	 * @param runningTo : {@link String }
	 */
	public void setRunningTo(String runningTo) {
		this.runningTo = runningTo;
	}

	/**
	 * This method is used to get property latencyMode of class {@link MoneyThorTips }.
	 *
	 * @return latencyMode : {@link String }
	 */
	public String getLatencyMode() {
		return this.latencyMode;
	}

	/**
	 * This method is used to set property latencyMode of class {@link MoneyThorTips }.
	 *
	 * @param latencyMode : {@link String }
	 */
	public void setLatencyMode(String latencyMode) {
		this.latencyMode = latencyMode;
	}

	/**
	 * This method is used to get property events of class {@link MoneyThorTips }.
	 *
	 * @return events : {@link List} &lt; {@link Object} &gt;
	 */
	public List<Object> getEvents() {
		return this.events;
	}

	/**
	 * This method is used to set property events of class {@link MoneyThorTips }.
	 *
	 * @param events : {@link List} &lt; {@link Object} &gt;
	 */
	public void setEvents(List<Object> events) {
		this.events = events;
	}

	/**
	 * This method is used to represent the current instance in String format.
	 *
	 * @return {@link String}
	 */
	@Override
	public String toString() {
		return "MoneyThorTips [tipKey=" + this.tipKey + ", title=" + this.title + ", status=" + this.status
				+ ", creationDate="
				+ this.creationDate + ", origin=" + this.origin + ", runningFrom=" + this.runningFrom + ", runningTo="
				+ this.runningTo
				+ ", latencyMode=" + this.latencyMode + ", events=" + this.events + "]";
	}

}
