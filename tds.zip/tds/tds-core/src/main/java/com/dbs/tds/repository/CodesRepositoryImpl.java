package com.dbs.tds.repository;

import java.util.List;

import com.dbs.tds.dto.Codes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

/***
 *
 * This class is used for populate or manage codes of T_XREF_CODES table
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Repository
public class CodesRepositoryImpl implements CodesRepository {

	private static final Logger LOGGER = LoggerFactory.getLogger(CodesRepositoryImpl.class);

	private static final String IS_TDIN = "IS_TDIN";

	private static final String DESCRIPTION = "DESCRIPTION";

	private static final String VALUE = "VALUE";

	private static final String NAME = "NAME";

	private static final String PROVIDER = "PROVIDER";

	private static final String CODE_TYPE = "CODE_TYPE";

	private static final String ORG_CODE = "ORG_CODE";

	private static final String COUNTRY_CODE = "COUNTRY_CODE";

	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	private String selectCodes;

	public CodesRepositoryImpl(JdbcTemplate jdbcTemplate) {
		this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate);
		this.selectCodes = "select * from T_XREF_CODES codes where codes.COUNTRY_CODE='IN' and upper(codes.CODE_TYPE)=:codeType and codes.IS_TDIN='Y'";
	}

	/***
	 *
	 * This method is used to load list of codes for a given specific code type.
	 * @param codeType : {@link String}
	 * @return codes {@link List} &lt; {@link Codes} &gt;
	 */
	@Override
	public List<Codes> getCodesByCodeType(String codeType) {
		LOGGER.info("Load all codes for codetype={}", codeType);
		Assert.notNull(codeType, "Code type cannot be null");

		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("codeType", codeType.toUpperCase());

		List<Codes> codeTypes = this.namedParameterJdbcTemplate.query(this.selectCodes,
				paramSource,
				(RowMapper<Codes>) (rs, rowNum) -> {
					Codes code = new Codes();
					code.setCountryCode(rs.getString(COUNTRY_CODE));
					code.setOrgCode(rs.getString(ORG_CODE));
					code.setCodeType(rs.getString(CODE_TYPE));
					code.setProvider(rs.getString(PROVIDER));
					code.setName(rs.getString(NAME));
					code.setValue(rs.getString(VALUE));
					code.setDescription(rs.getString(DESCRIPTION));
					code.setIstdin(rs.getString(IS_TDIN));
					return code;
				});

		LOGGER.info("Load all codes for codetype={}, number of codes={}", codeType, codeTypes.size());

		return codeTypes;
	}

}
