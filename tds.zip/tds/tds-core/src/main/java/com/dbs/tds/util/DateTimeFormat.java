package com.dbs.tds.util;

public enum DateTimeFormat {

	DATE_TIME_ISO("yyyy-MM-dd'T'HH:mm:ss.SSS"),
	DATE_FULL_ISO_WITHOUT_MILLI_SECONDS("yyyy-MM-dd'T'HH:mm:ss"),
	DATE("dd-MM-yyyy");

	private String pattern;

	DateTimeFormat(String pattern) {
		this.pattern = pattern;
	}

	public String pattern() {
		return pattern;
	}

}
