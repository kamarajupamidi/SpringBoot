/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: TransactionFields.java
 * Author: DBS Asia Hub 2
 * Date: Oct 13, 2017
 */
package com.dbs.tds.constants;

/**
 * This enum is used for defining the name of the fields of the Transaction table in TDS
 * DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public enum TransactionFields {

	TRANID,
	ACCTID,
	ACCTCURR,
	LEDGERBAL,
	AVAILABLEBAL,
	RELATEDRECID,
	TRANSEQNUM,
	TRANDATE,
	VALUEDATE,
	POSTINGDATE,
	TRANCODE,
	TRANDESC,
	AMOUNT,
	CURRENCY,
	TXNTYPE,
	RELATEDTRANREF,
	ADDNLREF,
	TRANKEY,
	EXT_TRANID,
	LST_UPDT_SYS_ID,
	LST_UPDT_DTTM;

}
