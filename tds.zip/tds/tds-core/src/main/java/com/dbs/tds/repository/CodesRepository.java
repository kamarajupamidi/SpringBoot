package com.dbs.tds.repository;

import java.util.List;

import com.dbs.tds.dto.Codes;

import org.springframework.stereotype.Repository;

/***
 *
 * This class is used for read list of codes from TDS DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Repository
public interface CodesRepository {

	/***
	 *
	 * This method is used to load list of codes for a given specific code type.
	 * @param codeType : {@link String}
	 * @return codes {@link List} &lt; {@link Codes} &gt;
	 */
	List<Codes> getCodesByCodeType(String codeType);
}
