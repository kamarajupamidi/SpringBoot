package com.dbs.tds.constants;

/**
 * This enum is used for defining constants which will be used for logging errors. TECH
 * represents technical failures FUNCTIONAL represents business case failures
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public enum ErrorConstants {
	TECH,
	FUNC
}