package com.dbs.moneythor.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * This Java class will act as the simple POJO for storing the details coming in the
 * message from MoneyThor.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 */
@JsonIgnoreProperties
public class Transaction {

	/**
	 * This field is used to store value for key which is of type {@link String }.
	 */
	@JsonProperty("key")
	private String key;

	/**
	 * This field is used to store value for currency which is of type {@link String }.
	 */
	@JsonProperty("currency")
	private String currency;

	/**
	 * This field is used to store value for amount which is of type {@link Double }.
	 */
	@JsonProperty("amount")
	private Double amount;

	/**
	 * This field is used to store value for description which is of type {@link String }.
	 */
	@JsonProperty("description")
	private String description;

	/**
	 * This field is used to store value for date which is of type {@link String }.
	 */
	@JsonProperty("date")
	private String date;

	/**
	 * This field is used to store value for balance which is of type {@link Double }.
	 */
	@JsonProperty("balance")
	private Double balance;

	/**
	 * This field is used to store value for movement which is of type {@link String }.
	 */
	@JsonProperty("movement")
	private String movement;

	/**
	 * This field is used to store value for type which is of type {@link String }.
	 */
	@JsonProperty("type")
	private String type;

	/**
	 * This field is used to store value for original_category which is of type
	 * {@link String }.
	 */
	@JsonProperty("original_category")
	private String originalCategory;

	/**
	 * This field is used to store value for extraction which is of type {@link String }.
	 */
	@JsonProperty("extraction")
	private String extraction;

	/**
	 * This field is used to store value for status which is of type {@link String }.
	 */
	@JsonProperty("status")
	private String status;

	/**
	 * This field is used to store value for account_key which is of type {@link String }.
	 */
	@JsonProperty("account_key")
	private String accountKey;

	/**
	 * This field is used to store value for is_new which is of type {@link boolean }.
	 */
	@JsonProperty("is_new")
	private boolean isNew;

	/**
	 * This field is used to store value for tips which is of type
	 * {@link List}&lt;{@link MoneyThorTips}&gt;.
	 */
	@JsonProperty("tips")
	private List<MoneyThorTips> tips;

	/**
	 * This field is used to store value for custom_fields which is of type
	 * {@link List}&lt; {@link CustomField} &gt;.
	 */
	@JsonProperty("custom_fields")
	private List<CustomField> customFields;

	/**
	 * This method is used to get property key of class {@link Transaction }.
	 *
	 * @return key : {@link String }
	 */
	public String getKey() {
		return this.key;
	}

	/**
	 * This method is used to set property key of class {@link Transaction }.
	 *
	 * @param key : {@link String }
	 */
	public void setKey(String key) {
		this.key = key;
	}

	/**
	 * This method is used to get property currency of class {@link Transaction }.
	 *
	 * @return currency : {@link String }
	 */
	public String getCurrency() {
		return this.currency;
	}

	/**
	 * This method is used to set property currency of class {@link Transaction }.
	 *
	 * @param currency : {@link String }
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * This method is used to get property amount of class {@link Transaction }.
	 *
	 * @return amount : {@link Double }
	 */
	public Double getAmount() {
		return this.amount;
	}

	/**
	 * This method is used to set property amount of class {@link Transaction }.
	 *
	 * @param amount : {@link Double }
	 */
	public void setAmount(Double amount) {
		this.amount = amount;
	}

	/**
	 * This method is used to get property description of class {@link Transaction }.
	 *
	 * @return description : {@link String }
	 */
	public String getDescription() {
		return this.description;
	}

	/**
	 * This method is used to set property description of class {@link Transaction }.
	 *
	 * @param description : {@link String }
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * This method is used to get property date of class {@link Transaction }.
	 *
	 * @return date : {@link String }
	 */
	public String getDate() {
		return this.date;
	}

	/**
	 * This method is used to set property date of class {@link Transaction }.
	 *
	 * @param date : {@link String }
	 */
	public void setDate(String date) {
		this.date = date;
	}

	/**
	 * This method is used to get property balance of class {@link Transaction }.
	 *
	 * @return balance : {@link Double }
	 */
	public Double getBalance() {
		return this.balance;
	}

	/**
	 * This method is used to set property balance of class {@link Transaction }.
	 *
	 * @param balance : {@link Double }
	 */
	public void setBalance(Double balance) {
		this.balance = balance;
	}

	/**
	 * This method is used to get property movement of class {@link Transaction }.
	 *
	 * @return movement : {@link String }
	 */
	public String getMovement() {
		return this.movement;
	}

	/**
	 * This method is used to set property movement of class {@link Transaction }.
	 *
	 * @param movement : {@link String }
	 */
	public void setMovement(String movement) {
		this.movement = movement;
	}

	/**
	 * This method is used to get property type of class {@link Transaction }.
	 *
	 * @return type : {@link String }
	 */
	public String getType() {
		return this.type;
	}

	/**
	 * This method is used to set property type of class {@link Transaction }.
	 *
	 * @param type : {@link String }
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * This method is used to get property original_category of class {@link Transaction
	 * }.
	 *
	 * @return originalCategory : {@link String }
	 */
	public String getOriginalCategory() {
		return this.originalCategory;
	}

	/**
	 * This method is used to set property original_category of class {@link Transaction
	 * }.
	 *
	 * @param originalCategory : {@link String }
	 */
	public void setOriginalCategory(String originalCategory) {
		this.originalCategory = originalCategory;
	}

	/**
	 * This method is used to get property extraction of class {@link Transaction }.
	 *
	 * @return extraction : {@link String }
	 */
	public String getExtraction() {
		return this.extraction;
	}

	/**
	 * This method is used to set property extraction of class {@link Transaction }.
	 *
	 * @param extraction : {@link String }
	 */
	public void setExtraction(String extraction) {
		this.extraction = extraction;
	}

	/**
	 * This method is used to get property status of class {@link Transaction }.
	 *
	 * @return status : {@link String }
	 */
	public String getStatus() {
		return this.status;
	}

	/**
	 * This method is used to set property status of class {@link Transaction }.
	 *
	 * @param status : {@link String }
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * This method is used to get property account_key of class {@link Transaction }.
	 *
	 * @return account_key : {@link String }
	 */
	public String getAccountKey() {
		return this.accountKey;
	}

	/**
	 * This method is used to set property account_key of class {@link Transaction }.
	 *
	 * @param accountKey : {@link String }
	 */
	public void setAccountKey(String accountKey) {
		this.accountKey = accountKey;
	}

	/**
	 * This method is used to get property is_new of class {@link Transaction }.
	 *
	 * @return is_new : {@link boolean }
	 */
	public boolean isIsNew() {
		return this.isNew;
	}

	/**
	 * This method is used to set property is_new of class {@link Transaction }.
	 *
	 * @param isNew : {@link boolean }
	 */
	public void setIsNew(boolean isNew) {
		this.isNew = isNew;
	}

	/**
	 * This method is used to get property tips of class {@link Transaction }.
	 *
	 * @return tips : {@link List}&lt;{@link MoneyThorTips}&gt;
	 */
	public List<MoneyThorTips> getTips() {
		return this.tips;
	}

	/**
	 * This method is used to set property tips of class {@link Transaction }.
	 *
	 * @param tips : {@link List}&lt;{@link MoneyThorTips}&gt;
	 */
	public void setTips(List<MoneyThorTips> tips) {
		this.tips = tips;
	}

	/**
	 * This method is used to get property custom_fields of class {@link Transaction }.
	 *
	 * @return custom_fields : {@link List} &lt; {@link CustomField} &gt;
	 */
	public List<CustomField> getCustomFields() {
		return this.customFields;
	}

	/**
	 * This method is used to set property custom_fields of class {@link Transaction }.
	 *
	 * @param customFields : {@link List} &lt; {@link CustomField} &gt;
	 */
	public void setCustomFields(List<CustomField> customFields) {
		this.customFields = customFields;
	}

	/**
	 * This method is used to represent the current instance in String format.
	 *
	 * @return {@link String}
	 */
	@Override
	public String toString() {
		return "Transaction [key=" + this.key + ", currency=" + this.currency + ", amount=" + this.amount
				+ ", description="
				+ this.description + ", date=" + this.date + ", balance=" + this.balance + ", movement=" + this.movement
				+ ", type=" + this.type
				+ ", originalCategory=" + this.originalCategory + ", extraction=" + this.extraction + ", status="
				+ this.status
				+ ", accountKey=" + this.accountKey + ", isNew=" + this.isNew + ", tips=" + this.tips
				+ ", customFields="
				+ this.customFields + "]";
	}

}
