package com.dbs.tds.dto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import com.dbs.tds.repository.CodesRepository;

import org.springframework.stereotype.Component;

@Component
public class CodeTypes {

	private static Map<String, String> schemeCodes = new HashMap<>();

	private static Map<String, String> prodtypes = new HashMap<>();

	private CodesRepository codesRepository;

	public CodeTypes(CodesRepository codesRepository) {
		this.codesRepository = codesRepository;
	}

	@PostConstruct
	public void loadSchemCodes() {
		List<Codes> codes = this.codesRepository.getCodesByCodeType("SchemeCodes");
		for (Codes code : codes) {
			schemeCodes.put(code.getName(), code.getValue());
		}

	}

	@PostConstruct
	public void loadprodTypeCodes() {
		List<Codes> codes = this.codesRepository.getCodesByCodeType("ProdType");
		for (Codes code : codes) {
			prodtypes.put(code.getName(), code.getValue());
		}

	}

	public Map<String, String> getSchemeCodes() {
		return schemeCodes;
	}

	public Map<String, String> getProdtypes() {
		return prodtypes;
	}

}
