package com.dbs.tds.dto;

import java.util.List;

public class TransactionHistoryResponse {

	private Integer totalCount;

	private List<TransactionNotification> transactions;

	private Integer lastIndex;

	private Integer maxRec;

	private Integer cursor;

	private Integer currentPageCount;

	public Integer getTotalCount() {
		return this.totalCount;
	}

	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}

	public List<TransactionNotification> getTransactions() {
		return this.transactions;
	}

	public void setTransactions(List<TransactionNotification> transactions) {
		this.transactions = transactions;
	}

	public Integer getLastIndex() {
		return this.lastIndex;
	}

	public void setLastIndex(Integer lastIndex) {
		this.lastIndex = lastIndex;
	}

	public Integer getMaxRec() {
		return this.maxRec;
	}

	public void setMaxRec(Integer maxRec) {
		this.maxRec = maxRec;
	}

	public Integer getCursor() {
		return this.cursor;
	}

	public void setCursor(Integer cursor) {
		this.cursor = cursor;
	}

	public Integer getCurrentPageCount() {
		return this.currentPageCount;
	}

	public void setCurrentPageCount(Integer currentPageCount) {
		this.currentPageCount = currentPageCount;
	}

	@Override
	public String toString() {
		return "TransactionHistoryResponse [totalCount=" + this.totalCount + ", transactions=" + this.transactions
				+ ", lastIndex=" + this.lastIndex + ", maxRec=" + this.maxRec + ", cursor=" + this.cursor
				+ ", currentPageCount="
				+ this.currentPageCount + "]";
	}

}
