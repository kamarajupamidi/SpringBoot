package com.dbs.moneythor.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * This Java class will act as the simple POJO for storing the Header details coming in
 * the transaction message from MoneyThor.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 */
public class HeaderInfoMoneyThor {

	/**
	 * This field is used to store value for success which is of type {@link Boolean }.
	 */
	@JsonProperty("success")
	private boolean success;

	/**
	 * This field is used to store value for error which is of type {@link Boolean }.
	 */
	@JsonProperty("error")
	private boolean error;

	/**
	 * This field is used to store value for authenticated which is of type {@link Boolean
	 * }.
	 */
	@JsonProperty("authenticated")
	private boolean authenticated;

	/**
	 * This field is used to store value for errorCode which is of type {@link String }.
	 */
	@JsonProperty("code")
	private String errorCode;

	/**
	 * This field is used to store value for errorMessage which is of type {@link String
	 * }.
	 */
	@JsonProperty("message")
	private String errorMessage;

	/**
	 * This method is used to get property success of class {@link HeaderInfoMoneyThor }.
	 *
	 * @return success : {@link Boolean }
	 */
	public boolean getSuccess() {
		return this.success;
	}

	/**
	 * This method is used to set property success of class {@link HeaderInfoMoneyThor }.
	 *
	 * @param success : {@link Boolean }
	 */
	public void setSuccess(boolean success) {
		this.success = success;
	}

	/**
	 * This method is used to get property error of class {@link HeaderInfoMoneyThor }.
	 *
	 * @return error : {@link boolean }
	 */
	public boolean getError() {
		return this.error;
	}

	/**
	 * This method is used to set property error of class {@link HeaderInfoMoneyThor }.
	 *
	 * @param error : {@link boolean }
	 */
	public void setError(boolean error) {
		this.error = error;
	}

	/**
	 * This method is used to get property authenticated of class
	 * {@link HeaderInfoMoneyThor }.
	 *
	 * @return authenticated : {@link boolean }
	 */
	public boolean getAuthenticated() {
		return this.authenticated;
	}

	/**
	 * This method is used to set property authenticated of class
	 * {@link HeaderInfoMoneyThor }.
	 *
	 * @param authenticated : {@link boolean }
	 */
	public void setAuthenticated(boolean authenticated) {
		this.authenticated = authenticated;
	}

	/**
	 * This method is used to get property errorCode of class {@link HeaderInfoMoneyThor
	 * }.
	 *
	 * @return errorCode : {@link String }
	 */
	public String getErrorCode() {
		return this.errorCode;
	}

	/**
	 * This method is used to set property errorCode of class {@link HeaderInfoMoneyThor
	 * }.
	 *
	 * @param errorCode : {@link String }
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * This method is used to get property errorMessage of class
	 * {@link HeaderInfoMoneyThor }.
	 *
	 * @return errorMessage : {@link String }
	 */
	public String getErrorMessage() {
		return this.errorMessage;
	}

	/**
	 * This method is used to set property errorMessage of class
	 * {@link HeaderInfoMoneyThor }.
	 *
	 * @param errorMessage : {@link String }
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * This method is used to represent the current instance of this class in String
	 * format.
	 *
	 * @return {@link String}
	 */
	@Override
	public String toString() {
		return "HeaderInfoMoneyThor [success=" + this.success + ", error=" + this.error + ", authenticated="
				+ this.authenticated
				+ ", errorCode=" + this.errorCode + ", errorMessage=" + this.errorMessage + "]";
	}

}