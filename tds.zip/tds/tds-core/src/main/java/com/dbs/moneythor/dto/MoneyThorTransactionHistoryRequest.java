/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: MoneyThorTransactionHistoryRequest.java
 * Author: DBS Asia Hub 2
 * Date: Oct 27, 2017
 */
package com.dbs.moneythor.dto;

import com.dbs.moneythor.constants.TransactionStatus;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * This class will act as the simple POJO for storing the details which are being sent to
 * MoneyThor for Transaction Read.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public class MoneyThorTransactionHistoryRequest {

	/**
	 * This field is used to store value for key which is of type {@link String }.
	 */
	@JsonProperty("key")
	private String key;

	/**
	 * This field is used to store value for accountType which is of type {@link String }.
	 */
	@JsonProperty("account_type")
	private String accountType;

	/**
	 * This field is used to store value for movement which is of type {@link String }.
	 */
	@JsonProperty("movement")
	private String movement;

	/**
	 * This field is used to store value for query which is of type {@link String }.
	 */
	@JsonProperty("query")
	private String query;

	/**
	 * 'authorized' or 'posted' or null for any.
	 */
	@JsonProperty("status")
	private TransactionStatus status;

	/**
	 * Index of the page to return, first page is 0, returns first page if null.
	 */
	@JsonProperty("page")
	private Integer page;

	/**
	 * Expand tip to include raw data: true or false.
	 */
	@JsonProperty("expand_tip")
	private Boolean expandTip;

	/**
	 * Number of transactions to return, 12 if null. If more transactions exist then count
	 * + 1 transactions will be returned.
	 */
	@JsonProperty("count")
	private Integer count;

	/**
	 * This method is used to get property key of class
	 * {@link MoneyThorTransactionHistoryRequest }.
	 *
	 * @return key : {@link String }
	 */
	public String getKey() {
		return this.key;
	}

	/**
	 * This method is used to set property key of class
	 * {@link MoneyThorTransactionHistoryRequest }.
	 *
	 * @param key : {@link String }
	 */
	public void setKey(String key) {
		this.key = key;
	}

	/**
	 * This method is used to get property accountType of class
	 * {@link MoneyThorTransactionHistoryRequest }.
	 *
	 * @return accountType : {@link String }
	 */
	public String getAccountType() {
		return this.accountType;
	}

	/**
	 * This method is used to set property accountType of class
	 * {@link MoneyThorTransactionHistoryRequest }.
	 *
	 * @param accountType : {@link String }
	 */
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	/**
	 * This method is used to get property movement of class
	 * {@link MoneyThorTransactionHistoryRequest }.
	 *
	 * @return movement : {@link String }
	 */
	public String getMovement() {
		return this.movement;
	}

	/**
	 * This method is used to set property movement of class
	 * {@link MoneyThorTransactionHistoryRequest }.
	 *
	 * @param movement : {@link String }
	 */
	public void setMovement(String movement) {
		this.movement = movement;
	}

	/**
	 * This method is used to get property query of class
	 * {@link MoneyThorTransactionHistoryRequest }.
	 *
	 * @return query : {@link String }
	 */
	public String getQuery() {
		return this.query;
	}

	/**
	 * This method is used to set property query of class
	 * {@link MoneyThorTransactionHistoryRequest }.
	 *
	 * @param query : {@link String }
	 */
	public void setQuery(String query) {
		this.query = query;
	}

	/**
	 * This method is used to get property status of class
	 * {@link MoneyThorTransactionHistoryRequest }.
	 *
	 * @return status : {@link TransactionStatus }
	 */
	public TransactionStatus getStatus() {
		return this.status;
	}

	/**
	 * This method is used to set property status of class
	 * {@link MoneyThorTransactionHistoryRequest }.
	 *
	 * @param status : {@link TransactionStatus }
	 */
	public void setStatus(TransactionStatus status) {
		this.status = status;
	}

	/**
	 * This method is used to get property page of class
	 * {@link MoneyThorTransactionHistoryRequest }.
	 *
	 * @return page : {@link Integer }
	 */
	public Integer getPage() {
		return this.page;
	}

	/**
	 * This method is used to set property page of class
	 * {@link MoneyThorTransactionHistoryRequest }.
	 *
	 * @param page : {@link Integer }
	 */
	public void setPage(Integer page) {
		this.page = page;
	}

	/**
	 * This method is used to get property expandTip of class
	 * {@link MoneyThorTransactionHistoryRequest }.
	 *
	 * @return expandTip : {@link Boolean }
	 */
	public Boolean getExpandTip() {
		return this.expandTip;
	}

	/**
	 * This method is used to set property expandTip of class
	 * {@link MoneyThorTransactionHistoryRequest }.
	 *
	 * @param expandTip : {@link Boolean }
	 */
	public void setExpandTip(Boolean expandTip) {
		this.expandTip = expandTip;
	}

	/**
	 * This method is used to get property count of class
	 * {@link MoneyThorTransactionHistoryRequest }.
	 *
	 * @return count : {@link Integer }
	 */
	public Integer getCount() {
		return this.count;
	}

	/**
	 * This method is used to set property count of class
	 * {@link MoneyThorTransactionHistoryRequest }.
	 *
	 * @param count : {@link Integer }
	 */
	public void setCount(Integer count) {
		this.count = count;
	}

	/**
	 * This method is used to represent the current instance in String format.
	 *
	 * @return {@link String}
	 */
	@Override
	public String toString() {
		return "MoneyThorTransactionHistoryRequest [key=" + this.key + ", accountType=" + this.accountType
				+ ", movement="
				+ this.movement + ", query=" + this.query + ", status=" + this.status + ", page=" + this.page
				+ ", expandTip=" + this.expandTip
				+ ", count=" + this.count + "]";
	}

}
