package com.dbs.tds.dto;

/***
 *
 * This class is a POJO class that contains properties of transaction details
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public class TransactionDetailsResponse {

	/**
	 * This field is used to store value for transactionDetails which is of type
	 * {@link TransactionNotification }.
	 */
	private TransactionNotification transactionDetails;

	/**
	 * This method is used to get property transactionDetails of class
	 * {@link TransactionDetailsResponse }.
	 *
	 * @return transactionDetails : {@link TransactionNotification }
	 */
	public TransactionNotification getTransactionDetails() {
		return this.transactionDetails;
	}

	/**
	 * This method is used to set property transactionDetails of class
	 * {@link TransactionDetailsResponse }.
	 *
	 * @param transactionDetails : {@link TransactionNotification }
	 */
	public void setTransactionDetails(TransactionNotification transactionDetails) {
		this.transactionDetails = transactionDetails;
	}

	/**
	 * This method is used to get String representation of TransactionDetailsResponse
	 * @return
	 */
	@Override
	public String toString() {
		return "TransactionDetailsResponse [transactionDetails=" + this.transactionDetails + "]";
	}



}
