/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: TransactionImageFields.java
 * Author: DBS Asia Hub 2
 * Date: Oct 13, 2017
 */
package com.dbs.tds.constants;

/**
 * This enum is used for defining the name of the fields of the Transaction Image table in
 * TDS DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public enum TransactionImageFields {

	TRANKEY,
	IMAGE,
	LST_UPDT_SYS_ID,
	LST_UPDT_DTTM;

}
