package com.dbs.tds.config;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.dbs.tds")
public class CoreConfiguration {

}
