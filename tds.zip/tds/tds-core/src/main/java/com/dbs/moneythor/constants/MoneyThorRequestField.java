/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: MoneyThorRequestField.java
 * Author: DBS Asia Hub 2
 * Date: Sep 1, 2017
 */
package com.dbs.moneythor.constants;

/**
 * This enum is used for defining constants which will be used for construction MoneyThor
 * Request.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public enum MoneyThorRequestField {

	FALSE("false"),
	TRUE("true"),
	NULL("null"),
	COUNT("count"),
	EXPAND_TIP("expand_tip"),
	PAGE("page"),
	EQUAL("="),
	STATUS("status"),
	AMPERSAND("&"),
	QUESTION("?"),
	READ("read"),
	UPDATE("update");

	/**
	 * This field is used to store value for value which is of type {@link String }.
	 */
	private String value;

	/**
	 * This is used to initialize the enum property.
	 *
	 * @param value : {@link String}
	 */
	MoneyThorRequestField(String value) {
		this.value = value;
	}

	/**
	 * This method is used to return the value of the enum type.
	 *
	 * @return {@link String}
	 */
	public String value() {
		return this.value;
	}

}
