/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: AccountFields.java
 * Author: DBS Asia Hub 2
 * Date: Oct 13, 2017
 */
package com.dbs.tds.constants;

/**
 * This enum is used for defining the name of the fields of the Account table in TDS DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public enum AccountFields {

	ACCT_NO,
	ACCT_NAME,
	ACCT_TYP,
	ACCT_AVLBL_BAL,
	ACCT_SCHM_CODE,
	ACCT_LDGR_BAL,
	IS_BAL_SYNC,
	LST_UPDT_SYS_ID,
	LST_UPDT_DTTM,
	ACCT_LDGR_CRRNCY,
	ACCT_AVALBL_CRRNCY,
	VENDR_LST_UPDT_DTTM,
	BAL_ASOFDATETIME;

}
