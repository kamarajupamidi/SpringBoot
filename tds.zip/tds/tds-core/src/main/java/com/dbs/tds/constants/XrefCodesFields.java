/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: XrefCodesFields.java
 * Author: DBS Asia Hub 2
 * Date: Oct 13, 2017
 */
package com.dbs.tds.constants;

/**
 * This enum is used for defining the name of the fields of the Xref Code table in TDS DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public enum XrefCodesFields {

	ID,
	COUNTRY_CODE,
	ORG_CODE,
	CODE_TYPE,
	PROVIDER,
	NAME,
	VALUE,
	DESCRIPTION,
	IS_TDIN;

}
