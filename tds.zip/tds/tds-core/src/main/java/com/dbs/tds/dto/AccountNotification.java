/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: AccountNotification.java
 * Author: DBS Asia Hub 2
 * Date: Sep 28, 2017
 */
package com.dbs.tds.dto;

import java.util.Date;

/**
 * This class is used as POJO similar to the Account Table in TDS DB to store account
 * details.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public class AccountNotification {

	private String inputLine;

	/**
	 * This field is used to store value for accountNumber which is of type {@link String
	 * }.
	 */
	private String accountNumber;

	private String accountName;

	/**
	 * This field is used to store value for accountType which is of type {@link String }.
	 */
	private String accountType;

	/**
	 * This field is used to store value for accountAvailableBalance which is of type
	 * {@link Double }.
	 */
	private Double accountAvailableBalance;

	/**
	 * This field is used to store value for accountAvailableCurrency which is of type
	 * {@link String }.
	 */
	private String accountAvailableCurrency;

	/**
	 * This field is used to store value for accountSchemaCode which is of type
	 * {@link String }.
	 */
	private String accountSchemaCode;

	/**
	 * This field is used to store value for accountLedgerBalance which is of type
	 * {@link Double }.
	 */
	private Double accountLedgerBalance;

	/**
	 * This field is used to store value for accountLedgerCurrency which is of type
	 * {@link String }.
	 */
	private String accountLedgerCurrency;

	/**
	 * This field is used to store value for isBalSyncFlag which is of type {@link String
	 * }.
	 */
	private String isBalSyncFlag;

	/**
	 * This field is used to store value for balanceAsOfDateTm which is of type
	 * {@link Date }.
	 */
	private Date balanceAsOfDateTm;

	/**
	 * This field is used to store value for lastUpdtSysId which is of type {@link String
	 * }.
	 */
	private String lastUpdtSysId;

	/**
	 * This field is used to store value for lastUpdtDtTm which is of type {@link Date }.
	 */
	private Date lastUpdtDtTm;

	/**
	 * This field is used to store value for success which is of type {@link boolean }.
	 */
	private boolean success;

	/**
	 * This field is used to store value for errorCode which is of type {@link String }.
	 */
	private String errorCode;

	/**
	 * This field is used to store value for errorDesc which is of type {@link String }.
	 */
	private String errorDesc;

	private Date recordGenerationTime;

	/**
	 * This method is used to get property accountNumber of class
	 * {@link AccountNotification }.
	 *
	 * @return accountNumber : {@link String }
	 */
	public String getAccountNumber() {
		return this.accountNumber;
	}

	/**
	 * This method is used to set property accountNumber of class
	 * {@link AccountNotification }.
	 *
	 * @param accountNumber : {@link String }
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * This method is used to get property accountType of class {@link AccountNotification
	 * }.
	 *
	 * @return accountType : {@link String }
	 */
	public String getAccountType() {
		return this.accountType;
	}

	/**
	 * This method is used to set property accountType of class {@link AccountNotification
	 * }.
	 *
	 * @param accountType : {@link String }
	 */
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	/**
	 * This method is used to get property accountAvailableBalance of class
	 * {@link AccountNotification }.
	 *
	 * @return accountAvailableBalance : {@link Double }
	 */
	public Double getAccountAvailableBalance() {
		return this.accountAvailableBalance;
	}

	/**
	 * This method is used to set property accountAvailableBalance of class
	 * {@link AccountNotification }.
	 *
	 * @param accountAvailableBalance : {@link Double }
	 */
	public void setAccountAvailableBalance(Double accountAvailableBalance) {
		this.accountAvailableBalance = accountAvailableBalance;
	}

	/**
	 * This method is used to get property accountAvailableCurrency of class
	 * {@link AccountNotification }.
	 *
	 * @return accountAvailableCurrency : {@link String }
	 */
	public String getAccountAvailableCurrency() {
		return this.accountAvailableCurrency;
	}

	/**
	 * This method is used to set property accountAvailableCurrency of class
	 * {@link AccountNotification }.
	 *
	 * @param accountAvailableCurrency : {@link String }
	 */
	public void setAccountAvailableCurrency(String accountAvailableCurrency) {
		this.accountAvailableCurrency = accountAvailableCurrency;
	}

	/**
	 * This method is used to get property accountSchemaCode of class
	 * {@link AccountNotification }.
	 *
	 * @return accountSchemaCode : {@link String }
	 */
	public String getAccountSchemaCode() {
		return this.accountSchemaCode;
	}

	/**
	 * This method is used to set property accountSchemaCode of class
	 * {@link AccountNotification }.
	 *
	 * @param accountSchemaCode : {@link String }
	 */
	public void setAccountSchemaCode(String accountSchemaCode) {
		this.accountSchemaCode = accountSchemaCode;
	}

	/**
	 * This method is used to get property accountLedgerBalance of class
	 * {@link AccountNotification }.
	 *
	 * @return accountLedgerBalance : {@link Double }
	 */
	public Double getAccountLedgerBalance() {
		return this.accountLedgerBalance;
	}

	/**
	 * This method is used to set property accountLedgerBalance of class
	 * {@link AccountNotification }.
	 *
	 * @param accountLedgerBalance : {@link Double }
	 */
	public void setAccountLedgerBalance(Double accountLedgerBalance) {
		this.accountLedgerBalance = accountLedgerBalance;
	}

	/**
	 * This method is used to get property accountLedgerCurrency of class
	 * {@link AccountNotification }.
	 *
	 * @return accountLedgerCurrency : {@link String }
	 */
	public String getAccountLedgerCurrency() {
		return this.accountLedgerCurrency;
	}

	/**
	 * This method is used to set property accountLedgerCurrency of class
	 * {@link AccountNotification }.
	 *
	 * @param accountLedgerCurrency : {@link String }
	 */
	public void setAccountLedgerCurrency(String accountLedgerCurrency) {
		this.accountLedgerCurrency = accountLedgerCurrency;
	}

	/**
	 * This method is used to get property isBalSyncFlag of class
	 * {@link AccountNotification }.
	 *
	 * @return isBalSyncFlag : {@link String }
	 */
	public String getIsBalSyncFlag() {
		return this.isBalSyncFlag;
	}

	/**
	 * This method is used to set property isBalSyncFlag of class
	 * {@link AccountNotification }.
	 *
	 * @param isBalSyncFlag : {@link String }
	 */
	public void setIsBalSyncFlag(String isBalSyncFlag) {
		this.isBalSyncFlag = isBalSyncFlag;
	}

	/**
	 * This method is used to get property balanceAsOfDateTm of class
	 * {@link AccountNotification }.
	 *
	 * @return balanceAsOfDateTm : {@link Date }
	 */
	public Date getBalanceAsOfDateTm() {
		return this.balanceAsOfDateTm;
	}

	/**
	 * This method is used to set property balanceAsOfDateTm of class
	 * {@link AccountNotification }.
	 *
	 * @param balanceAsOfDateTm : {@link Date }
	 */
	public void setBalanceAsOfDateTm(Date balanceAsOfDateTm) {
		this.balanceAsOfDateTm = balanceAsOfDateTm;
	}

	/**
	 * This method is used to get property lastUpdtSysId of class
	 * {@link AccountNotification }.
	 *
	 * @return lastUpdtSysId : {@link String }
	 */
	public String getLastUpdtSysId() {
		return this.lastUpdtSysId;
	}

	/**
	 * This method is used to set property lastUpdtSysId of class
	 * {@link AccountNotification }.
	 *
	 * @param lastUpdtSysId : {@link String }
	 */
	public void setLastUpdtSysId(String lastUpdtSysId) {
		this.lastUpdtSysId = lastUpdtSysId;
	}

	/**
	 * This method is used to get property lastUpdtDtTm of class
	 * {@link AccountNotification }.
	 *
	 * @return lastUpdtDtTm : {@link Date }
	 */
	public Date getLastUpdtDtTm() {
		return this.lastUpdtDtTm;
	}

	/**
	 * This method is used to set property lastUpdtDtTm of class
	 * {@link AccountNotification }.
	 *
	 * @param lastUpdtDtTm : {@link Date }
	 */
	public void setLastUpdtDtTm(Date lastUpdtDtTm) {
		this.lastUpdtDtTm = lastUpdtDtTm;
	}

	/**
	 * This method is used to get property success of class {@link AccountNotification }.
	 *
	 * @return success : {@link boolean }
	 */
	public boolean isSuccess() {
		return this.success;
	}

	/**
	 * This method is used to set property success of class {@link AccountNotification }.
	 *
	 * @param success : {@link boolean }
	 */
	public void setSuccess(boolean success) {
		this.success = success;
	}

	/**
	 * This method is used to get property errorCode of class {@link AccountNotification
	 * }.
	 *
	 * @return errorCode : {@link String }
	 */
	public String getErrorCode() {
		return this.errorCode;
	}

	/**
	 * This method is used to set property errorCode of class {@link AccountNotification
	 * }.
	 *
	 * @param errorCode : {@link String }
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * This method is used to get property errorDesc of class {@link AccountNotification
	 * }.
	 *
	 * @return errorDesc : {@link String }
	 */
	public String getErrorDesc() {
		return this.errorDesc;
	}

	/**
	 * This method is used to set property errorDesc of class {@link AccountNotification
	 * }.
	 *
	 * @param errorDesc : {@link String }
	 */
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	public Date getRecordGenerationTime() {
		return this.recordGenerationTime;
	}

	public void setRecordGenerationTime(Date recordGenerationTime) {
		this.recordGenerationTime = recordGenerationTime;
	}

	public String getInputLine() {
		return this.inputLine;
	}

	public void setInputLine(String inputLine) {
		this.inputLine = inputLine;
	}

	public String getAccountName() {
		return this.accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	@Override
	public String toString() {
		return "AccountNotification [accountNumber=" + this.accountNumber + ", accountName=" + this.accountName
				+ ", accountType="
				+ this.accountType + ", accountAvailableBalance=" + this.accountAvailableBalance
				+ ", accountAvailableCurrency="
				+ this.accountAvailableCurrency + ", accountSchemaCode=" + this.accountSchemaCode
				+ ", accountLedgerBalance="
				+ this.accountLedgerBalance + ", accountLedgerCurrency=" + this.accountLedgerCurrency
				+ ", isBalSyncFlag="
				+ this.isBalSyncFlag + ", balanceAsOfDateTm=" + this.balanceAsOfDateTm + ", lastUpdtSysId="
				+ this.lastUpdtSysId
				+ ", lastUpdtDtTm=" + this.lastUpdtDtTm + ", success=" + this.success + ", errorCode=" + this.errorCode
				+ ", errorDesc=" + this.errorDesc + ", recordGenerationTime=" + this.recordGenerationTime + "]";
	}

}
