/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: TransactionNotification.java
 * Author: DBS Asia Hub 2
 * Date: Aug 18, 2017
 */
package com.dbs.tds.dto;

import java.sql.Blob;
import java.util.Date;

/**
 * This class is used as java POJO class for storing Transaction Notification Details,
 * which are coming from Different systems and this instance will be used to store details
 * which will be forwarded to Services to interact with DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public class TransactionNotification {

	/**
	 * This field is used to store value for inputLine which is of type {@link String }.
	 */
	private String inputLine;

	/**
	 * This field is used to store value for transactionDate which is of type {@link Date
	 * }.
	 */
	private Date transactionDate;

	/**
	 * This field is used to store value for valueDate which is of type {@link Date }.
	 */
	private Date valueDate;

	/**
	 * This field is used to store value for transactionId which is of type {@link String
	 * }.
	 */
	private String transactionId;

	/**
	 * This field is used to store value for transactionCurrencyCode which is of type
	 * {@link String }.
	 */
	private String transactionCurrencyCode;

	/**
	 * This field is used to store value for transactionType which is of type
	 * {@link String }.
	 */
	private String transactionType;

	/**
	 * This field is used to store value for transactionParticulars which is of type
	 * {@link String }.
	 */
	private String transactionParticulars;

	/**
	 * This field is used to store value for relatedRecordId which is of type
	 * {@link String }.
	 */
	private String relatedRecordId;

	/**
	 * This field is used to store value for additionalReference which is of type
	 * {@link String }.
	 */
	private String additionalReference;

	/**
	 * This field is used to store value for transactionReferenceNumber which is of type
	 * {@link String }.
	 */
	private String transactionReferenceNumber;

	/**
	 * This field is used to store value for transactionAmount which is of type
	 * {@link Double }.
	 */
	private Double transactionAmount;

	/**
	 * This field is used to store value for partTransactionType which is of type
	 * {@link String }.
	 */
	private String partTransactionType;

	/**
	 * This field is used to store value for partTransactionSerialNumber which is of type
	 * {@link Long }.
	 */
	private Long partTransactionSerialNumber;

	/**
	 * This field is used to store value for transactionStatus which is of type
	 * {@link String }.
	 */
	private String transactionStatus;

	/**
	 * This field is used to store value for accountNumber which is of type {@link String
	 * }.
	 */
	private String accountNumber;

	/**
	 * This field is used to store value for transactionParticularCode which is of type
	 * {@link String }.
	 */
	private String transactionParticularCode;

	/**
	 * This field is used to store value for ledgerBalance which is of type {@link Double
	 * }.
	 */
	private Double ledgerBalance;

	/**
	 * This field is used to store value for postedDate which is of type {@link Date }.
	 */
	private Date postedDate;

	/**
	 * This field is used to store value for availableBalance which is of type
	 * {@link Double }.
	 */
	private Double availableBalance;

	/**
	 * This field is used to store value for accountCurrencyCode which is of type
	 * {@link String }.
	 */
	private String accountCurrencyCode;

	/**
	 * This field is used to store value for recordGenerationTime which is of type
	 * {@link Date }.
	 */
	private Date recordGenerationTime;

	/**
	 * This field is used to store value for bankId which is of type {@link String }.
	 */
	private String bankId;

	/**
	 * This field is used to store value for tranCategory which is of type {@link String
	 * }.
	 */
	private String tranCategory;

	/**
	 * This field is used to store value for extTranId which is of type {@link String }.
	 */
	private String extTranId;

	/**
	 * This field is used to store value for photo which is of type {@link Blob }.
	 */
	private Blob photo;

	/**
	 * This field is used to store value for notes which is of type {@link String }.
	 */
	private String notes;

	/**
	 * This field is used to store value for tranKey which is of type {@link String }.
	 */
	private String tranKey;

	/**
	 * This field is used to store value for error which is of type {@link boolean }.
	 */
	private boolean isError;

	/**
	 * This field is used to store value for errorReason which is of type {@link String }.
	 */
	private String errorReason;

	/**
	 * This field is used to store value for errorMessage which is of type {@link String
	 * }.
	 */
	private String errorMessage;

	/**
	 * This method is used to get property inputLine of class
	 * {@link TransactionNotification }.
	 *
	 * @return inputLine : {@link String }
	 */
	public String getInputLine() {
		return this.inputLine;
	}

	/**
	 * This method is used to set property inputLine of class
	 * {@link TransactionNotification }.
	 *
	 * @param inputLine : {@link String }
	 */
	public void setInputLine(String inputLine) {
		this.inputLine = inputLine;
	}

	/**
	 * This method is used to get property transactionDate of class
	 * {@link TransactionNotification }.
	 *
	 * @return transactionDate : {@link Date }
	 */
	public Date getTransactionDate() {
		return this.transactionDate;
	}

	/**
	 * This method is used to set property transactionDate of class
	 * {@link TransactionNotification }.
	 *
	 * @param transactionDate : {@link Date }
	 */
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	/**
	 * This method is used to get property valueDate of class
	 * {@link TransactionNotification }.
	 *
	 * @return valueDate : {@link Date }
	 */
	public Date getValueDate() {
		return this.valueDate;
	}

	/**
	 * This method is used to set property valueDate of class
	 * {@link TransactionNotification }.
	 *
	 * @param valueDate : {@link Date }
	 */
	public void setValueDate(Date valueDate) {
		this.valueDate = valueDate;
	}

	/**
	 * This method is used to get property transactionId of class
	 * {@link TransactionNotification }.
	 *
	 * @return transactionId : {@link String }
	 */
	public String getTransactionId() {
		return this.transactionId;
	}

	/**
	 * This method is used to set property transactionId of class
	 * {@link TransactionNotification }.
	 *
	 * @param transactionId : {@link String }
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	/**
	 * This method is used to get property transactionCurrencyCode of class
	 * {@link TransactionNotification }.
	 *
	 * @return transactionCurrencyCode : {@link String }
	 */
	public String getTransactionCurrencyCode() {
		return this.transactionCurrencyCode;
	}

	/**
	 * This method is used to set property transactionCurrencyCode of class
	 * {@link TransactionNotification }.
	 *
	 * @param transactionCurrencyCode : {@link String }
	 */
	public void setTransactionCurrencyCode(String transactionCurrencyCode) {
		this.transactionCurrencyCode = transactionCurrencyCode;
	}

	/**
	 * This method is used to get property transactionType of class
	 * {@link TransactionNotification }.
	 *
	 * @return transactionType : {@link String }
	 */
	public String getTransactionType() {
		return this.transactionType;
	}

	/**
	 * This method is used to set property transactionType of class
	 * {@link TransactionNotification }.
	 *
	 * @param transactionType : {@link String }
	 */
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	/**
	 * This method is used to get property transactionParticulars of class
	 * {@link TransactionNotification }.
	 *
	 * @return transactionParticulars : {@link String }
	 */
	public String getTransactionParticulars() {
		return this.transactionParticulars;
	}

	/**
	 * This method is used to set property transactionParticulars of class
	 * {@link TransactionNotification }.
	 *
	 * @param transactionParticulars : {@link String }
	 */
	public void setTransactionParticulars(String transactionParticulars) {
		this.transactionParticulars = transactionParticulars;
	}

	/**
	 * This method is used to get property relatedRecordId of class
	 * {@link TransactionNotification }.
	 *
	 * @return relatedRecordId : {@link String }
	 */
	public String getRelatedRecordId() {
		return this.relatedRecordId;
	}

	/**
	 * This method is used to set property relatedRecordId of class
	 * {@link TransactionNotification }.
	 *
	 * @param relatedRecordId : {@link String }
	 */
	public void setRelatedRecordId(String relatedRecordId) {
		this.relatedRecordId = relatedRecordId;
	}

	/**
	 * This method is used to get property additionalReference of class
	 * {@link TransactionNotification }.
	 *
	 * @return additionalReference : {@link String }
	 */
	public String getAdditionalReference() {
		return this.additionalReference;
	}

	/**
	 * This method is used to set property additionalReference of class
	 * {@link TransactionNotification }.
	 *
	 * @param additionalReference : {@link String }
	 */
	public void setAdditionalReference(String additionalReference) {
		this.additionalReference = additionalReference;
	}

	/**
	 * This method is used to get property transactionReferenceNumber of class
	 * {@link TransactionNotification }.
	 *
	 * @return transactionReferenceNumber : {@link String }
	 */
	public String getTransactionReferenceNumber() {
		return this.transactionReferenceNumber;
	}

	/**
	 * This method is used to set property transactionReferenceNumber of class
	 * {@link TransactionNotification }.
	 *
	 * @param transactionReferenceNumber : {@link String }
	 */
	public void setTransactionReferenceNumber(String transactionReferenceNumber) {
		this.transactionReferenceNumber = transactionReferenceNumber;
	}

	/**
	 * This method is used to get property transactionAmount of class
	 * {@link TransactionNotification }.
	 *
	 * @return transactionAmount : {@link Double }
	 */
	public Double getTransactionAmount() {
		return this.transactionAmount;
	}

	/**
	 * This method is used to set property transactionAmount of class
	 * {@link TransactionNotification }.
	 *
	 * @param transactionAmount : {@link Double }
	 */
	public void setTransactionAmount(Double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	/**
	 * This method is used to get property partTransactionType of class
	 * {@link TransactionNotification }.
	 *
	 * @return partTransactionType : {@link String }
	 */
	public String getPartTransactionType() {
		return this.partTransactionType;
	}

	/**
	 * This method is used to set property partTransactionType of class
	 * {@link TransactionNotification }.
	 *
	 * @param partTransactionType : {@link String }
	 */
	public void setPartTransactionType(String partTransactionType) {
		this.partTransactionType = partTransactionType;
	}

	/**
	 * This method is used to get property partTransactionSerialNumber of class
	 * {@link TransactionNotification }.
	 *
	 * @return partTransactionSerialNumber : {@link Long }
	 */
	public Long getPartTransactionSerialNumber() {
		return this.partTransactionSerialNumber;
	}

	/**
	 * This method is used to set property partTransactionSerialNumber of class
	 * {@link TransactionNotification }.
	 *
	 * @param partTransactionSerialNumber : {@link Long }
	 */
	public void setPartTransactionSerialNumber(Long partTransactionSerialNumber) {
		this.partTransactionSerialNumber = partTransactionSerialNumber;
	}

	/**
	 * This method is used to get property transactionStatus of class
	 * {@link TransactionNotification }.
	 *
	 * @return transactionStatus : {@link String }
	 */
	public String getTransactionStatus() {
		return this.transactionStatus;
	}

	/**
	 * This method is used to set property transactionStatus of class
	 * {@link TransactionNotification }.
	 *
	 * @param transactionStatus : {@link String }
	 */
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	/**
	 * This method is used to get property accountNumber of class
	 * {@link TransactionNotification }.
	 *
	 * @return accountNumber : {@link String }
	 */
	public String getAccountNumber() {
		return this.accountNumber;
	}

	/**
	 * This method is used to set property accountNumber of class
	 * {@link TransactionNotification }.
	 *
	 * @param accountNumber : {@link String }
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * This method is used to get property transactionParticularCode of class
	 * {@link TransactionNotification }.
	 *
	 * @return transactionParticularCode : {@link String }
	 */
	public String getTransactionParticularCode() {
		return this.transactionParticularCode;
	}

	/**
	 * This method is used to set property transactionParticularCode of class
	 * {@link TransactionNotification }.
	 *
	 * @param transactionParticularCode : {@link String }
	 */
	public void setTransactionParticularCode(String transactionParticularCode) {
		this.transactionParticularCode = transactionParticularCode;
	}

	/**
	 * This method is used to get property ledgerBalance of class
	 * {@link TransactionNotification }.
	 *
	 * @return ledgerBalance : {@link Double }
	 */
	public Double getLedgerBalance() {
		return this.ledgerBalance;
	}

	/**
	 * This method is used to set property ledgerBalance of class
	 * {@link TransactionNotification }.
	 *
	 * @param ledgerBalance : {@link Double }
	 */
	public void setLedgerBalance(Double ledgerBalance) {
		this.ledgerBalance = ledgerBalance;
	}

	/**
	 * This method is used to get property postedDate of class
	 * {@link TransactionNotification }.
	 *
	 * @return postedDate : {@link Date }
	 */
	public Date getPostedDate() {
		return this.postedDate;
	}

	/**
	 * This method is used to set property postedDate of class
	 * {@link TransactionNotification }.
	 *
	 * @param postedDate : {@link Date }
	 */
	public void setPostedDate(Date postedDate) {
		this.postedDate = postedDate;
	}

	/**
	 * This method is used to get property availableBalance of class
	 * {@link TransactionNotification }.
	 *
	 * @return availableBalance : {@link Double }
	 */
	public Double getAvailableBalance() {
		return this.availableBalance;
	}

	/**
	 * This method is used to set property availableBalance of class
	 * {@link TransactionNotification }.
	 *
	 * @param availableBalance : {@link Double }
	 */
	public void setAvailableBalance(Double availableBalance) {
		this.availableBalance = availableBalance;
	}

	/**
	 * This method is used to get property accountCurrencyCode of class
	 * {@link TransactionNotification }.
	 *
	 * @return accountCurrencyCode : {@link String }
	 */
	public String getAccountCurrencyCode() {
		return this.accountCurrencyCode;
	}

	/**
	 * This method is used to set property accountCurrencyCode of class
	 * {@link TransactionNotification }.
	 *
	 * @param accountCurrencyCode : {@link String }
	 */
	public void setAccountCurrencyCode(String accountCurrencyCode) {
		this.accountCurrencyCode = accountCurrencyCode;
	}

	/**
	 * This method is used to get property recordGenerationTime of class
	 * {@link TransactionNotification }.
	 *
	 * @return recordGenerationTime : {@link Date }
	 */
	public Date getRecordGenerationTime() {
		return this.recordGenerationTime;
	}

	/**
	 * This method is used to set property recordGenerationTime of class
	 * {@link TransactionNotification }.
	 *
	 * @param recordGenerationTime : {@link Date }
	 */
	public void setRecordGenerationTime(Date recordGenerationTime) {
		this.recordGenerationTime = recordGenerationTime;
	}

	/**
	 * This method is used to get property bankId of class {@link TransactionNotification
	 * }.
	 *
	 * @return bankId : {@link String }
	 */
	public String getBankId() {
		return this.bankId;
	}

	/**
	 * This method is used to set property bankId of class {@link TransactionNotification
	 * }.
	 *
	 * @param bankId : {@link String }
	 */
	public void setBankId(String bankId) {
		this.bankId = bankId;
	}

	/**
	 * This method is used to get property tranCategory of class
	 * {@link TransactionNotification }.
	 *
	 * @return tranCategory : {@link String }
	 */
	public String getTranCategory() {
		return this.tranCategory;
	}

	/**
	 * This method is used to set property tranCategory of class
	 * {@link TransactionNotification }.
	 *
	 * @param tranCategory : {@link String }
	 */
	public void setTranCategory(String tranCategory) {
		this.tranCategory = tranCategory;
	}

	/**
	 * This method is used to get property extTranId of class
	 * {@link TransactionNotification }.
	 *
	 * @return extTranId : {@link String }
	 */
	public String getExtTranId() {
		return this.extTranId;
	}

	/**
	 * This method is used to set property extTranId of class
	 * {@link TransactionNotification }.
	 *
	 * @param extTranId : {@link String }
	 */
	public void setExtTranId(String extTranId) {
		this.extTranId = extTranId;
	}

	/**
	 * This method is used to get property photo of class {@link TransactionNotification
	 * }.
	 *
	 * @return photo : {@link Blob }
	 */
	public Blob getPhoto() {
		return this.photo;
	}

	/**
	 * This method is used to set property photo of class {@link TransactionNotification
	 * }.
	 *
	 * @param photo : {@link Blob }
	 */
	public void setPhoto(Blob photo) {
		this.photo = photo;
	}

	/**
	 * This method is used to get property notes of class {@link TransactionNotification
	 * }.
	 *
	 * @return notes : {@link String }
	 */
	public String getNotes() {
		return this.notes;
	}

	/**
	 * This method is used to set property notes of class {@link TransactionNotification
	 * }.
	 *
	 * @param notes : {@link String }
	 */
	public void setNotes(String notes) {
		this.notes = notes;
	}

	/**
	 * This method is used to get property tranKey of class {@link TransactionNotification
	 * }.
	 *
	 * @return tranKey : {@link String }
	 */
	public String getTranKey() {
		return this.tranKey;
	}

	/**
	 * This method is used to set property tranKey of class {@link TransactionNotification
	 * }.
	 *
	 * @param tranKey : {@link String }
	 */
	public void setTranKey(String tranKey) {
		this.tranKey = tranKey;
	}

	/**
	 * This method is used to get property isError of class {@link TransactionNotification
	 * }.
	 *
	 * @return isError : {@link boolean }
	 */
	public boolean isError() {
		return this.isError;
	}

	/**
	 * This method is used to set property isError of class {@link TransactionNotification
	 * }.
	 *
	 * @param isError : {@link boolean }
	 */
	public void setError(boolean isError) {
		this.isError = isError;
	}

	/**
	 * This method is used to get property errorReason of class
	 * {@link TransactionNotification }.
	 *
	 * @return errorReason : {@link String }
	 */
	public String getErrorReason() {
		return this.errorReason;
	}

	/**
	 * This method is used to set property errorReason of class
	 * {@link TransactionNotification }.
	 *
	 * @param errorReason : {@link String }
	 */
	public void setErrorReason(String errorReason) {
		this.errorReason = errorReason;
	}

	/**
	 * This method is used to get property errorMessage of class
	 * {@link TransactionNotification }.
	 *
	 * @return errorMessage : {@link String }
	 */
	public String getErrorMessage() {
		return this.errorMessage;
	}

	/**
	 * This method is used to set property errorMessage of class
	 * {@link TransactionNotification }.
	 *
	 * @param errorMessage : {@link String }
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * This method is used to calculate value for property tranKey of class
	 * {@link TransactionNotification }.
	 *
	 */
	public void calculateTranKey() {
		String generatedTranKey = (this.transactionId != null ? this.transactionId.trim() : null)
				+ (this.transactionDate != null
				? this.transactionDate.getTime()
						: null)
				+ this.partTransactionSerialNumber;
		setTranKey(generatedTranKey);
	}

	@Override
	public String toString() {
		return "TransactionNotification [inputLine=" + this.inputLine + ", transactionDate=" + this.transactionDate
				+ ", valueDate=" + this.valueDate + ", transactionId=" + this.transactionId
				+ ", transactionCurrencyCode="
				+ this.transactionCurrencyCode + ", transactionType=" + this.transactionType
				+ ", transactionParticulars="
				+ this.transactionParticulars + ", relatedRecordId=" + this.relatedRecordId + ", additionalReference="
				+ this.additionalReference + ", transactionReferenceNumber=" + this.transactionReferenceNumber
				+ ", transactionAmount=" + this.transactionAmount + ", partTransactionType=" + this.partTransactionType
				+ ", partTransactionSerialNumber=" + this.partTransactionSerialNumber + ", transactionStatus="
				+ this.transactionStatus + ", accountNumber=" + this.accountNumber + ", transactionParticularCode="
				+ this.transactionParticularCode + ", ledgerBalance=" + this.ledgerBalance + ", postedDate="
				+ this.postedDate
				+ ", availableBalance=" + this.availableBalance + ", accountCurrencyCode=" + this.accountCurrencyCode
				+ ", recordGenerationTime=" + this.recordGenerationTime + ", bankId=" + this.bankId + ", tranCategory="
				+ this.tranCategory + ", extTranId=" + this.extTranId + ", photo=" + this.photo + ", notes="
				+ this.notes + ", tranKey="
				+ this.tranKey + ", isError=" + this.isError + ", errorReason=" + this.errorReason + ", errorMessage="
				+ this.errorMessage
				+ "]";
	}



}
