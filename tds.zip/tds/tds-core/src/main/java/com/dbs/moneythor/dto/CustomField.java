/**
 * This file is property of DBS Bank Pvt Ltd File Name: CustomField.java Author:
 * DBS Asia Hub 2 Date: Aug 18, 2017
 */
package com.dbs.moneythor.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * This Java class will act as the simple POJO for storing the details which are being
 * sent to MoneyThor for Transaction Read/Update.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 */
public class CustomField {

	/**
	 * This field is used to store value for name which is of type {@link String }.
	 */
	@JsonProperty("name")
	private String name;

	/**
	 * This field is used to store value for value which is of type {@link String }.
	 */
	@JsonProperty("value")
	private String value;

	/**
	 * This method is used to get property name of class {@link CustomField }.
	 *
	 * @return name : {@link String }
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * This method is used to set property name of class {@link CustomField }.
	 *
	 * @param name : {@link String }
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * This method is used to get property value of class {@link CustomField }.
	 *
	 * @return value : {@link String }
	 */
	public String getValue() {
		return this.value;
	}

	/**
	 * This method is used to set property value of class {@link CustomField }.
	 *
	 * @param value : {@link String }
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * This method is used to represent the current instance in String format.
	 *
	 * @return {@link String}
	 */
	@Override
	public String toString() {
		return "CustomField [name=" + this.name + ", value=" + this.value + "]";
	}

}
