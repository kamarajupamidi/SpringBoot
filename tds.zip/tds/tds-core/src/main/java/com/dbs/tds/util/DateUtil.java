package com.dbs.tds.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

public class DateUtil {

	private DateUtil() {

	}

	public static Date parseDate(String inputDate, String pattern) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
		dateFormat.setLenient(false);
		try {
			return dateFormat.parse(inputDate);
		}
		catch (ParseException e) {
			throw new IllegalArgumentException(e.getMessage() + ", format: [" + pattern + "]");
		}
	}

	public static String parseDateToString(Date inputDate, String pattern) {
		return new SimpleDateFormat(pattern).format(inputDate);
	}

	/***
	 *
	 * This method is used to get XMLGregorianCalendar with Date value for the given
	 * java.util.Date. Used to get only date part of the given input
	 * @param inputDate {@link Date}
	 * @return XMLGregorianCalendar {@link XMLGregorianCalendar}
	 */
	public static XMLGregorianCalendar getXMLGregorianCalendarDate(Date inputDate) {

		GregorianCalendar inputCalendar = new GregorianCalendar();
		inputCalendar.setTime(inputDate);

		try {
			return DatatypeFactory.newInstance()
					.newXMLGregorianCalendar(inputCalendar.get(Calendar.YEAR), inputCalendar.get(Calendar.MONTH) + 1,
							inputCalendar.get(Calendar.DAY_OF_MONTH), DatatypeConstants.FIELD_UNDEFINED,
							DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED,
							DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED);
		}
		catch (DatatypeConfigurationException e) {
			throw new IllegalArgumentException(getExceptionMessage(inputCalendar, e));
		}
	}

	/***
	 *
	 * This method is used to get XMLGregorianCalendar with Time value for the given
	 * java.util.Date. Used to get only time part of the given input.
	 * @param inputDate {@link Date}
	 * @return XMLGregorianCalendar {@link XMLGregorianCalendar}
	 */
	public static XMLGregorianCalendar getXMLGregorianCalendarTime(Date inputDate) {

		GregorianCalendar inputCalendar = new GregorianCalendar();
		inputCalendar.setTime(inputDate);

		try {
			return DatatypeFactory.newInstance()
					.newXMLGregorianCalendar(DatatypeConstants.FIELD_UNDEFINED,
							DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED,
							inputCalendar.get(Calendar.HOUR_OF_DAY),
							inputCalendar.get(Calendar.MINUTE), inputCalendar.get(Calendar.SECOND),
							DatatypeConstants.FIELD_UNDEFINED,
							DatatypeConstants.FIELD_UNDEFINED);
		}
		catch (DatatypeConfigurationException e) {
			throw new IllegalArgumentException(getExceptionMessage(inputCalendar, e));
		}
	}

	/***
	 *
	 * This method is used to get XMLGregorianCalendar with dateTime value for the given
	 * java.util.Date. Used to get only time part of the given input.
	 * @param inputDate {@link Date}
	 * @return XMLGregorianCalendar {@link XMLGregorianCalendar}
	 */
	public static XMLGregorianCalendar getXMLGregorianCalendarDateTime(Date inputDate) {

		GregorianCalendar inputCalendar = new GregorianCalendar();
		inputCalendar.setTime(inputDate);

		try {
			return DatatypeFactory.newInstance().newXMLGregorianCalendar(inputCalendar);
		}
		catch (DatatypeConfigurationException e) {
			throw new IllegalArgumentException(getExceptionMessage(inputCalendar, e));
		}
	}

	private static String getExceptionMessage(GregorianCalendar inputCalendar,
			DatatypeConfigurationException dataTypeConfigurationException) {
		return dataTypeConfigurationException.getMessage() + ", input: [" + inputCalendar.toString() + "]";
	}

	public static XMLGregorianCalendar getCurrentXMLGregorianCalendarDate() throws DatatypeConfigurationException {

		GregorianCalendar inputCalendar = new GregorianCalendar();
		inputCalendar.setTimeInMillis(System.currentTimeMillis());
		return DatatypeFactory.newInstance().newXMLGregorianCalendar(inputCalendar);

	}

}
