package com.dbs.tds.dto;

import java.math.BigInteger;
import java.util.Date;

public class TransactionHistoryRequest {

	private String acctId;

	private BigInteger maxRec;

	private String cursor;

	private Date startDt;

	private Date endDt;

	private String sortOrder;

	private Integer lowerLimit;

	private Integer lastTranRef;

	private Double amountFrom;

	private Double amountTo;

	private String currency;

	private String crDrInd;

	public String getAcctId() {
		return this.acctId;
	}

	public void setAcctId(String acctId) {
		this.acctId = acctId;
	}

	public BigInteger getMaxRec() {
		return this.maxRec;
	}

	public void setMaxRec(BigInteger maxRec) {
		this.maxRec = maxRec;
	}

	public String getCursor() {
		return this.cursor;
	}

	public void setCursor(String cursor) {
		this.cursor = cursor;
	}

	public Date getStartDt() {
		return this.startDt;
	}

	public void setStartDt(Date startDt) {
		this.startDt = startDt;
	}

	public Date getEndDt() {
		return this.endDt;
	}

	public void setEndDt(Date endDt) {
		this.endDt = endDt;
	}

	public String getSortOrder() {
		return this.sortOrder;
	}

	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	public Integer getLowerLimit() {
		return this.lowerLimit;
	}

	public void setLowerLimit(Integer lowerLimit) {
		this.lowerLimit = lowerLimit;
	}

	public Integer getLastTranRef() {
		return this.lastTranRef;
	}

	public void setLastTranRef(Integer lastTranRef) {
		this.lastTranRef = lastTranRef;
	}

	public Double getAmountFrom() {
		return this.amountFrom;
	}

	public void setAmountFrom(Double amountFrom) {
		this.amountFrom = amountFrom;
	}

	public Double getAmountTo() {
		return this.amountTo;
	}

	public void setAmountTo(Double amountTo) {
		this.amountTo = amountTo;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getCrDrInd() {
		return this.crDrInd;
	}

	public void setCrDrInd(String crDrInd) {
		this.crDrInd = crDrInd;
	}

	@Override
	public String toString() {
		return "TransactionHistoryRequest [acctId=" + this.acctId + ", maxRec=" + this.maxRec + ", cursor="
				+ this.cursor
				+ ", startDt=" + this.startDt + ", endDt=" + this.endDt + ", sortOrder=" + this.sortOrder
				+ ", lowerLimit="
				+ this.lowerLimit + ", lastTranRef=" + this.lastTranRef + ", amountFrom=" + this.amountFrom
				+ ", amountTo=" + this.amountTo
				+ ", currency=" + this.currency + ", crDrInd=" + this.crDrInd + "]";
	}

}
