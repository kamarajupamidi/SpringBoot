/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: LoggingConstants.java
 * Author: DBS Asia Hub 2
 * Date: Oct 25, 2017
 */
package com.dbs.tds.constants;

/**
 * This enum is used for defining constants which will be used for Logging Purpose.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public enum LoggingConstants {

	SERVICE_ID("SERVICE_ID"),
	INTERFACE_MAP("INTERFACE_MAP"),
	FUNCTIONAL_MAP("FUNCTIONAL_MAP"),
	REQUEST_TYPE("REQUEST_TYPE"),
	SERVICE_NAME("serviceName"),
	ORG_CODE("orgCode"),
	HOSTNAME("hostname"),
	LOG_UUID("logUID"),
	ID("ID"),
	MSG_UID("MSG_UID"),
	CLIENT_IP("CLIENT_IP"),
	STATUS_CODE("STATUS_CODE"),
	ERROR_TYPE("ERROR_CLASSIFICATION"),
	RESPONSE_TIME("RESPONSE_TIME");

	/**
	 * This field is used to store value for value which is of type {@link String }.
	 */
	private String value;

	/**
	 * This is used to initialize the enum property.
	 *
	 * @param value : {@link String}
	 */
	LoggingConstants(String value) {
		this.value = value;
	}

	/**
	 * This method is used to return the value of the enum type.
	 *
	 * @return {@link String}
	 */
	public String value() {
		return this.value;
	}

}
