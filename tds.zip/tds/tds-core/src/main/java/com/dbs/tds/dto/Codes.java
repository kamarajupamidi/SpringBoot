/**
 * This file is property of DBS Bank Pvt Ltd
 *
 * File Name: Codes.java
 * Author: DBS Asia Hub 2
 * Date: Oct 12, 2017
 */
package com.dbs.tds.dto;

/**
 * This class is used as the POJO class for the storing the codes values which are fetched
 * from TDS DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
public class Codes {

	/**
	 * This field is used to store value for countryCode which is of type {@link String }.
	 */
	private String countryCode;

	/**
	 * This field is used to store value for orgCode which is of type {@link String }.
	 */
	private String orgCode;

	/**
	 * This field is used to store value for codeType which is of type {@link String }.
	 */
	private String codeType;

	/**
	 * This field is used to store value for provider which is of type {@link String }.
	 */
	private String provider;

	/**
	 * This field is used to store value for name which is of type {@link String }.
	 */
	private String name;

	/**
	 * This field is used to store value for value which is of type {@link String }.
	 */
	private String value;

	/**
	 * This field is used to store value for description which is of type {@link String }.
	 */
	private String description;

	/**
	 * This field is used to store value for istdin which is of type {@link String }.
	 */
	private String istdin;

	/**
	 * This method is used to get property countryCode of class {@link Codes }.
	 *
	 * @return countryCode : {@link String }
	 */
	public String getCountryCode() {
		return this.countryCode;
	}

	/**
	 * This method is used to set property countryCode of class {@link Codes }.
	 *
	 * @param countryCode : {@link String }
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	/**
	 * This method is used to get property orgCode of class {@link Codes }.
	 *
	 * @return orgCode : {@link String }
	 */
	public String getOrgCode() {
		return this.orgCode;
	}

	/**
	 * This method is used to set property orgCode of class {@link Codes }.
	 *
	 * @param orgCode : {@link String }
	 */
	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	/**
	 * This method is used to get property codeType of class {@link Codes }.
	 *
	 * @return codeType : {@link String }
	 */
	public String getCodeType() {
		return this.codeType;
	}

	/**
	 * This method is used to set property codeType of class {@link Codes }.
	 *
	 * @param codeType : {@link String }
	 */
	public void setCodeType(String codeType) {
		this.codeType = codeType;
	}

	/**
	 * This method is used to get property provider of class {@link Codes }.
	 *
	 * @return provider : {@link String }
	 */
	public String getProvider() {
		return this.provider;
	}

	/**
	 * This method is used to set property provider of class {@link Codes }.
	 *
	 * @param provider : {@link String }
	 */
	public void setProvider(String provider) {
		this.provider = provider;
	}

	/**
	 * This method is used to get property name of class {@link Codes }.
	 *
	 * @return name : {@link String }
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * This method is used to set property name of class {@link Codes }.
	 *
	 * @param name : {@link String }
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * This method is used to get property value of class {@link Codes }.
	 *
	 * @return value : {@link String }
	 */
	public String getValue() {
		return this.value;
	}

	/**
	 * This method is used to set property value of class {@link Codes }.
	 *
	 * @param value : {@link String }
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * This method is used to get property description of class {@link Codes }.
	 *
	 * @return description : {@link String }
	 */
	public String getDescription() {
		return this.description;
	}

	/**
	 * This method is used to set property description of class {@link Codes }.
	 *
	 * @param description : {@link String }
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * This method is used to get property istdin of class {@link Codes }.
	 *
	 * @return istdin : {@link String }
	 */
	public String getIstdin() {
		return this.istdin;
	}

	/**
	 * This method is used to set property istdin of class {@link Codes }.
	 *
	 * @param istdin : {@link String }
	 */
	public void setIstdin(String istdin) {
		this.istdin = istdin;
	}

	/**
	 * This method is used to represent the current object in String format.
	 *
	 * @return {@link String }
	 */
	@Override
	public String toString() {
		return "Codes [countryCode=" + this.countryCode + ", orgCode=" + this.orgCode + ", codeType=" + this.codeType
				+ ", provider="
				+ this.provider + ", name=" + this.name + ", value=" + this.value + ", description=" + this.description
				+ ", istdin="
				+ this.istdin + "]";
	}


}
