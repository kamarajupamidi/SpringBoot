CREATE TABLE T_XREF_CODES (
  ID smallint(5) unsigned NOT NULL AUTO_INCREMENT ,
  COUNTRY_CODE varchar(20) NOT NULL ,
  ORG_CODE varchar(20) NOT NULL ,
  CODE_TYPE varchar(50) NOT NULL ,
  PROVIDER varchar(50) NOT NULL ,
  NAME varchar(100) NOT NULL ,
  VALUE varchar(100) NOT NULL ,
  DESCRIPTION varchar(100) NOT NULL,
  IS_TDIN enum('Y','N') NOT NULL ,
  PRIMARY KEY (ID)
);
