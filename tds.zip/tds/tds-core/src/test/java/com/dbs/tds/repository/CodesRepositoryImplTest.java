package com.dbs.tds.repository;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.dbs.tds.config.CoreConfigurationTest;


@RunWith(SpringRunner.class)
@ContextConfiguration(classes = { CoreConfigurationTest.class })
public class CodesRepositoryImplTest {
	
	@Autowired
	CodesRepository codesRepository;

	@Test
	public void testGetCodesByCodeType() {
		int rowCount =  codesRepository.getCodesByCodeType("SchemeCodes").size();
		assertEquals(5, rowCount);
		
	}

}
