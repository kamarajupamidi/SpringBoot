package com.dbs.tds.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.xml.datatype.XMLGregorianCalendar;
import org.junit.Assert;
import org.junit.Test;

public class DateUtilTest {

	private static final String PARSE_DATE_PATTERN = "yyyy-MM-dd HH:mm:ss";
	private static final String PARSE_DATE_TO_STRING_PATTERN = "yyyy/MM/dd";
	private final SimpleDateFormat dateFormat  = new SimpleDateFormat(PARSE_DATE_PATTERN);
	private final SimpleDateFormat parseDateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	private final SimpleDateFormat parseDateToStringFormat = new SimpleDateFormat(PARSE_DATE_TO_STRING_PATTERN);
	private final SimpleDateFormat getXMLGregorianCalendarDateFormat = new SimpleDateFormat("yyyy-MM-dd");
	private final SimpleDateFormat getXMLGregorianCalendarTimeFormat = new SimpleDateFormat("HH:mm:ss");
	private final SimpleDateFormat getXMLGregorianCalendarDateTimeFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
	private final Date currentDate = new Date();

	@Test
	public void testParseDate() {
		Date date = DateUtil.parseDate(dateFormat.format(currentDate), PARSE_DATE_PATTERN);
		Assert.assertEquals(currentDate.toString(), date.toString());
	}

	@Test(expected = IllegalArgumentException.class)
	public void testParseDateWithInvalidDateFormat() {
		DateUtil.parseDate(parseDateFormat.format(currentDate), PARSE_DATE_PATTERN);
	}

	@Test
	public void testParseDateToString() throws ParseException {
		String date = DateUtil.parseDateToString(currentDate, PARSE_DATE_TO_STRING_PATTERN);
		Assert.assertEquals(parseDateToStringFormat.format(currentDate), date);
	}

	@Test
	public void testGetXMLGregorianCalendarDate() throws ParseException {
		XMLGregorianCalendar date = DateUtil.getXMLGregorianCalendarDate(currentDate);
		Assert.assertEquals(getXMLGregorianCalendarDateFormat.format(currentDate), date.toString());
	}

	@Test
	public void testGetXMLGregorianCalendarTime() throws ParseException {
		XMLGregorianCalendar time = DateUtil.getXMLGregorianCalendarTime(currentDate);
		Assert.assertEquals(getXMLGregorianCalendarTimeFormat.format(currentDate), time.toString());
	}

	@Test
	public void testGetXMLGregorianCalendarDateTime() throws ParseException {
		XMLGregorianCalendar dateTime = DateUtil.getXMLGregorianCalendarDateTime(currentDate);
		Assert.assertEquals(getXMLGregorianCalendarDateTimeFormat.format(currentDate), dateTime.toString());
	}
}
