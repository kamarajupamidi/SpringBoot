package com.dbs.tds.dto;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.dbs.tds.config.CoreConfigurationTest;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = { CoreConfigurationTest.class })
public class CodeTypesTest {
	
	@Autowired
	private CodeTypes codeTypes;
	
	@Test
	public void testGetSchemeCodes() {
		int schemCodesCount = codeTypes.getSchemeCodes().size();
		assertEquals(5, schemCodesCount);
	}

	@Test
	public void testGetProdtypes() {
		int productTypeCount = codeTypes.getProdtypes().size();
		assertEquals(5, productTypeCount);
	}

}
