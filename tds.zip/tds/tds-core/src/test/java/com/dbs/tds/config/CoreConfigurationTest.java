package com.dbs.tds.config;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

@Configuration
@ComponentScan({ "com.dbs.tds.repository","com.dbs.tds.dto" })
public class CoreConfigurationTest {
	
	@Bean
	public JdbcTemplate jdbcTemplate() {
		DataSource dataSource = new EmbeddedDatabaseBuilder()
		.addScripts("codesschema.sql", "codesdata.sql")
		.setType(EmbeddedDatabaseType.H2).build();
		return new JdbcTemplate(dataSource);
	}
	
}
