package com.dbs.tds.util;

import java.sql.Blob;
import java.sql.SQLException;

import javax.sql.rowset.serial.SerialBlob;

import org.junit.Assert;
import org.junit.Test;

public class CommonUtilsTest {

	public static final String HELLO = "hello";

	@Test
	public void testConvertBlobToString() throws SQLException {
		Blob blob = new SerialBlob(HELLO.getBytes());
		String blobVal = CommonUtils.convertBlobToString(blob);
		Assert.assertEquals(HELLO, blobVal);
	}

	@Test
	public void testConvertBlobToStringWithInvalidData() throws SQLException {
		Blob blob = new SerialBlob("".getBytes());
		String blobVal = CommonUtils.convertBlobToString(blob);
		Assert.assertNull(blobVal);
	}

	@Test
	public void testConvertStringToBlob() throws SQLException {
		Blob blob = new SerialBlob(HELLO.getBytes());
		Blob blobVal = CommonUtils.convertStringToBlob(HELLO);
		Assert.assertEquals(blob, blobVal);
	}

	@Test
	public void testConvertStringToBlobWithInvalidData() throws SQLException {
		String string = "";
		Blob blobVal = CommonUtils.convertStringToBlob(string);
		Assert.assertEquals(0, blobVal.length());
	}

}
