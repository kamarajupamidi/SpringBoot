package com.dbs.tds.liennotificationbatch.config;

import javax.sql.DataSource;

import com.dbs.tds.liennotificationbatch.LienNotificationBatchApplication;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

/***
 *
 * This class is used for configuring the embedded data base builder
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Configuration
@ComponentScan({ "com.dbs.tds.liennotification.repository" })
@Import(LienNotificationBatchApplication.class)
public class LienNotificationrRepoConfig {

	@Bean
	public DataSource dataSource() {
		return new EmbeddedDatabaseBuilder()
				.addScripts("schema_accounts.sql", "data.sql")
				.setType(EmbeddedDatabaseType.H2).build();
	}

}
