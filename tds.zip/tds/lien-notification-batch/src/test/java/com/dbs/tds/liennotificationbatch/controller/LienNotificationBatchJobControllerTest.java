package com.dbs.tds.liennotificationbatch.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import com.dbs.tds.exception.FileAccessException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.internal.util.reflection.Whitebox;
import org.mockito.runners.MockitoJUnitRunner;

import org.springframework.messaging.MessageChannel;
import org.springframework.mock.web.MockMultipartFile;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class LienNotificationBatchJobControllerTest {

	private static final String FILE_PATH = "batchFile/batch.txt";

	@Mock
	private MessageChannel fileInputChannel;

	@Mock
	private MockMultipartFile mockMultipartFile;

	@InjectMocks
	private LienNotificationBatchJobController lienNotificationBatchJobController;

	@Before
	public void setUp() {

		this.lienNotificationBatchJobController = new LienNotificationBatchJobController(this.fileInputChannel);
	}

	/***
	 *
	 * This method contains test case of batch invokation
	 */
	@Test
	public void invokeLienNotificationBatchJobTest() {

		try {
			File file = getFile();
			Whitebox.setInternalState(this.lienNotificationBatchJobController, "filePath", file.getAbsolutePath());
			MockMultipartFile multiFile = new MockMultipartFile("batch", Files.readAllBytes(file.toPath()));
			assertThat("INVOKED_LIEN_NOTIFICATION".equals(this.lienNotificationBatchJobController
					.invokeLienNotificationBatchJob(multiFile)));
		}
		catch (IOException e) {
			throw new FileAccessException("Error Accessing File", e);
		}

	}

	@Test
	public void invokeLienNotificationBatchFileFailedtoUpload() {

		try {
			File file = getFile();
			Whitebox.setInternalState(this.lienNotificationBatchJobController, "filePath", "C://");
			MockMultipartFile multiFile = new MockMultipartFile("batch", Files.readAllBytes(file.toPath()));
			assertThat("INVOKE_FAILED_TO_UPLOAD".equals(this.lienNotificationBatchJobController
					.invokeLienNotificationBatchJob(multiFile)));
		}
		catch (IOException e) {
			throw new FileAccessException("Error Accessing File", e);
		}

	}

	@Test
	public void invokeLienNotificationBatchFileNonExistance() {
		when(this.mockMultipartFile.isEmpty()).thenReturn(true);
		when(this.mockMultipartFile.getOriginalFilename()).thenReturn("file");
		assertThat("INVOKE_FAILED_AS_FILE_IS_EMPTY".equals(this.lienNotificationBatchJobController
				.invokeLienNotificationBatchJob(this.mockMultipartFile)));

	}

	/***
	 *
	 * This method is used to build {@link File}
	 * @return
	 */
	private File getFile() {
		ClassLoader loader = getClass().getClassLoader();
		return spy(new File(loader.getResource(FILE_PATH).getFile()));
	}

}
