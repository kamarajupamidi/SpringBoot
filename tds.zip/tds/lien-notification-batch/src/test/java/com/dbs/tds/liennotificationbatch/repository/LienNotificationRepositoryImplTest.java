package com.dbs.tds.liennotificationbatch.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.dbs.tds.dto.LienNotification;
import com.dbs.tds.liennotificationbatch.config.LienNotificationrRepoConfig;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

/***
 *
 * This class contains unit test case for {@link LienNotificationRepository}
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@RunWith(SpringRunner.class)
@TestPropertySource(locations = "classpath:application.properties")
@ContextConfiguration(classes = { LienNotificationrRepoConfig.class })
public class LienNotificationRepositoryImplTest {

	@Autowired
	private LienNotificationRepository lienNotificationRepository;

	/***
	 *
	 * This method is used to test data base invoke to update Account details in TDS DB
	 */
	@Test
	public void updateAccountDetailsTest() {
		this.lienNotificationRepository.updateAccountDetails(getLienNotifications());
	}

	/***
	 *
	 * This method is used to build list of {@link LienNotification}
	 * @return
	 */
	private List<? extends LienNotification> getLienNotifications() {

		List<LienNotification> lienNotifications = new ArrayList<>();
		LienNotification lienNotification = new LienNotification();
		lienNotification.setAccountNumber("123445");
		lienNotification.setAvailableBalance(100.00);
		lienNotification.setAvailableBalanceCurrencyCode("INR");
		lienNotification.setLedgerBalance(100.00);
		lienNotification.setRecordGenerationTime(new Date());
		lienNotification.setLedgerBalanceCurrencyCode("INR");
		lienNotifications.add(lienNotification);

		return lienNotifications;
	}
}
