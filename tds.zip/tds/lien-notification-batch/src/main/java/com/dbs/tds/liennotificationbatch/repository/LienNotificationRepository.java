package com.dbs.tds.liennotificationbatch.repository;

import java.util.List;

import com.dbs.tds.dto.LienNotification;

import org.springframework.stereotype.Repository;

/**
 * This interface is used to provide abstract functionalities for interacting with TDS DB
 * for Lien Notifications DB operations.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Repository
public interface LienNotificationRepository {

	/***
	 * This method is to execute batch operation for Lien Notifications to update into TDS
	 * data base.
	 *
	 * @param lienNotifications : {@link List} &lt; {@link LienNotification} &gt;
	 */
	public void updateAccountDetails(List<? extends LienNotification> lienNotifications);

}
