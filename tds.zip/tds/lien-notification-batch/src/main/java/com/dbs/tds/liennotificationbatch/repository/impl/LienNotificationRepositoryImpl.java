package com.dbs.tds.liennotificationbatch.repository.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import com.dbs.tds.dto.LienNotification;
import com.dbs.tds.liennotificationbatch.repository.LienNotificationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import static com.dbs.tds.constants.AccountFields.ACCT_AVALBL_CRRNCY;
import static com.dbs.tds.constants.AccountFields.ACCT_AVLBL_BAL;
import static com.dbs.tds.constants.AccountFields.ACCT_LDGR_BAL;
import static com.dbs.tds.constants.AccountFields.ACCT_LDGR_CRRNCY;
import static com.dbs.tds.constants.AccountFields.ACCT_NO;
import static com.dbs.tds.constants.AccountFields.IS_BAL_SYNC;
import static com.dbs.tds.constants.AccountFields.LST_UPDT_DTTM;
import static com.dbs.tds.constants.AccountFields.LST_UPDT_SYS_ID;
import static com.dbs.tds.constants.AccountFields.VENDR_LST_UPDT_DTTM;

/**
 * This class is used to provide implementation for {@link LienNotificationRepository} and
 * also provide behaviors to interact with TDS DB.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Repository
public class LienNotificationRepositoryImpl implements LienNotificationRepository {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(LienNotificationRepositoryImpl.class);

	/**
	 * This field is used to store value for accountUpdateJdbcTemplate which is of type
	 * {@link NamedParameterJdbcTemplate }.
	 */
	private NamedParameterJdbcTemplate accountUpdateJdbcTemplate;

	/**
	 * This field is used to store value for accountUpdateSQL which is of type
	 * {@link String }.
	 */
	private String accountUpdateSQL;

	/**
	 * This constructor is used with injected {@link DataSource} instance to setup the
	 * named parameterized Query in {@link String} type, for update Balances operation and
	 * setup the {@link NamedParameterJdbcTemplate} instance for updating account details.
	 *
	 * @param dataSource : {@link DataSource}
	 */
	public LienNotificationRepositoryImpl(DataSource dataSource) {
		this.accountUpdateJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
		this.accountUpdateSQL = "UPDATE T_ACCT SET"
				+ " ACCT_AVLBL_BAL = CASE WHEN (BAL_ASOFDATETIME is NULL OR BAL_ASOFDATETIME <= :VENDR_LST_UPDT_DTTM) THEN :ACCT_AVLBL_BAL ELSE ACCT_AVLBL_BAL END,"
				+ " ACCT_LDGR_BAL = CASE WHEN (BAL_ASOFDATETIME is NULL OR BAL_ASOFDATETIME <= :VENDR_LST_UPDT_DTTM) THEN :ACCT_LDGR_BAL ELSE ACCT_LDGR_BAL END,"
				+ " BAL_ASOFDATETIME = CASE WHEN (BAL_ASOFDATETIME is NULL OR BAL_ASOFDATETIME <= :VENDR_LST_UPDT_DTTM) THEN :VENDR_LST_UPDT_DTTM ELSE BAL_ASOFDATETIME END,"
				+ " ACCT_LDGR_CRRNCY = CASE WHEN (BAL_ASOFDATETIME is NULL OR BAL_ASOFDATETIME <= :VENDR_LST_UPDT_DTTM) THEN :ACCT_LDGR_CRRNCY ELSE ACCT_LDGR_CRRNCY END,"
				+ " ACCT_AVALBL_CRRNCY = CASE WHEN (BAL_ASOFDATETIME is NULL OR BAL_ASOFDATETIME <= :VENDR_LST_UPDT_DTTM) THEN :ACCT_AVALBL_CRRNCY ELSE ACCT_AVALBL_CRRNCY END,"
				+ " IS_BAL_SYNC = CASE WHEN (BAL_ASOFDATETIME is NULL OR BAL_ASOFDATETIME <= :VENDR_LST_UPDT_DTTM) THEN :IS_BAL_SYNC ELSE IS_BAL_SYNC END,"
				+ " LST_UPDT_SYS_ID = :LST_UPDT_SYS_ID, LST_UPDT_DTTM = :LST_UPDT_DTTM"
				+ " WHERE ACCT_NO = :ACCT_NO";
	}

	/**
	 * This method is used to update account details, coming from Lien Notification batch,
	 * into TDS DB.
	 * @param lienNotifications : {@link List} &lt; {@link LienNotification} &gt;
	 */
	@Override
	@Transactional
	public void updateAccountDetails(List<? extends LienNotification> lienNotifications) {
		LOGGER.info("Initated batch update events to DB.");

		List<MapSqlParameterSource> mapSqlParameterSources = buildMapSqlParameterSources(lienNotifications);
		this.accountUpdateJdbcTemplate.batchUpdate(this.accountUpdateSQL,
				mapSqlParameterSources.toArray(new MapSqlParameterSource[mapSqlParameterSources.size()]));
		LOGGER.info("Completed batch update events to DB.");
	}

	/***
	 * This method is used to build {@link List} &lt; {@link MapSqlParameterSource} &gt;
	 * using {@link List} &lt; {@link LienNotification} &gt;
	 * @param lienNotifications : {@link List} &lt; {@link LienNotification} &gt;
	 * @return {@link List} &lt; {@link MapSqlParameterSource} &gt;
	 */
	private List<MapSqlParameterSource> buildMapSqlParameterSources(
			List<? extends LienNotification> lienNotifications) {

		List<MapSqlParameterSource> mapSqlParameterSources = new ArrayList<>();
		for (LienNotification lienNotification : lienNotifications) {
			MapSqlParameterSource parameterSource = new MapSqlParameterSource();
			parameterSource.addValue(ACCT_NO.name(), lienNotification.getAccountNumber())
					.addValue(ACCT_LDGR_BAL.name(), lienNotification.getLedgerBalance())
					.addValue(ACCT_LDGR_CRRNCY.name(), lienNotification.getLedgerBalanceCurrencyCode())
					.addValue(ACCT_AVLBL_BAL.name(), lienNotification.getAvailableBalance())
					.addValue(ACCT_AVALBL_CRRNCY.name(), lienNotification.getAvailableBalanceCurrencyCode())
					.addValue(VENDR_LST_UPDT_DTTM.name(), lienNotification.getRecordGenerationTime())
					.addValue(IS_BAL_SYNC.name(), "Y")
					.addValue(LST_UPDT_SYS_ID.name(), "BATCH")
					.addValue(LST_UPDT_DTTM.name(), new Date());
			mapSqlParameterSources.add(parameterSource);

		}

		return mapSqlParameterSources;
	}

}
