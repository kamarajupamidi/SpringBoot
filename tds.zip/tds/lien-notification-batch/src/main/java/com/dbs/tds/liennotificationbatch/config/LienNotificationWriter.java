package com.dbs.tds.liennotificationbatch.config;

import java.util.List;

import com.dbs.tds.dto.LienNotification;
import com.dbs.tds.liennotificationbatch.repository.LienNotificationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

/**
 * This class will act as a Writer and is used to move lien notification details to
 * repository which takes care of inserting or updating data into TDS data base
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 */
@Component
public class LienNotificationWriter implements ItemWriter<LienNotification> {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(LienNotificationWriter.class);

	/**
	 * This field is used to store instance of type {@link LienNotificationRepository }.
	 */
	private LienNotificationRepository lienNotificationRepository;

	/***
	 * This constructor will help in building the instance of
	 * {@link LienNotificationRepository} which will help in interacting with TDS DB for
	 * storing the lien notification details.
	 * @param lienNotificationRepository : {@link LienNotificationRepository}
	 *
	 */
	public LienNotificationWriter(LienNotificationRepository lienNotificationRepository) {
		this.lienNotificationRepository = lienNotificationRepository;
	}

	/**
	 * This method is used to call methods of {@link LienNotificationRepository} update
	 * details, coming from Finacle online Event Queue Notification, into TDS DB.
	 * @param lienNotifications : {@link List}
	 * @throws Exception {@link Exception}
	 */
	@Override
	public void write(List<? extends LienNotification> lienNotifications) throws Exception {

		LOGGER.info("Started writing batch events to db");

		this.lienNotificationRepository.updateAccountDetails(lienNotifications);

		LOGGER.info("Completed writing batch events to db");

	}

}
