package com.dbs.tds.liennotificationbatch.config;

import java.io.File;

import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.integration.launch.JobLaunchingMessageHandler;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.file.Files;
import org.springframework.integration.file.support.FileExistsMode;
import org.springframework.integration.handler.LoggingHandler;
import org.springframework.messaging.MessageChannel;

/**
 * This class is used as the configuration class which configure the behavior and working
 * of the rest Service which will receive the message for batch trigger and process the
 * message accordingly and trigger the batch process.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Configuration
public class LienIntegrationConfiguration {

	/**
	 * This method is used to return the message channel for message which is coming.
	 *
	 * @return {@link MessageChannel}
	 */
	@Bean
	public MessageChannel lienNotificationBatchFileInputChannel() {
		return new DirectChannel();
	}

	/**
	 * This method is used to configure the job launcher which will connect to the job
	 * repository and return the instance of the job launcher which will launch the batch
	 * job for processing of the batch file.
	 *
	 * @param lienNotificationBatchJobRepository : {@link JobRepository}
	 * @return {@link JobLauncher}
	 */
	@Bean
	public JobLauncher asyncLienNotificationBatchJobLauncher(JobRepository lienNotificationBatchJobRepository) {
		SimpleJobLauncher lienNotificationBatchJobLauncher = new SimpleJobLauncher();
		lienNotificationBatchJobLauncher.setJobRepository(lienNotificationBatchJobRepository);
		lienNotificationBatchJobLauncher.setTaskExecutor(new SimpleAsyncTaskExecutor());
		return lienNotificationBatchJobLauncher;
	}

	/**
	 * This method is used to launch the batch job with the help of the Job Launcher. It
	 * provides a service which will put the message on the job channel to launch the
	 * batch job.
	 *
	 * @param asyncLienNotificationBatchJobLauncher : {@link JobLauncher}
	 * @return {@link JobLaunchingMessageHandler}
	 */
	@Bean
	@ServiceActivator(inputChannel = "jobChannel", outputChannel = "nullChannel")
	protected JobLaunchingMessageHandler launcher(
			@Qualifier("asyncLienNotificationBatchJobLauncher") JobLauncher asyncLienNotificationBatchJobLauncher) {

		return new JobLaunchingMessageHandler(asyncLienNotificationBatchJobLauncher);
	}

	/**
	 * This method is used to define the flow of the message channel which will be invoked
	 * whenever there is a message put on Job Channel. This method will transform the
	 * incoming message and put the message to Job Channel for triggering the batch job.
	 *
	 * @param lienNotificationBatchFileMessageToJobRequestTransformer :
	 * {@link FileMessageToJobRequestTransformer}
	 * @return {@link IntegrationFlow}
	 */
	@Bean
	public IntegrationFlow processFileFlow(
			FileMessageToJobRequestTransformer lienNotificationBatchFileMessageToJobRequestTransformer) {
		return IntegrationFlows.from(lienNotificationBatchFileInputChannel())
				.transform(lienNotificationBatchFileMessageToJobRequestTransformer)
				.channel("jobChannel")
				.get();
	}

	/**
	 * This method is used to define the flow of the error channel which will be invoked
	 * whenever there is an error during the processing of the incoming message batch
	 * trigger.
	 *
	 * @return {@link IntegrationFlow}
	 */
	@Bean
	public IntegrationFlow errorFlow() {
		return IntegrationFlows.from("errorChannel").handle(new LoggingHandler("ERROR")).get();
	}

	/**
	 * This method is used to define the output flow of the message channel which will be
	 * invoked whenever there is a message put on file error Channel. This method will
	 * create a new file in error folder (if not exist), and append the error message to
	 * that error file.
	 *
	 * @param lienNotificationBatchFilePath : {@link String}
	 * @return {@link IntegrationFlow}
	 */
	@Bean
	public IntegrationFlow fileOutputFlow(
			@Value("${file.outbound.error.path}") String lienNotificationBatchFilePath) {
		return IntegrationFlows.from(lienNotificationBatchFileParseErrorChannel())
				.handle(Files.outboundAdapter(new File(lienNotificationBatchFilePath)).autoCreateDirectory(true)
						.appendNewLine(true)
						.fileExistsMode(FileExistsMode.APPEND))
				.get();
	}

	/**
	 * This method is used to return the Message Channel for Error message Flow.
	 *
	 * @return {@link MessageChannel}
	 */
	@Bean
	public MessageChannel lienNotificationBatchFileParseErrorChannel() {
		return new DirectChannel();
	}
}
