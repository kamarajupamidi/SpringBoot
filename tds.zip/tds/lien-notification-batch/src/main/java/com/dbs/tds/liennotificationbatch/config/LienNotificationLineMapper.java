package com.dbs.tds.liennotificationbatch.config;

import com.dbs.tds.dto.LienNotification;

import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.stereotype.Component;

/**
 * This class is used to map each record from the batch file to the Java POJO instance, so
 * that the records can be processed.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Component
public class LienNotificationLineMapper implements LineMapper<LienNotification> {

	/**
	 * This field is used to store value for tokenizer which is of type
	 * {@link LineTokenizer }.
	 */
	private LineTokenizer tokenizer;

	/**
	 * This field is used to store value for fieldSetMapper which is of type
	 * {@link FieldSetMapper }<{@link LienNotification}>.
	 */
	private FieldSetMapper<LienNotification> fieldSetMapper;

	/**
	 * This constructor is used along with an injected fieldSetMapper to set up the
	 * default instances for tokenizer and mapper.
	 *
	 * @param fieldSetMapper {@link LienNotificationFieldSetMapper}
	 */
	public LienNotificationLineMapper(LienNotificationFieldSetMapper fieldSetMapper) {
		this.tokenizer = new DelimitedLineTokenizer("|");
		this.fieldSetMapper = fieldSetMapper;
	}

	/**
	 * This method is used to map each record present in a batch file to an instance of
	 * {@link LienNotification}.
	 *
	 * @param line : {@link String}
	 * @param lineNumber : {@link Integer}
	 * @return {@link LienNotification}
	 *
	 * @throws Exception {@link Exception}
	 */
	@Override
	public LienNotification mapLine(String line, int lineNumber) throws Exception {
		if (line != null && line.startsWith("T")) {
			return null;
		}
		LienNotification lienNotification = this.fieldSetMapper
				.mapFieldSet(this.tokenizer.tokenize(line));
		lienNotification.setInputLine(line);
		return lienNotification;
	}
}
