package com.dbs.tds.liennotificationbatch.config;

import com.dbs.tds.batch.core.util.FileInputData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.integration.launch.JobLaunchRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.annotation.Transformer;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

/**
 * This class is used to transform the incoming request for batch trigger.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 */
@Component
public class FileMessageToJobRequestTransformer {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(FileMessageToJobRequestTransformer.class);

	/**
	 * This field is used to store value for lienNotificationBatchJob which is of type
	 * {@link Job }.
	 */
	private Job lienNotificationBatchJob;

	/**
	 * This field is used to store value for lienNotificationBatchFileParameterName which
	 * is of type {@link String }.
	 */
	@Value("${liennotification.batch.file.parameter.name}")
	private String lienNotificationBatchFileParameterName;

	/**
	 * This field is used to store value for lienNotificationBatchFileAbsolutePath which
	 * is of type {@link String }.
	 */
	@Value("${liennotification.batch.file.parameter.absolutepath}")
	private String lienNotificationBatchFileAbsolutePath;

	/**
	 * This constructor is used with injected {@link Job} instance to setup the batch
	 * lienNotificationBatchJob which will process the batch file.
	 *
	 * @param lienNotificationBatchJob : {@link Job}
	 */
	public FileMessageToJobRequestTransformer(Job lienNotificationBatchJob) {
		this.lienNotificationBatchJob = lienNotificationBatchJob;
	}

	/**
	 * This method is used to transform the incoming message into the request for
	 * lienNotificationBatchJob. This lienNotificationBatchJob launch request will launch
	 * the batch lienNotificationBatchJob for processing of the batch file.
	 *
	 * @param lienNotificationBatchJobMessage : {@link Message} &lt; {@link FileInputData}
	 * &gt;
	 * @return {@link JobLaunchRequest}
	 */
	@Transformer
	public JobLaunchRequest toRequest(Message<FileInputData> lienNotificationBatchJobMessage) {
		JobParametersBuilder lienNotificationBatchJobParamBuilder = new JobParametersBuilder();
		lienNotificationBatchJobParamBuilder.addString(this.lienNotificationBatchFileAbsolutePath,
				lienNotificationBatchJobMessage.getPayload().getAbsolutePath());
		lienNotificationBatchJobParamBuilder.addString(this.lienNotificationBatchFileParameterName,
				lienNotificationBatchJobMessage.getPayload().getFileName());

		LOGGER.info(
				"Job parameteres to launch the lienNotificationBatchJob lienNotificationBatchFileAbsolutePath={},lienNotificationBatchFileParameterName={}",
				lienNotificationBatchJobMessage.getPayload().getAbsolutePath(),
				lienNotificationBatchJobMessage.getPayload().getFileName());

		return new JobLaunchRequest(this.lienNotificationBatchJob,
				lienNotificationBatchJobParamBuilder.toJobParameters());
	}
}
