package com.dbs.tds.liennotificationbatch;

import com.dbs.tds.config.BatchCoreConfiguration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

@SpringBootApplication
@Import(BatchCoreConfiguration.class)
public class LienNotificationBatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(LienNotificationBatchApplication.class, args);
	}
}
