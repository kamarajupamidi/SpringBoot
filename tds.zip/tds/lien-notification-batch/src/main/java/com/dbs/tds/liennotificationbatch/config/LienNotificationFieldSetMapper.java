package com.dbs.tds.liennotificationbatch.config;

import com.dbs.tds.dto.LienNotification;
import com.dbs.tds.util.DateTimeFormat;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindException;

/**
 * This class is used to map each record from the batch file to the Java POJO instance, so
 * that the records can be processed and DTO instance is created for DAO interaction.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 *
 */
@Component
public class LienNotificationFieldSetMapper implements FieldSetMapper<LienNotification> {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(LienNotificationFieldSetMapper.class);

	/**
	 * This method is used to map one record which is parsed from a line in the batch file
	 * to an instance of {@link LienNotification} so that this instance can be transfered
	 * to DAO layer for DB interaction.
	 *
	 * @param fieldSet : {@link FieldSet}
	 * @return {@link LienNotification}
	 *
	 * @throws BindException {@link BindException}
	 */
	@Override
	public LienNotification mapFieldSet(FieldSet fieldSet) throws BindException {

		LOGGER.info("Lien Notification field Mapping started");

		LienNotification lienNotification = new LienNotification();
		lienNotification.setAccountNumber(fieldSet.readString(0));
		lienNotification
				.setAvailableBalance(StringUtils.isNotBlank(fieldSet.readString(4)) ? fieldSet.readDouble(4) : null);
		lienNotification
				.setLedgerBalance(StringUtils.isNotBlank(fieldSet.readString(5)) ? fieldSet.readDouble(5) : null);
		lienNotification.setAvailableBalanceCurrencyCode(fieldSet.readString(6));
		lienNotification.setLedgerBalanceCurrencyCode(fieldSet.readString(6));
		lienNotification.setRecordGenerationTime(StringUtils.isNotBlank(fieldSet.readString(9))
				? fieldSet.readDate(9, DateTimeFormat.DATE_TIME_ISO.pattern())
				: null);

		LOGGER.info("Lien Notification field Mapping end");

		return lienNotification;
	}

}
