package com.dbs.tds.liennotificationbatch.config;

import com.dbs.tds.dto.LienNotification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.core.annotation.OnReadError;
import org.springframework.batch.core.annotation.OnSkipInWrite;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.file.FileHeaders;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.MessageChannel;
import org.springframework.stereotype.Component;

/**
 * This class is used as configuration and instance for chunk processing of the lien batch
 * file, which is coming from Finacle. Records will be read and processed in chunks and
 * only after one chunk is processed then the control moves to next chunk. If the error
 * occurs while processing then that chunk is skipped and control moves to next chunk.
 *
 * @author DBS Asia Hub 2
 * @version 1.0
 */
@StepScope
@Component
public class LienNotificationChunkListener {

	/**
	 * This field is used to store value for LOGGER which is of type {@link Logger }.
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(LienNotificationChunkListener.class);

	/**
	 * This field is used to store value for filePath which is of type {@link String }.
	 */
	@Value("#{jobParameters['fileName']}")
	private String filePath;

	/**
	 * This field is used to store value for fileParseErrorChannel which is of type
	 * {@link MessageChannel }.
	 */
	private MessageChannel lienNotificationBatchFileParseErrorChannel;

	/**
	 * This constructor is used with injected instance of {@link MessageChannel} which
	 * will be used to receive the message when there is any error during the processing
	 * of the batch file chunk.
	 *
	 * @param lienNotificationBatchFileParseErrorChannel : {@link MessageChannel}
	 */
	public LienNotificationChunkListener(MessageChannel lienNotificationBatchFileParseErrorChannel) {
		this.lienNotificationBatchFileParseErrorChannel = lienNotificationBatchFileParseErrorChannel;
	}

	/**
	 * This method will be executed whenever any specific chunk is skipped due to any
	 * error during the processing of the chunk. Skipped chunk will be written in the
	 * logs.
	 *
	 * @param exception : {@link Exception}
	 */
	@OnReadError
	public void onReadError(Exception exception) {
		if (exception instanceof FlatFileParseException) {
			FlatFileParseException ffpe = (FlatFileParseException) exception;

			LOGGER.error("Error reading data on filePath={}, line={}, data={}", this.filePath, ffpe.getLineNumber(),
					ffpe.getInput());

			this.lienNotificationBatchFileParseErrorChannel.send(
					MessageBuilder.withPayload(ffpe.getInput()).setHeader(FileHeaders.FILENAME, this.filePath).build());
		}
	}

	/**
	 *
	 * This method will be executed whenever any specific chunk is skipped due to any
	 * error during the processing of the chunk. Skipped chunk will be written in the
	 * logs.
	 * @param lienNotification : {@link LienNotification}
	 * @param throwable {@link Throwable}
	 */
	@OnSkipInWrite
	public void onSkipInWrite(LienNotification lienNotification, Throwable throwable) {
		LOGGER.error("Error writing data={} because of exception.", lienNotification.getInputLine(), throwable);
		this.lienNotificationBatchFileParseErrorChannel.send(
				MessageBuilder.withPayload(lienNotification.getInputLine())
				.setHeader(FileHeaders.FILENAME, this.filePath).build());
	}
}
