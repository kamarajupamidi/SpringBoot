package com.dbs.iwf.config;

import javax.jms.MessageListener;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.listener.SimpleMessageListenerContainer;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.dbs.iwf.listener.PrintListener;
import com.ibm.mq.jms.MQQueueConnectionFactory;
import com.ibm.mq.jms.MQTopicConnectionFactory;
import com.ibm.msg.client.wmq.WMQConstants;

@Profile({ "DEV", "SIT", "UAT" })
@SuppressWarnings("all")
@Configuration
public class JmsConfig2 {
	
	@Value("${iwf.mq.host}")
	private String host;
	@Value("${iwf.mq.port}")
	private Integer port;
	@Value("${iwf.mq.queue-manager}")
	private String queueManager;
	@Value("${iwf.mq.channel}")
	private String channel;
	@Value("${iwf.mq.queue}")
	private String queue;
	@Value("${iwf.mq.topic}")
	private String topic;
	@Value("${iwf.mq.timeout}")
	private long timeout;
	
	@Bean
	public MQTopicConnectionFactory mqTopicConnectionFactory() {
		MQTopicConnectionFactory mqTopicConnectionFactory = new MQTopicConnectionFactory();
		try {	
			mqTopicConnectionFactory.setHostName(host);
			mqTopicConnectionFactory.setQueueManager(queueManager);
			mqTopicConnectionFactory.setPort(port);
			mqTopicConnectionFactory.setChannel(channel);
			mqTopicConnectionFactory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
			mqTopicConnectionFactory.setCCSID(1208);					
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mqTopicConnectionFactory;
	}
	
	@Bean
	@Primary
	public MQQueueConnectionFactory mqQueueConnectionFactory() {
		MQQueueConnectionFactory mqQueueConnectionFactory = new MQQueueConnectionFactory();
		try {	
			mqQueueConnectionFactory.setHostName(host);
			mqQueueConnectionFactory.setQueueManager(queueManager);
			mqQueueConnectionFactory.setPort(port);
			mqQueueConnectionFactory.setChannel(channel);
			mqQueueConnectionFactory.setAppName(System.getProperty("user.name"));
			mqQueueConnectionFactory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
			mqQueueConnectionFactory.setCCSID(1208);					
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mqQueueConnectionFactory;
	}
	
	@Bean
	public SimpleMessageListenerContainer queueContainer(MQQueueConnectionFactory mqQueueConnectionFactory) {
		MessageListener listener = new PrintListener();
		SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
		container.setConnectionFactory(mqQueueConnectionFactory);
		container.setDestinationName(queue);
		container.setMessageListener(listener);
		container.start();
		return container;
	}	
	
	@Bean
	public SimpleMessageListenerContainer topicContainer(MQTopicConnectionFactory mqTopicConnectionFactory) {
		MessageListener listener = new PrintListener();
		SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
		container.setConnectionFactory(mqTopicConnectionFactory);
		container.setDestinationName(topic);
		container.setPubSubDomain(true);
		container.setMessageListener(listener);
		container.start();
		return container;
	}
	
	@Bean
	public JmsTemplate queueTemplate(MQQueueConnectionFactory mqQueueConnectionFactory) {
		JmsTemplate jmsTemplate = new JmsTemplate(mqQueueConnectionFactory);
		jmsTemplate.setReceiveTimeout(timeout);
		return jmsTemplate;
	}
	
	@Bean
	public JmsTemplate topicTemplate(MQTopicConnectionFactory mqTopiceConnectionFactory) {
		JmsTemplate jmsTemplate = new JmsTemplate(mqTopiceConnectionFactory);
		jmsTemplate.setPubSubDomain(true);
		jmsTemplate.setReceiveTimeout(timeout);
		return jmsTemplate;
	}
}
